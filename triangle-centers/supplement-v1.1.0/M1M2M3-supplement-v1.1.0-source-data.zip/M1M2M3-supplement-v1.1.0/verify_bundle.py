"""Verify the fixed release before running programs that regenerate outputs."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "manifest-sha256.json").read_text(encoding="utf-8"))
bad = []
for entry in manifest["files"]:
    p = ROOT / entry["path"]
    if not p.is_file():
        bad.append(f"missing: {entry['path']}")
    elif p.stat().st_size != entry["bytes"] or hashlib.sha256(p.read_bytes()).hexdigest() != entry["sha256"]:
        bad.append(f"changed: {entry['path']}")
if bad:
    raise SystemExit("\n".join(bad))
print(f"Verified {len(manifest['files'])} files for version {manifest['version']}.")
