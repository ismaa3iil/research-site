"""Run revised checks in an extracted WORKING COPY; no network required."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--wolframscript", default=shutil.which("wolframscript"))
p.add_argument("--rebuild-caches", action="store_true", help="Rebuild platform-dependent MX files from readable data first")
p.add_argument("--audit-data", action="store_true", help="Additionally recheck all 72807 source-cache entries")
p.add_argument("--figure", action="store_true", help="Regenerate the vector branch figure")
args = p.parse_args()
if not args.wolframscript:
    p.error("Provide --wolframscript with your licensed Wolfram executable")
env = os.environ.copy()
env["LEJEAN_KIMBERLING_ROOT"] = str(ROOT / "data/LeJean-Kimberling")
logs = ROOT / "verification_logs"
logs.mkdir(exist_ok=True)

def run(script, wolfram=True):
    command = ([args.wolframscript,"-file",str(ROOT/script)] if wolfram
               else [sys.executable,str(ROOT/script)])
    print(f"Running {script} ...",flush=True)
    with (logs / (script+".log")).open("w",encoding="utf-8") as f:
        result = subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit(f"Failed ({result.returncode}): see {logs / (script+'.log')}")

if args.rebuild_caches:
    run("rebuild_readable_caches.wls")
run("m1m2m3_algebraic_revision_checks.wls")
run("m1m2m3_referee_exact_checks.wls")
if args.audit_data:
    run("m1m2m3_revision_audit.wls")
run("m1m2m3_revision_validate.wls")
run("m1m2m3_coverage_correction.py",False)
run("m1m2m3_final_status.py",False)
if args.figure:
    run("m1m2m3_branch_figure.wls")

data = ROOT / "output/m1m2m3"
exact = json.loads((data/"algebraic_revision/algebraic_revision_checks.json").read_text())
assert exact["allChecksTrue"] is True
assert len(exact["constantFamilyChecks"]) == 9
assert all(r["exactFormulaMatch"] for r in exact["constantFamilyChecks"])
assert all(r["orientationSign_4_6_7"] == -1 and
           r["orientationSign_100000_100001_100002"] == 1 for r in exact["orientationRows"])
assert json.loads((data/"referee_revision/x795_exact_check.json").read_text())["circumcircleSubstitutionIsExactZero"] is True
manifest = json.loads((data/"revision_20260907/validation_manifest.json").read_text())
assert manifest["comparisonCount"] == 15352 and manifest["baselineSurvivors"] == 41
correction = json.loads((data/"revision_20260907/coverage_correction.json").read_text())
assert correction["additional_strip_exclusions"] == 6000
assert correction["additional_diagonal_exclusions"] == 8
summary = json.loads((data/"revision_20260907/final_status_summary.json").read_text())
assert summary["retained"] == 32 and summary["unresolved"] == 10
print("Verified: exact identities; nine branch exclusions; 15352 comparisons; corrected coverage; 32 retained rows.")
print("Generated timestamps and numeric last digits may differ. Historical discovery was not rerun.")
