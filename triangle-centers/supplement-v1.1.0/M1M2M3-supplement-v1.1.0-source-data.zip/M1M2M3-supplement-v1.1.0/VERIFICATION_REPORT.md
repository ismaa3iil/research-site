# Release verification, 7 September 2026

The package was extracted to a separate directory containing spaces. Its verification entry point selected only the bundled data, not the original external ETC folder. Wolfram 15.0.0 for 64-bit Windows and Python standard-library programs were used.

## Executed checks

- The untouched release manifest verified successfully.
- All four MX caches were rebuilt from the readable Wolfram associations before testing. This checks the usable completeness of the readable snapshot, not just the original binary caches.
- All principal exact polynomial checks returned true. All nine constant-family identifications matched exactly; each has negative relative circumcevian orientation at (4,6,7) and positive orientation at (100000,100001,100002).
- The X795 circumcircle substitution returned exact zero.
- Fresh validation performed 15352 comparisons: 11194 passed, 2181 failed, 1976 source-unavailable and one target-unavailable. There were 41 baseline survivors, and no final insufficient-accuracy records. The numerical evaluation loop took approximately 24 seconds, excluding process startup and data/cache rebuilding.
- The coverage correction reproduced 6000 additional acute strip and eight diagonal exclusions, without changing the discovery candidate union.
- The regenerated final-status CSV is byte-identical to the distributed CSV: 32 retained rows, comprising 20 proved in the article, two further classical relations and ten unresolved candidates.
- The article compiled in the separate extracted directory to 15 pages, with no final LaTeX warnings, unresolved references, overfull boxes or underfull boxes.
- All 15 pages of the release PDF were rendered and visually inspected. Figure-label spacing and mathematical legend notation were corrected and the affected pages rechecked.

The corresponding process logs are in `verification/`. Timestamps and final floating-point digits are not required to reproduce byte-for-byte. No expensive full-discovery rerun was made during this verification, and the numerical checks do not certify the ten candidates as identities. This is a relocation/readable-data test of the same implementation, not an independent software verification or a cross-platform test.
