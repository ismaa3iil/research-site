# Attribution and rights

The ETC definitions originate with Clark Kimberling and the contributors credited in the Encyclopedia of Triangle Centers, https://faculty.evansville.edu/ck6/encyclopedia/. Individual centers' ETC entries remain the appropriate mathematical source attribution.

The Wolfram support library and database infrastructure derive from the LeJean-Kimberling project, upstream https://github.com/lejean2000/Kimberling. Its public-domain dedication is copied verbatim to data/LeJean-Kimberling/LICENSE. The bundled local snapshot and library may include local extensions; this release is fixed by its SHA-256 manifest, not represented as a pristine upstream git release. No other files from the user's computer are required.

The author's article, revisions and original supplementary code are supplied for this research package; this release does not impose a new open-source or Creative Commons license on them. Rights are retained by the respective rights holders. The upstream software license is not represented as a blanket relicensing of third-party web material. A deposit license and any journal-specific permissions should be selected by the author before permanent public archiving.

Wolfram software itself is not included. Readers need their own appropriately licensed installation. Python helper scripts depend only on the Python standard library.
