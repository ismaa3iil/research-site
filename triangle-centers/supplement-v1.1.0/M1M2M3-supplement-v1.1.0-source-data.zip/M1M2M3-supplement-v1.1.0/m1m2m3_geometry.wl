(* Dimensionless Cartesian audit, independent of discovery caches. *)
ClearAll[mCross,mSides,mPoint,mCircumcenter,mDerived,mCenter,mTest];
(* The supplied library truncated polynomial roots to 50 digits.  Preserve
   the input precision and the same ordered-real-root selection instead. *)
Clear[etcPolynomialRealRoots];
etcPolynomialRealRoots[coefficients_List] /; VectorQ[coefficients,NumericQ] := Module[{z,pr,wp,roots},
 pr=Min[Precision /@ coefficients];
 wp=If[pr===Infinity,$mAuditPrecision,Min[$mAuditPrecision,Max[20,Floor[pr]-5]]];
 roots=z/.Quiet@NSolve[Sum[coefficients[[j+1]]z^j,{j,0,Length[coefficients]-1}]==0,z,Reals,WorkingPrecision->wp];
 Sort[Re[roots]]];
mCross[u_,v_] := Det[{u,v}];
mSides[v_] := Sqrt[Total[#^2]]& /@ {v[[2]]-v[[3]],v[[3]]-v[[1]],v[[1]]-v[[2]]};
mPoint[v_] := ListQ[v] && Length[v]==2 && VectorQ[v,NumericQ] && FreeQ[v,Indeterminate|DirectedInfinity|ComplexInfinity];
mCircumcenter[v_] := Quiet@Check[LinearSolve[2{v[[2]]-v[[1]],v[[3]]-v[[1]]},
 {v[[2]].v[[2]]-v[[1]].v[[1]],v[[3]].v[[3]]-v[[1]].v[[1]]}],$Failed];
mDerived[k_,p_,v_,tol_] := Module[{o,d,tri,den,scale},
 o=If[k==2,mCircumcenter[v],{}];If[o===$Failed,Return[$Failed]];
 tri=Table[Switch[k,
 1,With[{u=v[[i]],b0=v[[Mod[i,3]+1]],c0=v[[Mod[i+1,3]+1]]},
   d=p-u;den=mCross[d,c0-b0];
   If[Abs[den]<=tol Norm[d]Norm[c0-b0],Return[$Failed,Module]];
   u+d mCross[b0-u,c0-b0]/den],
 2,d=p-v[[i]];den=d.d;
   If[Abs[den]<=tol,Return[$Failed,Module]];
   v[[i]]-2((v[[i]]-o).d)/den d,
 3,With[{u=v[[Mod[i,3]+1]],w=v[[Mod[i+1,3]+1]]},
   d=w-u;u+((p-u).d)/(d.d)d]],{i,3}];
 If[!AllTrue[tri,mPoint],Return[$Failed]];
 scale=Max[mSides[tri]];
 If[!TrueQ[scale>0]||Abs[mCross[tri[[2]]-tri[[1]],tri[[3]]-tri[[1]]]]<=tol scale^2,$Failed,tri]];
mCenter[formula_,v_,wp_] := Module[{q,qn,qt,tol=10^-60},
 q=Quiet@Check[TimeConstrained[N[formula/.Thread[{a,b,c}->mSides[v]],wp],30.,$Failed],$Failed];
 If[!ListQ[q]||Length[q]!=3||!VectorQ[q,NumericQ]||!FreeQ[q,Indeterminate|DirectedInfinity|ComplexInfinity],Return[$Failed]];
 qn=Norm[q];If[!TrueQ[qn>0]||!TrueQ[Norm[Im[q]]/qn<10^-60],Return[$Failed]];
 q=Re[q]/qn;qt=Total[q];If[!TrueQ[Abs[qt]>tol],Return[$Failed]];
 (q/qt).v];
mTest[key_,sides_,formulas_,wp_:100] := Block[{$mAuditPrecision=wp},mTestInternal[key,sides,formulas,wp]];
mTestInternal[key_,sides_,formulas_,wp_] := Module[{s=N[sides/Total[sides],wp],x,y,v,p,tri,target,err,acc,stat},
 x=(s[[3]]^2+s[[1]]^2-s[[2]]^2)/(2s[[1]]);y=Sqrt[s[[3]]^2-x^2];
 v={{x,y},{0,0},{s[[1]],0}};
 p=mCenter[formulas[key[[2]]],v,wp];If[p===$Failed,Return[{"source-unavailable","",0}]];
 tri=mDerived[key[[1]],p,v,10^-60];If[tri===$Failed,Return[{"derived-unavailable","",0}]];
 target=mCenter[formulas[key[[3]]],tri,wp];If[target===$Failed,Return[{"target-unavailable","",0}]];
 err=Norm[p-target];acc=Accuracy[err];
 stat=Which[!TrueQ[acc>=50],"insufficient-accuracy",TrueQ[err<10^-40],"passed",True,"failed"];
 {stat,ToString[err,InputForm],If[acc===Infinity,"Infinity",N[acc,8]]}];
