# Referee report: M1M2M3

Reviewed on 7 September 2026. Manuscript: `M1M2M3.tex`, dated August 2026, titled *Triangle Centers Relative to Their Cevian, Circumcevian, and Pedal Triangles*.

**Recommendation: major revision, with encouragement to resubmit.** The paper has a worthwhile mathematical core. Its present weaknesses are specific and repairable, but they affect theorem formulation, numerical coverage, and the classification of unresolved results. This is not merely a request for stylistic revision.

## Scope of this review

I read the complete LaTeX source, the algebraic verification program and its JSON report, the discovery/aggregation/validation programs, the six-shape and additional-shape result files, and the earlier supplied revision notes. I checked the cited Stothers pages and the relevant official ETC entries. I ran new symbolic and exact-coordinate diagnostics, compared the historical and current formula caches through index 53700, and checked an identified source-evaluation defect against the local ETC data.

I did not rerun the approximately 434 million off-diagonal comparisons per discovery seed, and this is not a visual review of the PDF layout. The manuscript and published site have not been changed by this review. Diagnostic scripts are in `tmp/referee_20260907_checks.wls`, `tmp/referee_20260907_cache_audit.wls`, and `tmp/referee_20260907_followup.wls`.

The PDF reviewed by association with this source has SHA-256 `0F86A9BE1CD079C4B8F738CC45CB608E1C7872E2C8FEF7DAC321A8B470ED16DA`; the LaTeX source has SHA-256 `D24B8823E6070E3AA6BEB0A9C881AF7A6801C87CF446A7439DBE6D4CEA90A9ED`.

## 1. Merits and publishable contribution

The change-of-reference question is clear and interesting. Distinguishing a reclassification of the same Euclidean point from an ordinary point map is useful. The classical transfer theorem provides a coherent framework, the Steiner-focus proof is short and attractive, and the manuscript appropriately warns that repeated numerical agreement is not a universal identity.

The strongest material is the explicit parameter law, its interpretation on standard ETC branches, and the symmetric-polynomial mechanism for X67371. I independently verified the polynomial identities

\[
U(kA+n,kB+n,kC+n)=k^3U(A,B,C),
\]
\[
W(kA+n,kB+n,kC+n)=k^3(kW+nU).
\]

I also verified the family Heron identity, the sum of the source barycentrics, and the circumcircle-power factorization below. These checks support the core mechanism; they do not substitute for stating its domain correctly.

The paper should be positioned as an explicit branch refinement and structural application of established circumcevian theory, accompanied by a computational census. A broad historical claim that the family or transfer itself is new would be inappropriate. The present previous-theory section is a substantial improvement in this respect.

## 2. Required mathematical correction: the orientation convention

Section 4 defines H as the positive Heron radical, and defines the oriented radical of a triangle UVW as twice its Cartesian determinant. It then states

\[
F_\lambda(ABC)=F_{-\lambda}^{\rm or}(\mathcal T_2(F_\lambda(ABC))).
\]

As written, this mixes an orientation-independent source convention with an orientation-dependent target convention. The paper does not require the source ABC to be counterclockwise. The formula fails for a clockwise source under the stated definitions.

Here is an exact check. Take

\[
A=(4,0),\quad B=(0,0),\quad C=(0,3),\quad\lambda=\tfrac12.
\]

The source point is P=(-30,-12). Evaluating the stated oriented target in its circumcevian triangle gives (158/63,12/7), rather than P. Reversing the source order to the counterclockwise order makes the displayed identity hold exactly. All the triangles used in this diagnostic are nondegenerate.

**Repair:** either require a counterclockwise realization at the start of the oriented discussion, or replace the target signed radical by a radical oriented relative to ABC:

\[
\widehat H_T=\operatorname{sgn}(\det(B-A,C-A))\,2\det(V-U,W-U).
\]

Alternatively, use the orientation-independent, positive-Heron formulation in section 3 of this report as the main theorem. The algebraic verification script implicitly implements relative orientation when it multiplies the barycentric determinant by positive H. This explains why its checks pass despite the manuscript's missing convention.

The pedal corollary also needs a sentence establishing compatibility of the orientations of the two derived triangles. Ordinary similarity of side triples alone does not establish a statement involving signed radicals. This is a missing justification, rather than a counterexample to the correctly normalized pedal relation: the corresponding circumcevian and pedal triples have the same orientation sign relative to ABC on their common admissible real domain.

## 3. A stronger and simpler branch theorem is already available

Use the paper's notation A=a², B=b², C=c², S=A+B+C and

\[
Q=(3\lambda^2+1)H-2\lambda S.
\]

Its own distance identity implies

\[
BCH^2q_a=s_A=-(u+v+w)^2PA^2<0
\]

for a finite source distinct from A. Consequently all three q's are negative on the regular real domain. Thus delta is negative and the sign of the relatively oriented derived radical is simply sign(Q). There is no need to leave the reader with the sign of a quotient involving four separate factors.

More geometrically, direct exact reduction gives

\[
t=u+v+w=H(\lambda S-H),
\]
\[
Avw+Bwu+Cuv=ABCHQ.
\]

Therefore the signed circumcircle power is

\[
\Pi_P=-\frac{ABCQ}{H(\lambda S-H)^2}.
\]

For a regular finite source, Q>0 means that P is inside the circumcircle, and Q<0 means that P is outside. The positive-Heron theorem should consequently read

\[
F_\lambda(ABC)=
\begin{cases}
F_{-\lambda}(\mathcal T_2(P)),&Q>0,\\
F_\lambda(\mathcal T_2(P)),&Q<0,
\end{cases}
\qquad P=F_\lambda(ABC),
\]

with the stated generic exceptions, especially 3 lambda²=1, and the nonzero-coordinate/definition conditions wherever they are used. Q=0 is the circumcircle degeneracy boundary. The separate locus lambda S=H concerns a source at infinity or an undefined source formula.

For positive lambda, the branch boundary can be expressed using one familiar shape quantity:

\[
\frac{a^2+b^2+c^2}{4[ABC]}=\frac{3\lambda^2+1}{2\lambda}.
\]

This explains the near-equilateral phenomenon much more directly. The left side has minimum sqrt(3), and the right side approaches this minimum as lambda approaches 1/sqrt(3). The branch component missed by random testing can therefore become very small. This is a natural place for one scientific figure showing the boundary in normalized triangle-shape space.

## 4. Required proof completion at both exceptional parameters

The parameter-reversal theorem excludes both lambda=1/sqrt(3) and lambda=-1/sqrt(3), because its proportionality factor is 3 lambda²-1. The constant-family obstruction, however, treats only the positive exceptional value separately. The negative exceptional value cannot be dispatched by applying the preceding generic theorem.

Both parameters produce equilateral circumcevian triangles on their regular domains. For the positive value, the same positive-Heron center formula on that equilateral target is the zero triple. For the negative value, it is the common center O of that equilateral triangle. Since the circumcevian triangle lies on the original circumcircle, this is the original circumcenter, whereas F_{-1/sqrt(3)} is generally different from O. This supplies the missing separate argument.

More generally, replace expressions such as “usual nondegeneracy and definition qualifications” with a stated admissible domain. Distinguish zero barycentric triples, finite-point normalization failures, points on the circumcircle, source vertices, coincident derived vertices, and exceptional equilateral targets. In the X67371 proof, explain which zeros of U are removable in the polynomial barycentrics and which derived-target failures remain excluded.

## 5. A demonstrated defect in acute discovery

In `m1m2m3_unified_worker.wls`, lines 191–202, a missing acute source in `sourceBaryAssociation` is replaced by `ETCBaryNormFull`. That table contains coordinates for the obtuse discovery triangle (6,9,13). The historical first-500 worker has the same fallback at lines 144–159.

This is not only a hypothetical risk. I checked all 72807 expanded first-coordinate entries individually at the acute seed and found these three examples with an invalid complex acute triple but a finite real cached obtuse triple:

- X10221;
- X66870;
- X66871.

I independently checked that their cached triples agree projectively with their formulas evaluated at (6,9,13). Applying those triples to the vertices of (4,6,7) creates an unrelated Euclidean point. Such comparisons cannot be counted as valid acute ETC comparisons.

These three indices do not occur in the recorded candidate union, and the later high-precision validation recalculates source formulas directly. The evidence does not justify saying that this defect invalidates the 34 retained rows. It does require repairing the fallback and recomputing the affected coverage statistics; other timeout or block-evaluation paths should be checked as well.

**Required remedy:** key every numerical source cache by its triangle and convention. If the acute evaluation is unavailable, preserve that status or retry the formula on the same acute triangle. Do not use another seed's coordinates. Recheck affected diagonal and reverse-strip records, then regenerate the aggregate tables.

I compared the old and new expanded first-coordinate caches through 53700 and found no differing entries. Thus that particular possible cache-version discrepancy was not observed.

## 6. The count of unresolved rows overstates what remains open

The stored results reproduce the stated sequence of 54 six-shape survivors, 41 additional-shape survivors, and 34 after the seven near-equilateral exclusions. However, the mathematical subdivision “15 proved here + 3 classical + 16 unresolved” should not survive another revision.

Three of the alleged unresolved rows have immediate or short proofs:

\[
M_3:X_1\longmapsto X_3,\qquad
M_2:X_1\longmapsto X_4,\qquad
M_1:X_7\longmapsto X_6.
\]

The first says that the incenter is the circumcenter of its contact triangle. The second follows by the paper's transfer theorem, since the circumcenter and orthocenter are isogonal conjugates. For the third, the cevian triangle of the Gergonne point is the contact triangle. Put x=s-a, y=s-b, z=s-c. The source barycentrics are (1/x:1/y:1/z); its coordinates in its cevian triangle are

\[
(1/y+1/z:1/z+1/x:1/x+1/y).
\]

The squared sides of the contact triangle are cyclically

\[
\frac{4x^2yz}{(x+z)(x+y)}.
\]

These two triples are proportional. That is exactly the symmedian-center condition. I checked the resulting projective cross-products symbolically; all three are zero.

There is a fourth consequence of the manuscript's own new theorem. Write R=W/U. Exact comparison with the local ETC formula gives

\[
X_{9181}=F_\mu,\qquad \mu H=\frac{2S}{3}-R.
\]

Since S transforms to kS+3n and R transforms to kR+n under A_i -> kA_i+n, the quantity 2S/3-R also transforms to k(2S/3-R)+n. The same proof used for X67371 therefore proves the X9181 circumcevian fixed relation on its admissible domain. This projective formula identification was checked exactly, not inferred from a numerical coincidence.

After adding these four short arguments, the present 34-row list would have 22 rows mathematically accounted for and 12 still unresolved, subject to the domain and numerical-audit qualifications above. The remaining rows would be:

| Map | Remaining source–target rows |
|---|---|
| M2 diagonal | 368, 3513, 3514, 5467, 17851, 17852, 21906 |
| M2 off-diagonal | 202 -> 34321; 203 -> 34322 |
| M3 off-diagonal | 202 -> 6671; 203 -> 6672; 30335 -> 175 |

Some entries here may also be known or consequences of a common family; this is not a certified list of twelve new open problems. The first two M3 rows are paired with their M2 counterparts, so the twelve rows are not twelve independent questions.

The official ETC entry identifies the isogonal conjugate of X67371 as X54602. Thus the transfer theorem also yields M3:X67371 -> X54602, outside the two off-diagonal strips searched in this manuscript. This is a useful corollary that illustrates why algebraic consequences should be reported independently of the arbitrary census boundary.

## 7. Reproducibility and experimental design

The existing audit files are helpful, but a reader needs a public, versioned supplementary package. The website publication previously made available the article, its PDF and its LaTeX source; that alone is not the full computational supplement. The manuscript itself correctly calls for a permanent archive. Complete that before journal submission.

Provide a manifest with exact source versions, portable entry points, ordered triangles, residuals, failure categories, final status tables, and commands to reproduce the smaller validations without first rerunning discovery. Prefer readable source data alongside platform-dependent MX snapshots, where redistribution is permitted. Several workers and validators still hard-code the author's Windows path; only fixing the algebraic check script does not make the whole pipeline portable.

The 40-shape experiment is independent in its sample, but not in its implementation: it uses substantially the same source library and Cartesian routines as the primary validation. Call it an additional independent sample or an additional-shape validation. A second implementation or exact interval checks would provide stronger independence for the remaining candidates.

Use dimensionless numerical degeneracy checks. In particular, use area divided by a squared length scale, and barycentric sum divided by the norm of the barycentric triple. Absolute thresholds on raw barycentrics depend on an arbitrary homogeneous scaling of the center formula.

Record achieved precision and cancellation, rather than only requested working precision. The output `0.e-46`, for example, is an approximate zero with an accuracy scale; it is not an exact zero. Large failure residuals are strong evidence against an identity, but a rigorous counterexample should ideally include an exact inequality or a certified enclosure excluding zero.

The next experiment should target the identified branch boundaries, near-equilateral and near-isosceles families, near-circumcircle degeneracy, and infinity/definition loci. More random triangles or a larger ETC index bound alone will not address these issues.

## 8. Presentation, attribution, and editorial changes

Keep the current title and the ordering that puts theory before the census. Shorten the abstract: the detailed sequence of 161, 54, 41, 34 and its intermediate failure counts belongs in a compact table in the computational section. Present one final status table assigning each row a proof, a classical reference, a counterexample, or an unresolved status, with its exact domain. The reader should not need to subtract several earlier lists to discover the paper's final conclusions.

Delete “the two nonclassical circumcevian rows” in the paragraph following the Steiner-focus theorem: this conflicts with the section's correct identification of those relations as classical. Stothers supplies the focus characterization/class; cite the ETC separately for the modern labels X39162 and X39163. The cited Stothers page does not itself use those labels.

The Hajja acknowledgement is appropriate and should remain. The AI declaration should state the actual assistance and the author's responsibility accurately. In particular, the author should personally be able to affirm any assertion that every argument, computation and reference was independently verified. The absence of AI coauthorship can be stated plainly without the unnecessary and potentially misleading claim that AI did not help determine conclusions.

The revision priority is: correct the orientation/domain statements; repair and audit the acute cache fallback; replace the unresolved classification; state the inside/outside branch theorem; make the supplement publicly reproducible; then streamline the exposition. A full quadratic ETC search is not needed to make these improvements.

## Primary sources checked

- W. W. Stothers, [The Circumcevian Triangle](https://www.maths.gla.ac.uk/wws/cabripages/triangle/ninepoint/circumcevian1.htm): classical classes, focus relations, isodynamic exception, and parameter family.
- W. W. Stothers, [The Pedal Triangle](https://www.maths.gla.ac.uk/wws/cabripages/triangle/ninepoint/pedal1.htm): circumcevian–pedal transfer theorem.
- C. Kimberling, [ETC X67371](https://faculty.evansville.edu/ck6/encyclopedia/ETCPart34.html#X67371): polynomial barycentrics, Brocard-axis description, and isogonal partner X54602.
- C. Kimberling, [ETC X39162 and X39163](https://faculty.evansville.edu/ck6/encyclopedia/ETCPart20.html#X39162): real Steiner-inellipse focus labels.

These source checks establish relevant prior facts; they do not constitute an exhaustive novelty search for the paper's new results.
