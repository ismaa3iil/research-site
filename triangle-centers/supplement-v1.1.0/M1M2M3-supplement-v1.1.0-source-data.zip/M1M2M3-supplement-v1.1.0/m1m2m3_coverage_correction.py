"""Recompute the source-cache exclusion correction from archived failure logs."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "output" / "m1m2m3"
OUT = ROOT / "revision_20260907"

def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return [{k: v.strip('"') for k, v in r.items()} for r in csv.DictReader(stream)]

audit = json.loads((OUT / "source_cache_audit.json").read_text())
bad = audit["incompatibleAcuteFallbackIndices"]
records = []
for index in bad:
    for kind in ("strip", "diagonal"):
        if kind == "diagonal":
            files = (ROOT / "unified" / "acute_4_6_7").glob("diagonal_shard_*_failures.csv")
            targets = {index}
        elif index <= 53700:
            files = list((ROOT / "offdiagonal_first500" / "acute_4_6_7").glob("pass_b_shard_*_failures.csv"))
            files += list((ROOT / "offdiagonal_501_1000" / "acute_4_6_7").glob("pass_b_shard_*_failures.csv"))
            targets = set(range(1, 1001))
        else:
            files = (ROOT / "unified" / "acute_4_6_7").glob("extension_b_shard_*_failures.csv")
            targets = set(range(1, 1001))
        failures = [r for file in files for r in rows(file) if int(r["source"]) == index]
        for m in (1, 2, 3):
            excluded = set()
            for r in failures:
                if int(r["map"]) != m:
                    continue
                if r["target"] == "all":
                    excluded |= targets
                elif r["target"].isdigit():
                    excluded.add(int(r["target"]))
            records.append(dict(source=index, map=m, region=kind,
                                nominal=len(targets), already_excluded=len(excluded & targets),
                                additionally_excluded=len(targets - excluded)))

with (OUT / "coverage_correction_details.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(records[0])); w.writeheader(); w.writerows(records)
old = rows(ROOT / "unified" / "coverage_by_seed.csv")
for r in old:
    if r["discovery_triangle"] == "4-6-7":
        for kind, prefix in (("strip", "offdiagonal"), ("diagonal", "diagonal")):
            r[prefix + "_valid"] = str(int(r[prefix + "_valid"]) - sum(
                e["additionally_excluded"] for e in records if e["region"] == kind))
            r[prefix + "_coverage_fraction"] = str(int(r[prefix + "_valid"]) / int(r[prefix + "_nominal"]))
with (OUT / "coverage_corrected.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(old[0])); w.writeheader(); w.writerows(old)
candidate_rows = rows(ROOT / "unified" / "candidate_seed_matrix.csv")
affected = [r for r in candidate_rows if int(r["source"]) in bad]
assert not affected, affected
report = {"source_indices": bad, "candidate_rows_removed": len(affected),
          "additional_strip_exclusions": sum(r["additionally_excluded"] for r in records if r["region"] == "strip"),
          "additional_diagonal_exclusions": sum(r["additionally_excluded"] for r in records if r["region"] == "diagonal"),
          "corrected_coverage": old,
          "scope": "Historical coverage corrected by removing invalid cross-seed source comparisons; no full discovery rerun."}
(OUT / "coverage_correction.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
