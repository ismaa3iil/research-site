param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('extension_a', 'extension_b', 'overlap_1', 'overlap_2', 'diagonal')]
    [string]$Job,

    [ValidateSet('obtuse', 'acute')]
    [string]$Seed = 'obtuse',

    [bool]$Resume = $true,
    [string]$Kernel = (Get-Command WolframKernel -ErrorAction SilentlyContinue).Source
)

$workspace = $PSScriptRoot
if (-not $Kernel) { throw 'Pass -Kernel with the installed WolframKernel executable path.' }
$worker = Join-Path $workspace 'm1m2m3_unified_worker.wls'
$root = Join-Path $workspace 'output\m1m2m3\unified'
$manifestPath = Join-Path $root 'database_manifest.json'
if (-not (Test-Path -LiteralPath $manifestPath)) {
    throw "Missing database manifest: run m1m2m3_unified_build_cache.wls first."
}
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.status -ne 'complete') {
    throw "The unified formula cache is not complete (status=$($manifest.status))."
}
$maxIndex = [int]$manifest.maxCommonIndex

switch ($Job) {
    'extension_a' {
        $scanKind = 'offdiag'; $sourceLo = 1; $sourceHi = 1000
        $targetLo = 53701; $targetHi = $maxIndex
    }
    'extension_b' {
        $scanKind = 'offdiag'; $sourceLo = 53701; $sourceHi = $maxIndex
        $targetLo = 1; $targetHi = 1000
    }
    'overlap_1' {
        $scanKind = 'offdiag'; $sourceLo = 501; $sourceHi = 1000
        $targetLo = 1; $targetHi = 500
    }
    'overlap_2' {
        $scanKind = 'offdiag'; $sourceLo = 1; $sourceHi = 500
        $targetLo = 501; $targetHi = 1000
    }
    'diagonal' {
        $scanKind = 'diagonal'; $sourceLo = 1; $sourceHi = $maxIndex
        $targetLo = 0; $targetHi = 0
    }
}
if ($sourceHi -lt $sourceLo -or ($scanKind -eq 'offdiag' -and $targetHi -lt $targetLo)) {
    throw "The requested job has an empty range at database endpoint X$maxIndex."
}

function Split-IntegerRange([int]$Lo, [int]$Hi, [int]$Count) {
    $length = $Hi - $Lo + 1
    $base = [math]::Floor($length / $Count)
    $extra = $length % $Count
    $cursor = $Lo
    $result = @()
    for ($s = 1; $s -le $Count; $s++) {
        $size = $base + $(if ($s -le $extra) { 1 } else { 0 })
        $end = $cursor + $size - 1
        $result += ,@($s, $cursor, $end)
        $cursor = $end + 1
    }
    return $result
}

$ranges = Split-IntegerRange $sourceLo $sourceHi 4
$seedDir = if ($Seed -eq 'acute') { 'acute_4_6_7' } else { 'obtuse_6_9_13' }
$output = Join-Path $root $seedDir
$processes = @()
foreach ($range in $ranges) {
    $env:M1_SCAN_KIND = $scanKind
    $env:M1_TASK_LABEL = $Job
    $env:M1_SHARD = [string]$range[0]
    $env:M1_START = [string]$range[1]
    $env:M1_END = [string]$range[2]
    $env:M1_TARGET_START = [string]$targetLo
    $env:M1_TARGET_END = [string]$targetHi
    $env:M1_SEED = $Seed
    $env:M1_MAX_INDEX = [string]$maxIndex
    $env:M1_RESUME = if ($Resume) { '1' } else { '0' }
    $startArgs = @{
        FilePath = $kernel
        ArgumentList = @('-script', ('"' + $worker + '"'))
        WorkingDirectory = $workspace
        WindowStyle = 'Hidden'
        PassThru = $true
    }
    $processes += Start-Process @startArgs
}

Write-Output ("Launched {0}, seed {1}, X{2}..X{3} against X{4}..X{5}: {6}" -f
    $Job, $Seed, $sourceLo, $sourceHi, $targetLo, $targetHi,
    (($processes | ForEach-Object { $_.Id }) -join ','))

do {
    Start-Sleep -Seconds 30
    $parts = @()
    foreach ($range in $ranges) {
        $shard = $range[0]
        $checkpoint = Join-Path $output ("{0}_shard_{1}_checkpoint.json" -f $Job, $shard)
        if (Test-Path -LiteralPath $checkpoint) {
            try {
                $data = Get-Content -LiteralPath $checkpoint -Raw | ConvertFrom-Json
                $parts += ("s{0}:X{1}/{2},tests={3},cand={4},fail={5}" -f
                    $shard, $data.lastCompletedSource, $data.endSource,
                    $data.tests, $data.candidates, $data.failures)
            } catch {
                $parts += ("s{0}:checkpoint-writing" -f $shard)
            }
        } else {
            $parts += ("s{0}:starting" -f $shard)
        }
    }
    Write-Output ((Get-Date -Format 'HH:mm:ss') + ' ' + ($parts -join ' | '))
    $running = @($processes | Where-Object { -not $_.HasExited })
} while ($running.Count -gt 0)

$exitCodes = @($processes | ForEach-Object { $_.Refresh(); $_.ExitCode })
Write-Output ("Completed {0}, seed {1}; exit codes: {2}" -f
    $Job, $Seed, ($exitCodes -join ','))
if (($exitCodes | Where-Object { $_ -ne 0 }).Count -gt 0) { exit 1 }
