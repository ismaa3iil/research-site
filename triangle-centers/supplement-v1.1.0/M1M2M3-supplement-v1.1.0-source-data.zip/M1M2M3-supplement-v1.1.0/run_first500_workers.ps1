param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('a', 'b')]
    [string]$Mode,

    [ValidateSet('obtuse', 'acute')]
    [string]$Seed = 'obtuse',

    [ValidateSet('first500', '501_1000')]
    [string]$Scope = 'first500',
    [string]$Kernel = (Get-Command WolframKernel -ErrorAction SilentlyContinue).Source
)

$workspace = $PSScriptRoot
if (-not $Kernel) { throw 'Pass -Kernel with the installed WolframKernel executable path.' }
$worker = Join-Path $workspace 'm1m2m3_offdiagonal_first500_worker.wls'
$outputName = if ($Scope -eq '501_1000') { 'offdiagonal_501_1000' } else { 'offdiagonal_first500' }
$outputRoot = Join-Path $workspace (Join-Path 'output\m1m2m3' $outputName)
$output = if ($Seed -eq 'acute') { Join-Path $outputRoot 'acute_4_6_7' } else { $outputRoot }

if ($Mode -eq 'a') {
    if ($Scope -eq '501_1000') {
        $ranges = @(
            @(1, 501, 625),
            @(2, 626, 750),
            @(3, 751, 875),
            @(4, 876, 1000)
        )
    } else {
        $ranges = @(
            @(1, 1, 125),
            @(2, 126, 250),
            @(3, 251, 375),
            @(4, 376, 500)
        )
    }
} else {
    if ($Scope -eq '501_1000') {
        # Shard 1 contains 1--500 and 1001--13800; the worker skips the
        # distinguished block 501--1000, giving 13,300 sources per shard.
        $ranges = @(
            @(1, 1, 13800),
            @(2, 13801, 27100),
            @(3, 27101, 40400),
            @(4, 40401, 53700)
        )
    } else {
        $ranges = @(
            @(1, 501, 13800),
            @(2, 13801, 27100),
            @(3, 27101, 40400),
            @(4, 40401, 53700)
        )
    }
}

$processes = @()
foreach ($range in $ranges) {
    $env:M1_MODE = $Mode
    $env:M1_SHARD = [string]$range[0]
    $env:M1_START = [string]$range[1]
    $env:M1_END = [string]$range[2]
    $env:M1_SEED = $Seed
    $env:M1_SCOPE = $Scope
    $processes += Start-Process -FilePath $kernel `
        -ArgumentList @('-script', ('"' + $worker + '"'), $Mode, [string]$range[0],
            [string]$range[1], [string]$range[2], $Seed, $Scope) `
        -WorkingDirectory $workspace `
        -WindowStyle Hidden `
        -PassThru
}

Write-Output ("Launched mode {0}, seed {1}, scope {2}: {3}" -f $Mode, $Seed, $Scope,
    (($processes | ForEach-Object { $_.Id }) -join ','))

do {
    Start-Sleep -Seconds 30
    $parts = @()
    foreach ($range in $ranges) {
        $shard = $range[0]
        $checkpoint = Join-Path $output ("pass_{0}_shard_{1}_checkpoint.json" -f $Mode, $shard)
        if (Test-Path -LiteralPath $checkpoint) {
            try {
                $data = Get-Content -LiteralPath $checkpoint -Raw | ConvertFrom-Json
                $parts += ("s{0}:X{1}/{2},tests={3},cand={4},fail={5}" -f
                    $shard, $data.lastCompletedSource, $data.endSource,
                    $data.tests, $data.candidates, $data.failures)
            } catch {
                $parts += ("s{0}:checkpoint-writing" -f $shard)
            }
        } else {
            $parts += ("s{0}:starting" -f $shard)
        }
    }
    Write-Output ((Get-Date -Format 'HH:mm:ss') + ' ' + ($parts -join ' | '))
    $running = @($processes | Where-Object { -not $_.HasExited })
} while ($running.Count -gt 0)

$exitCodes = @($processes | ForEach-Object { $_.Refresh(); $_.ExitCode })
Write-Output ("Completed mode {0}, seed {1}; exit codes: {2}" -f $Mode, $Seed, ($exitCodes -join ','))
if (($exitCodes | Where-Object { $_ -ne 0 }).Count -gt 0) { exit 1 }
