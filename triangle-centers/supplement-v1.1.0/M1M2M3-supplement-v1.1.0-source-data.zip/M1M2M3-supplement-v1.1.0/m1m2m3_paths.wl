(* Portable paths shared by the supplement programs. *)
m1Workspace = DirectoryName[ExpandFileName[$InputFileName]];
m1DataEnvironment = Quiet@Check[Environment["LEJEAN_KIMBERLING_ROOT"], ""];
repo = If[StringQ[m1DataEnvironment] && m1DataEnvironment =!= "",
  ExpandFileName[m1DataEnvironment],
  FileNameJoin[{m1Workspace, "data", "LeJean-Kimberling"}]];
If[!DirectoryQ[repo], Print["Missing ETC data: set LEJEAN_KIMBERLING_ROOT or unpack data/LeJean-Kimberling."]; Exit[2]];
SetDirectory[m1Workspace];
