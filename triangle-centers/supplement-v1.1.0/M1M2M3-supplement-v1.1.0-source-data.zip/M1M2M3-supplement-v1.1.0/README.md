# M1M2M3 research supplement, version 1.1.0

Ismail Hammoudeh, *Triangle Centers Relative to Their Cevian, Circumcevian, and Pedal Triangles*, September 2026.

This release accompanies the revised article. It is a self-contained data and source package, not a claim that every numerical candidate is proved. The fixed snapshot ends at X72807. Search scope: all diagonal indices, plus both directed off-diagonal strips with at least one index at most 1000. It is NOT an all-pairs search through X72807.

## Start here

- Article: `output/pdf/M1M2M3.pdf`; editable source: `M1M2M3.tex`.
- Definitive result table: `output/m1m2m3/revision_20260907/final_status.csv`.
- All 161 discovery statuses: `output/m1m2m3/revision_20260907/all_candidate_status.csv`.
- Individual fresh tests: `output/m1m2m3/revision_20260907/validation.csv`.
- Exact checks: `output/m1m2m3/algebraic_revision/algebraic_revision_checks.json`.
- Changes addressing the review: `REVISION_RESPONSE.md`.

The retained census is **32 rows: 20 proved in the article (including classical recoveries), two further classical relations, and ten unresolved candidates**. Nine apparent fixed centers are rejected exactly as unrestricted identities, but do satisfy an outside-circumcircle branch relation. A further 13 six-shape survivors have numerical counterexamples. The ten unresolved rows include isogonally paired questions; they are not ten independent novelty claims. One retained candidate, M2:203->34322, has 151 passes and one target-unavailable instance; the other 31 have 152 passes.

## Verify and reproduce without rediscovery

Requirements: Python 3.10+ (standard library only), and a locally licensed Wolfram installation. Tested with Wolfram 15.0.0 on 64-bit Windows. No network access or external ETC folder is needed. MX files are platform-dependent; readable Wolfram associations are also supplied.

First verify the untouched extracted archive:

```text
python verify_bundle.py
```

Then make a separate working copy: reproduction regenerates outputs and timestamps, so its files will no longer all match the release manifest. In that copy run:

```text
python reproduce.py --wolframscript "PATH/TO/wolframscript"
```

On another operating system or incompatible Wolfram build, use:

```text
python reproduce.py --wolframscript "PATH/TO/wolframscript" --rebuild-caches
```

This reruns exact family, orientation, X67371, X9181, Gergonne, and X795 checks; the 15352-comparison high-precision audit; the coverage subtraction; and final status generation. It takes roughly a minute on the development machine, excluding startup/license variation. Add `--audit-data` to rerun the complete 72807-source cache audit (several additional minutes); add `--figure` to regenerate the vector branch plot. Logs go to `verification_logs/`. No discovery job is started by this entry point.

The program explicitly chooses its bundled data. For individual Wolfram scripts the default is also bundled data; `LEJEAN_KIMBERLING_ROOT` can optionally override it. `m1m2m3_algebraic_revision_checks.wls` also accepts a data-root argument. Root formulas use the supplied library's ordered-real-root convention; `m1m2m3_geometry.wl` improves its working precision without intentionally changing branch selection.

The observed residual accuracy is not a rigorous interval bound. The acceptance rule is dimensionless error < 10^-40 with at least 50 reported absolute digits, working initially at 100 digits and retrying insufficient accuracy at 180. Unavailable is not failure. No numerical row is promoted to a theorem merely by survival.

## Build the article

From the extracted root, with a LaTeX installation containing the usual AMS, TikZ, Latin Modern, microtype, booktabs and longtable packages:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=output/pdf M1M2M3.tex
```

The generated table and vector figure are included, so Wolfram is not needed just to compile the article. Without latexmk, run pdflatex with the same output directory twice.

## Provenance and the corrected acute coverage

`output/m1m2m3/offdiagonal_first500`, `offdiagonal_501_1000`, and `unified` preserve the historical discovery summaries, candidates, failure logs and checkpoints. The historical filename `universal_candidates.csv` means ONLY a six-shape numerical survivor. Its 54 rows are not the final list.

The old workers could replace an unavailable acute source by an obtuse-seed cache value. The complete source audit found X10221, X66870 and X66871. None appears in the candidate union. The correction removes 6000 additional acute off-diagonal and eight diagonal comparisons, while preserving already excluded cases. Corrected acute counts are 388279438 strip and 210440 diagonal comparisons. The obtuse counts remain 388166091 and 210351. `coverage_correction_details.csv` records every subtraction. This is a correction of historical coverage, not a claim of a fresh 434-million-comparison run.

`provenance_sources/` contains pre-correction programs and manuscript for audit only; they may contain the development machine's paths and known defects. Do not use them for a new search. Revised portable programs are at the package root. No changes were found between the old 53700-entry expansion and the corresponding new-cache entries. All three data associations have readable equivalents in `revision_20260907/readable_data/`.

## Optional expensive discovery rerun

Use ANOTHER working copy and preserve the release's historical logs. The original first-500 workers overwrite their outputs. The unified worker can resume checkpoints, but rerunning an old completed checkpoint is not a fresh audit. Full reruns may take many hours and need sufficient Wolfram subprocess licenses. Launchers are Windows PowerShell; the underlying `.wls` programs are portable and configurable through documented environment variables at their tops.

1. Run `m1m2m3_unified_build_cache.wls`; the historical 53700 cache is supplied (or rebuilt by `rebuild_readable_caches.wls`).
2. Run `run_first500_workers.ps1 -Mode a/b -Seed acute/obtuse -Scope first500/501_1000 -Kernel "PATH/TO/WolframKernel"` for all eight combinations. Supply a single value at each slash, not literal slashes.
3. Run `run_m1m2m3_unified_workers.ps1 -Job extension_a/extension_b/overlap_1/overlap_2/diagonal -Seed acute/obtuse -Resume $false -Kernel "PATH/TO/WolframKernel"` for all ten combinations.
4. In the package root run `m1m2m3_unified_validate.wls`, then `m1m2m3_unified_aggregate.wls`. These retain the historical 36-instance audit convention.
5. Run the revised validation and status programs. Do NOT apply `m1m2m3_coverage_correction.py` to a repaired fresh discovery: its subtraction is specifically for the archived, pre-repair counts and would double-correct new results. Use the fresh aggregate coverage directly and compare it with the corrected release table.

Numerical evaluability and timing can vary across systems, especially at singular or branch-sensitive formulas. Changed outputs require investigation, not automatic replacement of the published classification.

## Rights, attribution and archival status

See `THIRD_PARTY_NOTICES.md` and the upstream license. This package does not assign a new open license to the author's manuscript. The problem's origin and Hajja's support are acknowledged in the article. The article discloses AI assistance and excludes AI from authorship.

The manifest fixes version 1.1.0. A public permanent-archive DOI has not been obtained by this revision. Before journal submission, deposit this exact bundle in an appropriate permanent repository, select its license with the author, and add the resulting identifier to the article. Journal-specific formatting, author approval, and journal policy checks remain editorial submission steps.
