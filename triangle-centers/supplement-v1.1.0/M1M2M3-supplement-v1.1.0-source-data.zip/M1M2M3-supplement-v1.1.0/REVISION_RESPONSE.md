# Response to the referee review of 7 September 2026

The revised article addresses the mathematical, computational, and presentation issues as follows.

1. **Orientation:** the source is explicitly counterclockwise; arbitrary realizations use relative orientation. The two determinant identities establish the compatible pedal/circumcevian signs.
2. **Geometric branch law:** the sign reduces to Q, and the circumcircle-power formula identifies the inside/outside branches. A vector shape-space figure displays the branch boundary and the distinct infinite-source locus.
3. **Exceptional parameters and domains:** both signs of 1/sqrt(3) are handled separately. Zero triples, infinite sources and degenerate targets are distinguished; the polynomial extension at U=0 is explained.
4. **Acute cache defect:** both workers are repaired. All 72807 sources were audited; three incompatible fallbacks were identified. Historical failure logs yield exact count corrections of 6000 strip and eight diagonal exclusions. The candidate union is unchanged. Full discovery was not rerun.
5. **Proofs:** elementary contact-triangle proofs and isogonal transfer account for the incenter and Gergonne rows. Affine covariance proves X9181 alongside X67371, and gives the X67371->X54602 pedal corollary outside the enumerated strips.
6. **Additional branch exclusions:** structured tests identify X17851 and X17852 as further failures. Exact ETC substitution proves they are F_(16/27) and F_(9/16). Together with seven earlier entries, all nine unrestricted fixed-point claims have exact near-equilateral exclusions.
7. **Numerical audit:** dimensionless geometry, precision-preserving polynomial roots and achieved-accuracy reporting replace raw-scale tests in the revised validator. The fresh 15352 comparisons produce 32 retained rows. Twenty have proofs in the article, including classical recoveries; two further rows are cited classical relations; ten remain candidates. One candidate has a target-unavailable case, explicitly disclosed.
8. **Final presentation:** one definitive retained table and a full 161-row machine-readable status ledger replace subtraction across outdated lists. Classical results are attributed, unused references are removed, and the scope does not imply a complete all-pairs search.
9. **Reproducibility:** this versioned supplement includes source and readable data, fixed historical records, exact inputs, residuals, portable verification commands and hashes. Pre-correction code is explicitly archival. The article and figure are compiled and visually inspected.
10. **Acknowledgement and AI:** Hajja's origin, permission and support are preserved. The AI disclosure describes the actual assistance and does not claim an independent human verification that has not been documented; AI is not a coauthor.

## Remaining limitations, not concealed as completed work

- The ten retained numerical candidates are not universal theorems or a certified list of novel open problems.
- The 13 random-sample rejections are numerical, not exact interval certificates. The nine constant-family rejections are exact.
- No new full-discovery rerun or exhaustive pairwise search was made; the correction uses the historical records.
- Broader family classification, a scalable indexed invariant, independent software/interval validation and a full novelty review remain research directions.
- A permanent archive identifier and journal-specific author approval are still needed before formal submission. This local bundle does not itself constitute a public repository deposit.
