"""Generate the browser's daily SPA declinations and equation of time."""

from datetime import datetime, timezone
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "paper_v8"))
from solar_support import coordinates, spa

years = {}
for year in range(2026, 2031):
    start = datetime(year, 1, 1, 12, tzinfo=timezone.utc).timestamp()
    count = (datetime(year + 1, 1, 1) - datetime(year, 1, 1)).days
    times = start + np.arange(count) * 86400
    delta, _ = coordinates(times)
    eot = spa.solar_position(times, 0, 0, 0, 0, 15, 69.2, 0, numthreads=1)[-1]
    years[year] = [[round(float(d), 14), round(float(e), 10)] for d, e in zip(delta, eot)]

payload = {"source": "NREL Solar Position Algorithm via pvlib 0.16.1", "epoch": "12:00 UTC each date",
           "deltaTSeconds": 69.2, "columns": ["declinationRadians", "equationOfTimeMinutes"], "years": years}
path = ROOT / "prayer-explorer/dist/ephemeris.js"
path.write_text("globalThis.PRAYER_EPHEMERIS=" + json.dumps(payload, separators=(",", ":")) + ";\n", encoding="utf-8")
print(path)
