"""Package a single-file offline app and its editable project sources."""

from pathlib import Path
import re
import shutil
from urllib.parse import quote
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "dist/index.html").read_text(encoding="utf-8")
css = (ROOT / "dist/styles.css").read_text(encoding="utf-8")
css = re.sub(r"^@import[^;]+;\s*", "", css)
html = html.replace('<link rel="stylesheet" href="styles.css">', '<style>\n' + css + '\n</style>')
license_url = "data:text/plain;charset=utf-8," + quote((ROOT / "dist/third-party.txt").read_text())
for name in ("ephemeris", "cities", "engine", "charts", "help", "app"):
    script = (ROOT / f"dist/{name}.js").read_text(encoding="utf-8")
    if name == "help":
        script = script.replace('href="third-party.txt"', f'href="{license_url}"')
    html = html.replace(f'<script defer src="{name}.js"></script>', '<script>\n' + script + '\n</script>')
# All scripts run after the markup in the standalone file, preserving defer semantics.
scripts = re.findall(r"<script>[\s\S]*?</script>", html)
html = re.sub(r"<script>[\s\S]*?</script>", "", html)
html = html.replace("</body>", "\n".join(scripts) + "\n</body>")
assert 'src="' not in html and 'href="styles.css"' not in html
standalone = ROOT / "prayer-explorer.html"
standalone.write_text(html, encoding="utf-8")
sources = [*sorted(p for p in (ROOT / "dist").glob("*") if p.suffix != ".zip"), *sorted((ROOT / "scripts").glob("*.py")),
           *sorted((ROOT / "tests").glob("*.cjs")), ROOT / "README.md", ROOT / "Start Explorer.cmd", standalone]
archive = ROOT / "Prayer_Time_Explorer.zip"
with ZipFile(archive, "w", ZIP_DEFLATED) as z:
    for file in sources:
        z.write(file, file.relative_to(ROOT).as_posix())
with ZipFile(archive) as z:
    assert z.testzip() is None
shutil.copyfile(archive, ROOT / "dist/Prayer_Time_Explorer.zip")
print(standalone)
print(archive)
