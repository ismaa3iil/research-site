"use strict";
const assert = require("node:assert/strict");
const test = require("node:test");
require("../dist/ephemeris.js");
require("../dist/engine.js");
const E = globalThis.PrayerEngine;
const approx = (a, b, eps = 1e-8) => assert.ok(Math.abs(a - b) < eps, `${a} ≠ ${b}`);

test("reproduces archived geometric k=1 afternoon comparisons", () => {
  const cities = [[21.4225,152,365,20.227337544147495,10.330787212648783],
    [24.4672,137,365,20.466,10.09], [33.3152,182,365,20.59,8.76], [41.0082,192,365,19.44,14.17]];
  for (const [latitude, first, second, rms, max] of cities) {
    const r = E.calculate({...E.defaults, latitude});
    assert.equal(r.metrics.asr1.days, first); assert.equal(r.metrics.asr2.days, second);
    if (latitude === 21.4225) { approx(r.metrics.asr1.rms, rms); approx(r.metrics.asr2.maximum,max); }
  }
});

test("four independent horizon options preserve symmetric noon", () => {
  const base=E.calculate(E.defaults);
  for(const latitude of [21.4225,41.0085,60,-33,80,90,-90]) {
    const all=[false,true].flatMap(refraction=>[false,true].map(solarDisk=>E.calculate({...E.defaults,latitude,refraction,solarDisk})));
    for(let d=0;d<365;d++)for(const r of all){
      const row=r.rows[d];if(row.noon!==null){approx((row.sunrise+row.sunset)/2,row.noon);approx(row.noon,base.rows[d].transit);}
    }
    if(Math.abs(latitude)<60){
      const geo=all[0].rows[147], corrected=all[3].rows[147];assert.ok(corrected.sunrise<geo.sunrise);assert.ok(corrected.sunset>geo.sunset);
    }
  }
});

test("reference selection takes the smaller residual shadow and exact rules coincide there", () => {
  for(let year=2026;year<=2030;year++)for(const refraction of [false,true])for(const solarDisk of [false,true])for(const n of [6,7,8,9,10]){
    const cfg={...E.defaults,year,nightDenominator:n,refraction,solarDisk,fractions:"exact",shadowMode:"zero"};
    const r=E.calculate(cfg), cal=r.calibration, d=r.rows.find(row=>row.date===cal.date);
    approx(cal.noonShadow,Math.min(...cal.candidates.map(c=>c.noonShadow)),1e-12);
    for(const name of ["asr1","asr2","fajr"])approx(d.errors[name],0,1e-8);
    assert.ok(cal.r1>0&&cal.r1<cal.r2&&cal.r2<1);assert.ok(cal.angle>0&&cal.angle<40);
    assert.equal(r.rows.length,year===2028?366:365);
  }
});

test("all tested locations have coherent coverage and monotone counts",()=>{
  for(const latitude of [-90,-89.9,-70,-45,0,21.4225,55,65,80,89.9,90])for(const shadowMode of ["zero","one","mixed","optimal"]){
    const r=E.calculate({...E.defaults,latitude,shadowMode},false);
    for(const name of ["asr1","asr2","fajr"]){
      const values=[5,10,15,20,25,30].map(t=>E.metric(r.rows,name,t));
      values.forEach((m,i)=>{assert.ok(m.days<=m.defined);assert.ok(m.defined<=m.total);if(i)assert.ok(m.days>=values[i-1].days);});
      for(const d of r.rows)if(d.errors[name]!==null)assert.ok(Number.isFinite(d.errors[name]));
    }
    if(Math.abs(latitude)===90)assert.equal(r.metrics.fajr.days,0);
  }
});

test("count fitting reaches known fine-grid city maxima",()=>{
  for(const [latitude,first5,first10,second5] of [[21.4225,245,365,315],[24.4672,234,316,298],[33.3152,205,266,268],[41.0082,188,240,252]]){
    const a=E.calculate({...E.defaults,latitude,shadowMode:"optimal",fitTolerance:5,tolerance:5});
    assert.equal(a.metrics.asr1.days,first5);assert.equal(a.metrics.asr2.days,second5);
    const b=E.calculate({...E.defaults,latitude,shadowMode:"optimal",fitTolerance:10,tolerance:10});assert.equal(b.metrics.asr1.days,first10);
  }
});

test("fitting target is separate from counting tolerance and improves fixed candidates",()=>{
  for(const latitude of [0,21.4225,41.0085,55,65,-60])for(const refraction of [false,true]){
    const fixed=E.calculate({...E.defaults,latitude,refraction},false);
    const fitted=E.calculate({...fixed.config,shadowMode:"optimal",fitTolerance:10,tolerance:10},false);
    for(const name of ["asr1","asr2"]){assert.ok(fitted.metrics[name].days>=E.metric(fixed.rows,name,10).days);}
    const rescored=E.calculate({...fitted.config,tolerance:25},false);
    assert.deepEqual(fitted.ks,rescored.ks);
  }
});

test("a dense parameter grid never beats the interval-sweep fit",()=>{
  for(const latitude of [21.4225,55,65,-42])for(const horizon of [false,true]){
    const r=E.calculate({...E.defaults,latitude,refraction:horizon,solarDisk:horizon,shadowMode:"optimal",fitTolerance:5,tolerance:5},false);
    for(let j=0;j<2;j++){
      const fit=r.fits[j], g=r.rows.map(d=>d.geometry).filter(g=>g.crossing&&g.h0>0);
      let gridBest=0;
      for(let i=0;i<1800;i++){
        const k=fit.floor+i/600;
        const count=g.filter(x=>{const h=E.shadowHour(x,j+1,k);return h!==null&&Math.abs(E.F*(h-r.ratios[j]*x.hs))<5;}).length;
        gridBest=Math.max(gridBest,count);
      }
      assert.ok(fit.count>=gridBest,`${latitude} horizon ${horizon}, threshold ${j+1}`);
    }
  }
});

test("winter 70% sunset intervals reproduce the previous calculations",()=>{
  for(const [latitude,expected] of [[55,62.10147836213687],[60,49.60691697336214],[65,25.95181134122261]]){
    const row=E.calculate({...E.defaults,latitude}).rows.find(d=>d.date==="2026-12-22");approx(row.sunset-row.fractional.asr2,expected);
  }
});

test("longitude changes clock times and preserves discrepancies",()=>{
  const a=E.calculate({...E.defaults,timeZone:null,offset:0,longitude:0});
  const b=E.calculate({...a.config,longitude:100});
  a.rows.forEach((d,i)=>{approx(d.noon-b.rows[i].noon,400);for(const f of ["fajr","asr1","asr2"])approx(d.errors[f],b.rows[i].errors[f]);});
});

test("clock modes handle daylight saving, solar time, and adjacent dates",()=>{
  const r=E.calculate({...E.defaults,timeZone:"Europe/London",longitude:0});
  assert.equal(r.rows[0].offset,0);assert.equal(r.rows[180].offset,60);
  const solar=E.calculate({...E.defaults,clock:"solar"});solar.rows.forEach(d=>approx(d.noon,720));
  assert.equal(E.time(-5),"23:55 (-1d)");assert.equal(E.time(1445),"00:05 (+1d)");assert.equal(E.time(null),"—");
});

test("strict counts exclude equality and invalid input is rejected",()=>{
  assert.equal(E.metric([{errors:{fajr:5}}],"fajr",5).days,0);
  assert.throws(()=>E.calculate({...E.defaults,latitude:91}));assert.throws(()=>E.calculate({...E.defaults,nightDenominator:5}));
  assert.throws(()=>E.calculate({...E.defaults,year:2025}));assert.throws(()=>E.calculate({...E.defaults,longitude:NaN}));
});
