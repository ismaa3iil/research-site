# Attractivity follow-up: E0, M6, reaction centroids and solid-angle centers

30 September 2026. This research addendum supersedes the earlier statement that E0 was an attractive candidate. The six reading PDFs and their dated ZIP remain the previous edition; the live atlas receives the corrections below. The membrane source open in the editor is unchanged.

## Results and their precise scope

| Selector | New conclusion | Evidence |
|---|---|---|
| E0, equal-exit conformal center | **Not globally vertex-attractive** | Outward-rounded interval certificate for an explicit finite vertex motion |
| M6, uniform-volume-current magnitude mean | Remains the strongest positive conjecture among these candidates | 512 new shapes plus 100 repeated shapes; complex-step derivatives; ten difficult shapes refined; no retained negative result |
| Abs(0), Abs(1), Abs(10), Abs(100) | Still plausible; no theorem of global attractivity | Positive new direct-sensitivity screens and selected higher-degree refinements |
| Abs(10000) | Strong numerical evidence of failure | Independent polynomial Ritz and quadratic FEM sensitivities and finite motions |
| Abs(mu), as a whole family | **Fails global attractivity for every sufficiently large mu** | Thin-domain energy argument below; the threshold is not explicitly bounded |
| Solid(eta), as a whole family | **Fails the vertex-attractivity condition for every sufficiently small positive eta** | The certified M1 witness and convergence of all solid-angle maximizers to M1 |
| Solid(.01), Solid(.003), Solid(.001) | Negative numerical witnesses | Stationary minima checked at 45 and 75 decimal digits; no finite-height global-maximizer enclosure |
| Solid(.1), Solid(1), Solid(10) | Earlier open/no-failure status unchanged | The small-height argument does not classify these particular parameters |

Attractivity always means displacement of one vertex while the other two are fixed. It is unrelated to dynamical stability of the physical field. The physical parameters mu and eta are dimensionless and are held fixed during each comparison. A numerical screen tests the symmetric part of each vertex Jacobian, not merely the center's derivative along a symmetry line.

![Refinement results and limiting mechanisms](investigation_summary.png)

The plotted values are numerical evidence. The E0 sign has the separate interval certificate below, and the two family statements have analytical proofs below.

## 1. A certified counterexample for E0

Take the exact decimal triangle

\[
A=(0,0),\quad B=(1,0),\quad
C=(0.9963640131614389,\;0.0015991738862318396).
\]

Move A by h=10^{-5}d, where the exact decimal vector is

\[
d=(-0.9997966839583786,-0.02016409546273338).
\]

The triangle remains positively oriented throughout this motion. The certified normalized dot product is contained in the simpler outward enclosure

\[
-3.13100322614\,10^{-7}
<\frac{h\cdot(E_0(T+h)-E_0(T))}{|h|^2}
<-3.13100322613\,10^{-7}.
\]

Both endpoints are negative. This settles global E0 attractivity negatively, even though its response is positive on many ordinary triangles. The center displacement is extremely small; ordinary double-precision subtraction is inadequate for certification.

### Why the calculation is rigorous

For a counterclockwise triangle, put a=angle(A)/pi and b=angle(B)/pi. The Schwarz--Christoffel map normalized at A and B gives

\[
E_0=A+(B-A)\frac{B_z(a,b)}{B(a,b)},\qquad z=\frac12+\frac{\sqrt3}{2}i.
\]

Here B_z is the incomplete beta function. The three boundary intervals in the upper half-plane have equal harmonic measure at z, which gives the equal-exit definition. The construction is the one described by [Iannaccone](https://scholarship.claremont.edu/hmc_theses/149/).

Directly using a geometric tail at |z|=1 would be invalid. The certificate instead uses two stages:

1. Evaluate B_{z/2} by its hypergeometric power series through degree 250. Since |z/2|=1/2 and 0<a,b<1, the coefficient recurrence has modulus ratio at most 1/2. The omitted tail is bounded by the last term times r/(1-r).
2. Integrate t^{a-1}(1-t)^{b-1} from z/2 to z using a Taylor series about m=3z/4, with half-segment d=z/4. The circle |t-m|=1/2 avoids both branch points and stays in the upper half-plane. On it,

\[
|t^{a-1}(1-t)^{b-1}|
\le M=(1/4)^{a-1}(\sqrt{13}/4-1/2)^{b-1}.
\]

Cauchy's coefficient bound gives an integral remainder, after degree N, at most M/2^{N+1}. The certificate uses N=160. All powers, angles, gamma functions, arithmetic and tail additions use outward-rounded intervals at 75 decimal digits. Both coordinate enclosures are propagated into the actual finite-motion dot product; no derivative sign is substituted for it.

Files: [certificate](E0_interval_certificate.json), [independent high-precision values](E0_optimized_witness.json), and executable `research/equal_exit_certificate.py`. The independent incomplete-beta evaluation agrees at 45, 75 and 105 digits. The full, narrower interval is retained in the certificate file.

## 2. M6: stronger evidence, but still no positive theorem

The new sample consists of 512 scrambled Sobol shapes (seed 931271) concentrated near collinearity and vertex collision, plus the existing 100-shape grid. These are stress samples, not a uniform probability sample over all triangles. Some new heights are of order 10^{-9} relative to the unit base.

The initial subtraction-based finite differences produced two negative M6 values. They failed refinement and are retained as numerical artifacts, not counterexamples. In particular, the common step cap in extremely thin triangles makes two nominal step choices identical; those runs are not independent step-halving evidence.

An independent complex-step implementation differentiates the analytic interior segment formula and the pulled-back quadrature directly. On a moderate triangle it agrees with the earlier center to 3.2e-15 and with central differences to 1.3e-11. The 612-shape order-32 screen has minimum response about 0.1300. Six problematic subtraction cases and the four smallest complex-step screen margins were refined through order 256; all retained values are positive. The smallest refined value is about 0.1193. These are sampled values, not lower bounds over shape space. Several extreme cases still have appreciable quadrature dependence.

The host's `longdouble` has the same precision as `double`; no extended-precision benefit is claimed. Complex-step differentiation removes subtractive cancellation in the derivative, but does not certify the spatial quadrature.

### A continuum formula for a possible proof

Write p=A+B xi on a fixed reference triangle U, and ignore the fixed ninety-degree magnetic rotation, which preserves magnitude. Apart from a positive constant that cancels in the mean, the field is

\[
b_B(\xi)=\int_U\frac{B(\xi-\eta)}{|B(\xi-\eta)|^2}\,d\eta.
\]

For a variation dot B, differentiation gives the locally integrable kernel

\[
\dot b_B(\xi)=\int_U\left[
\frac{\dot B r}{|Br|^2}
-\frac{2Br\,(Br\cdot\dot B r)}{|Br|^4}\right]d\eta,
\qquad r=\xi-\eta.
\]

If z is the reference-coordinate mean weighted by |b_B|, then

\[
\dot z=\frac{\int_U(\xi-z)\,[b_B/|b_B|]\cdot\dot b_B\,d\xi}
{\int_U|b_B|\,d\xi},\qquad
\dot M_6=\dot A+\dot Bz+B\dot z.
\]

The norm derivative is interpreted almost everywhere away from field zeros. This separates direct transport from field redistribution. The latter has no immediately evident sign. Bounding its adverse contribution for every vertex motion is the remaining positive-theorem problem; positivity of the density by itself does not solve it.

## 3. Abs: direct shape sensitivities and a counterexample

The definition is

\[
-\Delta u+\frac{\mu}{L^2}u=1\quad\hbox{in }T,
\qquad u|_{\partial T}=0,
\qquad L^2=(a^2+b^2+c^2)/3,
\qquad C_\mu=\frac{\int_T p u(p)\,dp}{\int_Tu(p)\,dp}.
\]

On the reference triangle let G=B^{-1}B^{-T}. The weak operator is A=K(G)+(mu/L^2)M. Its derivative satisfies

\[
A\dot u=-\dot A u,
\qquad
\dot A=\dot K-\frac{\mu\dot L^2}{L^4}M.
\]

The second term is essential: mu, rather than the dimensional removal coefficient, is fixed. Differentiating the first-moment quotient gives the center derivative. Independent finite differences agree with the implemented Ritz derivative to less than 1.2e-10 on a moderate test triangle.

All seven sampled values mu=0,.1,1,10,100,1000,10000 were tested on 612 shapes. The degree-10 screen remains positive through mu=1000. Selected cases were refined at degrees 14,20,28. Passing these screens proves neither an interval of parameters nor all shapes. At mu=10000 several stable negative responses appear.

One witness has

\[
A=(0,0),\quad B=(1,0),\quad C=(0.9900690861977637,0.02247187149177476).
\]

Move B in direction (-0.7239766903874837,0.6898244354729584). The smallest symmetric-Jacobian eigenvalue changes as follows:

| Method | Resolution | Minimum eigenvalue |
|---|---|---|
| Polynomial Ritz | degree 14 | -0.355261 |
| Polynomial Ritz | degree 20 | -0.365065 |
| Polynomial Ritz | degree 28 | -0.366162 |
| Quadratic FEM | 48 subdivisions | -0.353508 |
| Quadratic FEM | 80 subdivisions | -0.362722 |
| Quadratic FEM | 128 subdivisions | -0.365409 |
| Quadratic FEM | 192 subdivisions | -0.366012 |

At the finest FEM level, finite-motion ratios at steps 1e-4, 5e-5 and 2.5e-5 are approximately -0.366066, -0.366039 and -0.366025. This is strong independently reproduced numerical evidence, not an interval-certified PDE counterexample at exactly mu=10000.

### An analytical failure theorem for sufficiently large mu

**Proposition.** There is a finite mu_0 such that for every mu>mu_0 the center C_mu is not globally vertex-attractive. This argument does not provide an explicit numerical value of mu_0.

Set epsilon=mu^{-1/2}. Fix x in (1/2,1), and use the triangles with vertices (0,0),(1,0),(x,epsilon tau). After rescaling y=epsilon t and u=epsilon^2 w, the energy on the fixed-height triangular domain D_{x,tau} becomes

\[
J_\epsilon(w)=\int_D\left[
\frac{\epsilon^2}{2}|w_s|^2+\frac12|w_t|^2
+\frac{\kappa_\epsilon^2}{2}w^2-w\right]ds\,dt,
\quad \kappa_\epsilon^2=L_\epsilon^{-2}.
\]

Here L_epsilon tends to L_0=[(1+x^2+(1-x)^2)/3]^{1/2}. If the local rescaled height is H(s), the minimizer of the energy with the longitudinal term removed is the vertical profile

\[
w_0(s,t)=\kappa^{-2}\left[
1-\frac{\cosh(\kappa(t-H(s)/2))}{\cosh(\kappa H(s)/2)}\right],
\quad
F(H)=\int_0^H w_0\,dt
=\frac{H}{\kappa^2}-\frac{2\tanh(\kappa H/2)}{\kappa^3}.
\]

For a fixed positive tau and x bounded away from 0 and 1, this vertical profile belongs to H_0^1(D), including across the apex's vertical line. Use kappa=kappa_epsilon and compare the full minimizer with this profile. Stationarity of the vertical energy and minimality of the full energy give

\[
\|(w_\epsilon-w_0)_t\|_2^2+
\kappa_\epsilon^2\|w_\epsilon-w_0\|_2^2
\le\epsilon^2\|(w_0)_s\|_2^2.
\]

Thus the field converges in L2 to the vertical profile, and its positive-mass centroid converges too. The bound is uniform for x in a small compact neighborhood of the chosen x. Consequently it also applies when x is shifted by epsilon.

Put

\[
R_\kappa(\tau)=\frac{\int_0^1 q F(\tau q)\,dq}{\int_0^1 F(\tau q)\,dq}.
\]

The two linear sides of the triangle give the limiting horizontal centroid

\[
c_x(\tau)=1-x+(2x-1)R_\kappa(\tau).
\]

Since F(H) is asymptotic to H^3/12 for small H and H/kappa^2 for large H,

\[
\lim_{\tau\downarrow0}R_\kappa(\tau)=\frac45,
\qquad
\lim_{\tau\to\infty}R_\kappa(\tau)=\frac23.
\]

Choose two finite heights tau_1<tau_2 sufficiently small and large, respectively, so that R(tau_2)<R(tau_1). Now move the apex from (x,epsilon tau_1) to (x+epsilon,epsilon tau_2), using the same mu=epsilon^{-2} for both triangles. Because x>1/2, the horizontal center displacement tends to a strictly negative constant -delta. The vertical center displacement is O(epsilon). Therefore

\[
h\cdot\Delta C
=\epsilon[-\delta+o(1)]+O(\epsilon^2)<0
\]

for every sufficiently small positive epsilon. Both the initial and final triangles, and their intervening straight vertex motion, are nondegenerate. This proves the proposition.

There is no contradiction with C_mu(T) tending to X2 as mu tends to infinity for each *fixed* triangle: the counterexample triangles become thinner as mu increases. The convergence to X2 is not uniform over all triangle shapes in the sense needed for attractivity.

For illustration, x=.75, tau_1=.1 and tau_2=10 give R values about .79993 and .70971. These numerical constants are not needed by the existence proof. Saved Ritz examples of the coupled limit have negative finite motions at mu=1e6 and 1e8; they are demonstrations, not certified explicit thresholds.

## 4. Solid-angle centers at small heights

There is a general closure observation: if C_t(T) tends to C_0(T) for each fixed triangle, and C_0 has a strict finite-motion counterexample, then the same two triangles give a negative dot product for all sufficiently small t. Only convergence on those two fixed triangles is needed, not convergence of shape derivatives.

For the solid angle at height h above an interior point p, polar integration gives

\[
\Omega_h(p)=2\pi-h\int_0^{2\pi}
\frac{d\theta}{\sqrt{R_p(\theta)^2+h^2}},
\]

where R_p is the distance to the triangle boundary along the ray. On compact interior sets the coefficient tends uniformly to the loop-field function defining M1. A sequence approaching the boundary has an unbounded coefficient as h tends to zero: a fixed angular sector sees a side at distance d and contributes at least a positive constant divided by sqrt(d^2+h^2). Comparing with a fixed interior point therefore keeps all maximizers away from the boundary. Uniqueness of the M1 minimizer then forces every solid-angle maximizing sequence to converge to M1.

Apply the closure observation to the already certified M1 negative finite motion. With h=eta L(T), eta tending to zero also makes both physical heights tend to zero. Consequently every choice of global solid-angle maximizers on those two triangles violates attractivity for all sufficiently small eta. This conclusion does not require an unproved global uniqueness theorem at arbitrary finite eta.

Using the old M1 witness, the numerical finite-motion ratios are:

| eta | Ratio |
|---|---|
| .03 | +0.161859 |
| .01 | -0.012401 |
| .003 | -0.061016 |
| .001 | -0.066061 |
| 0, M1 limit | approximately -0.066702 |

The finite-height stationary points have positive objective Hessians and repeat at 45 and 75 decimal digits. This does not certify that each is the unique global maximum, or an exact threshold. The limiting theorem is stronger in its eventual conclusion and weaker in not specifying the threshold.

## 5. Revised priorities

M6 remains the leading candidate for a global positive theorem. Abs(0) and the previously studied small/moderate parameters remain candidates, but a theorem for the entire Abs family is now ruled out. E0 must be removed from the positive-candidate list. Small-height solid-angle centers must likewise be separated from the three larger-height members previously screened.

The other plate, nonlinear membrane, weak-darkness, fluorescence and population candidates from the earlier answer were not reclassified in this follow-up. Their original evidence levels remain in force. The four previously proved attractive points X1, X2, X10 and X360 remain unchanged.

## Reproduction

Run from the project root, with the same Python scientific dependencies as the six-chapter bundle:

```
python research/attractivity_candidates.py screen E0
python research/attractivity_candidates.py screen M6
python research/attractivity_candidates.py screen Abs
python research/attractivity_candidates.py refine E0
python research/attractivity_candidates.py refine M6
python research/attractivity_candidates.py refine Abs
python research/attractivity_followup.py e0
python research/attractivity_followup.py abs_check
python research/equal_exit_certificate.py
python research/abs_fem_followup.py
python research/abs_thin_reaction.py
python research/m6_complex_derivative.py check
python research/m6_complex_derivative.py screen
python research/m6_complex_derivative.py refine
python research/solid_small_height.py
```

The certificate uses exact decimal input conventions. The PDE and magnetic quadrature computations use floating arithmetic and must not be relabeled interval proofs. No new full-ETC location search was needed or performed: this investigation addresses attractivity of already defined centers and additional parameter values.
