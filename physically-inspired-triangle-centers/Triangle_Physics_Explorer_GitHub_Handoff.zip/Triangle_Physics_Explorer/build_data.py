"""Build the public browser data from the PITC research atlas.
No Wolfram runtime or full ETC database is redistributed. Only requested
classical centers and three shortlisted expressions per PITC are included.
Run from the enclosing research-project directory with NumPy and SciPy.
"""
import sys,json,ast,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT.parent/'vendor/triangle-center-python'))
sys.path.insert(0,str(ROOT/'research'))
import numpy as np
from scipy.spatial import Delaunay
from etc_search import environment,evaluate

OUT=ROOT/'explorer/dist'
def load(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def records(x):return x.get('records',[]) if isinstance(x,dict) else x
catalog=load('output/article/catalogue.json')
for k,v in load('output/chapter_atlas_update/catalogue_patch.json').items():catalog[k].update(v)
for k,v in load('output/attractivity_candidates/atlas_patch.json').items():catalog[k]['attract']=v
rankings=load('output/lectures/scientific_data.json')['rankings']
for p in ['output/quantum/etc_location_shortlist.json','output/electro_heat/etc_location_shortlist.json','output/mechanical_optical/etc_shortlist.json','output/illumination/etc_location_shortlist.json','output/chapter_atlas_update/etc_comparison.json']:
 for k,v in load(p)['rankings'].items():rankings[k]=v
aliases={'E4':'X2','S3':'X10','S4':'X10','M3':'X360'}
for k,v in aliases.items():rankings.setdefault(k,[{'X':int(v[1:]),'grid_rms':0,'holdout_rms':0}])
samples={k:{} for k in catalog}
profiles={k:{'iso':[],'right':[],'thin':[]} for k in catalog}
sources=[]
def unpack(r,names=None):
 c=r.get('centers',{})
 return dict(zip(names,c)) if isinstance(c,list) else c
def geom(v):
 v=np.asarray(v,float);a=np.linalg.norm(np.roll(v,-1,axis=0)-np.roll(v,-2,axis=0),axis=1)
 angles=np.arccos(np.clip((np.roll(a,1)**2+np.roll(a,2)**2-a*a)/(2*np.roll(a,1)*np.roll(a,2)),-1,1))
 order=np.argsort(angles,kind='stable')
 return angles[order],order
def add(r,names=None):
 v=np.asarray(r['vertices'],float)
 angles,order=geom(v)
 for k,p in unpack(r,names).items():
  if k not in samples or p is None or any(z is None for z in p) or not np.all(np.isfinite(p)):continue
  if names and k in names and r.get('ambiguous',[False]*len(names))[names.index(k)]:continue
  b=np.linalg.solve(np.vstack([v.T,np.ones(3)]),np.r_[p,1.])[order]
  # Exact shape symmetries: eliminate numerical labels of equivalent vertices.
  for i in range(3):
   tied=np.where(abs(angles-angles[i])<1e-9)[0]
   if len(tied)>1:b[tied]=np.mean(b[tied])
  key=tuple(np.round(angles[:2],10))
  err=r.get('last_change_over_diameter',r.get('last_change_D',r.get('center_refinement_change_over_diameter',r.get('last_change',{}))))
  e=err.get(k) if isinstance(err,dict) else (err[names.index(k)] if names and len(err)>names.index(k) else None)
  samples[k][key]=[angles[:2].tolist(),b.tolist(),float(e) if e is not None else None]
def ingest(folder,names=None,grid='grid.json',holdout='holdout.json',derivatives='family_derivatives.json'):
 for name in [grid,holdout]:
  p='output/'+folder+'/'+name
  if (ROOT/p).exists():
   sources.append(p)
   for r in records(load(p)):add(r,names)
 p='output/'+folder+'/families.json'
 if not (ROOT/p).exists():return
 fam=load(p);dp=ROOT/'output'/folder/derivatives
 deriv=load(str(dp.relative_to(ROOT))) if dp.exists() else {}
 for kind,rs in fam.items():
  for i,r in enumerate(rs):
   add(r,names);h=r.get('height',r.get('h',r['vertices'][2][1] if kind=='isosceles' else r['vertices'][2][0]))
   dr=deriv.get(kind,[])
   dd=dr[i].get('derivatives',{}) if i<len(dr) else r.get('derivative',{})
   if isinstance(dd,list):dd=dict(zip(names,dd))
   for k,p in unpack(r,names).items():
    if k not in profiles or p is None:continue
    amb=bool(names and r.get('ambiguous',[False]*len(names))[names.index(k)])
    d=dd.get(k)
    if kind=='right':p=p[::-1];d=d[::-1] if d else None
    profiles[k]['iso' if kind=='isosceles' else 'right'].append([h,None if amb else p,d])
 tp=ROOT/'output'/folder/'thin.json'
 if tp.exists():
  for r in records(load(str(tp.relative_to(ROOT)))):
   add(r,names)
   x=r.get('x',r['vertices'][2][0]);eps=r.get('epsilon',r['vertices'][2][1])
   for k,p in unpack(r,names).items():
    if k in profiles:profiles[k]['thin'].append([x,eps,p])

qn=['Q0m','Q0','Q1','Q2','Q3','Q4']
ingest('quantum',qn,'angle_grid_100.json','holdout_40.json')
ingest('electro_heat',grid='angle_grid_100.json',holdout='holdout_40.json')
ingest('mechanical_optical')
ingest('magnetostatics_chapter',['M'+str(i) for i in range(1,8)])
ingest('chapter_atlas_update',['L3','L4'],'prism_grid.json','prism_holdout.json','absent.json')
# The prism files have distinct names.
for target,source in [('families','prism_families'),('thin','prism_thin')]:
 x=load('output/chapter_atlas_update/'+source+'.json')
 for kind,rs in (x.items() if target=='families' else [('thin',x)]):
  for r in rs:
   add(r,['L3','L4'])
   for i,k in enumerate(['L3','L4']):
    p=r['centers'][i]
    if kind=='thin':profiles[k]['thin'].append([r['x'],r['epsilon'],p])
    else:
     d=r.get('derivative',[None,None])[i]
     if kind=='right':p=p[::-1];d=d[::-1] if d else None
     profiles[k]['iso' if kind=='isosceles' else 'right'].append([r['h'],p,d])
ingest('illumination')
for p in ['output/chapter_atlas_update/charge_grid.json','output/chapter_atlas_update/charge_holdout.json']:
 for r in load(p):add({'vertices':r['vertices'],'centers':{k:r[k] for k in ['E2','E3']},'last_change_over_diameter':{'E3':r.get('E3_last_change_D')} })
# Include the verified reference triangle as an atlas anchor.
ref=load('output/lectures/scientific_data.json')
add({'vertices':ref['vertices'],'centers':ref['centers']})

jets={}
def jet5(k,z,method):
 jets[k]={'coefficients':z,'method':method}
ej=load('output/electro_heat/equilateral_jets.json')['fits'][-1]
for k,j in ej['jets'].items():jet5(k,[j['x_x_xy'][0],j['x_x_xy'][1],*j['y_y_x2_y2']],f"Atlas fit; PDE subdivision {ej['pde_n']}, perturbation step {ej['step']}; coefficients are numerical, not certified.")
mj=load('output/mechanical_optical/equilateral_jets.json')[-1]
for k,j in mj['jets'].items():jet5(k,[j[z] for z in ['alpha','beta','gamma','delta','eta']],f"Ritz/quadrature atlas fit: degree {mj['degree']}, step {mj['step']}; refinement may change the coefficients.")
qj=load('output/quantum/equilateral_perturbation.json')
fit=qj['numerical_jets'][-1]
for k,j in fit['fits'].items():jet5(k,[*j['x_coefficients_x_xy'],*j['y_coefficients_y_x2_y2']],f"Quadratic FEM fit n={fit['n']}, step={fit['h']}. Q3 second-order terms remain sensitive to step size.")
op=qj['operators'][-1]
for k in ['Q0','Q3']:
 J=op['simple'][k]['Jacobian_apex'];jets[k]['coefficients'][0]=J[0][0];jets[k]['coefficients'][2]=J[1][1]
 jets[k]['method']+=f" First-order terms replaced by simple-eigenvalue perturbation at n={op['n']}."
j=load('output/quantum/ground_max_equilateral_response.json')[-1]
jets['Q0m']['coefficients'][0]=j['Jacobian_apex'][0][0];jets['Q0m']['coefficients'][2]=j['Jacobian_apex'][1][1]
jets['Q0m']['method']+=f" First-order maximum response refined at n={j['n']}; second-order terms from the coarser fit."
for k in ['Q1','Q2','Q4']:jets[k]={'coefficients':None,'method':'No unique Taylor expansion: the equilateral eigenvalue is degenerate. An individual eigenvector expectation depends on its basis and on the perturbation direction; use a whole-eigenspace projector for an invariant alternative.'}
mj=load('output/magnetostatics_chapter/equilateral_jets.json')[-1]
for i,k in enumerate(['M1','M2','M3','M4','M5','M6','M7']):
 if k=='M1':continue
 J=mj['apex_J'][i];jet5(k,[J[0][0],None,J[1][1],None,None],f"Atlas finite difference, quadrature n={mj['n']}, step={mj['h']}; only linear terms available.")
pj=load('output/chapter_atlas_update/prism_equilateral.json')[-1]
for i,k in enumerate(['L3','L4']):
 J=pj['jacobian'][i][2];jet5(k,[J[0][0],None,J[1][1],None,None],f"Prism boundary/frequency calculation n={pj['n']}; only linear terms available.")
from physical_centers import illuminating,solid_center
from scipy.optimize import least_squares
def optics_extra(v):
 L=np.sqrt(np.mean(np.linalg.norm(np.roll(v,-1,axis=0)-np.roll(v,-2,axis=0),axis=1)**2))
 def xy(z):
  w=np.exp(np.r_[z,0]-max(0,*z));return (w@v)/w.sum()
 def eq(z):
  p=xy(z);a=v-p;b=np.roll(a,-1,axis=0);cr=a[:,0]*b[:,1]-a[:,1]*b[:,0]
  rho=2*np.arctan2(cr,np.sum(a*b,axis=1))/cr
  return (rho[:2]-rho[2])/max(abs(rho))
 sol=least_squares(eq,[0.,0.],xtol=1e-13,ftol=1e-13,gtol=1e-13,max_nfev=300)
 if np.linalg.norm(eq(sol.x))>1e-7:raise ValueError('New illumination root unresolved')
 return {'Illum':xy(sol.x),**{'Solid'+str(h):solid_center(v,h*L) for h in [.1,1.,10.]}}
for eps in [.2,.1,.05,.025]:
 for x in np.linspace(0,1,9):
  v=np.array([[-1.,0.],[1.,0.],[x,eps]])
  cc=optics_extra(v)
  add({'vertices':v,'centers':cc})
  for k,p in cc.items():profiles[k]['thin'].append([float(x),eps,p.tolist()])
step=.005
vextra=np.array([[[-1.,0.],[1.,0.],[x,math.sqrt(3)+y]] for x in [-step,0,step] for y in [-step,0,step] if x or y])
cextra=[optics_extra(v) for v in vextra];xy=vextra[:,2,:]-[0,math.sqrt(3)]
xp=np.c_[xy[:,0],xy[:,0]*xy[:,1]];yp=np.c_[xy[:,1],xy[:,0]**2,xy[:,1]**2]
for k in ['Illum','Solid0.1','Solid1.0','Solid10.0']:
 p=np.array([c[k] for c in cextra]);z=np.r_[np.linalg.lstsq(xp,p[:,0],rcond=None)[0],np.linalg.lstsq(yp,p[:,1]-math.sqrt(3)/3,rcond=None)[0]]
 jet5(k,z.tolist(),'New numerical fit to illumination stationarity / solid-angle optimization, step 0.005; second-order optimizer coefficients are not certified.')
# Thin optical and solid-angle entries absent from the old optical atlas.
if (ROOT/'output/mechanical_optical/optical_thin_limits.json').exists():
 t=load('output/mechanical_optical/optical_thin_limits.json')
 # Keep this separate: files may contain proven limits rather than raw coordinates.

def tree(n):
 if isinstance(n,ast.Expression):return tree(n.body)
 if isinstance(n,ast.Constant):return ['num',n.value]
 if isinstance(n,ast.Name):return ['var',n.id]
 if isinstance(n,ast.UnaryOp):return ['neg',tree(n.operand)] if isinstance(n.op,ast.USub) else tree(n.operand)
 if isinstance(n,ast.BinOp):
  op={ast.Add:'add',ast.Sub:'sub',ast.Mult:'mul',ast.Div:'div',ast.Pow:'pow'}[type(n.op)]
  return [op,tree(n.left),tree(n.right)]
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name):return ['call',n.func.id,*[tree(z) for z in n.args]]
 raise ValueError(ast.dump(n))
expressions=load('tmp/etc_expressions.json')
ids=set(range(1,21))|{360}
for k in catalog:
 for r in rankings.get(k,[])[:3]:ids.add(int(r['X']))
etc={str(i):{'tree':tree(ast.parse(expressions[str(i)],mode='eval')),'expression':expressions[str(i)]} for i in sorted(ids)}
# Evaluate classical/neighbor fingerprints with the same cached ETC expressions.
h=np.geomspace(.2,6,121);epses=[.2,.1,.05,.025]
for i in ids:
 k='X'+str(i);profiles[k]={'iso':[],'right':[],'thin':[]}
 for family in ['iso','right']:
  vs=np.array([[[-1,0],[1,0],[0,t]] if family=='iso' else [[0,0],[1,0],[0,t]] for t in h])
  def ev(v):
   return evaluate(expressions[str(i)],environment(v),v)
  p=ev(vs);step=1e-5
  vp=vs.copy();vm=vs.copy();vp[:,2,1]+=step;vm[:,2,1]-=step
  deriv=(ev(vp)-ev(vm))/(2*step)
  for t,q,d in zip(h,p,deriv):profiles[k][family].append([float(t),q.tolist(),d.tolist()])
 for eps in epses:
  vs=np.array([[[-1,0],[1,0],[x,eps]] for x in np.linspace(0,1,41)])
  p=ev(vs)
  for x,q in zip(np.linspace(0,1,41),p):profiles[k]['thin'].append([float(x),eps,q.tolist()])
 # Near-equilateral least-squares fit; only expose it if continuous near the origin.
 step=.002
 vs=np.array([[[-1,0],[1,0],[x,math.sqrt(3)+y]] for x in [-step,0,step] for y in [-step,0,step] if x or y])
 p=ev(vs);xy=vs[:,2,:]-[0,math.sqrt(3)];xp=np.c_[xy[:,0],xy[:,0]*xy[:,1]];yp=np.c_[xy[:,1],xy[:,0]**2,xy[:,1]**2]
 if np.all(np.isfinite(p)) and np.max(np.linalg.norm(p-[0,math.sqrt(3)/3],axis=1))<.04:
  z=np.r_[np.linalg.lstsq(xp,p[:,0],rcond=None)[0],np.linalg.lstsq(yp,p[:,1]-math.sqrt(3)/3,rcond=None)[0]]
  jet5(k,z.tolist(),'Numerical Taylor fit to the cached ETC center function, perturbation step 0.002. Singular or discontinuous cases are omitted.')
 else:jets[k]={'coefficients':None,'method':'No regular single-valued expansion established by this evaluation; the center function is singular at or near equilateral.'}

meshes={}
for k,ss in samples.items():
 rows=list(ss.values())
 if k not in ['Q1','Q2','Q4']:
  rows.append([[math.pi/3,math.pi/3],[1/3]*3,0])
 if len(rows)>=3:
  p=np.array([r[0] for r in rows]);tri=Delaunay(p)
  meshes[k]={'points':rows,'triangles':tri.simplices.tolist()}
 # Sort and discard duplicates in profiles.
 for family in ['iso','right']:
  rows2={round(r[0],9):r for r in profiles[k][family]}
  profiles[k][family]=[rows2[t] for t in sorted(rows2)]
for k,c in catalog.items():
 c['neighbors']=rankings.get(k,[])[:3];c['alias']=aliases.get(k)
 c['group']=('Quantum' if k.startswith('Q') else 'Charge & conformal' if k.startswith(('E','S','L')) else 'Magnetism' if k.startswith('M') and not k.startswith('Mem') else 'Heat & fluids' if k.startswith(('H','F','Abs','Bio')) else 'Optics' if k.startswith(('Dark','Persist','Opt','Illum','Solid')) else 'Elasticity')
 c.pop('etc_comparison',None)
 c['jet']=jets.get(k,{'coefficients':None,'method':'No near-equilateral expansion is stored in this atlas snapshot.'})
 c['data_points']=len(samples[k])
for k,v in aliases.items():catalog[k]['jet']=jets.get(v,catalog[k]['jet'])
jets['M1']['coefficients'][0]=4/9;jets['M1']['coefficients'][2]=2/9
jets['M1']['method']='Exact linear response a=4/9, c=2/9 from field-Hessian differentiation in Q(sqrt(3)). Second-order terms use the numerical atlas fit.'
jet5('X2',[1/3,0,1/3,0,0],'Exact: uniform-area centroid.')
catalog['E4']['jet']=jets['X2']
def clean(x):
 if isinstance(x,float) and not math.isfinite(x):return None
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 if isinstance(x,list):return [clean(z) for z in x]
 return x
data=clean({'catalog':catalog,'etc':etc,'meshes':meshes,'profiles':profiles,'jets':jets,'metadata':{'date':'2026-10-01','etcsnapshot':72807,'finite_candidates':70853,'excluded_candidates':1954,'sources':sources,'reference':ref['vertices'],'reference_centers':ref['centers'],'normalization':{'iso':'A=(-1,0), B=(1,0), C=(0,h)','right':'A=(0,0), B=(1,0), C=(0,h)','thin':'A=(-1,0), B=(1,0), C=(x,epsilon)','equilateral':'A=(-1,0), B=(1,0), C=(x,sqrt(3)+y)'}}})
(OUT/'atlas.json').write_text(json.dumps(data,separators=(',',':'),allow_nan=False),encoding='utf-8')
print(json.dumps({'PITCs':len(catalog),'ETC_expressions':len(etc),'meshes':len(meshes),'bytes':(OUT/'atlas.json').stat().st_size,'missing_meshes':[k for k in catalog if k not in meshes],'no_neighbors':[k for k in catalog if not catalog[k]['neighbors']]}))
