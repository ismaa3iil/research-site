# Triangle Physics Explorer

Free static scientific web app for 66 PITCs, X1–X20, X360 and 3 ETC neighbors per PITC.

Run any static server on dist, for example:

    python -m http.server 8000 --directory dist

Open http://localhost:8000. No build, Node, Wolfram runtime, backend, paid API or account is needed to run the application.

Geometry: mouse/touch dragging; keyboard arrow keys on focused vertices; exact coordinate inputs; SVG export. Theory cards preserve mathematical definitions and evidence levels. Fingerprints show seven diagrams, numerical Taylor terms, optional ETC neighbors and JSON export. The first six axes use atan(h) in degrees. Each selected PITC has an independent +3 ETC switch; neighbors are deduplicated. Colored hover readouts interpolate each plotted curve at one common abscissa, with no extrapolation. Response units can be dc/dh or dc/dtheta per degree.

Most PITC locations are atlas interpolations, explicitly labeled. M1 and Illum use direct floating-point browser solvers. Four exact aliases use direct classical centers. Interpolation is disabled outside coverage and is not an attractivity test. Individual quantum eigenstate centers are undefined at equilateral doublets. See dist/README.html for methods and qualifications.

build_data.py regenerates the browser atlas from the enclosing original research project and its NumPy/SciPy tools. The released app already contains the generated data. The full vendor ETC database is not distributed: only 153 selected formulas are used.

Run numerical verification with:

    node verify.cjs

Original app software: MIT license. KaTeX has its own bundled MIT license. External ETC material retains its attribution and is not relicensed by this app's software license.


For the receiving team: see DEPLOY_GITHUB.md for GitHub Pages deployment and portable verification instructions.
