'use strict';
const fs=require('fs'),assert=require('assert'),M=require('./dist/math.js').TCMath,DATA=JSON.parse(fs.readFileSync(__dirname+'/dist/atlas.json','utf8'));
let passed=0,maxETC=0,maxPermutation=0;
function near(a,b,tol,label){assert(a&&b,label+': missing value');assert(M.norm(M.sub(a,b))<tol,label);passed++;}
let v=[[0,0],[4,0],[0,3]];
near(M.classical('X1',v,DATA),[1,1],1e-12,'3–4–5 incenter');
near(M.classical('X2',v,DATA),[4/3,1],1e-12,'area centroid');
near(M.classical('X3',v,DATA),[2,1.5],1e-12,'circumcenter');
near(M.classical('X4',v,DATA),[0,0],1e-12,'orthocenter');
near(M.classical('X5',v,DATA),[1,.75],1e-12,'nine-point center');
near(M.classical('X10',v,DATA),[1.5,1],1e-12,'wire centroid');
near(M.classical('X20',v,DATA),[4,3],1e-12,'de Longchamps');
near(M.classical('X360',v,DATA),[.8193310587965337,.8855017059025997],1e-10,'angle-weighted M3');
let C=M.covariance(v),W=M.covariance(v,true);
assert(Math.abs(C.matrix[0][0]-8/9)<1e-12&&Math.abs(C.matrix[0][1]+1/3)<1e-12&&Math.abs(C.matrix[1][1]-.5)<1e-12,'area covariance');passed++;
assert(Math.abs(W.matrix[0][0]-7/4)<1e-12&&Math.abs(W.matrix[0][1]+2/3)<1e-12&&Math.abs(W.matrix[1][1]-1)<1e-12,'wire covariance');passed++;
function quadratic(q,S){let d=S[0][0]*S[1][1]-S[0][1]**2;return (S[1][1]*q[0]**2-2*S[0][1]*q[0]*q[1]+S[0][0]*q[1]**2)/d;}
for(let i=0;i<3;i++){let mid=M.mul(M.add(v[i],v[(i+1)%3]),.5);assert(Math.abs(quadratic(M.sub(mid,C.center),C.matrix)/2-1)<1e-12,'Steiner midpoint tangent');passed++;}
for(let id of Object.keys(DATA.etc).map(i=>'X'+i)){for(let family of['iso','right']){let rows=DATA.profiles[id][family];for(let i of[6,34,79,114]){let [h,p]=rows[i],vv=family==='iso'?[[-1,0],[1,0],[0,h]]:[[0,0],[1,0],[0,h]],q=M.classical(id,vv,DATA);if(!p||p.some(x=>x===null)||!q)continue;let err=M.norm(M.sub(p,q))/M.geometry(vv).D;maxETC=Math.max(maxETC,err);assert(err<2e-5,id+' cached expression equivalence');passed++;}}}
let vv=[[-1,0],[1,0],[.37,1.45]],perms=[[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]];
for(let id of Object.keys(DATA.catalog)){let c=DATA.catalog[id];assert(c.neighbors.length===3||c.alias,'neighbor completeness');passed++;let p=M.interpolate(id,vv,DATA).point;if(!p)continue;for(let perm of perms){let q=M.interpolate(id,perm.map(i=>vv[i]),DATA).point;if(!q)continue;let err=M.norm(M.sub(p,q));maxPermutation=Math.max(maxPermutation,err);assert(err<2e-8,id+' atlas permutation equivariance');passed++;}
 let translated=vv.map(p=>M.add(M.mul(p,2.3),[7,-4])),q=M.interpolate(id,translated,DATA).point;if(q)near(q,M.add(M.mul(p,2.3),[7,-4]),1e-8,id+' scale/translation covariance');
 let refl=vv.map(p=>[-p[0],p[1]]),r=M.interpolate(id,refl,DATA).point;if(r)near(r,[-p[0],p[1]],1e-8,id+' reflection covariance');
}
for(let id of ['Q1','Q2','Q4']){assert(M.interpolate(id,[[-1,0],[1,0],[0,Math.sqrt(3)]],DATA).point===null,'Quantum doublet must be undefined');passed++;}
let mag=M.liveM1(v);near(mag,DATA.metadata.reference_centers.M1,1e-5,'live M1 reference location');
let ill=M.liveIllum(v);near(ill,DATA.metadata.reference_centers.Illum,1e-7,'live Illum reference location');
for(let perm of perms){near(M.liveM1(perm.map(i=>v[i])),mag,2e-6,'M1 permutation');near(M.liveIllum(perm.map(i=>v[i])),ill,2e-7,'Illum permutation');}
assert(!M.geometry([[0,0],[1,0],[2,0]]).valid,'degeneracy guard');passed++;
for(let id of Object.keys(DATA.catalog)){for(let family of['iso','right','thin'])assert(DATA.profiles[id][family].length>0,id+' '+family+' fingerprint coverage');passed++;assert(DATA.catalog[id].jet,'Taylor record present');passed++;}
const report={date:'2026-10-01',passed,max_ETC_equivalence_error_over_D:maxETC,max_atlas_permutation_error:maxPermutation,M1_reference:mag,Illum_reference:ill,scope:'Exact geometry identities, all 153 selected ETC expression evaluations against exported Python samples, six vertex permutations, reflection/scaling/translation covariance, quantum doublet guards, live solver reference checks, atlas profiles and Taylor-record coverage. These are software verification checks, not continuum certificates.'};
fs.writeFileSync(__dirname+'/dist/verification.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
