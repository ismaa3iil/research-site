# Team handoff: Triangle Physics Explorer

Prepared 2 October 2026. This package includes the latest angular fingerprint,
comparison color, shared hover readout, and per-PITC neighbor controls.

## Deploy through GitHub Pages

1. Extract the ZIP. Put the CONTENTS of Triangle_Physics_Explorer at your repository
   root. Include the hidden .github directory. The root should contain dist,
   .github/workflows/pages.yml, README.md, and LICENSE.
2. Create or choose your GitHub repository and commit the files on main. If your
   publishing branch has another name, change the workflow branch list first.
3. In the repository, choose Settings > Pages > Build and deployment > Source >
   GitHub Actions. Enable Actions if your repository or organization disables them.
4. Push a commit or run Deploy explorer to GitHub Pages from the Actions tab.
5. The workflow's github-pages environment shows the deployed website URL.

The workflow publishes dist only. No application build, npm dependency installation,
Wolfram runtime, backend, or paid API is required. Paths are relative, so a project
URL such as https://TEAM.github.io/REPOSITORY/ is supported. There is no router or
custom domain to configure. Optional: set a canonical URL in dist/index.html after
the final public URL is known.

Workflow reference (checked 2 October 2026):
https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages

## Preview locally

From the extracted repository root:

    python -m http.server 8000 --bind 127.0.0.1 --directory dist

Open http://127.0.0.1:8000/ . Use a server: directly opening index.html as a file
can prevent the browser from fetching atlas.json. All runtime assets are bundled,
including KaTeX and its fonts; the app needs no external CDN.

## Verify

With Node.js installed:

    node verify.cjs
    node verify_fingerprints.cjs

These scripts use Node built-ins only. The retained reports record 1,973 geometry,
ETC, atlas and solver checks, 22 angular fingerprint checks, and desktop/mobile
browser checks. Software checks are not mathematical proofs or continuum
certificates. Actual certificate records are in dist/certificates.

Optional browser regression test, with the local server running in another terminal:

    npm install --no-save --package-lock=false playwright
    npx playwright install chromium
    node browser_check.cjs

The script defaults to http://127.0.0.1:8000/ and Playwright's Chromium. Optional
environment variables: EXPLORER_URL changes the test URL; CHROME_PATH selects an
installed Chromium/Chrome executable. Screenshots are written to qa/ (gitignored).
The browser suite changes the app only within its isolated test browser.

## Contents and research qualifications

- dist: deployable app, 66 PITC datasets, 153 selected ETC formulas, four certificate
  records, mathematical rendering assets, and a downloadable source ZIP.
- README.md and dist/README.html: features, numerical methods and provenance.
- LICENSE and dist/vendor/katex/LICENSE: application and bundled library licenses.
- build_data.py: research-data export script. Regenerating atlas.json requires the
  original enclosing research workspace plus NumPy/SciPy and its data files; this
  ZIP contains the precomputed atlas and is sufficient to run and deploy the app.
- SHA256SUMS.txt: SHA-256 hashes of all supplied files except the hash list itself.

Retain the ETC attribution and evidence qualifications. The application's MIT
license covers original code; it does not relicense external ETC material.
Most PITC locations are atlas interpolations; saved profiles are not extrapolated.
Attractivity evidence and equilateral quantum degeneracies are shown explicitly.

This package contains no hosting credentials, .openai registration, git history,
original research PDFs, or full vendor ETC database. The package has been prepared
locally; it has not been uploaded to GitHub or published by this handoff operation.
