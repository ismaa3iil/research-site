"""Lightweight numerical evaluators for the newly certified triangle centers.

Proofs and exact parameter values are in SHAPE_DEPENDENT_REPORT.md and the
certificate files. These evaluators are not a certification algorithm.
"""
import numpy as np
from omega_support import triangle_centers

SIMPLE=(2/5,6/5,-3/2,5/2)
SECOND=(2/5,1,-3/2,14/5)
THIRD=(3/8,1,-7/5,5/2)
RADIAL_LOWER=10478284289/10000000000
NEAR_BOUNDARY=tuple(RADIAL_LOWER*c for c in SIMPLE)


def shape_invariant(vertices):
    p=np.asarray(vertices,float)
    squared=np.array([np.sum((p[1]-p[2])**2),np.sum((p[2]-p[0])**2),np.sum((p[0]-p[1])**2)])
    if squared.sum()<=0:raise ValueError('all vertices coincide')
    sides=squared/squared.sum()
    return float((3*np.sum(sides*sides)-1)/2)


def center(vertices,coefficients=SIMPLE):
    f0,f1,g0,g1=coefficients
    q=shape_invariant(vertices)
    return triangle_centers(vertices,[f0+f1*q,g0+g1*q])[0]


def barycentric_weights(vertices,coefficients=SIMPLE):
    p=np.asarray(vertices,float)
    squared=np.array([np.sum((p[1]-p[2])**2),np.sum((p[2]-p[0])**2),np.sum((p[0]-p[1])**2)])
    if squared.sum()<=0:raise ValueError('all vertices coincide')
    ss=squared/squared.sum();q=(3*np.sum(ss*ss)-1)/2
    f0,f1,g0,g1=coefficients;f=f0+f1*q;g=g0+g1*q
    return 1/3+(f+4*g)*(ss-1/3)-6*g*(ss*ss-np.mean(ss*ss))
