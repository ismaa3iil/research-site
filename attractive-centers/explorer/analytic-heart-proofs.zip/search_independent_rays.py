"""Bounded serial discovery of distinct shape-dependent rays (not a proof)."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import json,time
from fractions import Fraction
import numpy as np
from scipy.optimize import differential_evolution, minimize, minimize_scalar
from search_shape_dependent import numerical_basis

HERE=Path(__file__).resolve().parent


def radial_minimum(cf,basis):
    def fun(point):
        abc=(basis(np.array([2*point[0]/3]),np.array([point[1]]))@cf)[0]
        a,b,c=abc
        return float((a+c-np.hypot(a-c,2*b))/2)
    trial=differential_evolution(fun,[(0,1),(0,1)],seed=20261016,
          maxiter=180,popsize=12,tol=1e-11,atol=1e-12,workers=1,polish=True)
    points=[(float(trial.fun),trial.x.tolist())]
    grid=np.linspace(0,1,65)
    for axis in [0,1]:
        for end in [0.,1.]:
            def edge(t):
                p=[t,t];p[axis]=end
                return fun(p)
            values=[edge(t) for t in grid]
            for i in range(1,len(grid)-1):
                if values[i]<=values[i-1] and values[i]<=values[i+1]:
                    sol=minimize_scalar(edge,bounds=(grid[i-1],grid[i+1]),method='bounded',
                                        options={'xatol':1e-14})
                    p=[float(sol.x),float(sol.x)];p[axis]=end
                    points.append((float(sol.fun),p))
            for t in [0.,1.]:
                p=[t,t];p[axis]=end;points.append((fun(p),p))
    best=min(points,key=lambda x:x[0])
    return dict(minimum_perturbation_eigenvalue=best[0],
                z=2*best[1][0]/3,h=best[1][1],lambda_estimate=-1/best[0])


def main():
    start=time.monotonic();basis=numerical_basis()
    rows=json.loads((HERE/'SHAPE_DEPENDENT_SEARCH.json').read_text())['candidates']
    objectives=np.array([row['objective'] for row in rows]);G=np.array([row['G'] for row in rows])
    old=np.array([row['baseline'] for row in rows])
    prior=np.array([.4,1.2,-1.5,2.5])*1.0478284289
    baseline=np.maximum(old,G+objectives@prior)
    ranked=sorted(rows,key=lambda row:row['G']+np.dot(row['objective'],row['coefficients'])-
                  max(row['baseline'],row['G']+np.dot(row['objective'],prior)),reverse=True)
    seeds=[]
    for row in ranked:
        cf=np.round(np.array(row['coefficients'])*20)/20
        if any(np.linalg.norm(cf/np.linalg.norm(cf)-oldcf/np.linalg.norm(oldcf))<.06 for oldcf in seeds):continue
        seeds.append(cf)
        if len(seeds)==12:break
    candidates=[]
    for i,cf in enumerate(seeds):
        opt=radial_minimum(cf,basis)
        lam=np.floor(opt['lambda_estimate']*1e8-2)/1e8
        vals=G+objectives@(lam*cf)
        gain=vals-baseline;j=int(np.argmax(gain))
        row=dict(seed=[str(Fraction(float(x)).limit_denominator(20)) for x in cf],
                 discovery=opt,trial_lambda=lam,maximum_gain_over_prior=float(gain[j]),
                 witness_target=rows[j])
        candidates.append(row)
        print('ray',i+1,row['seed'],'lambda',opt['lambda_estimate'],'gain',gain[j],flush=True)
    # Greedily select only rays that still add a positive support after earlier rays.
    current=baseline.copy();chosen=[];remaining=list(range(len(candidates)))
    for step in range(6):
        improvements=[]
        for i in remaining:
            row=candidates[i];cf=np.array([float(Fraction(x)) for x in row['seed']])*row['trial_lambda']
            values=G+objectives@cf;gain=values-current;j=int(np.argmax(gain))
            improvements.append((float(gain[j]),i,j,values))
        gain,i,j,values=max(improvements,key=lambda x:x[0])
        if gain<1e-5:break
        row=dict(candidates[i],label='R'+str(step+1),greedy_gain=gain,witness_target=rows[j])
        chosen.append(row);current=np.maximum(current,values);remaining.remove(i)
    result=dict(status='NUMERICAL DISCOVERY ONLY; global proof still required',
                search='12 rationalized rays from previous 168 support optimizations; all scalar searches bounded and serial',
                selected=chosen,candidates=candidates,seconds=round(time.monotonic()-start,3))
    (HERE/'INDEPENDENT_RAYS_SEARCH.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(seconds=result['seconds'],selected=[{k:row[k] for k in ['label','seed','greedy_gain','discovery']} for row in chosen]),indent=2))


if __name__=='__main__':main()
