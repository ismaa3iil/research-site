"""Independent bounded verification of the formulas in the incoming report.

Derives the six-parameter response directly before coordinate normalization,
then generates AND independently replays exact rational Bernstein covers.
This does not rely on the report's unavailable certificate files.
"""
from pathlib import Path
import json,time
from fractions import Fraction
import numpy as np
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
from prove_boundary_arc import certify,bernstein,bisect
from verify_boundary_arc import replay,bernstein_minimum
from verify_shape_dependent import independent_matrix

HERE=Path(__file__).resolve().parent
RAYS=[
 ('R7',['3/5','0','0','-29/20','2','0'],94423179),
 ('R8',['1','4/3','0','-1/2','-7/10','0'],99579960),
 ('R9',['0','-12/5','0','8/5','-9/2','0'],91081582),
 ('R10',['1/2','-7/5','0','-2','9','0'],96617699),
 ('P1',['3/5','1/10','-3/5','-8/5','3','7/10'],101367358),
 ('P2',['1/5','-14/5','1/5','13/10','-7/5','-1/5'],95069548),
 ('P3',['4/5','11/5','-1/5','-4/5','-4/5','2/5'],99773390)
]


def direct_six():
    names='r,X,Y,f0,fq,fp,g0,gq,gp'
    R,*syms=ring(names,QQ);r,X,Y,f0,fq,fp,g0,gq,gp=syms
    T,*ts=ring('z,u,v,f0,fq,fp,g0,gq,gp',QQ)
    z,u,v,*cs=ts
    p=[(r,R.zero),(-r/2+X,Y),(-r/2-X,-Y)]
    A=[4*(X*X+Y*Y),(3*r/2+X)**2+Y*Y,(3*r/2-X)**2+Y*Y]
    Q=sum(A,R.zero);A2=sum((a*a for a in A),R.zero)
    qn=Q*Q-3*(A[0]*A[1]+A[1]*A[2]+A[2]*A[0])
    pn=sum(((3*a-Q)**3 for a in A),R.zero)*QQ(4,3)
    fn=f0*Q**3+fq*qn*Q+fp*pn;gn=g0*Q**3+gq*qn*Q+gp*pn
    N=[Q**5+(fn+4*gn)*(3*a-Q)*Q-6*gn*(3*a*a-A2) for a in A]
    D=3*Q**5;assert sum(N,R.zero)==D
    center=[sum((N[i]*p[i][j] for i in range(3)),R.zero) for j in range(2)]
    J=[[R.zero,R.zero],[R.zero,R.zero]]
    for col,da in enumerate([[R.zero,3*r+2*X,3*r-2*X],[R.zero,2*Y,-2*Y]]):
        dq=sum(da,R.zero)
        de2=sum((da[i]*sum((A[j] for j in range(3) if j!=i),R.zero) for i in range(3)),R.zero)
        dqn=2*Q*dq-3*de2
        dpn=4*sum(((3*A[i]-Q)**2*(3*da[i]-dq) for i in range(3)),R.zero)
        dfn=3*f0*Q*Q*dq+fq*(dqn*Q+qn*dq)+fp*dpn
        dgn=3*g0*Q*Q*dq+gq*(dqn*Q+qn*dq)+gp*dpn
        dA2=2*sum((A[i]*da[i] for i in range(3)),R.zero)
        dn=[5*Q**4*dq+(dfn+4*dgn)*(3*A[i]-Q)*Q+
            (fn+4*gn)*((3*da[i]-dq)*Q+(3*A[i]-Q)*dq)-
            6*dgn*(3*A[i]**2-A2)-6*gn*(6*A[i]*da[i]-dA2) for i in range(3)]
        dd=15*Q**4*dq
        for row in range(2):
            dc=(N[0] if row==col else R.zero)+sum((dn[i]*p[i][row] for i in range(3)),R.zero)
            J[row][col]=dc*D-center[row]*dd
    def normalize(poly,off=False):
        if off:poly=poly.exquo(X*Y)
        out=T.zero
        for powers,coef in poly.items():
            assert all(e%2==0 for e in powers[:3])
            term=coef*z**(powers[0]//2)*u**(powers[1]//2)*v**(powers[2]//2)
            for c,e in zip(cs,powers[3:]):term*=c**e
            out+=term
        return s.expand(out.compose(u,(2-3*z)/4-v).as_expr())
    denom=normalize(D*D);assert denom==531441
    result=dict(a=normalize(3*J[0][0])/denom,
                b=normalize(3*(J[0][1]+J[1][0])/2,True)/denom,
                c=normalize(3*J[1][1])/denom)
    return {k:s.expand(v) for k,v in result.items()}


def certify_pair(det,remainder,variables,seconds=25):
    start=time.monotonic();count=0
    def walk(d,r,levels,depth):
        nonlocal count
        count+=1
        if time.monotonic()-start>seconds or count>12000 or depth>60:raise TimeoutError('bounded collar cover exhausted')
        for name,values in [('det',d),('remainder',r)]:
            low=min(values.flat)
            if low>=0:return dict(accepted=name,minimum=str(low))
        axis=min(range(len(variables)),key=lambda i:levels[i]);nl=levels.copy();nl[axis]+=1
        ds=bisect(d,axis);rs=bisect(r,axis)
        return dict(axis=axis,children=[walk(dd,rr,nl,depth+1) for dd,rr in zip(ds,rs)])
    return walk(bernstein(det,variables),bernstein(remainder,variables),[0]*len(variables),0)


def replay_pair(det,remainder,variables,node):
    if 'accepted' in node:
        poly=det if node['accepted']=='det' else remainder
        low=bernstein_minimum(poly,variables);assert low>=0 and low==s.Rational(node['minimum'])
        return 1
    axis=node['axis'];assert 0<=axis<len(variables) and len(node['children'])==2
    var=variables[axis]
    return sum(replay_pair(s.expand(det.subs(var,(var+i)/2)),s.expand(remainder.subs(var,(var+i)/2)),variables,child) for i,child in enumerate(node['children']))


def main():
    if not __debug__:raise RuntimeError('Assertions required.')
    start=time.monotonic();matrix=direct_six()
    z,v,f0,fq,fp,g0,gq,gp,Z,H,t=s.symbols('z v f0 fq fp g0 gq gp Z H t')
    symbols=[f0,fq,fp,g0,gq,gp]
    previous=independent_matrix()
    for name in matrix:
        assert s.expand(matrix[name].subs({fp:0,gp:0,fq:s.Symbol('f1'),gq:s.Symbol('g1')})-previous[name])==0
    result=dict(status='verification in progress',date='2026-10-17',matrix={k:str(p) for k,p in matrix.items()},records=[])
    for label,seed,integer in RAYS:
        cf=[s.Rational(integer,10**8)*s.Rational(c) for c in seed]
        a,b,c=[s.expand(matrix[k].subs(dict(zip(symbols,cf)))) for k in ['a','b','c']]
        delta=s.Rational(1,10**10);V=(2-3*z)/4;tasks=[]
        for name,poly in [('diagonal',a-delta),('determinant',(a-delta)*(c-delta)-v*(V-v)*b*b)]:
            unit=s.expand(poly.subs({z:2*Z/3,v:(1-Z)*H/2},simultaneous=True))
            proof=certify(unit,[Z,H],seconds=20,max_depth=70,max_nodes=12000)
            leaves=replay(unit,[Z,H],proof['tree'])
            tasks.append(dict(name=name,certificate=proof,leaves=leaves))
        result['records'].append(dict(id=label,coefficients=list(map(str,cf)),status='globally attractive lower map independently certified',scaled_margin=str(delta),tasks=tasks))
        print(label,'PASS',flush=True)
        (HERE/'INCOMING_ENLARGEMENT_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
    c2=s.Matrix(list(map(s.Rational,['3/4','23/10','-1','6/5'])))
    c5=s.Matrix(list(map(s.Rational,['9/20','6/5','-8/5','13/5'])))
    bow=s.Matrix(list(map(s.Rational,['-1/4','1','3/10','-6/5'])))
    D=1329*t*t+2042*t+9081
    bridge=(640*(5*t+14)*((1-t)*c2+t*c5)+10560*t*(1-t)*bow)/D
    for label,four,den,params in [('R2_star',s.Rational(8960,9081)*c2,s.Integer(1),[]),
                                 ('R5_star',s.Rational(3040,3113)*c5,s.Integer(1),[]),
                                 ('Bridge',bridge,D,[t])]:
        cf=[four[0],four[1],0,four[2],four[3],0]
        A,B,C=[s.expand(s.cancel(den*matrix[k].subs(dict(zip(symbols,cf))))) for k in ['a','b','c']]
        flatA=s.factor(A.subs(v,0));flatC=s.factor(C.subs(v,0))
        coefficient,factors=s.factor_list(flatC);assert coefficient>0 and all(e%2==0 for p,e in factors)
        det=s.expand(A*C-v*((2-3*z)/4-v)*B*B)
        unit=lambda p:s.expand(p.subs({z:2*Z/3,v:(1-Z)*H/2},simultaneous=True))
        variables=[Z,H]+params
        diag=certify(unit(A),variables,seconds=25,max_depth=60,max_nodes=12000)
        assert s.Rational(diag['minimum_leaf_coefficient'])>0
        replay(unit(A),variables,diag['tree'])
        flat=certify(s.expand(flatA.subs(z,2*Z/3)),[Z]+params,seconds=20,max_depth=60)
        replay(s.expand(flatA.subs(z,2*Z/3)),[Z]+params,flat['tree'])
        # det = flatA*flatC + H*R; flatA and flatC are nonnegative.
        detunit=unit(det);rest=s.cancel((detunit-s.expand(detunit.subs(H,0)))/H)
        assert s.denom(rest)==1
        cover=certify_pair(detunit,s.expand(rest),variables)
        leaves=replay_pair(detunit,s.expand(rest),variables,cover)
        result['records'].append(dict(id=label,status='globally attractive exact map or full continuous bridge independently certified',
          four_coefficients=list(map(str,four)),denominator=str(den),flat_c_square=str(flatC),
          diagonal=diag,flat_a=flat,determinant_or_remainder_cover=cover,cover_leaves=leaves))
        print(label,'PASS; determinant cover',leaves,flush=True)
        (HERE/'INCOMING_ENLARGEMENT_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
    result['status']='PASS: all supplied explicit maps and the full bridge have fresh global attractivity proofs'
    result['seconds']=round(time.monotonic()-start,3)
    result['scope']='Attractivity only. Supplied new sharpness, nonredundancy and 1389-shape audit claims were not replayed.'
    (HERE/'INCOMING_ENLARGEMENT_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'],result['seconds'],flush=True)


if __name__=='__main__':main()
