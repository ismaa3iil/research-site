"""Standalone independent exact verifier for all four Heart-enlargement extensions:
1. Zero-backoff (delta=0) global radial endpoint certificates for R2* = 8960/9081 and R5* = 3040/3113,
   plus exact algebraic proof of radial sharpness for all lambda > lambda*.
2. Continuous 3D Bernstein certificate (delta=0, 78 leaves across 5 sub-domains) for the repaired
   rational quadratic (conic) bridge c_bridge(t) on t in [0, 1].
3. Exact 2D Bernstein lower certificates and rational upper non-attractivity witnesses (width 3e-8)
   for the four new Omega_4 rays R7, R8, R9, R10.
4. Direct Cartesian ring derivation and product-rule verification of the 6-parameter cubic-phase
   moving-radius matrix M(z, v; f0, f1, f2, g0, g1, g2) for p = 36*R3, plus exact 2D Bernstein
   lower certificates and upper counterexamples for P1, P2, P3.
5. Exact rational leave-one-out separation replay for all 8 additions (Bridge_Mid, R7..R10, P1..P3)
   against B46 (including interval-bounded M_-, M_+), the entire constant domain Omega_K,HK,
   all 4 previous shape maps, R1..R6, R2*, R5*, and the continuous conic bridge c_bridge([0, 1]).
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import json, time, sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import numpy as np
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
from verify_shape_dependent import independent_matrix, leaf_minimum
from ray_separation_common import poly_value, shape_data, weights, omega_constraint, power_support


def replay_ring_exact(polynomial, variables, tree):
    """Independently replay a Bernstein subdivision tree by substituting the exact sub-box
    coordinates (var + side)/2 in QQ[variables] and computing the fresh Bernstein minimum
    at each leaf via exact rational binomial contraction (independent of de Casteljau bisection).
    """
    R, *rvars = ring(','.join(map(str, variables)), QQ)
    sp_poly = s.Poly(polynomial, *variables)
    degrees = sp_poly.degree_list()
    p_root = R.zero
    for powers, c in sp_poly.terms():
        term = QQ(int(c.p), int(c.q))
        for rv, pw in zip(rvars, powers):
            if pw:
                term *= rv**pw
        p_root += term

    binom_mats = [
        [[F(comb(i, k), comb(d, k)) for k in range(i + 1)] for i in range(d + 1)]
        for d in degrees
    ]

    def leaf_bernstein_min(p_ring):
        arr = np.full(tuple(d + 1 for d in degrees), F(0), dtype=object)
        for powers, c in p_ring.items():
            arr[powers] = F(int(c.numerator), int(c.denominator))
        for axis, (d, bmat) in enumerate(zip(degrees, binom_mats)):
            a = np.moveaxis(arr, axis, 0)
            out = np.empty_like(a)
            for i in range(d + 1):
                row_i = bmat[i]
                acc = a[0] * row_i[0]
                for k in range(1, i + 1):
                    acc = acc + a[k] * row_i[k]
                out[i] = acc
            arr = np.moveaxis(out, 0, axis)
        least = min(arr.flat)
        return s.Rational(least.numerator, least.denominator)

    def walk(p_ring, node):
        if node.get('nonnegative'):
            minimum = leaf_bernstein_min(p_ring)
            assert minimum >= 0
            assert minimum == s.Rational(node['minimum'])
            return 1
        axis = node['axis']
        assert 0 <= axis < len(rvars)
        assert len(node['children']) == 2
        var = rvars[axis]
        return sum(
            walk(p_ring.compose(var, (var + side) / QQ(2)), child)
            for side, child in enumerate(node['children'])
        )

    return walk(p_root, tree)


def independent_matrix_6param(m4):
    z, v, f0, f1, f2, g0, g1, g2 = s.symbols('z v f0 f1 f2 g0 g1 g2')
    old_f0, old_g0 = s.symbols('f0 g0')
    V = (2 - 3 * z) / 4
    u = V - v
    p_inv = (1 - 3 * z) * (36 * z**2 - 24 * z + 1 + 36 * z * v)

    kx = s.Rational(3, 2) - 3 * z - 2 * v
    hx = s.Rational(3, 2) - 3 * z + (6 * z - 4) * v
    gp_x = 6 * (4 * v * (27 * z**2 - 18 * z + 2) + 3 * (36 * z**3 - 48 * z**2 + 19 * z - 2))
    gp_y = 48 * (3 * z - 1)

    extraK_p = [
        s.expand(3 * z * kx * gp_x),
        s.expand(s.Rational(3, 2) * z * (kx * gp_y + 2 * gp_x)),
        s.expand(6 * z * u * v * gp_y),
    ]
    extraHK_p = [
        s.expand(3 * z * hx * gp_x),
        s.expand(s.Rational(3, 2) * z * (hx * gp_y + 4 * (1 - 3 * z) * gp_x)),
        s.expand(12 * z * u * v * (1 - 3 * z) * gp_y),
    ]
    m6 = {}
    for key, ekp, ehp in zip(['a', 'b', 'c'], extraK_p, extraHK_p):
        base4 = m4[key]
        uu = s.expand(base4.coeff(old_f0))
        vv = s.expand(base4.coeff(old_g0))
        m6[key] = s.expand(base4 + f2 * (p_inv * uu + ekp) + g2 * (p_inv * vv + ehp))

    R, r, X, Y = ring('r,X,Y', QQ)
    T, zr, ur, vr = ring('z,u,v', QQ)
    Q, zq, vq = ring('z,v', QQ)
    pts = [(r, R.zero), (-r / 2 + X, Y), (-r / 2 - X, -Y)]
    A = [4 * (X * X + Y * Y), (3 * r / 2 + X)**2 + Y * Y, (3 * r / 2 - X)**2 + Y * Y]
    q_sum = sum(A, R.zero)
    P_num = 4 * sum(((3 * a - q_sum)**3 for a in A), R.zero)
    da_cols = [[R.zero, 3 * r + 2 * X, 3 * r - 2 * X], [R.zero, 2 * Y, -2 * Y]]

    def normalize(poly, offdiag=False):
        if offdiag:
            poly = poly.exquo(X * Y)
        transformed = T.zero
        for (i, j, k), coef in poly.items():
            assert i % 2 == j % 2 == k % 2 == 0
            transformed += coef * zr**(i // 2) * ur**(j // 2) * vr**(k // 2)
        transformed = transformed.compose(ur, (2 - 3 * zr) / 4 - vr)
        result = Q.zero
        for (i, j, k), coef in transformed.items():
            assert j == 0
            result += coef * zq**i * vq**k
        return result.as_expr()

    assert s.expand(normalize(P_num) / 81 - p_inv) == 0
    for mode, sym_var in [('f2', f2), ('g2', g2)]:
        if mode == 'f2':
            N = [P_num * (3 * a - q_sum) for a in A]
            D = 9 * q_sum**4
            deg_q = 4
        else:
            sum_A2 = sum((b * b for b in A), R.zero)
            N = [P_num * (4 * q_sum * (3 * a - q_sum) - 6 * (3 * a * a - sum_A2)) for a in A]
            D = 9 * q_sum**5
            deg_q = 5
        assert sum(N, R.zero) == R.zero
        center_vec = [sum((N[i] * pts[i][j] for i in range(3)), R.zero) for j in range(2)]
        J = [[R.zero, R.zero], [R.zero, R.zero]]
        for col, da in enumerate(da_cols):
            dq = sum(da, R.zero)
            dP_num = 12 * sum(((3 * A[i] - q_sum)**2 * (3 * da[i] - dq) for i in range(3)), R.zero)
            if mode == 'f2':
                dn = [dP_num * (3 * A[i] - q_sum) + P_num * (3 * da[i] - dq) for i in range(3)]
            else:
                sum_A2 = sum((b * b for b in A), R.zero)
                d_sum_A2 = 2 * sum((A[m] * da[m] for m in range(3)), R.zero)
                dn = [
                    dP_num * (4 * q_sum * (3 * A[i] - q_sum) - 6 * (3 * A[i]**2 - sum_A2))
                    + P_num * (4 * dq * (3 * A[i] - q_sum) + 4 * q_sum * (3 * da[i] - dq) - 6 * (6 * A[i] * da[i] - d_sum_A2))
                    for i in range(3)
                ]
            dd = 9 * deg_q * q_sum**(deg_q - 1) * dq
            for row in range(2):
                dz = (N[0] if row == col else R.zero) + sum((dn[i] * pts[i][row] for i in range(3)), R.zero)
                J[row][col] = dz * D - center_vec[row] * dd
        denom_val = (9 * 3**deg_q)**2
        assert s.expand(normalize(3 * J[0][0]) / denom_val - m6['a'].coeff(sym_var)) == 0
        assert s.expand(normalize(3 * (J[0][1] + J[1][0]) / 2, True) / denom_val - m6['b'].coeff(sym_var)) == 0
        assert s.expand(normalize(3 * J[1][1]) / denom_val - m6['c'].coeff(sym_var)) == 0
    return m6


def weights_any(sides, coefficients):
    cf = [s.Rational(x) for x in coefficients]
    if len(cf) == 4:
        return weights(sides, cf)
    q, k, hk = shape_data(sides)
    sq = s.Matrix([s.Integer(a)**2 for a in sides])
    ss = sq / sum(sq)
    p = 36 * sum((ss[i] - s.Rational(1, 3))**3 for i in range(3))
    f0, f1, f2, g0, g1, g2 = cf
    return s.ones(3, 1) / 3 + (f0 + f1 * q + f2 * p) * k + (g0 + g1 * q + g2 * p) * hk


def main():
    if not __debug__:
        raise RuntimeError('Assertions required; do not run with -O.')
    t0 = time.monotonic()
    m4 = independent_matrix()
    m6 = independent_matrix_6param(m4)
    saved_m6 = json.loads((HERE / 'CUBIC_PHASE_MATRIX.json').read_text())['matrix']
    for k in ['a', 'b', 'c']:
        assert s.expand(m6[k] - s.sympify(saved_m6[k])) == 0
    print("1. Direct Cartesian & product-rule verification of 4-param and 6-param matrices: PASS", flush=True)

    z, v, t, f0, f1, g0, g1, Z, H, T = s.symbols('z v t f0 f1 g0 g1 Z H T')
    bridge_bundle = json.loads((HERE / 'CONIC_BRIDGE_CERTIFICATE.json').read_text())
    flat_checked = []
    for row, (Z_lo, Z_hi) in zip(
        bridge_bundle['exact_flat_endpoints'],
        [(s.Rational(27, 40), s.Rational(33, 40)), (s.Rational(21, 40), s.Rational(27, 40))],
    ):
        seed = [s.Rational(x) for x in row['seed']]
        lam_star = s.Rational(row['lambda_star'])
        cf = [s.Rational(x) for x in row['coefficients']]
        assert cf == [lam_star * x for x in seed]
        denom = lam_star.q
        a = s.expand(denom * m4['a'].subs(dict(zip([f0, f1, g0, g1], cf))))
        b = s.expand(denom * m4['b'].subs(dict(zip([f0, f1, g0, g1], cf))))
        c = s.expand(denom * m4['c'].subs(dict(zip([f0, f1, g0, g1], cf))))
        V = (2 - 3 * z) / 4
        det = s.expand(a * c - v * (V - v) * b * b)
        a0 = s.expand(a.subs(v, 0))
        c0 = s.expand(c.subs(v, 0))
        z_star = s.Rational(row['collinear_root_z_star'])
        assert s.expand(c0.subs(z, z_star)) == 0 and s.expand(s.diff(c0, z).subs(z, z_star)) == 0
        rem = s.expand(s.cancel((det - a0 * c0) / v))
        assert s.expand(det - (a0 * c0 + v * rem)) == 0

        Z_collar = Z_lo + (Z_hi - Z_lo) * Z
        Z_left = Z_lo * Z
        Z_right = Z_hi + (1 - Z_hi) * Z
        expected_polys = {
            'a_positive': s.expand((a - 1).subs({z: 2 * Z / 3, v: (1 - Z) * H / 2}, simultaneous=True)),
            'collar_remainder': s.expand(rem.subs({z: 2 * Z_collar / 3, v: (1 - Z_collar) * (H / 16) / 2}, simultaneous=True)),
            'det_outer_H': s.expand(det.subs({z: 2 * Z / 3, v: (1 - Z) * (s.Rational(1, 16) + s.Rational(15, 16) * H) / 2}, simultaneous=True)),
            'det_left_Z': s.expand(det.subs({z: 2 * Z_left / 3, v: (1 - Z_left) * (H / 16) / 2}, simultaneous=True)),
            'det_right_Z': s.expand(det.subs({z: 2 * Z_right / 3, v: (1 - Z_right) * (H / 16) / 2}, simultaneous=True)),
        }
        assert [tk['name'] for tk in row['tasks']] == list(expected_polys.keys())
        leaves_list = []
        for tk in row['tasks']:
            unit = expected_polys[tk['name']]
            assert s.expand(unit - s.sympify(tk['unit_polynomial'])) == 0
            proof = tk['certificate']
            replayed = replay_ring_exact(unit, [Z, H], proof['tree'])
            assert replayed == proof['leaves']
            assert leaf_minimum(proof['tree']) == s.Rational(proof['minimum_leaf_coefficient']) >= 0
            leaves_list.append(replayed)
        flat_checked.append(dict(label=row['label'], lambda_star=str(lam_star), leaves=leaves_list, status='PASS'))
        print(f"2a. Zero-backoff endpoint {row['label']} (lambda* = {lam_star}): PASS ({sum(leaves_list)} leaves)", flush=True)

    bcert = bridge_bundle['conic_bridge']
    left = s.Matrix([s.Rational(x) for x in ['3/4', '23/10', '-1', '6/5']])
    right = s.Matrix([s.Rational(x) for x in ['9/20', '6/5', '-8/5', '13/5']])
    bow = s.Matrix([s.Rational(x) for x in ['-1/4', '1', '3/10', '-6/5']])
    D_t = 1329 * t**2 + 2042 * t + 9081
    num_cf = [s.expand(640 * (5 * t + 14) * ((1 - t) * left[i] + t * right[i]) + 10560 * t * (1 - t) * bow[i]) for i in range(4)]
    a_sc = s.expand(D_t + (m4['a'] - 1).subs(dict(zip([f0, f1, g0, g1], num_cf))))
    b_sc = s.expand(m4['b'].subs(dict(zip([f0, f1, g0, g1], num_cf))))
    c_sc = s.expand(D_t + (m4['c'] - 1).subs(dict(zip([f0, f1, g0, g1], num_cf))))
    V = (2 - 3 * z) / 4
    det_sc = s.expand(a_sc * c_sc - v * (V - v) * b_sc**2)
    a0_sc = s.expand(a_sc.subs(v, 0))
    c0_sc = s.expand(c_sc.subs(v, 0))
    assert s.expand(c0_sc - (120 * t * z - 17 * t + 336 * z - 165)**2) == 0
    rem_sc = s.expand(s.cancel((det_sc - a0_sc * c0_sc) / v))
    assert s.expand(det_sc - (a0_sc * c0_sc + v * rem_sc)) == 0

    Z_lo = s.Rational(27, 40) - s.Rational(6, 40) * T
    Z_hi = s.Rational(33, 40) - s.Rational(6, 40) * T
    Z_collar = Z_lo + (Z_hi - Z_lo) * Z
    Z_left = Z_lo * Z
    Z_right = Z_hi + (1 - Z_hi) * Z
    expected_3d = {
        'a_scaled_minus_1': s.expand((a_sc - 1).subs({z: 2 * Z / 3, v: (1 - Z) * H / 2, t: T}, simultaneous=True)),
        'collar_remainder': s.expand(rem_sc.subs({z: 2 * Z_collar / 3, v: (1 - Z_collar) * (H / 16) / 2, t: T}, simultaneous=True)),
        'det_outer_H': s.expand(det_sc.subs({z: 2 * Z / 3, v: (1 - Z) * (s.Rational(1, 16) + s.Rational(15, 16) * H) / 2, t: T}, simultaneous=True)),
        'det_left_Z': s.expand(det_sc.subs({z: 2 * Z_left / 3, v: (1 - Z_left) * (H / 16) / 2, t: T}, simultaneous=True)),
        'det_right_Z': s.expand(det_sc.subs({z: 2 * Z_right / 3, v: (1 - Z_right) * (H / 16) / 2, t: T}, simultaneous=True)),
    }
    assert [tk['name'] for tk in bcert['tasks']] == list(expected_3d.keys())
    bridge_leaves = []
    for tk in bcert['tasks']:
        unit = expected_3d[tk['name']]
        assert s.expand(unit - s.sympify(tk['unit_polynomial'])) == 0
        proof = tk['certificate']
        replayed = replay_ring_exact(unit, [Z, H, T], proof['tree'])
        assert replayed == proof['leaves']
        assert leaf_minimum(proof['tree']) == s.Rational(proof['minimum_leaf_coefficient']) >= 0
        bridge_leaves.append(replayed)
    print(f"2b. Continuous 3D conic bridge c_bridge(t) on t in [0,1]: PASS ({sum(bridge_leaves)} leaves)", flush=True)

    f2, g2 = s.symbols('f2 g2')
    ray_checked = []
    for cert_file, mat, syms in [
        ('NEW_OMEGA4_RAYS_CERTIFICATES.json', m4, [f0, f1, g0, g1]),
        ('CUBIC_PHASE_CERTIFICATES.json', m6, [f0, f1, f2, g0, g1, g2]),
    ]:
        records = json.loads((HERE / cert_file).read_text())['records']
        for row in records:
            seed = [s.Rational(x) for x in row['seed']]
            lo = s.Rational(row['lower'])
            hi = s.Rational(row['upper'])
            cf = [s.Rational(x) for x in row['coefficients']]
            assert cf == [lo * x for x in seed]
            assert 0 < lo < hi and hi - lo == s.Rational(3, 10**8)
            margin = s.Rational(row['scaled_margin'])
            assert margin > 0
            a, b, c = [s.expand(mat[k].subs(dict(zip(syms, cf)))) for k in ['a', 'b', 'c']]
            polys = [a - margin, (a - margin) * (c - margin) - v * ((2 - 3 * z) / 4 - v) * b * b]
            assert [tk['name'] for tk in row['tasks']] == ['diagonal', 'determinant']
            boxes = []
            for tk, p_expr in zip(row['tasks'], polys):
                unit = s.expand(p_expr.subs({z: 2 * Z / 3, v: (1 - Z) * H / 2}, simultaneous=True))
                proof = tk['certificate']
                boxes.append(replay_ring_exact(unit, [Z, H], proof['tree']))
                low = leaf_minimum(proof['tree'])
                assert low == s.Rational(proof['minimum_leaf_coefficient'])
                if tk['name'] == 'diagonal':
                    assert low > 0
            witness = row['upper_witness']
            zz = s.Rational(witness['z'])
            hh = s.Rational(witness['h'])
            assert 0 < zz < s.Rational(2, 3) and 0 < hh <= 1
            vv = (2 - 3 * zz) * hh / 4
            assert vv == s.Rational(witness['v'])
            abc = [s.factor(mat[k].subs(dict(zip(syms, [hi * x for x in seed]))).subs({z: zz, v: vv})) for k in ['a', 'b', 'c']]
            det = s.factor(abc[0] * abc[2] - vv * ((2 - 3 * zz) / 4 - vv) * abc[1]**2)
            assert abc[0] == s.Rational(witness['a']) and abc[2] == s.Rational(witness['c'])
            assert det == s.Rational(witness['determinant'])
            assert det < 0 or abc[0] < 0 or abc[2] < 0
            ray_checked.append(dict(label=row['label'], lower=str(lo), upper=str(hi), boxes=boxes, status='PASS'))
            print(f"3. Ray {row['label']} bracket [{float(lo):.8f}, {float(hi):.8f}]: PASS ({boxes} leaves)", flush=True)

    sep_records = json.loads((HERE / 'ENLARGEMENT_SEPARATIONS.json').read_text())['records']
    models = json.loads((HERE / 'INDEPENDENT_RAYS_B46_MODELS.json').read_text())['models']
    old4 = json.loads((HERE / 'SHAPE_DEPENDENT_CERTIFICATES.json').read_text())['records']
    rays6 = json.loads((HERE / 'INDEPENDENT_RAYS_CERTIFICATES.json').read_text())['records']
    rays4_new = json.loads((HERE / 'NEW_OMEGA4_RAYS_CERTIFICATES.json').read_text())['records']
    rays6_p = json.loads((HERE / 'CUBIC_PHASE_CERTIFICATES.json').read_text())['records']
    bmid_record = dict(
        label='Bridge_Mid',
        seed=['43/80', '2', '-49/40', '8/5'],
        lower='42240/41737',
        upper='42240/41737',
        coefficients=['22704/41737', '84480/41737', '-51744/41737', '67584/41737'],
    )
    all_targets = [bmid_record] + rays4_new + rays6_p
    base_competitors = old4 + rays6 + [
        dict(label=r['label'], coefficients=r['coefficients']) for r in bridge_bundle['exact_flat_endpoints']
    ]

    sep_checked = []
    for row, target_row in zip(sep_records, all_targets):
        assert row['label'] == target_row['label']
        sides = row['sides_abc']
        assert min(sides) > 0 and 2 * max(sides) < sum(sides)
        n = s.Matrix([s.Rational(x) for x in row['normal']])
        q, k, hk = shape_data(sides)
        objective = s.Matrix([n.dot(s.Matrix(k[1:])), n.dot(s.Matrix(hk[1:]))])
        dual = row['omega_dual']
        total = s.zeros(2, 1)
        cap = 0
        for constraint, multiplier in zip(dual['constraints'], dual['multipliers']):
            zz = s.Rational(constraint['z'])
            assert 0 <= zz <= s.Rational(2, 3)
            A_c, b_c = omega_constraint(constraint['entry'], zz)
            mu = s.Rational(multiplier)
            assert mu >= 0
            total += mu * A_c
            cap += mu * b_c
        assert total == objective and cap == s.Rational(dual['upper'])
        omega_sup = cap + sum(n) / 3
        assert omega_sup == s.Rational(row['omega_support_upper'])

        target_w = weights_any(sides, target_row['coefficients'])
        assert list(map(str, target_w)) == row['target_weights']
        support = n.dot(s.Matrix(target_w[1:]))
        assert support == s.Rational(row['target_support'])

        centroid_sup = sum(n) / 3
        target_upper = centroid_sup + (support - centroid_sup) * s.Rational(target_row['upper']) / s.Rational(target_row['lower'])
        target_interval_lower = min(support, target_upper)

        bounds = [omega_sup]
        bracket_bounds = [omega_sup]
        expected_comp = base_competitors + [r for r in all_targets if r['label'] != row['label']]
        assert len(row['other_shape_maps']) == len(expected_comp)
        for item, source in zip(row['other_shape_maps'], expected_comp):
            w = weights_any(sides, source['coefficients'])
            val = n.dot(s.Matrix(w[1:]))
            assert val == s.Rational(item['support'])
            bounds.append(val)
            if 'upper' in source and 'lower' in source:
                other_up = centroid_sup + (val - centroid_sup) * s.Rational(source['upper']) / s.Rational(source['lower'])
                bracket_bounds.append(max(val, other_up))
            else:
                bracket_bounds.append(val)

        if row['label'] != 'Bridge_Mid':
            b_cert = row['continuous_bridge_upper_certificate']
            u_n = n.dot(s.Matrix(k[1:]))
            v_n = n.dot(s.Matrix(hk[1:]))
            D_T = 1329 * T**2 + 2042 * T + 9081
            num_T = 640 * (5 * T + 14) * ((1 - T) * left + T * right) + 10560 * T * (1 - T) * bow
            N_T = s.expand((num_T[0] + q * num_T[1]) * u_n + (num_T[2] + q * num_T[3]) * v_n)
            pert_up = s.Rational(b_cert['perturbation_upper'])
            diff_poly = s.expand(pert_up * D_T - N_T)
            assert s.expand(diff_poly - s.sympify(b_cert['polynomial'])) == 0
            assert replay_ring_exact(diff_poly, [T], b_cert['certificate']['tree']) == b_cert['certificate']['leaves']
            assert leaf_minimum(b_cert['certificate']['tree']) >= 0
            b_sup = centroid_sup + pert_up
            assert b_sup == s.Rational(b_cert['support_upper'])
            bounds.append(b_sup)
            bracket_bounds.append(b_sup)

        for item, model in zip(row['rational_B46'], models):
            assert item['label'] == model['label']
            den = poly_value(model['polys_abc'][3], sides)
            w = [s.Rational(poly_value(p_m, sides), den) for p_m in model['polys_abc'][:3]]
            val = n.dot(s.Matrix(w[1:]))
            assert val == s.Rational(item['support'])
            bounds.append(val)
            bracket_bounds.append(val)

        for item in row['power_enclosures']:
            fresh = power_support(sides, item['label'], item['rational_point'], row['normal'])
            assert fresh['support_upper'] == item['support_upper']
            bounds.append(s.Rational(fresh['support_upper']))
            bracket_bounds.append(s.Rational(fresh['support_upper']))

        comp_upper = max(bounds)
        gap = support - comp_upper
        robust_gap = target_interval_lower - max(bracket_bounds)
        assert gap == s.Rational(row['gap']) > 0
        assert robust_gap == s.Rational(row['robust_boundary_gap']) > 0
        sep_checked.append(dict(
            label=row['label'],
            sides_abc=sides,
            gap=str(gap),
            robust_boundary_gap=str(robust_gap),
            status='PASS',
        ))
        print(f"4. Separation {row['label']} on {sides}: PASS (gap = {float(gap):.6e})", flush=True)

    out = dict(
        status='PASS: all four Heart-enlargement recommendations independently verified and replayed',
        flat_endpoints=flat_checked,
        conic_bridge_3d_leaves=bridge_leaves,
        new_rays_checked=ray_checked,
        separations_checked=sep_checked,
        seconds=round(time.monotonic() - t0, 3),
    )
    (HERE / 'HEART_ENLARGEMENT_REPLAY.json').write_text(json.dumps(out, indent=2) + '\n')
    print(f"All verifications PASSED in {out['seconds']}s", flush=True)


if __name__ == '__main__':
    main()