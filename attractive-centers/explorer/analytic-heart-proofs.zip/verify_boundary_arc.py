"""Independent exact verifier for the continuous boundary-arc certificate.

No search or archived derivative helper is imported. Uses direct fixed-vertex
Cartesian differentiation, then a fresh Bernstein conversion on each saved
sub-box, independently of the generator's de Casteljau arithmetic.
Requires SymPy only; no numerical sampling is part of the proof.
"""
from pathlib import Path
import hashlib,itertools,json,time
from math import comb
import sympy as sp
from sympy.polys.rings import ring
from sympy.polys.domains import QQ

HERE=Path(__file__).resolve().parent


def cartesian_matrix():
    R,r,X,Y,t=ring('r,X,Y,t',QQ)
    T,z,u,v,tt=ring('z,u,v,t',QQ)
    Q,zq,vq,tq=ring('z,v,t',QQ)
    p=[(r,R.zero),(-r/2+X,Y),(-r/2-X,-Y)]
    A=[4*(X*X+Y*Y),(3*r/2+X)**2+Y*Y,(3*r/2-X)**2+Y*Y]
    q=sum(A,R.zero);d=t*t+8
    c0=t*t-8*t+40;c1=24*(t-4)
    N=[c0*q*q+c1*a*q+144*a*a-48*sum((b*b for b in A),R.zero) for a in A]
    D=3*d*q*q
    assert sum(N,R.zero)==D
    center=[sum((N[i]*p[i][j] for i in range(3)),R.zero) for j in range(2)]
    # Independently connect these barycentric weights to the invariant formula.
    # G=0, L=q/3, K=sum(A_i p_i)/q, H=6 S/q-I.
    kn=[sum((A[i]*p[i][j] for i in range(3)),R.zero) for j in range(2)]
    inertia=[[sum((p[i][j]*p[i][k] for i in range(3)),R.zero)
              for k in range(2)] for j in range(2)]
    for j in range(2):
        expected=3*((8*t+8)*q*kn[j]-48*sum((inertia[j][k]*kn[k] for k in range(2)),R.zero))
        assert center[j]==expected
    J=[[R.zero,R.zero],[R.zero,R.zero]]
    for col,da in enumerate([[R.zero,3*r+2*X,3*r-2*X],[R.zero,2*Y,-2*Y]]):
        dq=sum(da,R.zero)
        dn=[2*c0*q*dq+c1*(da[i]*q+A[i]*dq)+288*A[i]*da[i]
            -96*sum((A[j]*da[j] for j in range(3)),R.zero) for i in range(3)]
        dd=6*d*q*dq
        for row in range(2):
            dz=(N[0] if row==col else R.zero)+sum((dn[i]*p[i][row] for i in range(3)),R.zero)
            J[row][col]=dz*D-center[row]*dd
    def normalize(poly,offdiag=False):
        if offdiag:poly=poly.exquo(X*Y)
        transformed=T.zero
        for (i,j,k,l),coef in poly.items():
            assert i%2==j%2==k%2==0
            transformed+=coef*z**(i//2)*u**(j//2)*v**(k//2)*tt**l
        # Centered second moment L=3r^2/2+2X^2+2Y^2 is normalized to 1.
        transformed=transformed.compose(u,(2-3*z)/4-v)
        result=Q.zero
        for (i,j,k,l),coef in transformed.items():
            assert j==0
            result+=coef*zq**i*vq**k*tq**l
        return result
    denominator=normalize(D*D)
    assert denominator==729*(tq*tq+8)**2
    a=normalize(3*d*J[0][0]).exquo(denominator)
    b=normalize(3*d*(J[0][1]+J[1][0])/2,True).exquo(denominator)
    c=normalize(3*d*J[1][1]).exquo(denominator)
    determinant=a*c-vq*((2-3*zq)/4-vq)*b*b
    return {k:value.as_expr() for k,value in [('M11',a),('M12_over_XY',b),('M22',c),('det',determinant)]}


def bernstein_minimum(polynomial,variables):
    p=sp.Poly(polynomial,*variables);degrees=p.degree_list()
    coefficients=p.as_dict();values=[]
    for index in itertools.product(*(range(d+1) for d in degrees)):
        value=0
        for powers,c in coefficients.items():
            if any(k>i for k,i in zip(powers,index)):continue
            factor=sp.Integer(1)
            for k,i,d in zip(powers,index,degrees):factor*=sp.Rational(comb(i,k),comb(d,k))
            value+=c*factor
        values.append(value)
    return min(values)


def replay(polynomial,variables,node):
    if node.get('nonnegative'):
        minimum=bernstein_minimum(polynomial,variables)
        assert minimum>=0
        assert minimum==sp.Rational(node['minimum'])
        return 1
    axis=node['axis'];assert 0<=axis<len(variables)
    assert len(node['children'])==2
    variable=variables[axis]
    return sum(replay(sp.expand(polynomial.subs(variable,(variable+side)/2)),variables,child)
               for side,child in enumerate(node['children']))


def main():
    tic=time.monotonic();path=HERE/'BOUNDARY_ARC_CERTIFICATE.json'
    saved=json.loads(path.read_text());assert saved['parameter_interval']==['2/3','1']
    direct=cartesian_matrix();z,v,t,h,Z,H,T=sp.symbols('z v t h Z H T')
    for name,value in direct.items():assert sp.expand(value-sp.sympify(saved['matrix'][name]))==0
    a,b,c,det=[direct[name] for name in ['M11','M12_over_XY','M22','det']]
    flat_a=a.subs(v,0);flat_c=c.subs(v,0)
    assert sp.expand(flat_c-(12*z-t-4)**2)==0
    remainder=sp.cancel((det-flat_a*flat_c)/(96*z*v))
    assert sp.expand(remainder-sp.sympify(saved['matrix']['det_remainder'])/(96*z))==0
    vsub=(2-3*z)*h/4
    expected={}
    for endpoint in [0,1]:
        expected[f'M11_h{endpoint}']=(a.subs(v,vsub).subs(h,endpoint)-sp.Rational(1,16),[0,sp.Rational(2,3)],[Z,T])
        expected[f'remainder_middle_h{endpoint}']=(remainder.subs(v,vsub).subs(h,endpoint),[sp.Rational(1,3),sp.Rational(1,2)],[Z,T])
    expected['det_lower']=(det.subs(v,vsub),[0,sp.Rational(1,3)],[Z,H,T])
    expected['det_upper']=(det.subs(v,vsub),[sp.Rational(1,2),sp.Rational(2,3)],[Z,H,T])
    assert set(record['name'] for record in saved['tasks'])==set(expected)
    assert sp.degree(a,v)<=1 and sp.degree(remainder,v)<=1
    assert saved['M11_positive_lower_bound']=='1/16'
    checks=[]
    for record in saved['tasks']:
        polynomial,(lo,hi),variables=expected[record['name']]
        assert [sp.Rational(q) for q in record['z_interval']]==[lo,hi]
        assert sp.expand(polynomial-sp.sympify(record['original_polynomial']))==0
        unit=sp.expand(polynomial.subs({z:lo+(hi-lo)*Z,h:H,t:sp.Rational(2,3)+T/3},simultaneous=True))
        assert sp.expand(unit-sp.sympify(record['unit_polynomial']))==0
        leaves=replay(unit,variables,record['certificate']['tree'])
        checks.append(dict(name=record['name'],leaves=leaves,status='PASS'))
    # The remaining proof steps are scalar sign implications:
    # a>=1/16 everywhere; in the middle band det=flat_a*square+96*z*v*remainder>=0;
    # the two other bands have direct det certificates. Hence the full matrix is PSD.
    result=dict(status='PASS: continuous parameter interval globally certified',
                independent_cartesian_derivation=True,parameter_interval=['2/3','1'],
                certificate_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),checks=checks,
                seconds=round(time.monotonic()-tic,3))
    (HERE/'BOUNDARY_ARC_INDEPENDENT_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':main()
