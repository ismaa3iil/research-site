"""Bounded bridge exploration, with a separately checked exact midpoint failure."""
from pathlib import Path
import json
import sympy as s
import numpy as np

HERE=Path(__file__).resolve().parent


def main():
    z,v,t,f0,f1,g0,g1=s.symbols('z v t f0 f1 g0 g1')
    raw=json.loads((HERE/'SHAPE_DEPENDENT_MATRIX.json').read_text())['matrix']
    left=s.Matrix(list(map(s.Rational,['3/4','23/10','-1','6/5'])))
    right=s.Matrix(list(map(s.Rational,['9/20','6/5','-8/5','13/5'])))
    cf=(1-t)*left+t*right
    fbar=cf[0]+cf[1]/4;gbar=cf[2]+cf[3]/4
    cpert=fbar*(1-3*z)+gbar*(-18*z*z+12*z-1)
    zstar=s.solve(s.diff(cpert,z),z)[0]
    lam=s.factor(-1/cpert.subs(z,zstar))
    print('lambda(t)=',lam,'z*(t)=',s.factor(zstar),flush=True)
    a,b,c=[s.factor(s.sympify(raw[key]).subs(dict(zip([f0,f1,g0,g1],lam*cf)))) for key in ['a','b','c']]
    det=s.factor(a*c-v*((2-3*z)/4-v)*b*b)
    remainder=s.cancel((det-det.subs(v,0))/v)
    zz,hh=np.meshgrid(np.linspace(0,2/3,161),np.linspace(0,1,81),indexing='ij');vv=(2-3*zz)*hh/4
    fun=s.lambdify((z,v,t),remainder,'numpy');afun=s.lambdify((z,v,t),a,'numpy')
    rec=[]
    for tt in np.linspace(0,1,11):
        rec.append(dict(t=float(tt),minimum_remainder=float(np.min(fun(zz,vv,tt))),minimum_a=float(np.min(afun(zz,vv,tt)))))
    print(json.dumps(rec,indent=2))
    ii,jj=np.unravel_index(np.argmin(afun(zz,vv,.5)),zz.shape)
    ez=s.Rational(2*int(ii),3*160);eh=s.Rational(int(jj),80);ev=(2-3*ez)*eh/4
    negative=s.factor(a.subs({z:ez,v:ev,t:s.Rational(1,2)}));assert negative<0
    witness=dict(t='1/2',z=str(ez),h=str(eh),v=str(ev),scaled_diagonal=str(negative),
                 status='EXACT non-attractivity witness for the proposed collinear-normalized bridge')
    (HERE/'COLLINEAR_BRIDGE_PROBE.json').write_text(json.dumps(dict(status='Numerical exploration plus an exact negative midpoint witness',lambda_formula=str(lam),zstar=str(zstar),rows=rec,midpoint_counterexample=witness),indent=2)+'\n')
    print(json.dumps(witness,indent=2))


if __name__=='__main__':main()
