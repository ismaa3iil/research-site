"""Build a new archive, preserving previous work, and test an isolated copy."""
from pathlib import Path
import hashlib,importlib.metadata,json,os,platform,subprocess,sys,tempfile,zipfile

HERE=Path(__file__).resolve().parent
OUTPUT=HERE.parent
ARCHIVE=OUTPUT/'Attractive_Centers_Independent_Rays_2026-10-17.zip'
QA=HERE/'INDEPENDENT_RAYS_BUNDLE_REPLAY.json'
AUDIT=HERE/'reference/B46_NATIVE_AUDIT'
if not AUDIT.exists():AUDIT=OUTPUT/'goal2-etc-2026-09-30/B46_NATIVE_AUDIT'
PRIOR_NAME='Attractive_Centers_Shape_Dependent_2026-10-16.zip'
PRIOR=HERE/'reference'/PRIOR_NAME
if not PRIOR.exists():PRIOR=OUTPUT/PRIOR_NAME
FILES=[
 'INDEPENDENT_RAYS_REPORT.md','README_INDEPENDENT_RAYS.md',
 'search_independent_rays.py','INDEPENDENT_RAYS_SEARCH.json',
 'certify_independent_rays.py','INDEPENDENT_RAYS_CERTIFICATES.json',
 'verify_independent_rays.py','INDEPENDENT_RAYS_REPLAY.json',
 'audit_independent_rays.py','INDEPENDENT_RAYS_AUDIT.json','INDEPENDENT_RAYS_AUDIT_ROWS.json',
 'ray_separation_common.py','certify_ray_separations.py','INDEPENDENT_RAYS_SEPARATIONS.json',
 'INDEPENDENT_RAYS_B46_MODELS.json','verify_ray_separations.py','INDEPENDENT_RAYS_SEPARATION_REPLAY.json',
 'probe_collinear_bridge.py','COLLINEAR_BRIDGE_PROBE.json',
 'independent_ray_centers.py','test_independent_rays.py','IndependentRays.wl',
 'INDEPENDENT_RAYS_WOLFRAM_REPLAY.json','plot_independent_rays.py',
 'INDEPENDENT_RAYS_COMPARISON.png','INDEPENDENT_RAYS_COMPARISON.svg','INDEPENDENT_RAYS_AREAS.json',
 'build_independent_rays_bundle.py',
 # Prior modules needed for fresh differentiation, evaluation, discovery or generation.
 'verify_shape_dependent.py','verify_boundary_arc.py','derive_arc_matrix.py','prove_boundary_arc.py',
 'shape_dependent_centers.py','ShapeDependentCenters.wl','search_shape_dependent.py','omega_support.py',
 'SHAPE_DEPENDENT_CERTIFICATES.json','SHAPE_DEPENDENT_MATRIX.json','SHAPE_DEPENDENT_SEARCH.json',
 'SHAPE_DEPENDENT_REPORT.md',
]


def sha(data):return hashlib.sha256(data).hexdigest()


def build(qa=False):
    files={name:HERE/name for name in FILES};files['README.md']=HERE/'README_INDEPENDENT_RAYS.md'
    for name in ['SHAPES.json','BASE_WEIGHTS.npy','REFERENCE_B46.json','MODELS.jsonl']:
        files['reference/B46_NATIVE_AUDIT/'+name]=AUDIT/name
    files['reference/'+PRIOR_NAME]=PRIOR
    if qa:files[QA.name]=QA
    entries=[]
    for name,path in sorted(files.items()):
        assert path.is_file(),path
        entries.append(dict(path=name,bytes=path.stat().st_size,sha256=sha(path.read_bytes())))
    manifest=dict(date='2026-10-17',python=platform.python_version(),
      packages={name:importlib.metadata.version(name) for name in ['sympy','mpmath','numpy','scipy','matplotlib']},
      exact_claims=['Six global attractivity lower certificates and radial brackets of width 3e-8',
                    'Six exact leave-one-out separation witnesses',
                    'Exact failure of naive collinear-normalized bridge'],
      limitation='Not maximal Heart, not globally minimal base; audit and area results are numerical.',files=entries)
    with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
        for name,path in sorted(files.items()):bundle.write(path,name)
        bundle.writestr('BUNDLE_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')


def main():
    if not __debug__:raise RuntimeError('Assertions required.')
    build()
    target=Path(tempfile.mkdtemp(prefix='independent_rays_replay_',dir=OUTPUT))
    with zipfile.ZipFile(ARCHIVE) as bundle:
        for name in bundle.namelist():assert (target/name).resolve().is_relative_to(target.resolve())
        bundle.extractall(target)
    manifest=json.loads((target/'BUNDLE_MANIFEST.json').read_text())
    for row in manifest['files']:assert sha((target/row['path']).read_bytes())==row['sha256']
    env=os.environ.copy()
    for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:env[key]='1'
    results=[]
    for script,timeout in [('verify_independent_rays.py',60),('verify_ray_separations.py',30),
                           ('test_independent_rays.py',30),('audit_independent_rays.py',120)]:
        print('Running',script,flush=True)
        run=subprocess.run([sys.executable,str(target/script)],cwd=target,env=env,
                            capture_output=True,text=True,timeout=timeout)
        results.append(dict(script=script,returncode=run.returncode,stdout=run.stdout,stderr=run.stderr))
        assert run.returncode==0,(script,run.stdout,run.stderr)
        print(script,'PASS',flush=True)
    fresh=json.loads((target/'INDEPENDENT_RAYS_AUDIT.json').read_text())
    old=json.loads((HERE/'INDEPENDENT_RAYS_AUDIT.json').read_text())
    for key in ['evaluated','skipped','counts','union_count','leave_one_out_counts',
                'detected_shape_indices','independence_shape_indices']:
        assert fresh[key]==old[key],key
    assert fresh['union_count']==763 and fresh['leave_one_out_counts']==[290,300,82,108,730,32]
    exact=json.loads((target/'INDEPENDENT_RAYS_SEPARATION_REPLAY.json').read_text())
    from fractions import Fraction
    assert all(Fraction(row['robust_boundary_gap'])>0 for row in exact['records'])
    # Do not silently package a source edited after its isolated-copy test.
    originals={row['path']:row['sha256'] for row in manifest['files']}
    for name in FILES:assert sha((HERE/name).read_bytes())==originals[name],name
    record=dict(status='PASS: exact proofs, nonredundancy, regression and full audit in isolated extracted copy',
                extracted_folder=str(target),all_audit_index_sets_reproduced=True,results=results)
    QA.write_text(json.dumps(record,indent=2)+'\n')
    build(qa=True)
    with zipfile.ZipFile(ARCHIVE) as bundle:
        manifest=json.loads(bundle.read('BUNDLE_MANIFEST.json'))
        for row in manifest['files']:assert sha(bundle.read(row['path']))==row['sha256']
    print(json.dumps(dict(status=record['status'],archive=str(ARCHIVE),files=len(manifest['files']),
                          bytes=ARCHIVE.stat().st_size,sha256=sha(ARCHIVE.read_bytes())),indent=2))


if __name__=='__main__':main()
