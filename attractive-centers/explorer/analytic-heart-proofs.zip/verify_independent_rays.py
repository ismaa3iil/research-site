"""Independent product-rule replay of six global radial boundary brackets."""
from pathlib import Path
import json,time
import sympy as s
from verify_shape_dependent import independent_matrix,leaf_minimum
from verify_boundary_arc import replay

HERE=Path(__file__).resolve().parent


def main():
    if not __debug__:raise RuntimeError('Assertions required; do not use -O.')
    start=time.monotonic();direct=independent_matrix()
    z,v,f0,f1,g0,g1,Z,H=s.symbols('z v f0 f1 g0 g1 Z H')
    records=json.loads((HERE/'INDEPENDENT_RAYS_CERTIFICATES.json').read_text())['records']
    assert len(records)==6
    checked=[]
    for row in records:
        seed=list(map(s.Rational,row['seed']));lo=s.Rational(row['lower']);hi=s.Rational(row['upper'])
        cf=list(map(s.Rational,row['coefficients']));assert cf==[lo*x for x in seed]
        assert 0<lo<hi and hi-lo==s.Rational(3,10**8)
        margin=s.Rational(row['scaled_margin']);assert margin>0
        a,b,c=[s.expand(direct[key].subs(dict(zip([f0,f1,g0,g1],cf)))) for key in ['a','b','c']]
        polynomials=[a-margin,(a-margin)*(c-margin)-v*((2-3*z)/4-v)*b*b]
        assert [task['name'] for task in row['tasks']]==['diagonal','determinant']
        boxes=[]
        for task,p in zip(row['tasks'],polynomials):
            unit=s.expand(p.subs({z:2*Z/3,v:(1-Z)*H/2},simultaneous=True))
            proof=task['certificate'];boxes.append(replay(unit,[Z,H],proof['tree']))
            low=leaf_minimum(proof['tree'])
            assert low==s.Rational(proof['minimum_leaf_coefficient'])
            if task['name']=='diagonal':assert low>0
        witness=row['upper_witness'];zz=s.Rational(witness['z']);hh=s.Rational(witness['h'])
        assert 0<zz<s.Rational(2,3) and 0<hh<=1
        vv=(2-3*zz)*hh/4;assert vv==s.Rational(witness['v'])
        abc=[s.factor(direct[key].subs(dict(zip([f0,f1,g0,g1],[hi*x for x in seed]))).subs({z:zz,v:vv})) for key in ['a','b','c']]
        det=s.factor(abc[0]*abc[2]-vv*((2-3*zz)/4-vv)*abc[1]**2)
        assert abc[0]==s.Rational(witness['a']) and abc[2]==s.Rational(witness['c'])
        assert det==s.Rational(witness['determinant'])
        assert det<0 or abc[0]<0 or abc[2]<0
        V=(2-3*zz)/4
        apex=[s.Rational(3,2)*s.sqrt(zz*(1-hh)/V),s.Rational(3,2)*s.sqrt(zz*hh/V)]
        checked.append(dict(label=row['label'],seed=row['seed'],lower=str(lo),upper=str(hi),
            decimal_bracket=[float(lo),float(hi)],lower_Sym_J_margin=str(margin/3),boxes=boxes,
            witness_z=str(zz),witness_h=str(hh),upper_witness_apex=[str(s.N(t,17)) for t in apex],
            upper_scaled_determinant=str(s.N(det,17)),status='PASS: lower globally attractive; upper exactly non-attractive'))
        print(row['label'],'PASS',flush=True)
    # A tempting explicit bridge inferred from collinear obstructions alone
    # is NOT attractive; replay its exact midpoint failure independently.
    left=s.Matrix(list(map(s.Rational,records[1]['seed'])))
    right=s.Matrix(list(map(s.Rational,records[4]['seed'])))
    tt=s.Rational(1,2)
    bridge_scale=640*(5*tt+14)/(1329*tt**2+2042*tt+9081)
    bridge_coeff=bridge_scale*((1-tt)*left+tt*right)
    failure=s.factor(direct['a'].subs(dict(zip([f0,f1,g0,g1],bridge_coeff))).subs({z:s.Rational(9,40),v:s.Rational(53,160)}))
    assert failure==-s.Rational(58932991,2086850000)<0
    output=dict(status='PASS: six exact global boundary brackets independently replayed',records=checked,
                naive_collinear_bridge_midpoint_diagonal=str(failure),
                limitation='radial sharpness does not imply exposure on the unrestricted maximal Heart',
                seconds=round(time.monotonic()-start,3))
    (HERE/'INDEPENDENT_RAYS_REPLAY.json').write_text(json.dumps(output,indent=2)+'\n')
    print('seconds',output['seconds'],flush=True)


if __name__=='__main__':main()
