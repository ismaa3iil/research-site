"""Bounded, single-process numerical discovery in the four-parameter family.

Sampled constraints and eigenvector cuts only discover candidates; they are
NOT proofs. All workers are disabled. Exact certification is a separate step.
"""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import json
import time
import numpy as np
import sympy as s
from scipy.optimize import linprog
from scipy.spatial import ConvexHull
from omega_support import support_components,center_basis,arc_I,arc_II,TLOW,THIGH,ALPHA,BETA,TOP,LEFT

HERE=Path(__file__).resolve().parent
AUDIT=HERE/'reference/B46_NATIVE_AUDIT'
if not AUDIT.exists():AUDIT=HERE.parent/'goal2-etc-2026-09-30/B46_NATIVE_AUDIT'


def numerical_basis():
    z,v,f0,f1,g0,g1=s.symbols('z v f0 f1 g0 g1')
    coefficients=[f0,f1,g0,g1]
    raw=json.loads((HERE/'SHAPE_DEPENDENT_MATRIX.json').read_text())
    polys=[s.sympify(raw['matrix'][name]) for name in ['a','b','c']]
    funs=[[s.lambdify((z,v),s.diff(p,cf),'numpy') for cf in coefficients] for p in polys]
    def basis(zz,hh):
        zz,hh=np.broadcast_arrays(np.asarray(zz,float),np.asarray(hh,float))
        V=(2-3*zz)/4;vv=V*hh
        terms=np.array([[np.broadcast_to(fun(zz,vv),zz.shape) for fun in group] for group in funs])
        terms[1]*=np.sqrt(np.maximum(0.,vv*(V-vv)))
        return np.moveaxis(terms,-1,0) if zz.ndim==1 else terms
    return basis


def minimum_eigenvalue(abc):
    a,b,c=abc.T
    return (a+c-np.hypot(a-c,2*b))/2


def main():
    start=time.monotonic();basis=numerical_basis()
    zgrid=np.unique(np.r_[np.linspace(0,2/3,49),1/3,.271686050620948,.386458326894464,.5])
    hgrid=np.linspace(0,1,25)
    zz,hh=np.meshgrid(zgrid,hgrid,indexing='ij');zz=zz.ravel();hh=hh.ravel()
    mats=basis(zz,hh) # shape (points, entries, coefficients)
    A=[]
    for angle in np.linspace(0,np.pi,16,endpoint=False):
        co,si=np.cos(angle),np.sin(angle)
        A.append(co*co*mats[:,0,:]+2*co*si*mats[:,1,:]+si*si*mats[:,2,:])
    A=np.vstack(A)
    bound=np.ones(len(A))
    # Targets include true triangles and actual facets of B46 plus Omega.
    shapes=json.loads((AUDIT/'SHAPES.json').read_text())
    base=np.load(AUDIT/'BASE_WEIGHTS.npy')
    selected=[2868,3759]+np.linspace(0,6192,28,dtype=int).tolist()
    targets=[]
    curve=np.vstack([TOP,LEFT,arc_I(np.linspace(TLOW,THIGH,81)),arc_II(np.linspace(ALPHA,BETA,101))])
    for index in selected:
        sides=shapes[index]['sides_abc'];k,hk=center_basis(sides)
        cloud=np.vstack([base[index],np.array([1/3,1/3])+curve@np.vstack([k,hk])])
        singular=np.linalg.svd(cloud-cloud.mean(0),compute_uv=False)
        if singular[-1]<1e-10*singular[0]:continue
        normals=ConvexHull(cloud).equations[:,:2]
        # Finite set of representative supporting directions; exact support
        # replaces the sampled curve's support in the objective comparison.
        normals=normals[np.linspace(0,len(normals)-1,min(6,len(normals)),dtype=int)]
        parts=support_components(normals,k,hk)
        baseline=np.maximum.reduce([np.max(normals@base[index].T,axis=1)]
                    +[parts[name] for name in ['ArcI','ArcII','Ptop','Pleft']])
        ss=np.asarray(sides,float)**2;ss/=ss.sum();q=(3*np.sum(ss*ss)-1)/2
        for normal,old in zip(normals,baseline):
            u,v=normal@k,normal@hk
            targets.append(dict(shape=index,sides=sides,q=q,normal=normal.tolist(),
                        objective=np.array([u,q*u,v,q*v]),baseline=float(old),G=float(sum(normal)/3)))
    rows=[]
    for j,target in enumerate(targets):
        cf=None
        for iteration in range(5):
            solve=linprog(-target['objective'],A_ub=-A,b_ub=bound,
                          bounds=[(-2,2),(-32,32),(-8,8),(-32,32)],method='highs',
                          options={'time_limit':5.0,'dual_feasibility_tolerance':1e-9,
                                   'primal_feasibility_tolerance':1e-9})
            if not solve.success:break
            cf=solve.x
            abc=np.einsum('nij,j->ni',mats,cf)+np.array([1,0,1])
            eig=minimum_eigenvalue(abc)
            bad=np.flatnonzero(eig < -1e-8)
            if len(bad)==0:break
            new=[]
            for i in bad:
                _,vectors=np.linalg.eigh([[abc[i,0],abc[i,1]],[abc[i,1],abc[i,2]]])
                x,y=vectors[:,0]
                new.append(x*x*mats[i,0]+2*x*y*mats[i,1]+y*y*mats[i,2])
            A=np.vstack([A,new]);bound=np.ones(len(A))
        if cf is not None:
            rows.append(dict(shape=target['shape'],sides=target['sides'],q=target['q'],normal=target['normal'],
                coefficients=cf.tolist(),sampled_minimum_scaled_eigenvalue=float(np.min(eig)),
                sampled_support_gain=float(target['G']+target['objective']@cf-target['baseline']),
                baseline=target['baseline'],objective=target['objective'].tolist(),G=target['G']))
        if (j+1)%20==0:print('support optimizations',j+1,'/',len(targets),'cuts',len(A),flush=True)
    rows.sort(key=lambda row:row['sampled_support_gain'],reverse=True)
    result=dict(status='NUMERICAL DISCOVERY ONLY: sampled PSD is not global proof',
        parameters=['f0','f1','g0','g1'],grid_points=len(zz),targets=len(targets),candidates=rows,
        bounds=[[-2,2],[-32,32],[-8,8],[-32,32]],seconds=round(time.monotonic()-start,3))
    (HERE/'SHAPE_DEPENDENT_SEARCH.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],seconds=result['seconds'],top=rows[:6]),indent=2),flush=True)


if __name__=='__main__':main()
