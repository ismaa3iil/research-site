"""Evaluators for the zero-backoff endpoints (R2*, R5*), the repaired continuous
conic bridge c_bridge(t) on t in [0,1] (including exact closed-form support
maximization), the four new Omega_4 rays (R7..R10), and the three new
6-parameter cubic-phase rays (P1..P3).
"""
from pathlib import Path
from fractions import Fraction
import json
import numpy as np
from omega_support import triangle_centers, center_basis
from shape_dependent_centers import shape_invariant, center, barycentric_weights

HERE = Path(__file__).resolve().parent

_bridge_data = json.loads((HERE / 'CONIC_BRIDGE_CERTIFICATE.json').read_text())
_omega4_data = json.loads((HERE / 'NEW_OMEGA4_RAYS_CERTIFICATES.json').read_text())
_cubic_data = json.loads((HERE / 'CUBIC_PHASE_CERTIFICATES.json').read_text())

FLAT_ENDPOINTS = {
    row['label']: tuple(float(Fraction(c)) for c in row['coefficients'])
    for row in _bridge_data['exact_flat_endpoints']
}
NEW_OMEGA4_COEFFICIENTS = {
    row['label']: tuple(float(Fraction(c)) for c in row['coefficients'])
    for row in _omega4_data['records']
}
CUBIC_PHASE_COEFFICIENTS = {
    row['label']: tuple(float(Fraction(c)) for c in row['coefficients'])
    for row in _cubic_data['records']
}

LEFT_R2 = np.array([3.0 / 4.0, 23.0 / 10.0, -1.0, 6.0 / 5.0])
RIGHT_R5 = np.array([9.0 / 20.0, 6.0 / 5.0, -8.0 / 5.0, 13.0 / 5.0])
BOW_VEC = np.array([-1.0 / 4.0, 1.0, 3.0 / 10.0, -6.0 / 5.0])


def cubic_phase_invariant(vertices):
    """Return p = 36 * sum_{i=1}^3 (s_i - 1/3)^3 in [-1, 1]."""
    pts = np.asarray(vertices, float)
    squared = np.array([
        np.sum((pts[1] - pts[2])**2),
        np.sum((pts[2] - pts[0])**2),
        np.sum((pts[0] - pts[1])**2),
    ])
    if squared.sum() <= 0:
        raise ValueError('all vertices coincide')
    ss = squared / squared.sum()
    return float(36.0 * np.sum((ss - 1.0 / 3.0)**3))


def bridge_coefficients(t):
    """Return the 4-tuple (f0(t), f1(t), g0(t), g1(t)) along the repaired conic bridge."""
    t_arr = np.asarray(t, float)
    D = 1329.0 * t_arr * t_arr + 2042.0 * t_arr + 9081.0
    num = (
        640.0 * (5.0 * t_arr + 14.0)[..., None] * ((1.0 - t_arr)[..., None] * LEFT_R2 + t_arr[..., None] * RIGHT_R5)
        + (10560.0 * t_arr * (1.0 - t_arr))[..., None] * BOW_VEC
    )
    return num / D[..., None]


def bridge_curve(vertices, t=None):
    """Evaluate Z_bridge(t) on a triangle for scalar or 1D array t in [0, 1]."""
    if t is None:
        t = np.linspace(0.0, 1.0, 41)
    cf = bridge_coefficients(t)
    q = shape_invariant(vertices)
    fg = np.stack([cf[..., 0] + q * cf[..., 1], cf[..., 2] + q * cf[..., 3]], axis=-1)
    out = triangle_centers(vertices, fg)
    return out[0] if np.ndim(t) == 0 else out


def bridge_support_exact(normals, q, k, hk):
    """Exact maximum of n . Z_bridge(t) over t in [0, 1] via quadratic stationary roots."""
    A0 = 8960.0 * LEFT_R2
    A_sum = 12160.0 * RIGHT_R5
    A_mid = 5280.0 * (LEFT_R2 + RIGHT_R5) + 2640.0 * BOW_VEC
    A1 = 4.0 * A_mid - A_sum - 3.0 * A0
    A2 = A_sum - A0 - A1

    u_n = normals @ k
    v_n = normals @ hk
    d_n = np.column_stack([u_n, q * u_n, v_n, q * v_n])
    base = normals @ np.array([1.0 / 3.0, 1.0 / 3.0])

    p2 = d_n @ A2
    p1 = d_n @ A1
    p0 = d_n @ A0
    d2, d1, d0 = 1329.0, 2042.0, 9081.0

    Q2 = p2 * d1 - p1 * d2
    Q1 = 2.0 * (p2 * d0 - p0 * d2)
    Q0 = p1 * d0 - p0 * d1

    disc = np.maximum(0.0, Q1 * Q1 - 4.0 * Q2 * Q0)
    sqrt_disc = np.sqrt(disc)
    with np.errstate(divide='ignore', invalid='ignore'):
        r1 = np.where(np.abs(Q2) > 1e-24, (-Q1 + sqrt_disc) / (2.0 * Q2), -Q0 / Q1)
        r2 = np.where(np.abs(Q2) > 1e-24, (-Q1 - sqrt_disc) / (2.0 * Q2), -Q0 / Q1)

    cands = np.stack([np.zeros_like(u_n), np.ones_like(u_n), np.full_like(u_n, 0.5), r1, r2])
    valid = np.isfinite(cands) & (cands >= 0.0) & (cands <= 1.0)
    tt = np.where(valid, cands, 0.0)
    vals = (p2[None, :] * tt * tt + p1[None, :] * tt + p0[None, :]) / (d2 * tt * tt + d1 * tt + d0)
    vals = np.where(valid, vals, -np.inf)
    idx = np.argmax(vals, axis=0)
    best_t = tt[idx, np.arange(len(u_n))]
    best_val = vals[idx, np.arange(len(u_n))]
    return base + best_val, best_t


def center_6param(vertices, coefficients):
    """Evaluate a 6-parameter center Z = G + (f0+f1*q+f2*p)K + (g0+g1*q+g2*p)HK."""
    f0, f1, f2, g0, g1, g2 = coefficients
    q = shape_invariant(vertices)
    p = cubic_phase_invariant(vertices)
    return triangle_centers(vertices, [f0 + f1 * q + f2 * p, g0 + g1 * q + g2 * p])[0]


def barycentric_weights_6param(vertices, coefficients):
    """Return exact barycentric weights (w_A, w_B, w_C) for a 6-parameter center."""
    pts = np.asarray(vertices, float)
    squared = np.array([
        np.sum((pts[1] - pts[2])**2),
        np.sum((pts[2] - pts[0])**2),
        np.sum((pts[0] - pts[1])**2),
    ])
    if squared.sum() <= 0:
        raise ValueError('all vertices coincide')
    ss = squared / squared.sum()
    q = (3.0 * np.sum(ss * ss) - 1.0) / 2.0
    p = 36.0 * np.sum((ss - 1.0 / 3.0)**3)
    f0, f1, f2, g0, g1, g2 = coefficients
    f = f0 + f1 * q + f2 * p
    g = g0 + g1 * q + g2 * p
    return 1.0 / 3.0 + (f + 4.0 * g) * (ss - 1.0 / 3.0) - 6.0 * g * (ss * ss - np.mean(ss * ss))


def all_new_discrete_centers(vertices):
    """Return positions of R2*, R5*, Bridge_Mid, R7..R10, P1..P3 as a (10, 2) array."""
    bmid = tuple(bridge_coefficients(0.5))
    pts4 = [center(vertices, cf) for cf in list(FLAT_ENDPOINTS.values()) + [bmid] + list(NEW_OMEGA4_COEFFICIENTS.values())]
    pts6 = [center_6param(vertices, cf) for cf in CUBIC_PHASE_COEFFICIENTS.values()]
    return np.array(pts4 + pts6)


def all_new_discrete_weights(vertices):
    """Return barycentric weights of R2*, R5*, Bridge_Mid, R7..R10, P1..P3 as a (10, 3) array."""
    bmid = tuple(bridge_coefficients(0.5))
    w4 = [barycentric_weights(vertices, cf) for cf in list(FLAT_ENDPOINTS.values()) + [bmid] + list(NEW_OMEGA4_COEFFICIENTS.values())]
    w6 = [barycentric_weights_6param(vertices, cf) for cf in CUBIC_PHASE_COEFFICIENTS.values()]
    return np.array(w4 + w6)