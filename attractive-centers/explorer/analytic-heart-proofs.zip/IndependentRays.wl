(* Exact coefficients for certified inner approximations to six boundary rays.
   No solver is needed. Load this file, then call ACIndependentCenters[vertices]. *)
Get[FileNameJoin[{DirectoryName[$InputFileName], "ShapeDependentCenters.wl"}]];
ClearAll[ACIndependentSeeds, ACIndependentBrackets, ACIndependentCoefficients,
 ACIndependentCenters, ACIndependentWeights];
ACIndependentSeeds = {
 {-3/4, 49/20, 29/20, -53/20},
 {3/4, 23/10, -1, 6/5},
 {3/4, -21/4, 3/4, -27/20},
 {-19/20, 6/5, 3/4, -33/20},
 {9/20, 6/5, -8/5, 13/5},
 {3/4, -17/4, -9/5, 41/5}};
ACIndependentBrackets = {
 {99895956, 99895959}, {98667546, 98667549},
 {98083518, 98083521}, {100950335, 100950338},
 {97654994, 97654997}, {97871127, 97871130}}/100000000;
ACIndependentCoefficients = MapThread[Times,
 {ACIndependentBrackets[[All, 1]], ACIndependentSeeds}];
ACIndependentCenters[p_List] := ACShapeCenter[p, #] & /@ ACIndependentCoefficients;
ACIndependentWeights[p_List] := ACShapeWeights[p, #] & /@ ACIndependentCoefficients;
