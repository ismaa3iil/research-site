"""Replay exact nonredundancy against B46, Omega, and all competing maps.

No optimization or floating hull computation is used. Powers are bounded
by fresh interval residual checks. The only numerical inputs are approximate
root locations; their accuracy is not assumed.
"""
from pathlib import Path
import json,time
import sympy as s
from verify_shape_dependent import independent_matrix
from ray_separation_common import poly_value,shape_data,weights,omega_constraint,power_support

HERE=Path(__file__).resolve().parent


def main():
    if not __debug__:raise RuntimeError('Assertions required; do not use -O.')
    start=time.monotonic()
    direct=independent_matrix();z,v,f0,f1,g0,g1=s.symbols('z v f0 f1 g0 g1')
    constant={key:expr.subs({f1:0,g1:0}) for key,expr in direct.items()}
    # Verify the necessary half-planes used to bound the ENTIRE old Omega.
    tests=[('c0',constant['c'].subs(v,0)),('a1',constant['a'].subs(v,(2-3*z)/4))]
    for name,p in tests:
        A,b=omega_constraint(name,z)
        assert s.expand(p-(b-A.dot(s.Matrix([f0,g0]))))==0
    for name,zz in [('sum_lower',0),('sum_upper',s.Rational(1,2))]:
        A,b=omega_constraint(name,0)
        assert s.expand(constant['a'].subs({v:0,z:zz})-(b-A.dot(s.Matrix([f0,g0]))))==0
    records=json.loads((HERE/'INDEPENDENT_RAYS_CERTIFICATES.json').read_text())['records']
    old=json.loads((HERE/'SHAPE_DEPENDENT_CERTIFICATES.json').read_text())['records']
    cert=json.loads((HERE/'INDEPENDENT_RAYS_SEPARATIONS.json').read_text())['records']
    models=json.loads((HERE/'INDEPENDENT_RAYS_B46_MODELS.json').read_text())['models']
    assert len(models)==44 and len({r['label'] for r in models})==44
    assert [r['label'] for r in cert]==[r['label'] for r in records]
    checked=[]
    for row,targetrow in zip(cert,records):
        sides=row['sides_abc'];assert min(sides)>0 and 2*max(sides)<sum(sides)
        n=s.Matrix(list(map(s.Rational,row['normal'])))
        q,k,hk=shape_data(sides)
        objective=s.Matrix([n.dot(s.Matrix(k[1:])),n.dot(s.Matrix(hk[1:]))])
        dual=row['omega_dual'];assert len(dual['constraints'])==len(dual['multipliers'])==2
        total=s.zeros(2,1);cap=0
        for constraint,multiplier in zip(dual['constraints'],dual['multipliers']):
            zz=s.Rational(constraint['z']);assert 0<=zz<=s.Rational(2,3)
            A,b=omega_constraint(constraint['entry'],zz);mu=s.Rational(multiplier);assert mu>=0
            total+=mu*A;cap+=mu*b
        assert total==objective and cap==s.Rational(dual['upper'])
        omega=cap+sum(n)/3;assert omega==s.Rational(row['omega_support_upper'])
        target=weights(sides,targetrow['coefficients']);assert list(map(str,target))==row['target_weights']
        support=n.dot(s.Matrix(target[1:]));assert support==s.Rational(row['target_support'])
        bounds=[omega];bracket_bounds=[omega]
        centroid_support=sum(n)/3
        target_upper=centroid_support+(support-centroid_support)*s.Rational(targetrow['upper'])/s.Rational(targetrow['lower'])
        target_interval_lower=min(support,target_upper)
        expected=old+[r for r in records if r['label']!=row['label']]
        assert len(row['other_shape_maps'])==len(expected)
        for item,source in zip(row['other_shape_maps'],expected):
            w=weights(sides,source['coefficients']);value=n.dot(s.Matrix(w[1:]))
            assert value==s.Rational(item['support']);bounds.append(value)
            if 'upper' in source:
                other_upper=centroid_support+(value-centroid_support)*s.Rational(source['upper'])/s.Rational(source['lower'])
                bracket_bounds.append(max(value,other_upper))
            else:bracket_bounds.append(value)
        assert len(row['rational_B46'])==44
        for item,model in zip(row['rational_B46'],models):
            assert item['label']==model['label']
            den=poly_value(model['polys_abc'][3],sides);assert den!=0
            w=[s.Rational(poly_value(p,sides),den) for p in model['polys_abc'][:3]]
            assert sum(w)==1 and list(map(str,w))==item['weights']
            value=n.dot(s.Matrix(w[1:]));assert value==s.Rational(item['support']);bounds.append(value);bracket_bounds.append(value)
        assert [r['label'] for r in row['power_enclosures']]==['M_-','M_+']
        for item in row['power_enclosures']:
            fresh=power_support(sides,item['label'],item['rational_point'],row['normal'])
            assert fresh['distance_error_upper']==item['distance_error_upper']
            assert fresh['support_upper']==item['support_upper']
            bounds.append(s.Rational(fresh['support_upper']));bracket_bounds.append(s.Rational(fresh['support_upper']))
        upper=max(bounds);assert upper==s.Rational(row['competitor_support_upper'])
        gap=support-upper;assert gap==s.Rational(row['gap'])>0
        robust_gap=target_interval_lower-max(bracket_bounds)
        assert robust_gap>0
        checked.append(dict(label=row['label'],sides_abc=sides,gap=str(gap),gap_decimal=float(gap),
            robust_boundary_gap=str(robust_gap),robust_boundary_gap_decimal=float(robust_gap),
            status='PASS: exactly indispensable, uniformly over all six radial endpoint brackets'))
        print(row['label'],'PASS; gap',float(gap),flush=True)
    result=dict(status='PASS: all six new maps have exact separation witnesses uniform over their boundary brackets',
        records=checked,baseline='B46, entire attractive constant-coefficient family, four previous shape-dependent maps, and other five new lower maps',
        scope='nonredundancy within this specified family, for the certified lower maps and true radial boundary maps; not exposure on unrestricted maximal Heart',
        seconds=round(time.monotonic()-start,3))
    (HERE/'INDEPENDENT_RAYS_SEPARATION_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
