"""Numerical evaluation of the PROVED constant-coefficient region.

Attractivity is established by verify_complete_omega_domain.py, not here.
Support maxima use endpoint/stationary polynomial roots, not arc sampling.
"""
import numpy as np

TLOW=4*np.sqrt(10)-12
THIGH=1.040157923221270611479841890420777381297
ALPHA=0.27168605062094797061563562297511
BETA=.5-np.sqrt(2*np.sqrt(3)-3)/6
TOP=np.array([-1/6,5/6])
LEFT=np.array([-2/3,1/3])


def arc_I(t):
    t=np.asarray(t)
    return np.stack([8*t/(t*t+8),-8/(t*t+8)],axis=-1)


def arc_II(r):
    r=np.asarray(r)
    D=54*r**4-108*r**3+63*r*r-12*r+1
    return np.stack([-2*(9*r*r-7*r+1)/D,(2*r-1)/D],axis=-1)


def center_basis(sides):
    """Return the (w_B,w_C) barycentric displacements K and HK."""
    ss=np.asarray(sides,dtype=float)**2
    ss/=ss.sum()
    return (ss-1/3)[1:],(4*(ss-1/3)-6*(ss*ss-np.mean(ss*ss)))[1:]


def support_I(uv):
    uv=np.atleast_2d(uv)
    u,v=uv.T
    rad=np.hypot(v,np.sqrt(8)*u)
    q=v+np.copysign(rad,v)
    first=np.divide(q,u,out=np.full_like(u,np.nan),where=np.abs(u)>1e-30)
    second=np.divide(-8*u,q,out=np.full_like(u,np.nan),where=np.abs(q)>1e-30)
    candidates=np.stack([np.full_like(u,TLOW),np.full_like(u,THIGH),first,second])
    valid=np.isfinite(candidates)&(candidates>=TLOW)&(candidates<=THIGH)
    tt=np.where(valid,candidates,TLOW)
    vals=np.where(valid,8*(u*tt-v)/(tt*tt+8),-np.inf)
    indices=np.argmax(vals,axis=0)
    return vals[indices,np.arange(len(u))],tt[indices,np.arange(len(u))]


def support_II(uv):
    values=[]
    parameters=[]
    for u,v in np.atleast_2d(uv):
        # Positive derivative prefactor times this cubic; roots suffice.
        coefs=np.array([54*u,-63*u-9*v,18*u+9*v,-u-v])
        size=np.max(np.abs(coefs))
        candidates=[ALPHA,BETA]
        if size>1e-30:
            coefs=coefs/size
            coefs=np.trim_zeros(coefs,'f')
            if len(coefs)>1:
                for root in np.roots(coefs):
                    if abs(root.imag)<1e-9 and ALPHA-1e-12<=root.real<=BETA+1e-12:
                        candidates.append(float(np.clip(root.real,ALPHA,BETA)))
        vals=arc_II(candidates)@np.array([u,v])
        i=int(np.argmax(vals))
        values.append(float(vals[i]));parameters.append(candidates[i])
    return np.array(values),np.array(parameters)


def support_components(normals,k,hk):
    uv=np.column_stack([normals@k,normals@hk])
    base=normals@np.array([1/3,1/3])
    si,ti=support_I(uv)
    sii,rii=support_II(uv)
    return dict(ArcI=base+si,ArcII=base+sii,Ptop=base+uv@TOP,Pleft=base+uv@LEFT,
                t=ti,r=rii)


def triangle_centers(vertices,coefficients):
    """Evaluate Z for coefficient pairs, directly in Cartesian space."""
    p=np.asarray(vertices,float)
    G=p.mean(axis=0);r=p-G
    S=r.T@r;L=np.trace(S)
    if L<=0:raise ValueError('all vertices coincide')
    ss=np.array([np.sum((p[1]-p[2])**2),np.sum((p[2]-p[0])**2),np.sum((p[0]-p[1])**2)])
    K=ss@p/ss.sum()-G
    HK=(2*S/L-np.eye(2))@K
    return G+np.atleast_2d(coefficients)@np.vstack([K,HK])


def coefficient_membership(f,g,tolerance=1e-10):
    """Numerical evaluation of an exact necessary-and-sufficient criterion.

    The theorem reduces membership to minima of a quadratic and cubic on
    [0,2/3], and two scalar bounds. Near-zero results are labelled unresolved
    at numerical precision, not promoted to exact boundary certificates.
    """
    f=float(f);g=float(g)
    if not np.isfinite([f,g]).all():raise ValueError('finite coefficients required')
    records=[dict(entry='a0',z=0.,value=1+3*(f+g)),
             dict(entry='a0',z=.5,value=1-1.5*(f+g))]
    for name,polynomial in [('c0',[-18*g,-3*f+12*g,1+f-g]),
                            ('a1',[54*g,9*f-63*g,-9*f+18*g,1+f-g])]:
        points=[0.,2/3]
        derivative=np.trim_zeros(np.polyder(polynomial),'f')
        if len(derivative)>1:
            for root in np.roots(derivative):
                if abs(root.imag)<1e-10 and 0<root.real<2/3:points.append(float(root.real))
        values=np.polyval(polynomial,points)
        j=int(np.argmin(values))
        records.append(dict(entry=name,z=points[j],value=float(values[j])))
    worst=min(records,key=lambda item:item['value'])
    margin=worst['value']
    status=('numerically outside' if margin < -tolerance else
            'numerically inside' if margin > tolerance else 'near boundary: exact check required')
    return dict(status=status,minimum_scalar_slack=margin,limiting_test=worst,tests=records)
