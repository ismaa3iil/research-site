"""Exact parameter-uniform positivity certificates for t in [2/3,1].

All certificate decisions use rational Bernstein coefficients. Adaptive
subdivision is bounded; an incomplete search is never labelled a proof.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import itertools,json,time
import numpy as np
import sympy as s
from derive_arc_matrix import derive

HERE=Path(__file__).resolve().parent


def bernstein(polynomial,variables):
    p=s.Poly(polynomial,*variables)
    degrees=p.degree_list()
    terms={k:F(int(v.p),int(v.q)) for k,v in p.terms()}
    result=np.empty(tuple(d+1 for d in degrees),dtype=object)
    for index in np.ndindex(result.shape):
        total=F(0)
        for powers,coef in terms.items():
            if any(k>i for k,i in zip(powers,index)):continue
            scale=F(1)
            for k,i,d in zip(powers,index,degrees):scale*=F(comb(i,k),comb(d,k))
            total+=coef*scale
        result[index]=total
    return result


def bisect(coefficients,axis):
    a=np.moveaxis(coefficients,axis,0);left=a.copy();right=a.copy()
    for index in np.ndindex(a.shape[1:]):
        line=[a[(j,)+index] for j in range(a.shape[0])]
        left[(0,)+index]=line[0];right[(len(line)-1,)+index]=line[-1]
        for step in range(1,len(line)):
            line=[(line[j]+line[j+1])/2 for j in range(len(line)-1)]
            left[(step,)+index]=line[0]
            right[(a.shape[0]-1-step,)+index]=line[-1]
    return np.moveaxis(left,0,axis),np.moveaxis(right,0,axis)


def certify(polynomial,variables,seconds=15,max_nodes=20000,max_depth=24):
    coefficients=bernstein(polynomial,variables)
    started=time.monotonic();nodes=0;leaves=0;max_seen=0;least=None
    def walk(values,depth,levels):
        nonlocal nodes,leaves,max_seen,least
        nodes+=1;max_seen=max(max_seen,depth)
        if time.monotonic()-started>seconds or nodes>max_nodes or depth>max_depth:
            raise TimeoutError('bounded Bernstein search exhausted')
        minimum=min(values.flat)
        if minimum>=0:
            leaves+=1;least=minimum if least is None else min(least,minimum)
            return {'nonnegative':True,'minimum':str(minimum)}
        if max(values.flat)<0:raise ValueError('negative Bernstein box')
        axis=min((i for i,d in enumerate(values.shape) if d>1),key=lambda i:levels[i])
        next_levels=list(levels);next_levels[axis]+=1
        children=bisect(values,axis)
        return dict(axis=axis,children=[walk(child,depth+1,next_levels) for child in children])
    tree=walk(coefficients,0,[0]*len(variables))
    return dict(method='exact rational tensor Bernstein midpoint cover',
        degrees=[d-1 for d in coefficients.shape],tree=tree,nodes=nodes,leaves=leaves,
        max_depth=max_seen,minimum_leaf_coefficient=str(least),seconds=round(time.monotonic()-started,4))


def main():
    tic=time.monotonic();data=derive();z,v,t=[data[k] for k in ['z','v','t']]
    h,Z,H,T=s.symbols('h Z H T',real=True)
    remainder=s.cancel(data['det_remainder']/(96*z))
    vsub=(2-3*z)*h/4
    tasks=[]
    for endpoint in [0,1]:
        tasks.append((f'M11_h{endpoint}',data['M11'].subs(v,vsub).subs(h,endpoint)-s.Rational(1,16),F(0),F(2,3),False))
        tasks.append((f'remainder_middle_h{endpoint}',remainder.subs(v,vsub).subs(h,endpoint),F(1,3),F(1,2),False))
    tasks.extend([
        ('det_lower',data['det'].subs(v,vsub),F(0),F(1,3),True),
        ('det_upper',data['det'].subs(v,vsub),F(1,2),F(2,3),True)])
    records=[]
    for name,p,lo,hi,has_h in tasks:
        variables=[Z,H,T] if has_h else [Z,T]
        unit=s.expand(p.subs({z:s.Rational(lo.numerator,lo.denominator)+s.Rational((hi-lo).numerator,(hi-lo).denominator)*Z,
                             h:H,t:s.Rational(2,3)+T/3},simultaneous=True))
        certificate=certify(unit,variables)
        record=dict(name=name,original_polynomial=str(s.expand(p)),z_interval=[str(lo),str(hi)],
                    h_variable=has_h,unit_variables=list(map(str,variables)),unit_polynomial=str(unit),
                    certificate=certificate)
        records.append(record)
        print(json.dumps(dict(task=name,leaves=certificate['leaves'],nodes=certificate['nodes'],
                 minimum=certificate['minimum_leaf_coefficient'],seconds=certificate['seconds'])),flush=True)
    result=dict(parameter_interval=['2/3','1'],definition='Z_t=G+8t/(t^2+8) K-8/(t^2+8) H K',
                scaling='M=3(t^2+8) Sym D_i Z_t',matrix={k:str(v) for k,v in data.items()},
                tasks=records,M11_positive_lower_bound='1/16',
                status='proved attractive on full parameter interval by exact Bernstein covers',
                seconds=round(time.monotonic()-tic,3))
    (HERE/'BOUNDARY_ARC_CERTIFICATE.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],seconds=result['seconds'])),flush=True)


if __name__=='__main__':main()
