(* Exact Mathematica definitions. No optimization or numerical proof claim. *)
ClearAll[ACShapeInvariant, ACShapeWeights, ACShapeCenter];
ACShapeInvariant[p_List] := Module[{d, s},
  d = {Total[(p[[2]] - p[[3]])^2], Total[(p[[3]] - p[[1]])^2],
       Total[(p[[1]] - p[[2]])^2]};
  s = d/Total[d]; (3 Total[s^2] - 1)/2
];
ACShapeWeights[p_List, pars_List : {2/5, 6/5, -3/2, 5/2}] :=
 Module[{d, s, q, f, g},
  d = {Total[(p[[2]] - p[[3]])^2], Total[(p[[3]] - p[[1]])^2],
       Total[(p[[1]] - p[[2]])^2]};
  s = d/Total[d]; q = (3 Total[s^2] - 1)/2;
  f = pars[[1]] + pars[[2]] q; g = pars[[3]] + pars[[4]] q;
  ConstantArray[1/3, 3] + (f + 4 g) (s - ConstantArray[1/3, 3])
    - 6 g (s^2 - ConstantArray[Mean[s^2], 3])
];
ACShapeCenter[p_List, pars_List : {2/5, 6/5, -3/2, 5/2}] :=
  ACShapeWeights[p, pars].p;
ACShapeSimple = {2/5, 6/5, -3/2, 5/2};
ACShapeSecond = {2/5, 1, -3/2, 14/5};
ACShapeThird = {3/8, 1, -7/5, 5/2};
ACShapeRadialBracket = {10478284289/10000000000, 1047828429/1000000000};
ACShapeNearBoundary = First[ACShapeRadialBracket] ACShapeSimple;
(* Example: both points are globally certified attractive centers. *)
With[{p = {{0, 0}, {11, 0}, {-169/11, 20 Sqrt[62]/11}}},
 {ACShapeCenter[p], ACShapeCenter[p, ACShapeNearBoundary]} // N
]
