# Six independent shape-dependent rays — 17 October 2026

Read `INDEPENDENT_RAYS_REPORT.md` first. See `INDEPENDENT_RAYS_COMPARISON.png`.

Six new maps are globally certified attractive. Each is rigorously close to
its radial boundary, and each has an exact nonredundancy witness against B46,
the complete old constant family, all four earlier shape-dependent maps, and
the other five new maps. This is not a maximal-Heart or minimal-base theorem.

Exact replay, with assertions enabled:

    python verify_independent_rays.py
    python verify_ray_separations.py

Dependencies: Python, SymPy, mpmath. Numerical audit/tests additionally need
NumPy and SciPy. Plotting additionally needs Matplotlib.

Evaluators:

- Python: `independent_ray_centers.centers(vertices)` and `weights(vertices)`.
- Mathematica: `Get["IndependentRays.wl"]`, then `ACIndependentCenters[vertices]`.

The evaluators use rigorously certified lower endpoints, not unproved numerical
boundary guesses. All numerical area/audit claims are clearly distinguished
from exact proofs. `INDEPENDENT_RAYS_BUNDLE_REPLAY.json` records isolated-copy QA.

The previous shape-dependent proof archive is included under `reference/`.
It need not be extracted to run the new proofs. Archived shape data and B46
polynomial models are supplied for reproducibility, not modified in place.
