"""Independent product-rule derivation and exact rational proof replay.

Uses the constant-family Cartesian verifier, an area-based derivative of
q=1-3e2, and fresh Bernstein conversion at every saved subbox. The new
fixed-vertex differentiation generator is NOT imported. Requires SymPy.
"""
from pathlib import Path
import hashlib,json,time,math
import sympy as s
from verify_boundary_arc import cartesian_matrix,replay

HERE=Path(__file__).resolve().parent


def leaf_minimum(node):
    """Aggregate leaf minima only after replay has independently checked each."""
    if node.get('nonnegative'):return s.Rational(node['minimum'])
    return min(leaf_minimum(child) for child in node['children'])


def independent_matrix():
    z,v,t,f0,f1,g0,g1=s.symbols('z v t f0 f1 g0 g1')
    old=cartesian_matrix()
    U=[];Vmat=[]
    for key,identity in [('M11',1),('M12_over_XY',0),('M22',1)]:
        U.append(s.expand(old[key]).coeff(t)/8)
        Vmat.append(identity-old[key].subs(t,0)/8)
    V=(2-3*z)/4;u=V-v;q=s.Rational(1,4)-3*z*v
    kx=s.Rational(3,2)-3*z-2*v
    hx=s.Rational(3,2)-3*z+(6*z-4)*v
    # Let area T=3rY/2 and sum of squared sides Q=3 (at L=1).
    # q=1/4-12*T^2/Q^2. Fixed-vertex derivatives are grad T=(Y,-X),
    # grad Q=(6r,0). Hence grad q=(4r v(3z-1),4r XY).
    # K=(r*kx,2rXY), HK=(r*hx,4rXY(1-3z)).
    # These are the 3*Sym(K grad(q)^T) and 3*Sym(HK grad(q)^T) entries.
    extraK=[12*z*v*(3*z-1)*kx,6*z*kx+12*z*v*(3*z-1),24*z*u*v]
    extraHK=[12*z*v*(3*z-1)*hx,6*z*hx-24*z*v*(3*z-1)**2,48*z*u*v*(1-3*z)]
    return {name:s.expand(identity+f0*uu+f1*(q*uu+ek)+g0*vv+g1*(q*vv+eh))
            for name,identity,uu,vv,ek,eh in zip(['a','b','c'],[1,0,1],U,Vmat,extraK,extraHK)}


def main():
    if not __debug__:raise RuntimeError('Run without -O: assertions are essential.')
    start=time.monotonic()
    z,v,f0,f1,g0,g1,Z,H=s.symbols('z v f0 f1 g0 g1 Z H')
    direct=independent_matrix()
    matrix=json.loads((HERE/'SHAPE_DEPENDENT_MATRIX.json').read_text())
    for key in direct:assert s.expand(direct[key]-s.sympify(matrix['matrix'][key]))==0
    path=HERE/'SHAPE_DEPENDENT_CERTIFICATES.json';saved=json.loads(path.read_text())
    assert len(saved['records'])==4
    checked=[]
    for record in saved['records']:
        assert record['status']=='exact certificate generated'
        coeff=list(map(s.Rational,record['coefficients']))
        a,b,c=[s.expand(direct[name].subs(dict(zip([f0,f1,g0,g1],coeff)))) for name in ['a','b','c']]
        margin=s.Rational(record['scaled_margin']);assert margin>0
        determinant=s.expand((a-margin)*(c-margin)-v*((2-3*z)/4-v)*b*b)
        expected={'positive_diagonal':a-margin,'positive_determinant':determinant}
        assert len(record['tasks'])==2 and {r['name'] for r in record['tasks']}==set(expected)
        results=[]
        for task in record['tasks']:
            p=expected[task['name']]
            assert s.expand(p-s.sympify(task['polynomial']))==0
            unit=s.expand(p.subs({z:2*Z/3,v:(1-Z)*H/2},simultaneous=True))
            assert s.expand(unit-s.sympify(task['unit_polynomial']))==0
            leaves=replay(unit,[Z,H],task['certificate']['tree'])
            actual_minimum=leaf_minimum(task['certificate']['tree'])
            assert actual_minimum==s.Rational(task['certificate']['minimum_leaf_coefficient'])
            # Diagonal is strictly positive (all leaf minima positive).
            if task['name']=='positive_diagonal':assert actual_minimum>0
            results.append(dict(name=task['name'],leaves=leaves))
        checked.append(dict(coefficients=record['coefficients'],status='PASS: globally attractive',
                            lower_bound_on_Sym_J=str(margin/3),tasks=results))
        print('verified',record['coefficients'],flush=True)
    radial=saved['radial'];seed=list(map(s.Rational,radial['seed']))
    lower=s.Rational(radial['lower']);upper=s.Rational(radial['upper'])
    assert 0<lower<upper
    assert any(list(map(s.Rational,row['coefficients']))==[lower*x for x in seed] for row in checked)
    ce=radial['upper_counterexample'];zz=s.Rational(ce['z']);hh=s.Rational(ce['h'])
    assert 0<zz<s.Rational(2,3) and 0<hh<1
    vv=(2-3*zz)*hh/4;assert vv==s.Rational(ce['v'])
    abc=[s.factor(direct[name].subs(dict(zip([f0,f1,g0,g1],[upper*x for x in seed]))).subs({z:zz,v:vv})) for name in ['a','b','c']]
    determinant=s.factor(abc[0]*abc[2]-vv*((2-3*zz)/4-vv)*abc[1]**2)
    assert determinant==s.Rational(ce['determinant'])<0
    assert abc[0]==s.Rational(ce['a'])>0
    # The exact displacement (-sqrt(v(V-v))*b,a) has quadratic response
    # a*det(M)<0. Thus the upper map fails at a NONDEGENERATE scalene shape.
    V=(2-3*zz)/4
    apex=s.Matrix([s.Rational(3,2)*s.sqrt(zz*(1-hh)/V),s.Rational(3,2)*s.sqrt(zz*hh/V)])
    X=s.sqrt(V-vv);Y=s.sqrt(vv)
    motion=s.Matrix([-X*Y*abc[1],abc[0]])
    canonical_motion=s.Matrix([[X,Y],[Y,-X]])*motion/s.sqrt(V)
    angle=math.atan2(float(canonical_motion[1]),float(canonical_motion[0]))%math.pi
    # Numeric coordinates are explanatory only.
    result=dict(status='PASS: independent product-rule derivation and all exact certificates',
                checked=checked,radial_boundary_bracket=dict(lower=str(lower),upper=str(upper),
                    width=str(upper-lower),interpretation='supremal positive lambda; lower globally certified, upper exactly disproved',
                    counterexample_apex=[str(s.N(a,18)) for a in apex],
                    counterexample_base='(-1,0),(1,0)',
                    counterexample_motion_angle_radians=angle,
                    exact_motion_formula='In moving-radius frame: (-sqrt(v(V-v))*b, a); its quadratic response is a*det(M)/3 < 0.',
                    negative_scaled_determinant_decimal=str(s.N(determinant,18))),
                certificate_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),seconds=round(time.monotonic()-start,3))
    (HERE/'SHAPE_DEPENDENT_INDEPENDENT_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':main()
