"""Finite numerical leave-one-out hull audit; not an exact separation proof."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import json,time
from fractions import Fraction
import numpy as np
from scipy.spatial import ConvexHull
from omega_support import center_basis,support_components,arc_I,arc_II,TLOW,THIGH,ALPHA,BETA,TOP,LEFT
from search_shape_dependent import AUDIT

HERE=Path(__file__).resolve().parent


def main():
    started=time.monotonic();shapes=json.loads((AUDIT/'SHAPES.json').read_text());base=np.load(AUDIT/'BASE_WEIGHTS.npy')
    records=json.loads((HERE/'INDEPENDENT_RAYS_CERTIFICATES.json').read_text())['records']
    old=json.loads((HERE/'SHAPE_DEPENDENT_CERTIFICATES.json').read_text())['records']
    coefficients=np.array([[float(Fraction(v)) for v in row['coefficients']] for row in old+records])
    curve=np.vstack([TOP,LEFT,arc_I(np.linspace(TLOW,THIGH,41)),arc_II(np.linspace(ALPHA,BETA,41))])
    angles=np.linspace(0,2*np.pi,48,endpoint=False);fixed=np.column_stack([np.cos(angles),np.sin(angles)])
    rows=[];skip=0
    for i,(shape,cloud) in enumerate(zip(shapes,base)):
        sing=np.linalg.svd(cloud-cloud.mean(0),compute_uv=False)
        if sing[0]<1e-13 or sing[1]<1e-11*sing[0]:skip+=1;continue
        sides=np.array(shape['sides_abc'],float);ss=sides*sides;ss/=ss.sum();q=(3*sum(ss*ss)-1)/2
        k,hk=center_basis(sides)
        pts=1/3+(coefficients[:,0]+q*coefficients[:,1])[:,None]*k+(coefficients[:,2]+q*coefficients[:,3])[:,None]*hk
        oldcloud=np.vstack([cloud,1/3+curve@np.vstack([k,hk]),pts[:4]])
        allnorm=ConvexHull(np.vstack([oldcloud,pts[4:]])).equations[:,:2]
        allnorm=allnorm[np.argsort(np.arctan2(allnorm[:,1],allnorm[:,0]))]
        mid=allnorm+np.roll(allnorm,1,axis=0);mid/=np.linalg.norm(mid,axis=1)[:,None]
        normals=np.vstack([fixed,mid,ConvexHull(oldcloud).equations[:,:2]])
        parts=support_components(normals,k,hk)
        baseline=np.maximum.reduce([np.max(normals@cloud.T,axis=1)]+
                 [parts[name] for name in ['ArcI','ArcII','Ptop','Pleft']]+[np.max(normals@pts[:4].T,axis=1)])
        scores=normals@pts[4:].T
        gains=scores-baseline[:,None]
        leave=np.column_stack([scores[:,j]-np.maximum(baseline,np.max(np.delete(scores,j,axis=1),axis=1)) for j in range(6)])
        jj=np.argmax(leave,axis=0)
        rows.append(dict(shape=i,sides_abc=shape['sides_abc'],gains=np.max(gains,axis=0).tolist(),
                         leave_one_out=leave[jj,np.arange(6)].tolist(),normals=normals[jj].tolist()))
        if (i+1)%1000==0:print('audit',i+1,'/',len(shapes),flush=True)
    tol=1e-8
    sets=[[r['shape'] for r in rows if r['gains'][j]>tol] for j in range(6)]
    independent=[[r['shape'] for r in rows if r['leave_one_out'][j]>tol] for j in range(6)]
    simple=[]
    for j in range(6):
        useful=[r for r in rows if r['leave_one_out'][j]>1e-5]
        useful.sort(key=lambda r:(max(r['sides_abc']),-r['leave_one_out'][j]))
        simple.append(useful[:3])
    result=dict(status='numerical detections with continuous Omega support; finite normal set',
        evaluated=len(rows),skipped=skip,tolerance=tol,counts=list(map(len,sets)),
        union_count=len(set().union(*map(set,sets))),leave_one_out_counts=list(map(len,independent)),
        detected_shape_indices=sets,independence_shape_indices=independent,simple_witnesses=simple,
        baseline='B46 + full constant Omega + all four previously certified shape-dependent maps',
        seconds=round(time.monotonic()-started,3))
    (HERE/'INDEPENDENT_RAYS_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    (HERE/'INDEPENDENT_RAYS_AUDIT_ROWS.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','evaluated','counts','union_count','leave_one_out_counts','seconds']},indent=2))


if __name__=='__main__':main()
