"""Derive the vertex response in coordinates aligned with the moving radius."""
from pathlib import Path
import json
import sympy as s

HERE=Path(__file__).resolve().parent


def derive():
    z,u,v,w,t=s.symbols('z u v w t',real=True)
    I=s.eye(2)
    S=s.Matrix([[s.Rational(3,2)*z+2*u,2*w],[2*w,2*v]])
    H=2*S-I
    # L=1, moving radius r=(sqrt(z),0), other radii -r/2 +/- (X,Y).
    # u=X^2, v=Y^2, w=XY; K*r^T is expressible without square roots.
    Kr=s.Matrix([[-z*((3*z-1)/2-2*u),0],[2*z*w,0]])
    DK=(s.Rational(1,3)-z)*I-2*s.diag(z,0)+s.Rational(2,3)*S-2*Kr
    DHK=H*DK+2*(Kr[0,0]*I+Kr.T)-4*S*Kr
    M=(t*t+8)*I+12*t*(DK+DK.T)-12*(DHK+DHK.T)
    def reduce(expr):
        return s.factor(s.expand(expr).subs(w*w,u*v).subs(u,(2-3*z)/4-v))
    a=reduce(M[0,0]);b=reduce(M[0,1]/w);c=reduce(M[1,1])
    determinant=s.factor(a*c-v*((2-3*z)/4-v)*b*b)
    flat_a=s.factor(a.subs(v,0));flat_c=s.factor(c.subs(v,0))
    assert s.expand(flat_c-(t-12*z+4)**2)==0,flat_c
    remainder=s.factor((determinant-flat_a*flat_c)/v)
    return dict(z=z,v=v,t=t,M11=a,M12_over_XY=b,M22=c,det=determinant,
                flat_M11=flat_a,flat_M22=flat_c,det_remainder=remainder)


def main():
    data=derive()
    record={k:str(v) for k,v in data.items()}
    (HERE/'ARC_SYMBOLIC_MATRIX.json').write_text(json.dumps(record,indent=2)+'\n')
    for k in ['M11','M12_over_XY','M22','flat_M11','det_remainder']:
        print(k,'=',data[k],flush=True)


if __name__=='__main__':main()
