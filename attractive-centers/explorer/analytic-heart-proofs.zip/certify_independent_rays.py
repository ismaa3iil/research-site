"""Generate exact global lower certificates and rational upper counterexamples."""
from pathlib import Path
import json,time,math
import sympy as s
from prove_boundary_arc import certify

HERE=Path(__file__).resolve().parent


def main():
    started=time.monotonic()
    z,v,f0,f1,g0,g1,Z,H=s.symbols('z v f0 f1 g0 g1 Z H')
    symbols=[f0,f1,g0,g1]
    raw=json.loads((HERE/'SHAPE_DEPENDENT_MATRIX.json').read_text())
    abc=[s.sympify(raw['matrix'][key]) for key in ['a','b','c']]
    rows=json.loads((HERE/'INDEPENDENT_RAYS_SEARCH.json').read_text())['selected']
    results=[]
    for row in rows:
        seed=list(map(s.Rational,row['seed']));opt=row['discovery']
        lower=s.Rational(math.floor(opt['lambda_estimate']*10**8)-1,10**8)
        upper=lower+s.Rational(3,10**8)
        cf=[lower*x for x in seed];margin=s.Rational(1,10**10)
        a,b,c=[s.expand(p.subs(dict(zip(symbols,cf)))) for p in abc]
        V=(2-3*z)/4
        tasks=[]
        for name,poly in [('diagonal',a-margin),('determinant',(a-margin)*(c-margin)-v*(V-v)*b*b)]:
            unit=s.expand(poly.subs({z:2*Z/3,v:(1-Z)*H/2},simultaneous=True))
            try:
                proof=certify(unit,[Z,H],seconds=25,max_nodes=20000,max_depth=70)
                tasks.append(dict(name=name,certificate=proof))
                print(row['label'],name,proof['leaves'],'leaves',flush=True)
            except (ValueError,TimeoutError) as exc:
                tasks.append(dict(name=name,error=str(exc)));break
        # All upper witnesses are strictly nondegenerate, even when the
        # limiting numerical shape lies on the collinear edge h=0.
        zz=s.Rational(round(opt['z']*10**10),10**10)
        hh=s.Rational(round(opt['h']*10**10),10**10)
        if hh==0:hh=s.Rational(1,10**12)
        vv=(2-3*zz)*hh/4
        up=[s.factor(p.subs(dict(zip(symbols,[upper*x for x in seed]))).subs({z:zz,v:vv})) for p in abc]
        det=s.factor(up[0]*up[2]-vv*((2-3*zz)/4-vv)*up[1]**2)
        negative=bool(det<0 or up[0]<0 or up[2]<0)
        assert negative,(row['label'],det)
        passed=len(tasks)==2 and all('certificate' in task for task in tasks)
        results.append(dict(label=row['label'],seed=row['seed'],lower=str(lower),upper=str(upper),
            coefficients=list(map(str,cf)),scaled_margin=str(margin),tasks=tasks,
            upper_witness=dict(z=str(zz),h=str(hh),v=str(vv),a=str(up[0]),c=str(up[2]),determinant=str(det)),
            status='exact certificates generated; independent replay required' if passed else 'unresolved lower certificate'))
        (HERE/'INDEPENDENT_RAYS_CERTIFICATES.json').write_text(json.dumps(dict(records=results),indent=2)+'\n')
        print(row['label'],results[-1]['status'],'bracket',float(lower),float(upper),flush=True)
    result=dict(status='generation complete; independent replay required',date='2026-10-17',records=results,
                seconds=round(time.monotonic()-started,3))
    (HERE/'INDEPENDENT_RAYS_CERTIFICATES.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
