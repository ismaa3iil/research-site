"""Exact leave-one-out separation witnesses for the six new maps."""
from pathlib import Path
import json,hashlib,itertools
from fractions import Fraction as F
import numpy as np
import sympy as s
import mpmath as m
from scipy.optimize import linprog
from search_shape_dependent import AUDIT
from ray_separation_common import poly_value,shape_data,weights,omega_constraint,power_support

HERE=Path(__file__).resolve().parent


def omega_dual(normal):
    constraints=[dict(entry=entry,z=str(s.Rational(2*k,3*384))) for entry in ['c0','a1'] for k in range(385)]
    constraints += [dict(entry='sum_lower',z='0'),dict(entry='sum_upper',z='0')]
    ab=[omega_constraint(row['entry'],row['z']) for row in constraints]
    A=np.array([[float(t) for t in pair[0]] for pair in ab]);B=np.ones(len(A))
    sol=linprog(-np.array(normal,float).ravel(),A_ub=A,b_ub=B,bounds=[(None,None)]*2,method='highs')
    assert sol.success
    active=np.argsort(sol.ineqlin.marginals)[:8]
    for i,j in itertools.combinations(active,2):
        matrix=s.Matrix.hstack(ab[i][0],ab[j][0])
        if matrix.det()==0:continue
        multipliers=matrix.inv()*normal
        if all(t>=0 for t in multipliers):
            upper=sum(multipliers)
            if abs(float(upper)+sol.fun)>1e-8:continue
            return dict(constraints=[constraints[i],constraints[j]],multipliers=list(map(str,multipliers)),upper=str(upper))
    raise RuntimeError('No exact two-constraint dual found')


def main():
    if not __debug__:raise RuntimeError('Assertions required.')
    m.mp.dps=100
    reference=json.loads((AUDIT/'REFERENCE_B46.json').read_text())['members']
    models={}
    for line in (AUDIT/'MODELS.jsonl').read_text().splitlines():
        row=json.loads(line)
        if row.get('audit_kind')=='base':models[row['label']]=row
    rational_models=[dict(label=row['label'],polys_abc=models[row['label']]['polys_abc']) for row in reference if 'formula' in row]
    assert len(rational_models)==44
    modelrecord=dict(source='B46_NATIVE_AUDIT/MODELS.jsonl',source_sha256=hashlib.sha256((AUDIT/'MODELS.jsonl').read_bytes()).hexdigest(),
                     models=rational_models)
    (HERE/'INDEPENDENT_RAYS_B46_MODELS.json').write_text(json.dumps(modelrecord,indent=2)+'\n')
    audit=json.loads((HERE/'INDEPENDENT_RAYS_AUDIT.json').read_text())
    records=json.loads((HERE/'INDEPENDENT_RAYS_CERTIFICATES.json').read_text())['records']
    old=json.loads((HERE/'SHAPE_DEPENDENT_CERTIFICATES.json').read_text())['records']
    cloud=np.load(AUDIT/'BASE_WEIGHTS.npy');powers={};results=[]
    for j,row in enumerate(records):
        example=audit['simple_witnesses'][j][0];sides=example['sides_abc'];a,b,c=sides
        normal=list(map(s.Rational,[str(F(float(t)).limit_denominator(10000)) for t in example['normals'][j]]))
        q,k,hk=shape_data(sides);n=s.Matrix(normal)
        u=n.dot(s.Matrix([k[1],k[2]]));v=n.dot(s.Matrix([hk[1],hk[2]]))
        dual=omega_dual(s.Matrix([u,v]));omega=s.Rational(dual['upper'])+sum(n)/3
        target=weights(sides,row['coefficients']);support=n.dot(s.Matrix([target[1],target[2]]))
        others=[]
        for candidate in old+[r for r in records if r['label']!=row['label']]:
            w=weights(sides,candidate['coefficients']);value=n.dot(s.Matrix([w[1],w[2]]))
            others.append(dict(label=candidate.get('label','previous '+str(candidate['coefficients'])),support=str(value)))
        rational=[]
        for model in rational_models:
            den=poly_value(model['polys_abc'][3],sides);assert den!=0
            w=[s.Rational(poly_value(p,sides),den) for p in model['polys_abc'][:3]]
            assert sum(w)==1
            rational.append(dict(label=model['label'],weights=list(map(str,w)),support=str(n.dot(s.Matrix(w[1:])))))
        x=s.Rational(b*b+c*c-a*a,2*c);height=m.sqrt(m.mpf(str(b*b-x*x)))
        vertices=[(m.mpf(0),m.mpf(0)),(m.mpf(c),m.mpf(0)),(m.mpf(str(x)),height)]
        enclosed=[]
        for label,pp in [('M_-',4-2*m.sqrt(2)),('M_+',4+2*m.sqrt(2))]:
            key=(tuple(sides),label)
            if key not in powers:
                index=next(i for i,r in enumerate(reference) if r['label']==label)
                wb,wc=cloud[example['shape'],index]
                guess=[m.mpf(str(wb))*c+m.mpf(str(wc))*vertices[2][0],m.mpf(str(wc))*height]
                def gradient(X,Y):
                    return tuple(sum(((X-v[0])**2+(Y-v[1])**2)**((pp-2)/2)*([X,Y][axis]-v[axis]) for v in vertices) for axis in range(2))
                root=m.findroot(gradient,guess,tol=m.mpf('1e-90'),maxsteps=150)
                powers[key]=[m.nstr(t,90) for t in root]
            point=powers[key]
            bound=power_support(sides,label,point,list(map(str,normal)))
            enclosed.append(dict(label=label,rational_point=point,**bound))
        upper=max([omega]+[s.Rational(r['support']) for r in rational+others]+[s.Rational(r['support_upper']) for r in enclosed])
        gap=support-upper;assert gap>0,(row['label'],gap)
        results.append(dict(label=row['label'],sides_abc=sides,normal=list(map(str,n)),
            target_weights=list(map(str,target)),target_support=str(support),omega_dual=dual,
            omega_support_upper=str(omega),rational_B46=rational,power_enclosures=enclosed,
            other_shape_maps=others,competitor_support_upper=str(upper),gap=str(gap),gap_decimal=float(gap)))
        print(row['label'],sides,'exact positive gap',float(gap),flush=True)
    (HERE/'INDEPENDENT_RAYS_SEPARATIONS.json').write_text(json.dumps(dict(
        status='six exact leave-one-out separation certificates generated; replay required',records=results,
        interpretation='Each certified lower map is outside the hull of B46, all constant attractive maps, all previous shape maps, and the other five new lower maps.'),indent=2)+'\n')


if __name__=='__main__':main()
