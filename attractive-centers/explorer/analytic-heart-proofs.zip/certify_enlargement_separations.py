"""Generate exact rational leave-one-out separation certificates for:
- Bridge_Mid (the exact midpoint t=1/2 of the repaired conic bridge c_bridge(t)),
- R7, R8, R9, R10 (the four new certified Omega_4 rays),
- P1, P2, P3 (the three new certified 6-parameter cubic-phase rays).
"""
from pathlib import Path
from fractions import Fraction as F
import json, time, sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import numpy as np
import sympy as s
import mpmath as m
from scipy.spatial import ConvexHull
from prove_boundary_arc import certify
from verify_boundary_arc import replay
from verify_shape_dependent import leaf_minimum
from certify_ray_separations import omega_dual
from ray_separation_common import poly_value, shape_data, weights, omega_constraint, power_support
from omega_support import center_basis, support_components, arc_I, arc_II, TLOW, THIGH, ALPHA, BETA, TOP, LEFT
from search_shape_dependent import AUDIT


def shape_data_6param(sides):
    q, k, hk = shape_data(sides)
    sq = s.Matrix([s.Integer(a)**2 for a in sides])
    ss = sq / sum(sq)
    p = 36 * sum((ss[i] - s.Rational(1, 3))**3 for i in range(3))
    return q, p, k, hk


def weights_any(sides, coefficients):
    cf = [s.Rational(x) for x in coefficients]
    if len(cf) == 4:
        return weights(sides, cf)
    q, p, k, hk = shape_data_6param(sides)
    f0, f1, f2, g0, g1, g2 = cf
    return s.ones(3, 1) / 3 + (f0 + f1 * q + f2 * p) * k + (g0 + g1 * q + g2 * p) * hk


def certify_bridge_upper_bound(sides, normal):
    T = s.Symbol('T')
    q, k, hk = shape_data(sides)
    n = s.Matrix(normal)
    u_n = n.dot(s.Matrix([k[1], k[2]]))
    v_n = n.dot(s.Matrix([hk[1], hk[2]]))
    base_sup = sum(n) / 3

    left = s.Matrix([s.Rational(x) for x in ['3/4', '23/10', '-1', '6/5']])
    right = s.Matrix([s.Rational(x) for x in ['9/20', '6/5', '-8/5', '13/5']])
    bow = s.Matrix([s.Rational(x) for x in ['-1/4', '1', '3/10', '-6/5']])
    D_T = 1329 * T**2 + 2042 * T + 9081
    num_cf = 640 * (5 * T + 14) * ((1 - T) * left + T * right) + 10560 * T * (1 - T) * bow

    N_T = s.expand((num_cf[0] + q * num_cf[1]) * u_n + (num_cf[2] + q * num_cf[3]) * v_n)
    t_grid = np.linspace(0.0, 1.0, 2001)
    f_num = s.lambdify(T, N_T / D_T, 'numpy')
    max_pert = float(np.max(f_num(t_grid)))
    pert_upper = s.Rational(int(np.ceil(max_pert * 10**9)) + 5, 10**9)
    pert_0 = s.Rational(N_T.subs(T, 0), D_T.subs(T, 0))
    pert_1 = s.Rational(N_T.subs(T, 1), D_T.subs(T, 1))
    pert_upper = max(pert_upper, pert_0 + s.Rational(1, 10**9), pert_1 + s.Rational(1, 10**9))

    diff_poly = s.expand(pert_upper * D_T - N_T)
    proof = certify(diff_poly, [T], seconds=5, max_nodes=2000, max_depth=20)
    assert replay(diff_poly, [T], proof['tree']) == proof['leaves']
    assert leaf_minimum(proof['tree']) >= 0
    total_upper = base_sup + pert_upper
    return dict(
        support_upper=str(total_upper),
        perturbation_upper=str(pert_upper),
        polynomial=str(diff_poly),
        certificate=proof,
    )


def find_separating_normal(sides, cloud, target_row, comp_rows, include_bridge=True):
    sides_arr = np.array(sides, float)
    ss = sides_arr * sides_arr
    ss /= ss.sum()
    q = float((3 * np.sum(ss * ss) - 1) / 2)
    p_val = float(36 * np.sum((ss - 1 / 3)**3))
    k, hk = center_basis(sides_arr)

    def eval_pt(cf):
        cf_f = [float(F(x)) for x in cf]
        if len(cf_f) == 4:
            return 1 / 3 + (cf_f[0] + q * cf_f[1]) * k + (cf_f[2] + q * cf_f[3]) * hk
        return 1 / 3 + (cf_f[0] + q * cf_f[1] + p_val * cf_f[2]) * k + (cf_f[3] + q * cf_f[4] + p_val * cf_f[5]) * hk

    target_pt = eval_pt(target_row['coefficients'])
    comp_pts = np.array([eval_pt(r['coefficients']) for r in comp_rows])
    if include_bridge:
        t_vals = np.linspace(0.0, 1.0, 41)
        left = np.array([3 / 4, 23 / 10, -1, 6 / 5])
        right = np.array([9 / 20, 6 / 5, -8 / 5, 13 / 5])
        bow = np.array([-1 / 4, 1, 3 / 10, -6 / 5])
        b_cfs = [
            (640 * (5 * t + 14) * ((1 - t) * left + t * right) + 10560 * t * (1 - t) * bow) / (1329 * t * t + 2042 * t + 9081)
            for t in t_vals
        ]
        b_pts = np.array([1 / 3 + (c[0] + q * c[1]) * k + (c[2] + q * c[3]) * hk for c in b_cfs])
        comp_pts = np.vstack([comp_pts, b_pts])

    curve = np.vstack([TOP, LEFT, arc_I(np.linspace(TLOW, THIGH, 81)), arc_II(np.linspace(ALPHA, BETA, 81))])
    oldcloud = np.vstack([cloud, 1 / 3 + curve @ np.vstack([k, hk]), comp_pts])
    allcloud = np.vstack([oldcloud, target_pt[None, :]])
    allnorm = ConvexHull(allcloud).equations[:, :2]
    allnorm = allnorm[np.argsort(np.arctan2(allnorm[:, 1], allnorm[:, 0]))]
    mid = allnorm + np.roll(allnorm, 1, axis=0)
    mid /= np.linalg.norm(mid, axis=1)[:, None]
    angles = np.linspace(0, 2 * np.pi, 180, endpoint=False)
    fixed = np.column_stack([np.cos(angles), np.sin(angles)])
    normals = np.vstack([fixed, mid, ConvexHull(oldcloud).equations[:, :2], allnorm])
    parts = support_components(normals, k, hk)
    comp_sup = np.maximum.reduce(
        [np.max(normals @ cloud.T, axis=1)]
        + [parts[name] for name in ['ArcI', 'ArcII', 'Ptop', 'Pleft']]
        + [np.max(normals @ comp_pts.T, axis=1)]
    )
    gains = normals @ target_pt - comp_sup
    best_idx = int(np.argmax(gains))
    return normals[best_idx]


def main():
    t0 = time.monotonic()
    m.mp.dps = 100
    shapes = json.loads((AUDIT / 'SHAPES.json').read_text())
    shape_by_sides = {tuple(r['sides_abc']): i for i, r in enumerate(shapes)}
    reference = json.loads((AUDIT / 'REFERENCE_B46.json').read_text())['members']
    models = json.loads((HERE / 'INDEPENDENT_RAYS_B46_MODELS.json').read_text())['models']
    assert len(models) == 44

    old4 = json.loads((HERE / 'SHAPE_DEPENDENT_CERTIFICATES.json').read_text())['records']
    rays6 = json.loads((HERE / 'INDEPENDENT_RAYS_CERTIFICATES.json').read_text())['records']
    flat2 = json.loads((HERE / 'CONIC_BRIDGE_CERTIFICATE.json').read_text())['exact_flat_endpoints']
    rays4_new = json.loads((HERE / 'NEW_OMEGA4_RAYS_CERTIFICATES.json').read_text())['records']
    rays6_p = json.loads((HERE / 'CUBIC_PHASE_CERTIFICATES.json').read_text())['records']

    bmid_cf = ['22704/41737', '84480/41737', '-51744/41737', '67584/41737']
    bmid_record = dict(
        label='Bridge_Mid',
        seed=['43/80', '2', '-49/40', '8/5'],
        lower='42240/41737',
        upper='42240/41737',
        coefficients=bmid_cf,
    )

    witness_sides_map = {
        'Bridge_Mid': [12, 8, 6],
        'R7': [14, 11, 5],
        'R8': [6, 5, 3],
        'R9': [9, 8, 7],
        'R10': [9, 8, 7],
        'P1': [6, 5, 3],
        'P2': [6, 5, 3],
        'P3': [6, 5, 3],
    }

    all_targets = [bmid_record] + rays4_new + rays6_p
    base_competitors = old4 + rays6 + [dict(label=r['label'], coefficients=r['coefficients']) for r in flat2]

    cloud = np.load(AUDIT / 'BASE_WEIGHTS.npy')
    powers = {}
    results = []

    for target_row in all_targets:
        label = target_row['label']
        sides = witness_sides_map[label]
        shape_idx = shape_by_sides[tuple(sides)]
        a, b, c = sides
        comp_list = base_competitors + [r for r in all_targets if r['label'] != label]
        raw_normal = find_separating_normal(sides, cloud[shape_idx], target_row, comp_list, include_bridge=(label != 'Bridge_Mid'))
        normal = [s.Rational(str(F(float(t)).limit_denominator(10000))) for t in raw_normal]
        n = s.Matrix(normal)
        q, k, hk = shape_data(sides)
        u_n = n.dot(s.Matrix([k[1], k[2]]))
        v_n = n.dot(s.Matrix([hk[1], hk[2]]))
        dual = omega_dual(s.Matrix([u_n, v_n]))
        omega_sup = s.Rational(dual['upper']) + sum(n) / 3

        target_w = weights_any(sides, target_row['coefficients'])
        support = n.dot(s.Matrix([target_w[1], target_w[2]]))
        centroid_sup = sum(n) / 3
        lo_rat = s.Rational(target_row['lower'])
        hi_rat = s.Rational(target_row['upper'])
        target_upper = centroid_sup + (support - centroid_sup) * hi_rat / lo_rat
        target_interval_lower = min(support, target_upper)

        others = []
        bracket_bounds = [omega_sup]
        point_bounds = [omega_sup]
        for comp in comp_list:
            w = weights_any(sides, comp['coefficients'])
            val = n.dot(s.Matrix([w[1], w[2]]))
            others.append(dict(label=comp.get('label', 'prev'), support=str(val)))
            point_bounds.append(val)
            if 'upper' in comp and 'lower' in comp:
                c_hi = centroid_sup + (val - centroid_sup) * s.Rational(comp['upper']) / s.Rational(comp['lower'])
                bracket_bounds.append(max(val, c_hi))
            else:
                bracket_bounds.append(val)

        bridge_bound_cert = None
        if label != 'Bridge_Mid':
            bridge_bound_cert = certify_bridge_upper_bound(sides, normal)
            b_sup = s.Rational(bridge_bound_cert['support_upper'])
            point_bounds.append(b_sup)
            bracket_bounds.append(b_sup)

        rational = []
        for model in models:
            den = poly_value(model['polys_abc'][3], sides)
            assert den != 0
            w = [s.Rational(poly_value(p_m, sides), den) for p_m in model['polys_abc'][:3]]
            assert sum(w) == 1
            val = n.dot(s.Matrix(w[1:]))
            rational.append(dict(label=model['label'], weights=list(map(str, w)), support=str(val)))
            point_bounds.append(val)
            bracket_bounds.append(val)

        x_coord = s.Rational(b * b + c * c - a * a, 2 * c)
        height = m.sqrt(m.mpf(str(b * b - x_coord * x_coord)))
        vertices = [(m.mpf(0), m.mpf(0)), (m.mpf(c), m.mpf(0)), (m.mpf(str(x_coord)), height)]
        enclosed = []
        for p_label, pp in [('M_-', 4 - 2 * m.sqrt(2)), ('M_+', 4 + 2 * m.sqrt(2))]:
            key = (tuple(sides), p_label)
            if key not in powers:
                index = next(i for i, r in enumerate(reference) if r['label'] == p_label)
                wb, wc = cloud[shape_idx, index]
                guess = [m.mpf(str(wb)) * c + m.mpf(str(wc)) * vertices[2][0], m.mpf(str(wc)) * height]
                def gradient(X, Y):
                    return tuple(
                        sum(((X - v[0])**2 + (Y - v[1])**2)**((pp - 2) / 2) * ([X, Y][axis] - v[axis]) for v in vertices)
                        for axis in range(2)
                    )
                root = m.findroot(gradient, guess, tol=m.mpf('1e-90'), maxsteps=150)
                powers[key] = [m.nstr(t, 90) for t in root]
            point = powers[key]
            bound = power_support(sides, p_label, point, list(map(str, normal)))
            enclosed.append(dict(label=p_label, rational_point=point, **bound))
            point_bounds.append(s.Rational(bound['support_upper']))
            bracket_bounds.append(s.Rational(bound['support_upper']))

        comp_upper = max(point_bounds)
        gap = support - comp_upper
        robust_gap = target_interval_lower - max(bracket_bounds)
        assert gap > 0 and robust_gap > 0, (label, float(gap), float(robust_gap))
        results.append(dict(
            label=label, sides_abc=sides, normal=list(map(str, n)),
            target_weights=list(map(str, target_w)), target_support=str(support),
            omega_dual=dual, omega_support_upper=str(omega_sup),
            continuous_bridge_upper_certificate=bridge_bound_cert,
            rational_B46=rational, power_enclosures=enclosed,
            other_shape_maps=others, competitor_support_upper=str(comp_upper),
            gap=str(gap), gap_decimal=float(gap),
            robust_boundary_gap=str(robust_gap), robust_boundary_gap_decimal=float(robust_gap),
            status='PASS: exact leave-one-out separation certified',
        ))
        print(f"{label} on sides {sides}: exact gap = {float(gap):.6e}, robust bracket gap = {float(robust_gap):.6e}", flush=True)

    (HERE / 'ENLARGEMENT_SEPARATIONS.json').write_text(json.dumps(dict(
        status='PASS: 8 exact leave-one-out separation certificates generated (Bridge_Mid, R7..R10, P1..P3)',
        records=results,
        seconds=round(time.monotonic() - t0, 3),
    ), indent=2) + '\n')
    print(f"Saved ENLARGEMENT_SEPARATIONS.json in {round(time.monotonic() - t0, 3)}s", flush=True)


if __name__ == '__main__':
    main()