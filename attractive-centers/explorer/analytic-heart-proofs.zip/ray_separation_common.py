"""Exact rational geometry and rigorous power-center residual bounds."""
from fractions import Fraction as F
import mpmath as m
import sympy as s


def poly_value(poly,sides):
    return sum(int(t[3])*sides[0]**t[0]*sides[1]**t[1]*sides[2]**t[2] for t in poly)


def shape_data(sides):
    sq=s.Matrix([s.Integer(a)**2 for a in sides]);ss=sq/sum(sq)
    k=ss-s.ones(3,1)/3
    hk=4*k-6*(ss.applyfunc(lambda t:t*t)-s.ones(3,1)*ss.dot(ss)/3)
    return (3*ss.dot(ss)-1)/2,k,hk


def weights(sides,coefficients):
    q,k,hk=shape_data(sides);f0,f1,g0,g1=map(s.Rational,coefficients)
    return s.ones(3,1)/3+(f0+f1*q)*k+(g0+g1*q)*hk


def omega_constraint(entry,z):
    """A.(f,g)<=b, necessary for every globally attractive constant map."""
    z=s.sympify(z)
    if entry=='c0':return s.Matrix([3*z-1,18*z*z-12*z+1]),s.Integer(1)
    if entry=='a1':return s.Matrix([-9*z*z+9*z-1,-54*z**3+63*z*z-18*z+1]),s.Integer(1)
    if entry=='sum_lower':return s.Matrix([-3,-3]),s.Integer(1)
    if entry=='sum_upper':return s.Matrix([s.Rational(3,2),s.Rational(3,2)]),s.Integer(1)
    raise ValueError(entry)


def iv(x):
    x=F(str(x));return m.iv.mpf(x.numerator)/m.iv.mpf(x.denominator)


def endpoint(x,upper=True):
    sign,mantissa,exponent,_=x._mpi_[int(upper)]
    return F((-1 if sign else 1)*int(mantissa))*F(2)**int(exponent)


def power_support(sides,label,point,normal):
    """Recheck an approximate minimizer using intervals, not solver status.

    For F=sum |x-p_i|^p/p, Hessian lower bounds are
    3(p-1)diam^(p-2) for 1<p<2 on the triangle and
    (diam/2)^(p-2) for p>2 everywhere. Hence ||root-x||<=||grad F||/mu.
    """
    m.mp.dps=100;m.iv.dps=70
    a,b,c=map(s.Integer,sides);xx=(b*b+c*c-a*a)/(2*c);hh2=b*b-xx*xx
    assert hh2>0
    height=m.iv.sqrt(iv(hh2));vertices=[(iv(0),iv(0)),(iv(c),iv(0)),(iv(xx),height)]
    pointiv=[iv(t) for t in point]
    wc=pointiv[1]/height;wb=(pointiv[0]-iv(xx)*wc)/iv(c);wa=1-wb-wc
    assert min(endpoint(t,False) for t in [wa,wb,wc])>0
    pp=4-2*m.iv.sqrt(2) if label=='M_-' else 4+2*m.iv.sqrt(2)
    gradient=[sum(((pointiv[0]-v[0])**2+(pointiv[1]-v[1])**2)**((pp-2)/2)*
                  (pointiv[k]-v[k]) for v in vertices) for k in range(2)]
    residual=m.iv.sqrt(sum(t**2 for t in gradient));diam=iv(max(sides))
    mu=3*(pp-1)*diam**(pp-2) if label=='M_-' else (diam/2)**(pp-2)
    assert endpoint(mu,False)>0
    error=endpoint(residual/mu)
    nb,nc=map(iv,normal)
    nx=nb/iv(c);ny=(nc-nb*iv(xx)/iv(c))/height
    nsize=endpoint(m.iv.sqrt(nx**2+ny**2))
    support_upper=endpoint(nb*wb+nc*wc)+nsize*error
    assert error<F(1,10**55)
    return dict(distance_error_upper=str(error),support_upper=str(support_upper))
