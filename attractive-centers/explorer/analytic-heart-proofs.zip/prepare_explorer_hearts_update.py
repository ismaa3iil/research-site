"""Export proof-backed website data, exact references, and a cumulative archive."""
from pathlib import Path
import hashlib,json,zipfile
import sympy as s
from verify_shape_dependent import independent_matrix
from ray_separation_common import shape_data

HERE=Path(__file__).resolve().parent
SITE=Path('C:/Users/Ismail Hammoudeh/Documents/Triangle Sky/output/attractive-centers-web/research-site/attractive-centers/explorer')
DOWNLOADS=Path('C:/Users/Ismail Hammoudeh/Downloads')


def read(name):return json.loads((HERE/name).read_text())
def sha(data):return hashlib.sha256(data).hexdigest()


def main():
    first=read('SHAPE_DEPENDENT_CERTIFICATES.json')['records']
    rays=read('INDEPENDENT_RAYS_CERTIFICATES.json')['records']
    extra=read('NEW_OMEGA4_RAYS_CERTIFICATES.json')['records']+read('CUBIC_PHASE_CERTIFICATES.json')['records']
    conic=read('CONIC_BRIDGE_CERTIFICATE.json')
    replay=read('HEART_ENLARGEMENT_REPLAY.json');assert replay['status'].startswith('PASS')
    independent=read('INCOMING_ENLARGEMENT_VERIFICATION.json');assert independent['status'].startswith('PASS')
    f0,fq,fp,g0,gq,gp,f1,f2,g1,g2=s.symbols('f0 fq fp g0 gq gp f1 f2 g1 g2')
    matrix=read('CUBIC_PHASE_MATRIX.json')['matrix']
    for key in ['a','b','c']:
        assert s.expand(s.sympify(independent['matrix'][key]).subs({fq:f1,fp:f2,gq:g1,gp:g2})-s.sympify(matrix[key]))==0
    bridge=conic['conic_bridge'];t=s.symbols('t')
    coefficients=[s.sympify(p)/s.sympify(bridge['denominator_D_t']) for p in bridge['numerator_coefficients']]
    z,v=s.symbols('z v');m4=independent_matrix()
    contact=(17*t+165)/(24*(5*t+14))
    response=s.factor(m4['c'].subs(dict(zip([f0,f1,g0,g1],coefficients))).subs({z:contact,v:0}))
    assert response==0
    assert s.Poly(1329*t*t+2042*t+9081,t).all_coeffs()==[1329,2042,9081]
    assert [s.factor(p.subs(t,0)) for p in coefficients]==list(map(s.Rational,conic['exact_flat_endpoints'][0]['coefficients']))
    assert [s.factor(p.subs(t,1)) for p in coefficients]==list(map(s.Rational,conic['exact_flat_endpoints'][1]['coefficients']))
    entries=[]
    for label,row in zip(['S1','S2','S3','S*'],first):entries.append(dict(id=label,coefficients=row['coefficients']))
    for row in rays+extra:entries.append(dict(id=row['label'],seed=row['seed'],lower=row['lower'],upper=row['upper'],coefficients=row['coefficients']))
    for row in conic['exact_flat_endpoints']:entries.append(dict(id=row['label'].replace('_star','*'),lambda_star=row['lambda_star'],coefficients=row['coefficients']))
    for tt in [s.Integer(0),s.Rational(1,8),s.Rational(1,2),s.Rational(7,8),s.Integer(1)]:
        entries.append(dict(id='Bridge-'+str(tt),parameter=str(tt),coefficients=[str(s.factor(p.subs(t,tt))) for p in coefficients]))
    def weights(sides,cf):
        q,k,hk=shape_data(sides);cf=list(map(s.Rational,cf))
        if len(cf)==4:f=cf[0]+cf[1]*q;g=cf[2]+cf[3]*q
        else:
            sq=s.Matrix([s.Integer(a)**2 for a in sides]);ss=sq/sum(sq)
            p=36*sum((a-s.Rational(1,3))**3 for a in ss)
            f=cf[0]+cf[1]*q+cf[2]*p;g=cf[3]+cf[4]*q+cf[5]*p
        return s.ones(3,1)/3+f*k+g*hk
    triangles=[(6,5,3),(9,8,7),(9,6,5),(12,8,6),(14,11,5),(30,21,11),(1,1,1),(13,20,21),(3,4,5),(20,20,39)]
    refs=[dict(sides_abc=list(sides),maps=[dict(id=e['id'],coefficients=e['coefficients'],weights=list(map(str,weights(sides,e['coefficients'])))) for e in entries]) for sides in triangles]
    source_names=['heart_enlargement_report.md','certify_enlargement_separations.py','conic_bridge_and_cubic_centers.py','certify_conic_bridge_and_extensions.py','verify_conic_bridge_and_extensions.py']
    catalogue=dict(date='2026-10-17',parameter_order_4=['f0','fq','g0','gq'],parameter_order_6=['f0','fq','fp','g0','gq','gp'],
      maps=entries,conic_bridge=dict(denominator=bridge['denominator_D_t'],numerators=bridge['numerator_coefficients'],
       radially_sharp=True,collinear_contact=str(contact),response_at_contact=str(response)),
      exact_references=refs,source_sha256={name:sha((DOWNLOADS/name).read_bytes()) for name in source_names},
      status='Global attractivity, new radial brackets and eight separation witnesses replayed. Full maximal Heart remains open. Incoming 1389-shape audit not rerun.')
    (SITE/'analytic-hearts-catalogue.json').write_text(json.dumps(catalogue,indent=2)+'\n')
    # Keep copies of supplied prose and independently completed replay records.
    for source,dest in [(DOWNLOADS/'heart_enlargement_report.md','heart-enlargement-report.md'),
       (HERE/'HEART_ENLARGEMENT_REPLAY.json','heart-enlargement-replay.json'),
       (HERE/'INCOMING_ENLARGEMENT_VERIFICATION.json','independent-extension-certificate.json'),
       (HERE/'INDEPENDENT_RAYS_REPORT.md','independent-rays-report.md'),
       (HERE/'SHAPE_DEPENDENT_REPORT.md','shape-dependent-report.md'),
       (HERE/'COMPLETE_OMEGA_REPORT.md','constant-family-report.md')]:
        (SITE/dest).write_bytes(source.read_bytes())
    previous=HERE.parent/'Attractive_Centers_Independent_Rays_2026-10-17.zip'
    additions=['certify_enlargement_separations.py','conic_bridge_and_cubic_centers.py','certify_conic_bridge_and_extensions.py',
      'verify_conic_bridge_and_extensions.py','verify_incoming_enlargement.py','INCOMING_ENLARGEMENT_VERIFICATION.json',
      'CONIC_BRIDGE_CERTIFICATE.json','NEW_OMEGA4_RAYS_CERTIFICATES.json','CUBIC_PHASE_MATRIX.json','CUBIC_PHASE_CERTIFICATES.json',
      'ENLARGEMENT_SEPARATIONS.json','HEART_ENLARGEMENT_REPLAY.json','prepare_explorer_hearts_update.py']
    members={}
    with zipfile.ZipFile(previous) as old:
        for name in old.namelist():
            if name!='BUNDLE_MANIFEST.json':members[name]=old.read(name)
    for name in additions:members[name]=(HERE/name).read_bytes()
    members['incoming-heart-enlargement-report.md']=(DOWNLOADS/'heart_enlargement_report.md').read_bytes()
    members['EXPLORER_UPDATE_README.md']=(SITE/'new-hearts-verification.md').read_bytes()
    members['analytic-hearts-catalogue.json']=(SITE/'analytic-hearts-catalogue.json').read_bytes()
    manifest=dict(date='2026-10-17',baseline_archive_sha256=sha(previous.read_bytes()),
      status='Old exact results preserved; incoming explicit extension globally certified and complete supplied mathematical replay passed.',
      files=[dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())])
    output=SITE/'analytic-heart-proofs.zip'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
        for name,data in sorted(members.items()):bundle.writestr(name,data)
        bundle.writestr('BUNDLE_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(output) as bundle:
        for row in manifest['files']:assert sha(bundle.read(row['path']))==row['sha256']
    print(json.dumps(dict(status='PASS',exact_reference_triangles=len(refs),maps=len(entries),archive_bytes=output.stat().st_size,
        archive_sha256=sha(output.read_bytes()),direct_and_product_rule_matrices_agree=True,full_bridge_collinear_tangency_verified=True),indent=2))


if __name__=='__main__':main()
