"""Evaluate the six globally certified lower-endpoint maps; no optimization."""
from pathlib import Path
from fractions import Fraction
import json
import numpy as np
from shape_dependent_centers import center,barycentric_weights

_data=json.loads((Path(__file__).resolve().parent/'INDEPENDENT_RAYS_CERTIFICATES.json').read_text())
COEFFICIENTS={row['label']:tuple(float(Fraction(c)) for c in row['coefficients']) for row in _data['records']}


def centers(vertices):
    """Return R1,...,R6 positions as a (6,2) NumPy array."""
    return np.array([center(vertices,cf) for cf in COEFFICIENTS.values()])


def weights(vertices):
    return np.array([barycentric_weights(vertices,cf) for cf in COEFFICIENTS.values()])
