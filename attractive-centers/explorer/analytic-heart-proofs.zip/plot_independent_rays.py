"""Light-theme equal-scale figures; polygon areas are numerical only."""
from pathlib import Path
import json
from fractions import Fraction
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull
from omega_support import triangle_centers,arc_I,arc_II,TLOW,THIGH,ALPHA,BETA,TOP,LEFT
from independent_ray_centers import centers
from shape_dependent_centers import center

HERE=Path(__file__).resolve().parent


def closed_polygon(points):
    hull=ConvexHull(points);p=points[hull.vertices]
    return np.vstack([p,p[0]]),float(hull.volume)


def main():
    proofs=json.loads((HERE/'INDEPENDENT_RAYS_SEPARATIONS.json').read_text())['records']
    previous=json.loads((HERE/'SHAPE_DEPENDENT_CERTIFICATES.json').read_text())['records']
    fig,axes=plt.subplots(1,3,figsize=(15,6));areas=[]
    for ax,idx,labels in zip(axes,[0,2,3],[[0,1,4],[2,5],[3]]):
        row=proofs[idx];a,b,c=row['sides_abc'];x=(b*b+c*c-a*a)/(2*c)
        tri=np.array([[0,0],[c,0],[x,np.sqrt(b*b-x*x)]])
        base=np.array([[float(Fraction(t)) for t in r['weights']] for r in row['rational_B46']])@tri
        base=np.vstack([base,[[float(Fraction(t)) for t in r['rational_point']] for r in row['power_enclosures']]])
        prev=np.array([center(tri,[float(Fraction(t)) for t in r['coefficients']]) for r in previous])
        new=centers(tri);results=[]
        for samples in [1001,2001]:
            coeff=np.vstack([TOP,LEFT,arc_I(np.linspace(TLOW,THIGH,samples)),arc_II(np.linspace(ALPHA,BETA,samples))])
            old=np.vstack([base,triangle_centers(tri,coeff),prev])
            oldpoly,oldarea=closed_polygon(old);newpoly,newarea=closed_polygon(np.vstack([old,new]))
            results.append(dict(samples_per_arc=samples,old_area=oldarea,new_area=newarea,percentage_increase=100*(newarea/oldarea-1)))
        areas.append(dict(sides_abc=row['sides_abc'],area_checks=results))
        ax.fill(newpoly[:,0],newpoly[:,1],color='#efc9ad',label='With six new certified maps')
        ax.fill(oldpoly[:,0],oldpoly[:,1],color='#d7e8f4',label='Previous enlarged inner hull')
        ax.plot(oldpoly[:,0],oldpoly[:,1],color='#387798',lw=1.3)
        ax.plot(newpoly[:,0],newpoly[:,1],color='#b85b27',lw=1.4)
        ax.scatter(new[:,0],new[:,1],s=35,c='#b85b27',zorder=5)
        for j in labels:
            ax.annotate('R'+str(j+1),new[j],xytext=(5,7),textcoords='offset points',fontsize=11,color='#913c13',weight='bold')
        ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.2)
        ax.set_xlabel('Cartesian x');ax.set_ylabel('Cartesian y')
        ax.set_title(f'Sides ({a}, {b}, {c})\nNumerical area gain: {results[-1]["percentage_increase"]:.3f}%')
        pad=.14*np.ptp(newpoly,axis=0).max()
        ax.set_xlim(newpoly[:,0].min()-pad,newpoly[:,0].max()+pad)
        ax.set_ylim(newpoly[:,1].min()-pad,newpoly[:,1].max()+pad)
    fig.suptitle('Six globally certified additions, each with an exact nonredundancy witness',fontsize=17)
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=2,frameon=False,bbox_to_anchor=(.5,.04))
    fig.text(.5,.01,'Previous hull includes B46, the entire constant family, and all four earlier shape-dependent maps.',ha='center',fontsize=11)
    fig.tight_layout(rect=(0,.10,1,.91))
    fig.savefig(HERE/'INDEPENDENT_RAYS_COMPARISON.png',dpi=170)
    fig.savefig(HERE/'INDEPENDENT_RAYS_COMPARISON.svg');plt.close(fig)
    (HERE/'INDEPENDENT_RAYS_AREAS.json').write_text(json.dumps(dict(status='numerical sampled-curve areas; exact separation is certified separately',triangles=areas),indent=2)+'\n')
    print(json.dumps(areas,indent=2))


if __name__=='__main__':main()
