"""Fast, exact rational certificate generator for:
1. CONIC_BRIDGE_CERTIFICATE.json:
   - Exact zero-backoff (delta=0) radial endpoints R2* = 8960/9081 and R5* = 3040/3113
   - Exact 78-leaf 3D Bernstein certificate (delta=0) for the repaired conic bridge c_bridge(t), t in [0, 1]
2. NEW_OMEGA4_RAYS_CERTIFICATES.json:
   - Exact 2D Bernstein lower certificates and rational upper counterexamples (width 3e-8) for R7..R10
3. CUBIC_PHASE_MATRIX.json & CUBIC_PHASE_CERTIFICATES.json:
   - Exact 6-parameter moving-radius matrix for Z = G + (f0+f1*q+f2*p)K + (g0+g1*q+g2*p)HK with p = 36*R3
   - Exact 2D Bernstein lower certificates and rational upper counterexamples (width 3e-8) for P1..P3
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import json, time, math, sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import numpy as np
import sympy as s
from scipy.optimize import differential_evolution, minimize_scalar
from prove_boundary_arc import bisect
from verify_shape_dependent import independent_matrix


def bernstein_fast(polynomial, variables):
    """Exact rational tensor Bernstein conversion via separable 1D binomial contraction."""
    p = s.Poly(polynomial, *variables)
    degrees = p.degree_list()
    arr = np.full(tuple(d + 1 for d in degrees), F(0), dtype=object)
    for powers, c in p.terms():
        arr[powers] = F(int(c.p), int(c.q))
    for axis, d in enumerate(degrees):
        a = np.moveaxis(arr, axis, 0)
        out = np.empty_like(a)
        binom_mat = [[F(comb(i, k), comb(d, k)) for k in range(i + 1)] for i in range(d + 1)]
        for i in range(d + 1):
            row_i = binom_mat[i]
            acc = a[0] * row_i[0]
            for k in range(1, i + 1):
                acc = acc + a[k] * row_i[k]
            out[i] = acc
        arr = np.moveaxis(out, 0, axis)
    return arr


def certify_fast(polynomial, variables, seconds=25, max_nodes=25000, max_depth=70):
    coefficients = bernstein_fast(polynomial, variables)
    started = time.monotonic()
    nodes = 0
    leaves = 0
    max_seen = 0
    least = None

    def walk(values, depth, levels):
        nonlocal nodes, leaves, max_seen, least
        nodes += 1
        max_seen = max(max_seen, depth)
        if time.monotonic() - started > seconds or nodes > max_nodes or depth > max_depth:
            raise TimeoutError('bounded Bernstein search exhausted')
        minimum = min(values.flat)
        if minimum >= 0:
            leaves += 1
            least = minimum if least is None else min(least, minimum)
            return {'nonnegative': True, 'minimum': str(minimum)}
        if max(values.flat) < 0:
            raise ValueError('negative Bernstein box')
        axis = min((i for i, d in enumerate(values.shape) if d > 1), key=lambda i: levels[i])
        next_levels = list(levels)
        next_levels[axis] += 1
        children = bisect(values, axis)
        return dict(axis=axis, children=[walk(child, depth + 1, next_levels) for child in children])

    tree = walk(coefficients, 0, [0] * len(variables))
    return dict(
        method='exact rational tensor Bernstein midpoint cover',
        degrees=[d - 1 for d in coefficients.shape],
        tree=tree,
        nodes=nodes,
        leaves=leaves,
        max_depth=max_seen,
        minimum_leaf_coefficient=str(least),
        seconds=round(time.monotonic() - started, 4),
    )


def derive_6param_matrix(m4):
    z, v, f0, f1, f2, g0, g1, g2 = s.symbols('z v f0 f1 f2 g0 g1 g2')
    old_f0, old_g0 = s.symbols('f0 g0')
    V = (2 - 3 * z) / 4
    u = V - v
    p_inv = (1 - 3 * z) * (36 * z**2 - 24 * z + 1 + 36 * z * v)
    kx = s.Rational(3, 2) - 3 * z - 2 * v
    hx = s.Rational(3, 2) - 3 * z + (6 * z - 4) * v
    gp_x = 6 * (4 * v * (27 * z**2 - 18 * z + 2) + 3 * (36 * z**3 - 48 * z**2 + 19 * z - 2))
    gp_y = 48 * (3 * z - 1)

    extraK_p = [
        s.expand(3 * z * kx * gp_x),
        s.expand(s.Rational(3, 2) * z * (kx * gp_y + 2 * gp_x)),
        s.expand(6 * z * u * v * gp_y),
    ]
    extraHK_p = [
        s.expand(3 * z * hx * gp_x),
        s.expand(s.Rational(3, 2) * z * (hx * gp_y + 4 * (1 - 3 * z) * gp_x)),
        s.expand(12 * z * u * v * (1 - 3 * z) * gp_y),
    ]
    out = {}
    for key, ekp, ehp in zip(['a', 'b', 'c'], extraK_p, extraHK_p):
        base4 = m4[key]
        uu = s.expand(base4.coeff(old_f0))
        vv = s.expand(base4.coeff(old_g0))
        out[key] = s.expand(base4 + f2 * (p_inv * uu + ekp) + g2 * (p_inv * vv + ehp))
    return out


def numerical_basis_6param(m6):
    z, v, f0, f1, f2, g0, g1, g2 = s.symbols('z v f0 f1 f2 g0 g1 g2')
    coefficients = [f0, f1, f2, g0, g1, g2]
    polys = [m6[name] for name in ['a', 'b', 'c']]
    funs = [[s.lambdify((z, v), s.diff(p, cf), 'numpy') for cf in coefficients] for p in polys]

    def basis(zz, hh):
        zz, hh = np.broadcast_arrays(np.asarray(zz, float), np.asarray(hh, float))
        V = (2 - 3 * zz) / 4
        vv = V * hh
        terms = np.array([[np.broadcast_to(fun(zz, vv), zz.shape) for fun in group] for group in funs])
        terms[1] *= np.sqrt(np.maximum(0.0, vv * (V - vv)))
        return np.moveaxis(terms, -1, 0) if zz.ndim == 1 else terms

    return basis


def radial_minimum_6param(cf, basis):
    def fun(point):
        abc = (basis(np.array([2 * point[0] / 3]), np.array([point[1]])) @ cf)[0]
        a, b, c = abc
        return float((a + c - np.hypot(a - c, 2 * b)) / 2)

    trial = differential_evolution(
        fun, [(0, 1), (0, 1)], seed=20261017, maxiter=180, popsize=12, tol=1e-11, atol=1e-12, workers=1, polish=True
    )
    points = [(float(trial.fun), trial.x.tolist())]
    grid = np.linspace(0, 1, 65)
    for axis in [0, 1]:
        for end in [0.0, 1.0]:
            def edge(t):
                p = [t, t]
                p[axis] = end
                return fun(p)

            values = [edge(t) for t in grid]
            for i in range(1, len(grid) - 1):
                if values[i] <= values[i - 1] and values[i] <= values[i + 1]:
                    sol = minimize_scalar(edge, bounds=(grid[i - 1], grid[i + 1]), method='bounded', options={'xatol': 1e-14})
                    p = [float(sol.x), float(sol.x)]
                    p[axis] = end
                    points.append((float(sol.fun), p))
            for t in [0.0, 1.0]:
                p = [t, t]
                p[axis] = end
                points.append((fun(p), p))
    best = min(points, key=lambda x: x[0])
    return dict(
        minimum_perturbation_eigenvalue=best[0],
        z=2 * best[1][0] / 3,
        h=best[1][1],
        lambda_estimate=-1 / best[0],
    )


def generate_bridge_and_flat_certs(m4):
    z, v, t, f0, f1, g0, g1, Z, H, T = s.symbols('z v t f0 f1 g0 g1 Z H T')
    endpoints = [
        ('R2_star', ['3/4', '23/10', '-1', '6/5'], s.Rational(8960, 9081), s.Rational(55, 112),
         s.Rational(27, 40), s.Rational(33, 40)),
        ('R5_star', ['9/20', '6/5', '-8/5', '13/5'], s.Rational(3040, 3113), s.Rational(91, 228),
         s.Rational(21, 40), s.Rational(27, 40)),
    ]
    flat_records = []
    for label, seed_str, lam_star, z_star, Z_lo, Z_hi in endpoints:
        seed = [s.Rational(x) for x in seed_str]
        cf = [lam_star * x for x in seed]
        denom = lam_star.q
        a = s.expand(denom * m4['a'].subs(dict(zip([f0, f1, g0, g1], cf))))
        b = s.expand(denom * m4['b'].subs(dict(zip([f0, f1, g0, g1], cf))))
        c = s.expand(denom * m4['c'].subs(dict(zip([f0, f1, g0, g1], cf))))
        V = (2 - 3 * z) / 4
        det = s.expand(a * c - v * (V - v) * b * b)
        a0 = s.expand(a.subs(v, 0))
        c0 = s.expand(c.subs(v, 0))
        rem = s.expand(s.cancel((det - a0 * c0) / v))

        Z_collar = Z_lo + (Z_hi - Z_lo) * Z
        Z_left = Z_lo * Z
        Z_right = Z_hi + (1 - Z_hi) * Z
        spec = [
            ('a_positive', a - 1, {z: 2 * Z / 3, v: (1 - Z) * H / 2}, 'Z in [0,1], H in [0,1]'),
            ('collar_remainder', rem, {z: 2 * Z_collar / 3, v: (1 - Z_collar) * (H / 16) / 2}, f'Z in [{Z_lo},{Z_hi}], H in [0,1/16]'),
            ('det_outer_H', det, {z: 2 * Z / 3, v: (1 - Z) * (s.Rational(1, 16) + s.Rational(15, 16) * H) / 2}, 'Z in [0,1], H in [1/16,1]'),
            ('det_left_Z', det, {z: 2 * Z_left / 3, v: (1 - Z_left) * (H / 16) / 2}, f'Z in [0,{Z_lo}], H in [0,1/16]'),
            ('det_right_Z', det, {z: 2 * Z_right / 3, v: (1 - Z_right) * (H / 16) / 2}, f'Z in [{Z_hi},1], H in [0,1/16]'),
        ]
        tasks = []
        total_leaves = 0
        for name, poly, sub_map, domain_desc in spec:
            unit = s.expand(poly.subs(sub_map, simultaneous=True))
            proof = certify_fast(unit, [Z, H], seconds=20, max_nodes=20000, max_depth=40)
            total_leaves += proof['leaves']
            tasks.append(dict(name=name, domain=domain_desc, unit_polynomial=str(unit), certificate=proof))
        flat_records.append(dict(
            label=label, seed=seed_str, lambda_star=str(lam_star), lambda_star_decimal=float(lam_star),
            backoff_delta='0', coefficients=[str(x) for x in cf], collinear_root_z_star=str(z_star),
            collinear_c0_scaled_factored=str(s.factor(c0)),
            exact_radial_sharpness_identity=f"c(z_*, 0; lambda) = 1 - ({lam_star.q}/{lam_star.p})*lambda < 0 for all lambda > {lam_star}",
            total_2d_bernstein_leaves=total_leaves, tasks=tasks,
            status='exact zero-backoff (delta=0) global radial endpoint certificate generated',
        ))
        print(f"Certified {label}: {total_leaves} leaves", flush=True)

    left = s.Matrix([s.Rational(x) for x in ['3/4', '23/10', '-1', '6/5']])
    right = s.Matrix([s.Rational(x) for x in ['9/20', '6/5', '-8/5', '13/5']])
    bow = s.Matrix([s.Rational(x) for x in ['-1/4', '1', '3/10', '-6/5']])
    D_t = 1329 * t**2 + 2042 * t + 9081
    num_cf = [s.expand(640 * (5 * t + 14) * ((1 - t) * left[i] + t * right[i]) + 10560 * t * (1 - t) * bow[i]) for i in range(4)]
    a_sc = s.expand(D_t + (m4['a'] - 1).subs(dict(zip([f0, f1, g0, g1], num_cf))))
    b_sc = s.expand(m4['b'].subs(dict(zip([f0, f1, g0, g1], num_cf))))
    c_sc = s.expand(D_t + (m4['c'] - 1).subs(dict(zip([f0, f1, g0, g1], num_cf))))
    V = (2 - 3 * z) / 4
    det_sc = s.expand(a_sc * c_sc - v * (V - v) * b_sc**2)
    a0_sc = s.expand(a_sc.subs(v, 0))
    c0_sc = s.expand(c_sc.subs(v, 0))
    rem_sc = s.expand(s.cancel((det_sc - a0_sc * c0_sc) / v))

    mid_a = s.Rational(a_sc.subs({z: s.Rational(9, 40), v: s.Rational(53, 160), t: s.Rational(1, 2)}), D_t.subs(t, s.Rational(1, 2)))
    mid_det = s.Rational(det_sc.subs({z: s.Rational(9, 40), v: s.Rational(53, 160), t: s.Rational(1, 2)}), D_t.subs(t, s.Rational(1, 2))**2)

    Z_lo = s.Rational(27, 40) - s.Rational(6, 40) * T
    Z_hi = s.Rational(33, 40) - s.Rational(6, 40) * T
    Z_collar = Z_lo + (Z_hi - Z_lo) * Z
    Z_left = Z_lo * Z
    Z_right = Z_hi + (1 - Z_hi) * Z
    spec_3d = [
        ('a_scaled_minus_1', a_sc - 1, {z: 2 * Z / 3, v: (1 - Z) * H / 2, t: T}, 'Z in [0,1], H in [0,1], T in [0,1]'),
        ('collar_remainder', rem_sc, {z: 2 * Z_collar / 3, v: (1 - Z_collar) * (H / 16) / 2, t: T}, 'Z in [(27-6T)/40, (33-6T)/40], H in [0,1/16], T in [0,1]'),
        ('det_outer_H', det_sc, {z: 2 * Z / 3, v: (1 - Z) * (s.Rational(1, 16) + s.Rational(15, 16) * H) / 2, t: T}, 'Z in [0,1], H in [1/16,1], T in [0,1]'),
        ('det_left_Z', det_sc, {z: 2 * Z_left / 3, v: (1 - Z_left) * (H / 16) / 2, t: T}, 'Z in [0, (27-6T)/40], H in [0,1/16], T in [0,1]'),
        ('det_right_Z', det_sc, {z: 2 * Z_right / 3, v: (1 - Z_right) * (H / 16) / 2, t: T}, 'Z in [(33-6T)/40, 1], H in [0,1/16], T in [0,1]'),
    ]
    tasks_3d = []
    total_3d = 0
    for name, poly, sub_map, domain_desc in spec_3d:
        unit = s.expand(poly.subs(sub_map, simultaneous=True))
        proof = certify_fast(unit, [Z, H, T], seconds=30, max_nodes=20000, max_depth=40)
        total_3d += proof['leaves']
        tasks_3d.append(dict(name=name, domain=domain_desc, unit_variables=['Z', 'H', 'T'], unit_polynomial=str(unit), certificate=proof))
    print(f"Certified 3D conic bridge: {total_3d} leaves", flush=True)

    return dict(
        status='exact zero-backoff endpoints R2*, R5* and 3D conic bridge certificates generated',
        exact_flat_endpoints=flat_records,
        conic_bridge=dict(
            status='continuous rational quadratic bridge globally certified on t in [0,1] with zero backoff (delta=0)',
            parameter_interval=['0', '1'],
            denominator_D_t=str(D_t),
            numerator_coefficients=[str(num_cf[i]) for i in range(4)],
            bow_vector=['-1/4', '1', '3/10', '-6/5'],
            bow_scale='10560*t*(1-t)',
            collinear_c0_scaled_factored=str((120 * t * z - 17 * t + 336 * z - 165)**2),
            midpoint_repaired_witness=dict(
                t='1/2', z='9/40', h='1', v='53/160',
                repaired_a=str(mid_a), repaired_a_decimal=float(mid_a),
                repaired_det=str(mid_det), repaired_det_decimal=float(mid_det),
            ),
            total_3d_bernstein_leaves=total_3d,
            tasks=tasks_3d,
        ),
    )


def certify_ray_list(mat, syms, ray_specs):
    z, v, Z, H = s.symbols('z v Z H')
    V = (2 - 3 * z) / 4
    margin = s.Rational(1, 10**10)
    records = []
    for label, seed_str, lo_str, zz_str, hh_str in ray_specs:
        seed = [s.Rational(x) for x in seed_str]
        lower = s.Rational(lo_str)
        upper = lower + s.Rational(3, 10**8)
        cf = [lower * x for x in seed]
        a, b, c = [s.expand(mat[k].subs(dict(zip(syms, cf)))) for k in ['a', 'b', 'c']]
        tasks = []
        for name, poly in [('diagonal', a - margin), ('determinant', (a - margin) * (c - margin) - v * (V - v) * b * b)]:
            unit = s.expand(poly.subs({z: 2 * Z / 3, v: (1 - Z) * H / 2}, simultaneous=True))
            proof = certify_fast(unit, [Z, H], seconds=25, max_nodes=25000, max_depth=70)
            tasks.append(dict(name=name, certificate=proof))
        zz = s.Rational(zz_str)
        hh = s.Rational(hh_str)
        vv = (2 - 3 * zz) * hh / 4
        up = [s.factor(mat[k].subs(dict(zip(syms, [upper * x for x in seed]))).subs({z: zz, v: vv})) for k in ['a', 'b', 'c']]
        det = s.factor(up[0] * up[2] - vv * ((2 - 3 * zz) / 4 - vv) * up[1]**2)
        assert bool(det < 0 or up[0] < 0 or up[2] < 0), (label, float(det))
        records.append(dict(
            label=label, seed=seed_str, lower=str(lower), upper=str(upper),
            decimal_bracket=[float(lower), float(upper)],
            coefficients=[str(x) for x in cf], scaled_margin=str(margin),
            tasks=tasks,
            upper_witness=dict(z=str(zz), h=str(hh), v=str(vv), a=str(up[0]), c=str(up[2]), determinant=str(det)),
            status='exact lower certificate and rational upper counterexample generated',
        ))
        print(f"Certified {label}: {[tk['certificate']['leaves'] for tk in tasks]} leaves", flush=True)
    return records


def main():
    t0 = time.monotonic()
    f0, f1, f2, g0, g1, g2 = s.symbols('f0 f1 f2 g0 g1 g2')
    m4 = independent_matrix()
    m6 = derive_6param_matrix(m4)

    bridge_out = generate_bridge_and_flat_certs(m4)
    (HERE / 'CONIC_BRIDGE_CERTIFICATE.json').write_text(json.dumps(bridge_out, indent=2) + '\n')

    omega4_specs = [
        ('R7', ['3/5', '0', '-29/20', '2'], '94423179/100000000', '153433668/10000000000', '1'),
        ('R8', ['1', '4/3', '-1/2', '-7/10'], '99579960/100000000', '4979423868/10000000000', '1/1000000000000'),
        ('R9', ['0', '-12/5', '8/5', '-9/2'], '91081582/100000000', '849035569/10000000000', '2759258832/10000000000'),
        ('R10', ['1/2', '-7/5', '-2', '9'], '96617699/100000000', '1374730808/10000000000', '1'),
    ]
    omega4_records = certify_ray_list(m4, [f0, f1, g0, g1], omega4_specs)
    (HERE / 'NEW_OMEGA4_RAYS_CERTIFICATES.json').write_text(json.dumps(dict(
        status='four new Omega_4 rays globally certified',
        records=omega4_records,
    ), indent=2) + '\n')

    (HERE / 'CUBIC_PHASE_MATRIX.json').write_text(json.dumps(dict(
        status='exact 6-parameter moving-radius matrix for (f0,f1,f2,g0,g1,g2)',
        parameters=['f0', 'f1', 'f2', 'g0', 'g1', 'g2'],
        invariants=dict(q='1/4 - 3*z*v', p='(1 - 3*z)*(36*z^2 - 24*z + 1 + 36*z*v)'),
        matrix={k: str(v) for k, v in m6.items()},
    ), indent=2) + '\n')

    basis6 = numerical_basis_6param(m6)
    cubic_seeds = [
        ('P1', ['3/5', '1/10', '-3/5', '-8/5', '3', '7/10']),
        ('P2', ['1/5', '-14/5', '1/5', '13/10', '-7/5', '-1/5']),
        ('P3', ['4/5', '11/5', '-1/5', '-4/5', '-4/5', '2/5']),
    ]
    cubic_specs = []
    for label, seed_str in cubic_seeds:
        cf_f = np.array([float(s.Rational(x)) for x in seed_str])
        opt = radial_minimum_6param(cf_f, basis6)
        lo = s.Rational(math.floor(opt['lambda_estimate'] * 10**8) - 1, 10**8)
        zz = s.Rational(round(opt['z'] * 10**10), 10**10)
        hh = s.Rational(round(opt['h'] * 10**10), 10**10)
        if hh == 0:
            hh = s.Rational(1, 10**12)
        if zz == 0:
            zz = s.Rational(1, 10**12)
        cubic_specs.append((label, seed_str, str(lo), str(zz), str(hh)))

    cubic_records = certify_ray_list(m6, [f0, f1, f2, g0, g1, g2], cubic_specs)
    (HERE / 'CUBIC_PHASE_CERTIFICATES.json').write_text(json.dumps(dict(
        status='three 6-parameter cubic-phase rays globally certified',
        records=cubic_records,
        seconds=round(time.monotonic() - t0, 3),
    ), indent=2) + '\n')
    print(f"All certificates generated in {round(time.monotonic() - t0, 3)}s", flush=True)


if __name__ == '__main__':
    main()