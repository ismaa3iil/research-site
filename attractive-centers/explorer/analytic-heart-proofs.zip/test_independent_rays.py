"""Numerical evaluator regression, supplementary to exact proof replay."""
import itertools,json
import numpy as np
from independent_ray_centers import centers,weights,COEFFICIENTS
from shape_dependent_centers import center
from search_shape_dependent import numerical_basis


def main():
    rng=np.random.default_rng(20261017);basis=numerical_basis();worst=0.
    for cf in COEFFICIENTS.values():
        for _ in range(8):
            z=rng.uniform(.01,.62);h=rng.uniform(.01,.99);V=(2-3*z)/4
            r=np.sqrt(z);X=np.sqrt(V*(1-h));Y=np.sqrt(V*h)
            p=np.array([[r,0],[-r/2+X,Y],[-r/2-X,-Y]])
            a,b,c=(basis(np.array([z]),np.array([h]))@cf)[0]+[1,0,1]
            expected=np.array([[a,b],[b,c]])/3;J=np.zeros((2,2));eps=1e-6
            for k in [0,1]:
                plus=p.copy();minus=p.copy();plus[0,k]+=eps;minus[0,k]-=eps
                J[:,k]=(center(plus,cf)-center(minus,cf))/(2*eps)
            worst=max(worst,float(np.max(np.abs((J+J.T)/2-expected))))
    assert worst<3e-8
    p=np.array([[0,0],[3,0],[-1/3,4*np.sqrt(14)/3]])
    exact=centers(p)
    assert np.max(np.abs(weights(p)@p-exact))<1e-12
    for perm in itertools.permutations(range(3)):
        assert np.max(np.abs(centers(p[list(perm)])-exact))<1e-12
    print(json.dumps(dict(status='PASS',finite_difference_cases=48,maximum_error=worst),indent=2))


if __name__=='__main__':main()
