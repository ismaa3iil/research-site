# Certified failure of two attractive-center compositions

18 October 2026. This supplements the review with rigorous root enclosures
and strictly negative directional responses. It does not establish uniqueness
of centroid insertion, or non-inclusion of the pointwise Hearts.

For p>1, let M_p(P) minimize Phi(x)=sum_i |x-p_i|^p/p. The objective is
strictly convex and coercive, so the minimizer exists and is unique. Projection
onto conv(P) cannot increase distances and strictly improves the objective
outside the hull; hence the minimizer belongs to conv(P).

At a point distinct from the anchors, set

    K_i = |x-p_i|^(p-2) [I+(p-2) u_i u_i^T],
    K = sum_i K_i,    D_i M_p = K^(-1) K_i.

The derivative formula follows by differentiating the equilibrium equation.
All certified root boxes below are disjoint from their anchors, as checked
by a strictly positive interval lower bound on each squared distance.

## Root enclosure without assuming the root solver is correct

Every anchor and every rational trial center is in the rectangle
R=[-1,1] x [0,1]; the certificate checks this. Thus the true minimizer and
the segment to the trial center are also in R. Its diameter is sqrt(5)<3.

For p_minus=4-2sqrt(2), we have 1.1<p_minus<2. At every regular point in R,
each individual Hessian has minimum eigenvalue

    (p_minus-1) r^(p_minus-2) > (1/10)(1/3)=1/30.

This uses r<3 and -1<p_minus-2<0; at r=0 the derivative singularity does
not invalidate strong convexity, which extends by continuity along split
segments. Therefore the very conservative bound D^2 Phi >= (1/100) I
holds in the strong convexity sense on R for all low-power objectives here.

For p_plus=4+2sqrt(2)>2, B=(-1,0) and C=(1,0) remain anchors. At every x,
at least one distance to B,C is >=1. That anchor's Hessian has minimum
eigenvalue r^(p_plus-2)>=1. Thus D^2 Phi >= I globally.

For a differentiable mu-strongly convex objective, its minimizer x* and any
trial center z in the region satisfy

    |z-x*| <= |grad Phi(z)|/mu <= ||grad Phi(z)||_1/mu.

The script evaluates the right side with outward interval arithmetic. It
does not call an interval root finder. Decimal trial centers from the
80-digit calculation are treated simply as exact rational input decimals;
their acceptance depends solely on this residual inequality.

## Example 1

    A=(5/16,7/20), B=(-1,0), C=(1,0),
    D=M_pminus(A,B,C), Z=M_pplus(A,B,C,D), v=(-9,4).

The first residual bound encloses D in a box of radius 1e-50 about the
rational decimal trial center. The second root is enclosed in a box of
radius 1e-35, evaluating its residual uniformly over the first box. Recorded
error upper bounds are approximately 2.069e-63 and 1.632e-51, respectively.

Interval evaluation of the chain-rule response gives

    v^T [D_1 Z + D_4 Z D_A M_pminus] v
       in [-0.023743, -0.023742] < 0.

The full much narrower interval is in composition_interval_certificates.json.
The underlying three- and four-point power maps are globally attractive in
the continuous finite-response class by the established power theorem.
Their composite has a negative derivative response, so it is not attractive.
The root boxes avoid collisions, so local differentiability and the passage
to sufficiently small finite negative steps follow from the implicit function
theorem. This proof does not assert a certified sign for a particular 0.001
step; the separately reported values at that step are numerical.

## Example 2

    A=(1/2,1), B=(-1,0), C=(1,0),
    D=R5*(A,B,C), Z=M_pminus(A,B,C,D), v=(7,12).

Here

    R5* = G+(3040/3113)[(9/20+6q/5) K+(-8/5+13q/5) HK]

is the already certified rational triangle rule. Its value and derivative
at this rational input are computed exactly with SymPy and converted to
outward rational intervals. The normalized invariant is q=97/1156.
The sole equilibrium is enclosed in a radius-1e-35 box, with residual-based
error upper bound below 1.386e-62. The response satisfies

    v^T [D_1 Z + D_4 Z D_A R5*] v
       in [-0.077681, -0.077679] < 0.

Again this proves failure of the composed rule in the finite-law class,
relative to the project's existing global R5* attractivity certificate.
That certificate was independently replayed in the earlier
steiner_heart_ansatz_2026-10-15/HEART_ENLARGEMENT_REPLAY.json (R5_star entry).
It is not re-proved by the present counterexample calculation.

## Computation and trust boundary

Run:

    python audit_counterexamples.py
    python certify_composition_failures.py

The second command uses no optimizer or finite differences. It uses exact
rational differentiation, elementary outward interval operations (including
positive-base real powers), an explicit 2x2 inverse with determinant lower
bound >0, and interval comparisons. All numerical proof quantities are
recorded in the JSON output. The result is a computer-assisted proof using
SymPy and mpmath's interval backend, not a formal proof-assistant derivation.

The enclosure convention follows the
[mpmath interval-context documentation](https://mpmath.org/doc/current/contexts.html).
In particular, high precision alone is not an enclosure. Existence and
enclosure of the roots here come from the explicit strong-convexity argument,
not the success status of a numerical or interval root solver.

Both power maps are locally analytic in these collision-free neighborhoods.
Membership of the four-point fractional-power maps in a globally analytic
class across all anchor collisions has not been asserted.
