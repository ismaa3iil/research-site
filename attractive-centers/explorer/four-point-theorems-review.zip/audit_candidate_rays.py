"""Bounded adversarial numerical audit; a successful search is not a proof."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import ast, json, time
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
import incoming_verify as inc
HERE=Path(__file__).resolve().parent
def main():
    root=ast.parse((HERE/'incoming_verify.py').read_text())
    node=next(x for x in ast.walk(root) if isinstance(x,ast.Assign) and any(isinstance(y,ast.Name) and y.id=='ray_endpoints' for y in x.targets))
    # The one division in the literal is safely handled without eval.
    def literal(x):
        if isinstance(x,ast.BinOp) and isinstance(x.op,ast.Div):return literal(x.left)/literal(x.right)
        if isinstance(x,ast.UnaryOp) and isinstance(x.op,ast.USub):return -literal(x.operand)
        if isinstance(x,ast.Constant):return x.value
        if isinstance(x,ast.List):return [literal(a) for a in x.elts]
        if isinstance(x,ast.Dict):return {literal(k):literal(v) for k,v in zip(x.keys,x.values)}
        raise ValueError(ast.dump(x))
    rays=literal(node.value)[10:];rng=np.random.default_rng(20261018)
    report=[];started=time.monotonic()
    for idx,ray in enumerate(rays):
        def objective(x):
            p=np.vstack([x.reshape(3,3),-x.reshape(3,3).sum(axis=0)])
            p/=np.linalg.norm(p)
            data=inc.exact_rational_family_data(p)
            J=np.eye(3)/4+sum((c*data[k][1] for k,c in ray.items()),np.zeros((3,3)))
            return float(np.linalg.eigvalsh((J+J.T)/2)[0])
        best=None
        for _ in range(3):
            opt=minimize(objective,rng.normal(size=9),method='BFGS',options={'maxiter':120,'gtol':2e-8})
            if best is None or opt.fun<best.fun:best=opt
        p=np.vstack([best.x.reshape(3,3),-best.x.reshape(3,3).sum(axis=0)]);p/=np.linalg.norm(p)
        record={'ray':ray,'minimum_found':float(best.fun),'configuration':p.tolist(),'is_proof':False}
        report.append(record)
        print(idx+1,ray,record['minimum_found'],flush=True)
        (HERE/'adversarial_ray_audit.json').write_text(json.dumps(report,indent=2)+'\n')
        if time.monotonic()-started>110:break
    print('Elapsed',time.monotonic()-started,flush=True)
if __name__=='__main__':main()
