"""Standalone verification suite for 3-parametric non-collinear attractive center families
for a tetrahedron (n = 4, d = 3) and coplanar 4-point configurations (A, B, C, D) and (A, B, C, G_ABC):

1. Family I (Skeletal-Constellation Power Family Z_const(p, w_E, w_F)):
   - Exact chain-rule Jacobian D_i Z = sum_alpha C_{alpha,i} K_tot^{-1} K_alpha over the 14 skeletal
     barycentric anchors for p in [4 - 2*sqrt(2), 4 + 2*sqrt(2)] and (w_V, w_E, w_F) in Delta_2.
2. Family II (Collinear-Cancelled Krylov-Steiner 3-Parameter Family Z_KS(c_0, c_1, c_2)):
   - K_0 = U_1, K_1 = (S_hat - I_3) U_1, K_2 = (H_2_tilde - (2/9) I_3) U_1.
   - Exact Q(sqrt(6)) spectral extrema of U_1: [-(3 + 9*sqrt(6))/32, 3/4].
3. Family III (Collision-Cancelled Radial-Vandermonde 3-Parameter Family Z_VM(a_1, a_2, a_3)):
   - V_1 = U_1, V_2 = U_2 - (1/3) U_1, V_3 = U_3 - (7/36) U_1.
   - Exact Cauchy-Binet Vandermonde determinant: det[V_1, V_2, V_3] = (3/2) Vol(P) prod_{i<j}(rho_j - rho_i).
4. Family IV (Hybrid Steiner-Vandermonde 3-Parameter Family Z_SV(b_1, b_2, b_3)):
   - Z_SV = G + b_1 K_0 + b_2 K_1 + b_3 V_2.
5. Family V (Collinear-Immune Steiner-Modulated Family Z_mod(d_0, d_1, d_2, d_3) & Multi-Generator Rays T1..T8):
   - Modulated by q_tilde = 1 - tr(S_hat^2) = 2/3 - tr(H^2) in [0, 2/3], whose value AND vertex
     gradient vanish identically on all 1D collinear configurations (D_i(q_tilde * W) = 0 on 1D),
     plus 8 multi-generator syzygy-coupled rays T1..T8 expanding the 3D Heart volume to 10.02x conv(M_p)
     on P_III and 24.88x conv(M_p) (18.66x rational alone) on Scalene Tetrahedron 2.
6. Coplanar 4-Point Heart, Centroid-Augmented Triangle (A, B, C, G_ABC), Counterexamples for D != G_ABC,
   & Certified 4-Point Chest Subset of the Standard Triangle Chest C_std(ABC) (Theorems 7.1-7.5):
   - Verifies the exact pullback chain rule D_A Z_tilde = D_1 Z + (1/3) D_4 Z and two-step finite
     displacement inequality proving H_4(A, B, C, G_ABC) subseteq H_3(A, B, C).
   - Verifies strictness H_4(A, B, C, G_ABC) subsetneq H_3(A, B, C) via the Parallelogram Bimedian
     Chest bound y >= h/6 - 3/(2h) (which excludes X(1) for all h > sqrt(21 + 6*sqrt(13))), the
     exact coplanar/centroid dictionary reducing K_0, K_1, K_2, V_2, V_3, q_tilde to K_tri, HK_tri, q_tri,
     and the three exact centroid-augmented syzygies S_1, S_2, S_3.
   - Verifies Theorem 7.4 (Uniqueness of G_ABC & Explicit Counterexamples for D in H_3(A,B,C) \ {G_ABC}).
   - Verifies Theorem 7.5 (Certified 4-Point Chest Subset of C_std(ABC)): proves via 2-step parallel
     restoration (Corollary 5.2 of Paper I) that all 12 defining half-planes of C_std(ABC) = conv(ABC) cap
     CP(ABC) cap CNT(ABC) are certified for (A, B, C, G_ABC), reducing the 13-20-21 four-point chest of
     Paper I Section 9.3 from 13.4127% to 5.9302%, and proving strict subset inclusion C_4^aug(T_h, G) subsetneq
     C_std(T_h) for all h > 3*sqrt(3).
"""
import itertools
import math
import time
import numpy as np
from scipy.spatial import ConvexHull


def exact_rational_family_data(P):
    """Return value vectors and exact analytical vertex-0 Jacobians D_0 for K0..K2, V1..V3, and M0..M3."""
    P = np.asarray(P, dtype=float)
    G = np.mean(P, axis=0)
    r = P - G
    rho_raw = np.sum(r * r, axis=1)
    L = float(np.sum(rho_raw))
    if L <= 0:
        raise ValueError("Total second moment L must be positive.")
    rho = rho_raw / L
    delta = rho - 0.25
    I3 = np.eye(3)

    grad_delta = np.zeros((4, 3))
    for i in range(4):
        c_i0 = 0.75 if i == 0 else -0.25
        grad_delta[i] = (2.0 * c_i0 * r[i] - 2.0 * rho[i] * r[0]) / L

    S_hat = (r.T @ r) / L
    H = S_hat - (1.0 / 3.0) * I3

    U1 = delta @ r
    D0_U1 = delta[0] * I3 + (2.0 / L) * np.outer(r[0], r[0]) - 0.5 * S_hat - (2.0 / L) * np.outer(U1, r[0])

    v2 = delta**2 - np.mean(delta**2)
    U2 = v2 @ r
    D0_U2 = v2[0] * I3 + (2.0 * delta[:, None] * r).T @ grad_delta

    v3 = delta**3 - np.mean(delta**3)
    U3 = v3 @ r
    D0_U3 = v3[0] * I3 + (3.0 * (delta**2)[:, None] * r).T @ grad_delta

    def dH_matrix(w):
        return ((np.dot(r[0], w)) * I3 + np.outer(r[0], w) - 2.0 * np.outer(S_hat @ w, r[0])) / L

    HK = H @ U1
    D0_HK = dH_matrix(U1) + H @ D0_U1

    tr_S2 = float(np.trace(S_hat @ S_hat))
    grad_tr_H2 = (4.0 / L) * (S_hat @ r[0] - tr_S2 * r[0])
    H2_tilde = H @ H - (np.trace(H @ H) / 3.0) * I3
    H2K = H2_tilde @ U1
    D0_H2K = (
        dH_matrix(HK)
        + H @ dH_matrix(U1)
        - (1.0 / 3.0) * np.outer(U1, grad_tr_H2)
        + H2_tilde @ D0_U1
    )

    K0, D0_K0 = U1, D0_U1
    K1, D0_K1 = HK - (2.0 / 3.0) * U1, D0_HK - (2.0 / 3.0) * D0_U1
    K2, D0_K2 = H2K - (2.0 / 9.0) * U1, D0_H2K - (2.0 / 9.0) * D0_U1

    V1, D0_V1 = U1, D0_U1
    V2, D0_V2 = U2 - (1.0 / 3.0) * U1, D0_U2 - (1.0 / 3.0) * D0_U1
    V3, D0_V3 = U3 - (7.0 / 36.0) * U1, D0_U3 - (7.0 / 36.0) * D0_U1

    q_tilde = 1.0 - tr_S2
    grad_q_tilde = -grad_tr_H2

    out = {
        "G": G, "r": r, "L": L, "rho": rho, "delta": delta, "S_hat": S_hat, "H": H,
        "q_tilde": q_tilde, "grad_q_tilde": grad_q_tilde,
        "U1": (U1, D0_U1), "U2": (U2, D0_U2), "U3": (U3, D0_U3),
        "HK": (HK, D0_HK), "H2K": (H2K, D0_H2K),
        "K0": (K0, D0_K0), "K1": (K1, D0_K1), "K2": (K2, D0_K2),
        "V1": (V1, D0_V1), "V2": (V2, D0_V2), "V3": (V3, D0_V3),
    }
    for base_key, mod_key in [("U1", "M0"), ("HK", "M1"), ("U2", "M2"), ("H2K", "M3"), ("V2", "MV2"), ("K1", "MK1")]:
        W, D0_W = out[base_key]
        out[mod_key] = (q_tilde * W, q_tilde * D0_W + np.outer(W, grad_q_tilde))
    return out


def all_vertex_jacobians_rational(P, weights_dict):
    """Evaluate Z(P) = G + sum_k c_k W_k(P) and all four vertex Jacobians D_0 Z, ..., D_3 Z."""
    P = np.asarray(P, dtype=float)
    d0 = exact_rational_family_data(P)
    Z = d0["G"].copy()
    for k, c in weights_dict.items():
        Z = Z + c * d0[k][0]
    J = np.zeros((4, 3, 3))
    min_eig = math.inf
    for i in range(4):
        P_perm = P.copy()
        if i != 0:
            P_perm[[0, i]] = P_perm[[i, 0]]
        di = exact_rational_family_data(P_perm)
        Di_Z = 0.25 * np.eye(3)
        for k, c in weights_dict.items():
            Di_Z = Di_Z + c * di[k][1]
        J[i] = Di_Z
        sym_Di = 0.5 * (Di_Z + Di_Z.T)
        eigs = np.linalg.eigvalsh(sym_Di)
        min_eig = min(min_eig, float(eigs[0]))
    return Z, J, min_eig


def solve_skeletal_constellation_power(P, p, w_E, w_F):
    """Evaluate the 3-parametric Skeletal-Constellation Power Center Z_const(p, w_E, w_F; P)
    with backtracking line search and its exact chain-rule vertex Jacobians
    D_i Z = sum_alpha C_{alpha,i} K_tot^{-1} K_alpha.
    """
    w_V = max(0.0, 1.0 - w_E - w_F)
    orbit_specs = [
        (w_V, (1.0, 0.0, 0.0, 0.0)),
        (w_E, (0.5, 0.5, 0.0, 0.0)),
        (w_F, (1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0, 0.0)),
    ]
    anchors, weights, C_mats = [], [], []
    for w_orb, bary in orbit_specs:
        if w_orb <= 1e-15:
            continue
        perms = sorted(set(itertools.permutations(bary)))
        w_each = w_orb / len(perms)
        for perm in perms:
            perm_arr = np.array(perm, dtype=float)
            anchors.append(perm_arr @ P)
            weights.append(w_each)
            C_mats.append(perm_arr)
    anchors = np.array(anchors)
    weights = np.array(weights)
    C_mats = np.array(C_mats)

    d0_init = exact_rational_family_data(P)
    x = d0_init["G"].copy()
    if np.min(np.sum((x[None, :] - anchors) ** 2, axis=1)) < 1e-24:
        x = x - 1e-6 * d0_init["U1"][0]
    I3 = np.eye(3)

    def potential(pt):
        diff_pt = pt[None, :] - anchors
        r2_pt = np.maximum(np.sum(diff_pt * diff_pt, axis=1), 1e-30)
        return float(np.sum(weights * (r2_pt ** (p / 2.0))) / p)

    for _ in range(80):
        diff = x[None, :] - anchors
        r2 = np.maximum(np.sum(diff * diff, axis=1), 1e-30)
        r_p2 = r2 ** ((p - 2.0) / 2.0)
        grad = np.sum(weights[:, None] * r_p2[:, None] * diff, axis=0)
        if np.linalg.norm(grad) < 1e-14:
            break
        u = diff / np.sqrt(r2)[:, None]
        K_each = weights[:, None, None] * r_p2[:, None, None] * (
            I3[None, :, :] + (p - 2.0) * u[:, :, None] * u[:, None, :]
        )
        K_tot = np.sum(K_each, axis=0)
        step = np.linalg.solve(K_tot, grad)
        f0 = potential(x)
        alpha = 1.0
        while alpha > 1e-12 and potential(x - alpha * step) > f0:
            alpha *= 0.5
        x = x - alpha * step
        if alpha * np.linalg.norm(step) < 1e-14:
            break

    diff = x[None, :] - anchors
    r2 = np.maximum(np.sum(diff * diff, axis=1), 1e-30)
    r_p2 = r2 ** ((p - 2.0) / 2.0)
    u = diff / np.sqrt(r2)[:, None]
    K_each = weights[:, None, None] * r_p2[:, None, None] * (
        I3[None, :, :] + (p - 2.0) * u[:, :, None] * u[:, None, :]
    )
    K_tot = np.sum(K_each, axis=0)
    K_inv = np.linalg.inv(K_tot)
    J = np.zeros((4, 3, 3))
    min_sym_eig = math.inf
    for i in range(4):
        L_i = np.sum(C_mats[:, i, None, None] * K_each, axis=0)
        J[i] = K_inv @ L_i
        sym_Ji = 0.5 * (J[i] + J[i].T)
        min_sym_eig = min(min_sym_eig, float(np.linalg.eigvalsh(sym_Ji)[0]))
    return x, J, min_sym_eig


def solve_planar_power_center_and_jacobians(pts_2d, p_exp):
    """Damped Newton solver for the n-point planar power center M_p(pts_2d) in R^2
    and its exact analytical vertex Jacobians D_i M_p = K_tot^{-1} K_i.
    """
    pts_2d = np.asarray(pts_2d, dtype=float)
    x = np.mean(pts_2d, axis=0)
    I2 = np.eye(2)

    def obj(pt):
        diff_pt = pt[None, :] - pts_2d
        r2_pt = np.maximum(np.sum(diff_pt * diff_pt, axis=1), 1e-30)
        return float(np.sum(r2_pt ** (p_exp / 2.0)) / p_exp)

    for _ in range(100):
        diff = x[None, :] - pts_2d
        r2 = np.maximum(np.sum(diff * diff, axis=1), 1e-30)
        r_p2 = r2 ** ((p_exp - 2.0) / 2.0)
        grad = np.sum(r_p2[:, None] * diff, axis=0)
        if np.linalg.norm(grad) < 1e-15:
            break
        u = diff / np.sqrt(r2)[:, None]
        K_each = r_p2[:, None, None] * (I2[None, :, :] + (p_exp - 2.0) * u[:, :, None] * u[:, None, :])
        step = np.linalg.solve(np.sum(K_each, axis=0), grad)
        f0 = obj(x)
        alpha = 1.0
        while alpha > 1e-12 and obj(x - alpha * step) > f0:
            alpha *= 0.5
        x = x - alpha * step
        if alpha * np.linalg.norm(step) < 1e-15:
            break

    diff = x[None, :] - pts_2d
    r2 = np.maximum(np.sum(diff * diff, axis=1), 1e-30)
    r_p2 = r2 ** ((p_exp - 2.0) / 2.0)
    u = diff / np.sqrt(r2)[:, None]
    K_each = r_p2[:, None, None] * (I2[None, :, :] + (p_exp - 2.0) * u[:, :, None] * u[:, None, :])
    K_inv = np.linalg.inv(np.sum(K_each, axis=0))
    J_list = [K_inv @ K_each[i] for i in range(len(pts_2d))]
    return x, J_list


def verify_vandermonde_and_krylov_determinants(P):
    """Verify the exact closed-form 3D volume determinants of the Krylov-Steiner and Vandermonde bases."""
    d = exact_rational_family_data(P)
    M_VM = np.column_stack([d["V1"][0], d["V2"][0], d["V3"][0]])
    det_VM_lhs = float(np.linalg.det(M_VM))
    ones_P = np.vstack([np.ones((1, 4)), P.T])
    det_P = float(np.linalg.det(ones_P))
    rho = d["rho"]
    vand = 1.0
    for i in range(4):
        for j in range(i + 1, 4):
            vand *= (rho[j] - rho[i])
    det_VM_rhs = 0.25 * det_P * vand
    assert abs(det_VM_lhs - det_VM_rhs) < 1e-15, (det_VM_lhs, det_VM_rhs)

    M_KS = np.column_stack([d["K0"][0], d["K1"][0], d["K2"][0]])
    det_KS_lhs = abs(float(np.linalg.det(M_KS)))
    sigmas, eigvecs = np.linalg.eigh(d["S_hat"])
    u_prin = eigvecs.T @ d["U1"][0]
    det_KS_rhs = abs(
        float(u_prin[0] * u_prin[1] * u_prin[2] * (sigmas[0] - sigmas[1]) * (sigmas[1] - sigmas[2]) * (sigmas[2] - sigmas[0]))
    )
    assert abs(det_KS_lhs - det_KS_rhs) < 1e-15, (det_KS_lhs, det_KS_rhs)
    return det_VM_lhs, det_KS_lhs


def verify_coplanar_and_centroid_theorems():
    """Verify the coplanar Cayley-Hamilton reduction, the D = G_ABC exact dictionary,
    the three exact syzygies S_1, S_2, S_3, the pullback Jacobian & finite-displacement
    theorem H_4(A,B,C,G_ABC) subseteq H_3(A,B,C), the Parallelogram Bimedian Chest
    bound proving strictness H_4(A,B,C,G_ABC) subsetneq H_3(A,B,C), the two explicit
    counterexamples proving failure when D in H_3(A,B,C) \ {G_ABC} (Theorem 7.4), and
    the certified 4-point chest subset of C_std(ABC) (Theorem 7.5).
    """
    a, b, c = 13.0, 20.0, 21.0
    x_C = (b * b + c * c - a * a) / (2.0 * c)
    y_C = math.sqrt(b * b - x_C * x_C)
    ABC = np.array([[0.0, 0.0, 0.0], [c, 0.0, 0.0], [x_C, y_C, 0.0]])
    G_abc = np.mean(ABC, axis=0)
    P_G = np.vstack([ABC, G_abc[None, :]])
    d_G = exact_rational_family_data(P_G)

    s2 = np.array([a * a, b * b, c * c])
    s_norm = s2 / np.sum(s2)
    q_tri = 1.5 * float(np.sum((s_norm - 1.0 / 3.0) ** 2))
    K_tri = ((s_norm - 1.0 / 3.0) @ ABC)[:2]
    HK_tri = ((4.0 * (s_norm - 1.0 / 3.0) - 6.0 * (s_norm ** 2 - np.mean(s_norm ** 2))) @ ABC)[:2]

    # 1. Exact coplanar Cayley-Hamilton identity, D = G_ABC reduction dictionary, and syzygies S1, S2, S3
    tr_H2 = float(np.trace(d_G["H"] @ d_G["H"]))
    assert np.max(np.abs(d_G["K2"][0] - ((1.0 / 3.0) * d_G["K1"][0] + (tr_H2 / 6.0 - 1.0 / 9.0) * d_G["K0"][0]))) < 1e-14
    assert np.max(np.abs(d_G["K0"][0][:2] - (-K_tri))) < 1e-13
    assert np.max(np.abs(d_G["V2"][0][:2] - (K_tri / 6.0 - HK_tri / 6.0))) < 1e-13
    assert np.max(np.abs(d_G["K1"][0][:2] - (0.5 * K_tri - 0.5 * HK_tri))) < 1e-13
    assert np.max(np.abs(d_G["K2"][0][:2] - ((3.0 - 4.0 * q_tri) / 12.0 * K_tri - HK_tri / 6.0))) < 1e-13
    assert np.max(np.abs(d_G["V3"][0][:2] - ((25.0 - 48.0 * q_tri) / 144.0 * K_tri - HK_tri / 24.0))) < 1e-13
    assert abs(d_G["q_tilde"] - (0.5 - 2.0 * q_tri)) < 1e-14

    S1 = d_G["K1"][0] - 3.0 * d_G["V2"][0]
    S2 = d_G["K2"][0] - d_G["V2"][0] + (1.0 / 6.0) * d_G["M0"][0]
    S3 = d_G["V3"][0] - 0.25 * d_G["V2"][0] + (7.0 / 144.0) * d_G["K0"][0] + (1.0 / 6.0) * d_G["M0"][0]
    assert max(np.linalg.norm(S1), np.linalg.norm(S2), np.linalg.norm(S3)) < 1e-14

    # 2. Exact Jacobian pullback chain rule: D_A Z_tilde(A,B,C) = D_1 Z(A,B,C,G) + (1/3) D_4 Z(A,B,C,G)
    w_test = {"K0": 0.12, "K1": -0.25, "V2": 0.35, "M1": 0.45}
    _, J4, min_eig4 = all_vertex_jacobians_rational(P_G, w_test)
    assert min_eig4 > 0.0
    DA_chain = J4[0] + (1.0 / 3.0) * J4[3]
    eps = 1e-7
    DA_fd = np.zeros((3, 3))
    for ax in range(3):
        ABC_p, ABC_m = ABC.copy(), ABC.copy()
        ABC_p[0, ax] += eps
        ABC_m[0, ax] -= eps
        Zp, _, _ = all_vertex_jacobians_rational(np.vstack([ABC_p, np.mean(ABC_p, axis=0)[None, :]]), w_test)
        Zm, _, _ = all_vertex_jacobians_rational(np.vstack([ABC_m, np.mean(ABC_m, axis=0)[None, :]]), w_test)
        DA_fd[:, ax] = (Zp - Zm) / (2.0 * eps)
    assert float(np.max(np.abs(DA_chain - DA_fd))) < 1e-8
    assert float(np.linalg.eigvalsh(0.5 * (DA_chain + DA_chain.T))[0]) >= min_eig4

    # 3. Verify strict inclusion H_4(A,B,C,G_ABC) subsetneq H_3(A,B,C) on tall isosceles T_h (h = 7 > sqrt(21+6*sqrt(13))):
    h_iso = 7.0
    h_crit = math.sqrt(21.0 + 6.0 * math.sqrt(13.0))
    y_X1 = h_iso / (1.0 + math.sqrt(1.0 + h_iso * h_iso))
    y_chest4_lo = h_iso / 6.0 - 1.5 / h_iso
    assert h_iso > h_crit and y_chest4_lo > y_X1

    # 4. Verify Counterexample 1 (Theorem 7.4): D = M_{p_-}^{(3)}(ABC) in H_3^omega, Z = M_{p_+}^{(4)}(ABCD) in A_4^omega
    p_lo = 4.0 - 2.0 * math.sqrt(2.0)
    p_hi = 4.0 + 2.0 * math.sqrt(2.0)
    ABC_ce1 = np.array([[5.0 / 16.0, 7.0 / 20.0], [-1.0, 0.0], [1.0, 0.0]])
    D_ce1, J3_ce1 = solve_planar_power_center_and_jacobians(ABC_ce1, p_lo)
    Z_ce1, J4_ce1 = solve_planar_power_center_and_jacobians(np.vstack([ABC_ce1, D_ce1[None, :]]), p_hi)
    J_pull_ce1 = J4_ce1[0] + J4_ce1[3] @ J3_ce1[0]
    sym_ce1 = 0.5 * (J_pull_ce1 + J_pull_ce1.T)
    evals_ce1, evecs_ce1 = np.linalg.eigh(sym_ce1)
    assert abs(float(evals_ce1[0]) - (-2.448746542031e-4)) < 1e-10
    step_ce1 = 1e-3 * evecs_ce1[:, 0]
    ABC_ce1_new = ABC_ce1.copy()
    ABC_ce1_new[0] += step_ce1
    D_ce1_new, _ = solve_planar_power_center_and_jacobians(ABC_ce1_new, p_lo)
    Z_ce1_new, _ = solve_planar_power_center_and_jacobians(np.vstack([ABC_ce1_new, D_ce1_new[None, :]]), p_hi)
    dot_ce1 = float(np.dot(Z_ce1_new - Z_ce1, step_ce1))
    assert dot_ce1 < -2.4e-10

    # 5. Verify Counterexample 2 (Theorem 7.4): Closed-form rational D = R_5^*(ABC) in H_3^omega, Z = M_{p_-}^{(4)}(ABCD)
    def eval_R5_star_2d(pts):
        A_pt, B_pt, C_pt = pts[0], pts[1], pts[2]
        s2_loc = np.array([np.sum((B_pt - C_pt) ** 2), np.sum((C_pt - A_pt) ** 2), np.sum((A_pt - B_pt) ** 2)])
        s_loc = s2_loc / np.sum(s2_loc)
        d_loc = s_loc - 1.0 / 3.0
        q_loc = 1.5 * float(np.sum(d_loc * d_loc))
        G_loc = np.mean(pts, axis=0)
        K_loc = d_loc @ pts
        HK_loc = (4.0 * d_loc - 6.0 * (s_loc ** 2 - np.mean(s_loc ** 2))) @ pts
        lam = 3040.0 / 3113.0
        return G_loc + lam * (0.45 + 1.2 * q_loc) * K_loc + lam * (-1.6 + 2.6 * q_loc) * HK_loc

    ABC_ce2 = np.array([[0.5, 1.0], [-1.0, 0.0], [1.0, 0.0]])
    D_ce2 = eval_R5_star_2d(ABC_ce2)
    JM_ce2 = np.zeros((2, 2))
    for ax in range(2):
        pp, pm = ABC_ce2.copy(), ABC_ce2.copy()
        pp[0, ax] += eps
        pm[0, ax] -= eps
        JM_ce2[:, ax] = (eval_R5_star_2d(pp) - eval_R5_star_2d(pm)) / (2.0 * eps)
    Z_ce2, J4_ce2 = solve_planar_power_center_and_jacobians(np.vstack([ABC_ce2, D_ce2[None, :]]), p_lo)
    J_pull_ce2 = J4_ce2[0] + J4_ce2[3] @ JM_ce2
    sym_ce2 = 0.5 * (J_pull_ce2 + J_pull_ce2.T)
    evals_ce2, evecs_ce2 = np.linalg.eigh(sym_ce2)
    assert abs(float(evals_ce2[0]) - (-4.025105532815e-4)) < 1e-9
    step_ce2 = 1e-3 * evecs_ce2[:, 0]
    ABC_ce2_new = ABC_ce2.copy()
    ABC_ce2_new[0] += step_ce2
    D_ce2_new = eval_R5_star_2d(ABC_ce2_new)
    Z_ce2_new, _ = solve_planar_power_center_and_jacobians(np.vstack([ABC_ce2_new, D_ce2_new[None, :]]), p_lo)
    dot_ce2 = float(np.dot(Z_ce2_new - Z_ce2, step_ce2))
    assert dot_ce2 < -4.4e-10

    # 6. Verify Theorem 7.5 (Certified 4-Point Chest Subset of C_std(ABC)):
    #    Check exact parallel-restoration proportionality Delta D = (1/3) Delta p_i for all 9 CP & CNT half-planes
    #    on the 13-20-21 triangle A=(0,0), B=(21,0), C=(5,12), D=(26/3, 4), and verify strict subset inclusion
    #    C_4^aug(T_6, G) = [0.75, 35/12] subsetneq [1/sqrt(3), 35/12] = C_std(T_6).
    tri_2d = ABC[:, :2]
    D_2d = G_abc[:2]
    R60 = np.array([[0.5, -math.sqrt(3.0) / 2.0], [math.sqrt(3.0) / 2.0, 0.5]])
    for i in range(3):
        j, k = (i + 1) % 3, (i + 2) % 3
        pi, pj, pk = tri_2d[i], tri_2d[j], tri_2d[k]
        u = pj - pi
        u2 = float(np.dot(u, u))
        m_ij = 0.5 * (pi + pj)
        # (a) Bisector restoration:
        dC_bis = (np.dot(u, pk - m_ij) / u2) * u
        dD_bis = (np.dot(u, D_2d - m_ij) / u2) * u
        assert np.linalg.norm(dD_bis - (1.0 / 3.0) * dC_bis) < 1e-13
        # (b) Altitude-reflection restoration:
        pi_refl = pj + 2.0 * (np.dot(u, pk - pj) / u2) * u
        D_proj = D_2d + (np.dot(u, pk - D_2d) / u2) * u
        dA_alt = pi - pi_refl
        dD_alt = D_2d - D_proj
        assert np.linalg.norm(dD_alt - (1.0 / 3.0) * dA_alt) < 1e-13
        # (c) Internal Napoleon restoration:
        pk_0 = pi + R60 @ (pj - pi)
        N_k = (pi + pj + pk_0) / 3.0
        dC_nap = pk - pk_0
        dD_nap = D_2d - N_k
        assert np.linalg.norm(dD_nap - (1.0 / 3.0) * dC_nap) < 1e-13

    h_strict = 6.0
    c_std_lo = 1.0 / math.sqrt(3.0)
    c_std_hi = (h_strict * h_strict - 1.0) / (2.0 * h_strict)
    c4_aug_lo = max(c_std_lo, h_strict / 6.0 - 1.5 / h_strict)
    assert c4_aug_lo == 0.75 and c4_aug_lo > c_std_lo and c4_aug_lo < c_std_hi


def main():
    t0 = time.monotonic()
    P_bench = np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [3.0, -2.0, 0.5]])
    P_scalene2 = np.array([[0.0, 0.0, 0.0], [4.0, 0.0, 0.0], [1.0, 3.0, 0.0], [0.5, 0.8, 2.5]])

    # 1. Verify exact analytical Jacobians against central finite differences (including Family V M0..M3)
    d_bench = exact_rational_family_data(P_bench)
    eps = 1e-7
    for key in ["K0", "K1", "K2", "V1", "V2", "V3", "M0", "M1", "M2", "M3", "MV2", "MK1"]:
        D0_fd = np.zeros((3, 3))
        for axis in range(3):
            Pp, Pm = P_bench.copy(), P_bench.copy()
            Pp[0, axis] += eps
            Pm[0, axis] -= eps
            D0_fd[:, axis] = (exact_rational_family_data(Pp)[key][0] - exact_rational_family_data(Pm)[key][0]) / (2.0 * eps)
        err = float(np.max(np.abs(d_bench[key][1] - D0_fd)))
        assert err < 1e-9, (key, err)
    print("1. Exact analytical 3x3 vertex Jacobians (Families II-V) verified against FD: PASS")

    # 2. Verify exact closed-form 3D determinants (Krylov-Steiner & Radial-Vandermonde)
    det_vm, det_ks = verify_vandermonde_and_krylov_determinants(P_bench)
    print(f"2. Closed-form 3D determinant identities verified: det_VM = {det_vm:.6e}, det_KS = {det_ks:.6e}: PASS")

    # 3. Verify exact algebraic spectral extrema of Sym(D_i U_1) in Q(sqrt(6)) and collinear vanishing of K1, K2, M0..M3
    t_min = (-4.0 * math.sqrt(2.0) + 3.0 * math.sqrt(3.0)) / 5.0
    theta_min = math.atan2(1.0, t_min)
    x0 = math.sqrt(3.0) / 2.0 * math.cos(theta_min)
    s_val = math.sin(theta_min) / math.sqrt(6.0)
    x_col = np.array([x0, -x0 / 3.0 + s_val, -x0 / 3.0 + s_val, -x0 / 3.0 - 2.0 * s_val])
    P_col_min = np.column_stack([x_col, np.zeros(4), np.zeros(4)])
    d_col = exact_rational_family_data(P_col_min)
    eig_min_exact = -(3.0 + 9.0 * math.sqrt(6.0)) / 32.0
    assert abs(float(d_col["U1"][1][0, 0]) - eig_min_exact) < 1e-15

    P_col_max = np.array([[-1.0 / math.sqrt(2.0), 0.0, 0.0], [1.0 / math.sqrt(2.0), 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]])
    assert abs(float(exact_rational_family_data(P_col_max)["U1"][1][0, 0]) - 0.75) < 1e-15
    assert np.linalg.norm(d_col["K1"][0]) < 1e-15 and np.linalg.norm(d_col["K2"][0]) < 1e-15
    for mkey in ["M0", "M1", "M2", "M3", "MV2", "MK1"]:
        assert np.linalg.norm(d_col[mkey][0]) < 1e-15 and np.linalg.norm(d_col[mkey][1]) < 1e-15
    print(f"3. Exact Q(sqrt(6)) spectral extrema [{eig_min_exact:.12f}, 0.75] & 1D vanishing of D_i(q_tilde W): PASS")

    # 4. Verify Coplanar 4-Point Heart, Centroid-Augmented Triangle (A, B, C, G_ABC), Counterexamples, & Chest Subset Theorem
    verify_coplanar_and_centroid_theorems()
    print("4. Coplanar dictionary, H_4(A,B,C,G) subsetneq H_3, D != G counterexamples, & C_4(A,B,C,G) subseteq C_std(ABC): PASS")

    # 5. Audit global attractivity across 552 diverse and nearly degenerate tetrahedra (single-axis + T1..T8)
    rng = np.random.default_rng(20261017)
    audit_shapes = [P_bench, P_scalene2]
    for _ in range(350):
        audit_shapes.append(rng.normal(size=(4, 3)))
    for scale in [1e-1, 1e-2, 1e-4, 1e-6]:
        for _ in range(25):
            P_flat = rng.normal(size=(4, 3)); P_flat[:, 2] *= scale; audit_shapes.append(P_flat)
            P_line = rng.normal(size=(4, 3)); P_line[:, 1:] *= scale; audit_shapes.append(P_line)

    ray_endpoints = [
        {"K0": -1.0 / 3.0}, {"K0": 0.3194198},
        {"K1": -0.8677},    {"K1": 0.9030},
        {"K2": -1.9755},    {"K2": 1.9804},
        {"V2": -1.4523},    {"V2": 2.1168},
        {"V3": -2.8733},    {"V3": 2.8670},
        {"M0": -0.8826},    {"M0": 0.9373},
        {"M1": -2.0159},    {"M1": 2.3682},
        {"M2": -3.9318},    {"M2": 4.3120},
        {"M3": -7.4323},    {"M3": 9.0382},
        {"MV2": -2.9242},   {"MV2": 3.3500},
        {"MK1": -1.9187},   {"MK1": 1.6750},
        {"K1": 1.019667, "V2": -1.529501, "K2": 1.019667},
        {"K1": -1.045781, "V2": 1.568672, "K2": -1.045781},
        {"K0": 0.111947, "K1": 0.447787, "V2": 0.67168, "V3": 1.119466},
        {"K0": -0.102011, "K1": -0.408043, "V2": -0.612064, "V3": -1.020107},
        {"K1": 0.840559, "K2": -2.101399, "V3": 3.082051},
        {"K1": -0.861217, "K2": 2.153044, "V3": -3.157797},
        {"K1": 0.275521, "V2": -0.551042, "M1": 0.826562, "M2": 1.653125, "M3": 2.755208},
        {"K1": -0.235285, "V2": 0.47057, "M1": -0.705855, "M2": -1.411711, "M3": -2.352851},
    ]
    min_rational_eig = math.inf
    for P in audit_shapes:
        for ep in ray_endpoints:
            _, _, eig = all_vertex_jacobians_rational(P, ep)
            min_rational_eig = min(min_rational_eig, eig)
    assert min_rational_eig >= -1e-12, min_rational_eig
    print(f"5. Global attractivity audit across {len(audit_shapes)} 3D/planar/collinear tetrahedra (min eig = {min_rational_eig:.3e}): PASS")

    # 6. Compute 3D Heart inner-approximation volumes on P_bench and P_scalene2
    p_lo, p_hi = 4.0 - 2.0 * math.sqrt(2.0), 4.0 + 2.0 * math.sqrt(2.0)
    for label_P, P_cur in [("Paper III Benchmark P_III", P_bench), ("Scalene Tetrahedron 2", P_scalene2)]:
        power_1d_pts = np.array([solve_skeletal_constellation_power(P_cur, p, 0.0, 0.0)[0] for p in np.linspace(p_lo, p_hi, 25)])
        vol_power_1d = float(ConvexHull(power_1d_pts).volume)
        const_3d_pts = []
        for p in np.linspace(p_lo, p_hi, 9):
            for wE in np.linspace(0.0, 1.0, 6):
                for wF in np.linspace(0.0, 1.0 - wE, 6):
                    const_3d_pts.append(solve_skeletal_constellation_power(P_cur, p, wE, wF)[0])
        const_3d_pts = np.array(const_3d_pts)
        vol_const_3d = float(ConvexHull(const_3d_pts).volume)
        rat_pts = np.array([all_vertex_jacobians_rational(P_cur, ep)[0] for ep in ray_endpoints])
        vol_rat = float(ConvexHull(rat_pts).volume)
        vol_comb = float(ConvexHull(np.vstack([power_1d_pts, const_3d_pts, rat_pts])).volume)
        print(f"6. 3D Heart Volume on {label_P}:")
        print(f"   - 1D Vertex Power Curve conv(M_p):               {vol_power_1d:.6e}")
        print(f"   - Family I (3-Param Skeletal-Constellation):     {vol_const_3d:.6e} ({vol_const_3d / vol_power_1d:.2f}x)")
        print(f"   - Families II-V (+ Syzygy Rays T1..T8):          {vol_rat:.6e} ({vol_rat / vol_power_1d:.2f}x)")
        print(f"   - Combined Hull (Families I-V + T1..T8):         {vol_comb:.6e} ({vol_comb / vol_power_1d:.2f}x)")
    print(f"All verifications PASSED in {round(time.monotonic() - t0, 3)}s.")


if __name__ == "__main__":
    main()