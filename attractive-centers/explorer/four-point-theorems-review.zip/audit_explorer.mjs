import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const root='C:/Users/Ismail Hammoudeh/Documents/Triangle Sky/output/attractive-centers-web/research-site/attractive-centers/explorer/';
const {triangle,four,fourCombined,area,clipAll,mean,normalize}=await import(pathToFileURL(root+'geometry.mjs'));
const {revisedFour,edgeSlabs,centroidTransfer}=await import(pathToFileURL(root+'revision.mjs'));
const P=[[0,0],[21,0],[5,12],[26/3,4]];
const base=four(P), old=fourCombined(base,{para:true,bisector:true,network:true});
const tri=triangle(P.slice(0,3));
const result={standard:{area:area(tri.poly),vertices:tri.poly},old:{area:area(old)},withEdgeSlabs:{area:area(clipAll(old,edgeSlabs(P)))},withCentroidTransfer:{area:area(clipAll(old,centroidTransfer(P)))},allUnconditional:{area:area(revisedFour(P,{para:true,bisector:true,network:true,edge:true,transfer:true,orbit:true,stable:false,ball:false}).combined)}};
for(const h of [6,7]){
 const pp=[[-1,0],[1,0],[0,h],[0,h/3]];
 result['isosceles'+h]=revisedFour(pp,{para:true,bisector:true,network:true,edge:true,transfer:true,orbit:true,stable:false,ball:false}).combined;
}
fs.writeFileSync(new URL('./explorer_audit.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
