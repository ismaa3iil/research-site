# Three-Parametric Non-Collinear Attractive Center Families for the Tetrahedron ($n = 4, d = 3$) and the Coplanar / Centroid-Augmented Heart Theorems

**Date:** 17 October 2026

**Scope:** Exact mathematical constructions, analytical global attractivity proofs, closed-form 3D non-coplanarity determinants, volumetric Heart inner-approximation benchmarks, and exact coplanar / centroid-augmented subset theorems extending *Attractive Centers I–IV* (`https://ismaa3iil.fyi`) from triangles ($n=3, d=2$) to tetrahedra ($n=4, d=3$).

## 1. Why Estimating the Tetrahedron Heart Requires 3-Parametric Families

For a tetrahedron $P = (p_1, p_2, p_3, p_4) \in (\mathbb{R}^3)^4$ with centroid $G = \frac{1}{4}\sum_{i=1}^4 p_i$, the ambient space is $\mathbb{R}^3$ and the normalized barycentric weight simplex $\sum_{i=1}^4 w_i = 1$ is 3-dimensional:

* Both the **vertex power center curve** $M_p(P) = \arg\min_{x \in \mathbb{R}^3} \sum_{i=1}^4 \frac{1}{p}\|x - p_i\|^p$ for $p \in [4 - 2\sqrt{2}, \, 4 + 2\sqrt{2}]$ (Paper III, Theorem 4.1) and the **hull-power center curve** $H_p(P)$ are **1-parametric space curves** in $\mathbb{R}^3$ (requiring convex hulling across distinct exponents to span 3D volume).

* Moreover, as shown in Paper III (Section 7.2, *Failure for tetrahedra*), the intermediate skeletal centroids $C_{3,1}$ (wireframe centroid) and $C_{3,2}$ (surface area centroid) **fail** global attractivity on $A=(0,0,0), \, B=(1,0,0), \, C=(0,1,0), \, D=(3,-2,1/2)$ because metric weighting by edge lengths $\ell_{ij}$ or face areas $A_k$ introduces non-radial metric-stretching drift when a vertex moves.

To map a 3D parameter domain $\Omega \subset \mathbb{R}^3$ directly onto a **3-dimensional volumetric region** inside the tetrahedron Heart $\mathcal{H}(P) \subset \mathbb{R}^3$ (the 3D analogue of the 2-parameter Symmedian–Steiner domain $\Omega_{K, HK}$ for triangles), we need a **3-parametric family** $(\theta_1, \theta_2, \theta_3) \mapsto Z(\theta_1, \theta_2, \theta_3; P) \in \mathbb{R}^3$ whose parameter Jacobian $\frac{\partial Z}{\partial(\theta_1, \theta_2, \theta_3)} \in \mathbb{R}^{3 \times 3}$ has **full rank 3** ($\det \frac{\partial Z}{\partial \theta} \neq 0$) on a generic scalene tetrahedron while satisfying $\operatorname{Sym} D_i Z(P) \succeq 0$ for all $i \in \{1,2,3,4\}$ across all configurations.

Below are **five complementary 3-parametric families** (one variational/mechanical family with an unconditional zero-backoff proof from Paper III, three root-free rational polynomial covariant families, and one collinear-immune Steiner-modulated family whose value and vertex Jacobian vanish identically on all 1D collinear configurations), followed in **Section 7** by the complete proof that the coplanar centroid-augmented Heart satisfies the **strict inclusion** $\mathcal{H}_4(A, B, C, G_{ABC}) \subsetneq \mathcal{H}_3(A, B, C)$.

## 2. Family I: The 3-Parametric Skeletal-Constellation Power Family $Z_{\text{const}}(p, w_E, w_F)$

### 2.1 Definition

Instead of weighting the 1-skeleton and 2-skeleton by Euclidean edge lengths or face areas (which destroys attractivity at $p=2$ in Paper III Section 7.2), equip the **three canonical** $S_4$**-orbits of affine barycentric anchors**—the $4$ vertices $v_i = p_i$, the $6$ edge midpoints $m_{ij} = \frac{1}{2}(p_i + p_j)$, and the $4$ face centroids $f_k = \frac{1}{3}\sum_{j \neq k} p_j$—with homogeneous radial power springs of exponent $p$:

$$
Z_{\text{const}}(p, w_E, w_F; P) := \arg\min_{x \in \mathbb{R}^3} \left[ \frac{1 - w_E - w_F}{4}\sum_{i=1}^4 \frac{\|x - p_i\|^p}{p} + \frac{w_E}{6}\sum_{1 \le i < j \le 4} \frac{\|x - m_{ij}\|^p}{p} + \frac{w_F}{4}\sum_{k=1}^4 \frac{\|x - f_k\|^p}{p} \right]
$$

over the **3-dimensional parameter prism**:

$$
\Omega_{\text{const}} = \bigl\{(p, w_E, w_F) \in \mathbb{R}^3 : 4 - 2\sqrt{2} \le p \le 4 + 2\sqrt{2}, \quad w_E \ge 0, \quad w_F \ge 0, \quad w_E + w_F \le 1\bigr\}.
$$

### 2.2 Theorem 2.1 (Unconditional Global Attractivity of Barycentric-Constellation Power Centers)

For every $(p, w_E, w_F) \in \Omega_{\text{const}}$ (and more generally for any probability measure over $S_4$-orbits of barycentric anchors $a_\alpha(P) = \sum_{i=1}^4 C_{\alpha i} p_i$ with $C_{\alpha i} \ge 0, \, \sum_i C_{\alpha i} = 1$), $Z_{\text{const}}(p, w_E, w_F; P)$ is Euclidean similarity-equivariant, $S_4$-invariant, and **globally attractive on all configurations** $P \in (\mathbb{R}^d)^4$ ($d \ge 1$) **with zero parameter backoff**.

**Proof:**

1. *Similarity equivariance:* Because all 14 anchors $a_\alpha(P)$ are affine barycentric combinations ($\sum_{i=1}^4 C_{\alpha i} = 1$) and every term shares the same homogeneous exponent $p$, translation, orthogonal rotation, and positive scaling $P \mapsto \lambda P$ transform the objective by $x \mapsto \lambda x$ and scale the potential by $\lambda^p$, preserving the unique minimizer.

2. *Positive semidefinite vertex response:* Let $K_\alpha = \omega_\alpha D^2\bigl(\frac{1}{p}\|x - a_\alpha\|^p\bigr)\big|_{x=Z}$ be the stiffness tensor of anchor $\alpha \in \{1, \dots, 14\}$ and $K_{\text{tot}} = \sum_{\alpha=1}^{14} K_\alpha$. By Theorem 4.1 of Paper III (*Exact Power Classification*), $4 - 2\sqrt{2} \le p \le 4 + 2\sqrt{2}$ implies $\operatorname{Sym}(K_{\text{tot}}^{-1} K_\alpha) \succeq 0$ for every individual anchor $\alpha$. Since $\frac{\partial a_\alpha}{\partial p_i} = C_{\alpha i} I_3$ with $C_{\alpha i} \ge 0$, the chain rule gives:

   $$
   D_i Z_{\text{const}}(P) = \sum_{\alpha=1}^{14} C_{\alpha i} K_{\text{tot}}^{-1} K_\alpha \implies \operatorname{Sym}\bigl(D_i Z_{\text{const}}(P)\bigr) = \sum_{\alpha=1}^{14} C_{\alpha i} \operatorname{Sym}\bigl(K_{\text{tot}}^{-1} K_\alpha\bigr) \succeq 0.
   $$

   The finite-displacement inequality across anchor collisions follows identically by summing the anchor finite-displacement inequalities with nonnegative weights $C_{\alpha i} \ge 0$. $\square$

## 3. Family II: The 3-Parametric Krylov–Steiner Operator Family $Z_{\text{KS}}(c_0, c_1, c_2)$

### 3.1 Construction and Collinear Cancellation

Let $r_i = p_i - G$ ($\sum_{i=1}^4 r_i = 0$), let $L := \sum_{i=1}^4 \|r_i\|^2 = \frac{1}{4}\sum_{1 \le i < j \le 4} \ell_{ij}^2$ be the total second moment, and let

$$
\rho_i := \frac{\|r_i\|^2}{L} \in \left[0, \, \frac{3}{4}\right], \qquad \delta_i := \rho_i - \frac{1}{4} = \frac{1}{4} - \frac{F_i}{12L},
$$

where $F_i = \sum_{\{j,k\}\subset\{1..4\}\setminus\{i\}} \ell_{jk}^2 = 3L - 4\|r_i\|^2$ is the sum of squared edge lengths of the face opposite vertex $i$. Define the **3D Lemoine / Radial-Moment Vector**:

$$
U_1(P) := \sum_{i=1}^4 \delta_i p_i = \sum_{i=1}^4 \delta_i r_i \in \mathbb{R}^3.
$$

Let $\widehat{S} := \frac{1}{L}\sum_{i=1}^4 r_i r_i^T \in \mathbb{R}^{3 \times 3}$ be the normalized Steiner inertia tensor ($\operatorname{tr}\widehat{S} = 1, \, \widehat{S} \succeq 0$), let $H := \widehat{S} - \frac{1}{3}I_3$ be its traceless part, and let $\widetilde{H}_2 := H^2 - \frac{1}{3}\operatorname{tr}(H^2)I_3$ be its traceless square.

On any 1D collinear configuration along a unit axis $e_1$, $\widehat{S} = e_1 e_1^T$, so $H U_1 = \frac{2}{3} U_1$ and $\widetilde{H}_2 U_1 = \frac{2}{9} U_1$. Subtracting these collinear limits yields the **Collinear-Cancelled Krylov–Steiner Basis**:

$$
\mathcal{K}_0(P) := U_1(P), \qquad \mathcal{K}_1(P) := \left(H - \frac{2}{3}I_3\right) U_1(P) = (\widehat{S} - I_3) U_1(P), \qquad \mathcal{K}_2(P) := \left(\widetilde{H}_2 - \frac{2}{9}I_3\right) U_1(P),
$$

and the **3-parametric Krylov–Steiner family**:

$$
Z_{\text{KS}}(c_0, c_1, c_2; P) := G + c_0 \mathcal{K}_0(P) + c_1 \mathcal{K}_1(P) + c_2 \mathcal{K}_2(P).
$$

### 3.2 Exact Closed-Form 3D Non-Coplanarity Determinant

In the principal frame of $\widehat{S}$ with eigenvalues $\sigma_1, \sigma_2, \sigma_3$ ($\sigma_1 + \sigma_2 + \sigma_3 = 1$), the transition between $(U_1, H U_1, \widetilde{H}_2 U_1)$ and $(\mathcal{K}_0, \mathcal{K}_1, \mathcal{K}_2)$ is unit upper-triangular, so the $3 \times 3$ Vandermonde determinant in $(\sigma_1, \sigma_2, \sigma_3)$ gives:

$$
\boxed{\left|\det\bigl[\mathcal{K}_0(P), \, \mathcal{K}_1(P), \, \mathcal{K}_2(P)\bigr]\right| = \bigl|(U_1)_1 (U_1)_2 (U_1)_3 (\sigma_1 - \sigma_2)(\sigma_2 - \sigma_3)(\sigma_3 - \sigma_1)\bigr|.}
$$

### 3.3 Exact Vertex Jacobians and Exact $\mathbb{Q}(\sqrt{6})$ Spectral Thresholds

Differentiating $U_1, HK, \widetilde{H}_2 K$ with respect to vertex $p_1$ (labeled $i=0$) yields the exact closed-form $3 \times 3$ vertex Jacobian:

$$
D_0 U_1 = \delta_0 I_3 + \frac{2}{L} r_0 r_0^T - \frac{1}{2}\widehat{S} - \frac{2}{L} U_1 r_0^T, \qquad \operatorname{Sym}(D_0 U_1) = \delta_0 I_3 + \frac{2}{L} r_0 r_0^T - \frac{1}{2}\widehat{S} - \frac{1}{L}\bigl(U_1 r_0^T + r_0 U_1^T\bigr).
$$

**Theorem 3.1 (Exact Global Spectral Range of** $U_1, U_2, HK, \widetilde{H}_2 K$ **in** $\mathbb{Q}(\sqrt{6})$**):**
For any unit vector $e \in S^2$, letting $x_i = (r_i \cdot e)/\sqrt{L}$ and $w_i = \rho_i - x_i^2 \ge 0$, the Rayleigh quotient $e^T (\operatorname{Sym} D_0 U_1) e$ is affine linear in $w = (w_0, w_1, w_2, w_3)$:

$$
e^T (\operatorname{Sym} D_0 U_1) e = 3 x_0^2 - \frac{1}{4} - \frac{1}{2}\sum_{i=0}^3 x_i^2 - 2 x_0 \sum_{i=0}^3 x_i^3 + (1 - 2 x_0^2) w_0 - 2 x_0 \sum_{i=1}^3 x_i w_i,
$$

and attains its global extrema over all configurations $P \in (\mathbb{R}^3)^4$ on the 1D collinear boundary ($w_i = 0$) with two equal passive coordinates ($x_1 = x_2 = -\frac{1}{3}x_0 + \frac{\sin\theta}{\sqrt{6}}, \; x_3 = -\frac{1}{3}x_0 - \frac{2\sin\theta}{\sqrt{6}}, \; x_0 = \frac{\sqrt{3}}{2}\cos\theta$). Setting $t = \cot\theta$, the stationary equation factors over $\mathbb{Q}(\sqrt{2})$ as

$$
5t^3 + 3\sqrt{2}t^2 - 15t - \sqrt{2} = (t - \sqrt{2})\bigl(5t^2 + 8\sqrt{2}t + 1\bigr) = 0,
$$

yielding the **exact global eigenvalue bounds**:

$$
\boxed{-\frac{3 + 9\sqrt{6}}{32} \le \lambda\bigl(\operatorname{Sym} D_i U_1(P)\bigr) \le \frac{3}{4} \qquad \left(-\frac{3 + 9\sqrt{6}}{32} \approx -0.782668990158\right),}
$$

and hence the **exact maximal globally attractive ray interval** for $G + c_0 \mathcal{K}_0$:

$$
\boxed{c_0 \in \left[-\frac{1}{3}, \; \frac{8(3\sqrt{6} - 1)}{159}\right] \approx [-0.33333333, \; +0.31941984].}
$$

## 4. Family III: The 3-Parametric Radial–Vandermonde Covariant Family $Z_{\text{VM}}(a_1, a_2, a_3)$

By the $S_4$ generalization of Theorem 5.1 (`thm:covmodule`) of Paper IV, every zero-sum $S_4$-equivariant polynomial in $(\rho_1, \rho_2, \rho_3, \rho_4)$ is generated over $\mathbb{R}[e_2(\delta), e_3(\delta), e_4(\delta)]$ by $v_i^{(m)} = \delta_i^m - \frac{1}{4}\sum_{j=1}^4 \delta_j^m$ ($m=1,2,3$). Subtracting the 3-to-1 vertex-collision ratios yields the **Collision-Cancelled Radial–Vandermonde Basis**:

$$
\mathcal{V}_1(P) := U_1(P), \qquad \mathcal{V}_2(P) := U_2(P) - \frac{1}{3}U_1(P), \qquad \mathcal{V}_3(P) := U_3(P) - \frac{7}{36}U_1(P),
$$

with exact Cauchy–Binet Vandermonde determinant:

$$
\boxed{\det\bigl[\mathcal{V}_1(P), \, \mathcal{V}_2(P), \, \mathcal{V}_3(P)\bigr] = \det\bigl[U_1(P), \, U_2(P), \, U_3(P)\bigr] = \frac{3}{2}\,\operatorname{Vol}(P) \prod_{1 \le i < j \le 4} (\rho_j - \rho_i).}
$$

## 5. Family IV: The 3-Parametric Hybrid Steiner–Vandermonde Family $Z_{\text{SV}}(b_1, b_2, b_3)$

Combining $\mathcal{K}_0 = U_1$, $\mathcal{K}_1 = (\widehat{S} - I_3) U_1$, and $\mathcal{V}_2 = U_2 - \frac{1}{3}U_1$ defines the **Hybrid Steiner–Vandermonde family**:

$$
Z_{\text{SV}}(b_1, b_2, b_3; P) := G + b_1 \mathcal{K}_0(P) + b_2 \mathcal{K}_1(P) + b_3 \mathcal{V}_2(P),
$$

which avoids both the $\sigma_1 = \sigma_2$ rank drop of Family II and the $\rho_i = \rho_j$ rank drop of Family III.

## 6. Family V: The Collinear-Immune Steiner-Modulated Family $Z_{\text{mod}}(d_0, d_1, d_2, d_3)$ and Syzygy Rays `T1`–`T8`

Define the **collinear-vanishing 3D Steiner invariant**:

$$
\tilde{q}_3(P) := 1 - \operatorname{tr}(\widehat{S}^2) = \frac{2}{3} - \operatorname{tr}(H^2) = 2(\sigma_1 \sigma_2 + \sigma_2 \sigma_3 + \sigma_3 \sigma_1) \in \left[0, \, \frac{2}{3}\right].
$$

**Theorem 6.1 (Second-Order Collinear Vanishing & Exact Collinear Immunity):**
Because $\tilde{q}_3(P) \ge 0$ attains its global minimum $0$ on the entire 1D collinear stratum ($\sigma_1 = 1, \sigma_2 = \sigma_3 = 0$), both $\tilde{q}_3(P) = 0$ and its vertex gradient

$$
\nabla_{p_0}\tilde{q}_3(P) = -\frac{4}{L}\bigl(\widehat{S} r_0 - \operatorname{tr}(\widehat{S}^2) r_0\bigr)
$$

vanish identically on every 1D collinear configuration (where $\widehat{S} r_0 = r_0$ and $\operatorname{tr}(\widehat{S}^2) = 1$). Consequently, for every base covariant $W \in \{U_1, HK, U_2, \widetilde{H}_2 K, \mathcal{V}_2, \mathcal{K}_1\}$, the modulated vector field $\mathcal{M}_W(P) := \tilde{q}_3(P) W(P)$ has **identically zero value and identically zero vertex Jacobian** on the entire 1D collinear stratum:

$$
D_0\bigl(\tilde{q}_3 W\bigr) = \tilde{q}_3 D_0 W + W (\nabla_{p_0}\tilde{q}_3)^T \equiv 0 \qquad \text{on all 1D collinear configurations.}
$$

This expands the globally attractive ray intervals by **$2.7\times$ to $6.2\times$**:
* $\mathcal{M}_0 := \tilde{q}_3 U_1$: $d_0 \in [-0.8826, \, +0.9373]$ (vs $[-\frac{1}{3}, 0.3194]$ for $U_1$),
* $\mathcal{M}_1 := \tilde{q}_3 H U_1$: $d_1 \in [-2.0159, \, +2.3682]$ (vs $[-\frac{1}{2}, 0.4791]$ for $H U_1$),
* $\mathcal{M}_2 := \tilde{q}_3 U_2$: $d_2 \in [-3.9318, \, +4.3120]$ (vs $[-1, 0.9583]$ for $U_2$),
* $\mathcal{M}_3 := \tilde{q}_3 \widetilde{H}_2 U_1$: $d_3 \in [-7.4323, \, +9.0382]$ (vs $[-\frac{3}{2}, 1.4374]$ for $\widetilde{H}_2 U_1$).

Furthermore, combining the collinear-cancelled and $\tilde{q}_3$-modulated generators along the syzygy-coupled multi-generator rays `T1`–`T8` (e.g., `T1` $= 1.019667\,\mathcal{K}_1 - 1.529501\,\mathcal{V}_2 + 1.019667\,\mathcal{K}_2$ and `T5` $= 0.840559\,\mathcal{K}_1 - 2.101399\,\mathcal{K}_2 + 3.082051\,\mathcal{V}_3$, which exceed the individual coordinate bounds simultaneously by cancelling the planar stellar bottleneck $\mathcal{K}_1 = 3\mathcal{V}_2$) expands the rational 3D Heart volume to **$18.66\times \operatorname{conv}(M_p)$** and the combined 3D Heart volume to **$24.88\times \operatorname{conv}(M_p)$** on Scalene Tetrahedron 2.

## 7. Coplanar 4-Point Hearts and the Centroid-Augmented Triangle $(A, B, C, G_{ABC})$

### 7.1 What Is the Heart of 4 Coplanar Points $(A, B, C, D)$?

When $P = (A, B, C, D)$ lies in an affine plane $\Pi \subset \mathbb{R}^3$:
1. **Planar Confinement & Radon Dichotomy:** Reflection equivariance across $\Pi$ ($R_\Pi(P) = P \implies R_\Pi(Z(P)) = Z(P)$) forces $\mathcal{H}_4(A, B, C, D) \subset \operatorname{conv}(A, B, C, D) \subset \Pi$. By Radon's theorem in $\mathbb{R}^2$, the configuration falls into either the **convex quadrilateral regime** ($A, B, C, D$ in convex position) or the **stellar $(3+1)$ regime** ($D \in \operatorname{conv}(A, B, C)$, where $\operatorname{conv}(A, B, C, D) = \triangle ABC$).
2. **Stellar Surface-Measure Doubling Theorem ($D \in \triangle ABC$):** Whenever $D \in \triangle ABC$, the three sub-triangles $\triangle DBC, \, \triangle ADC, \, \triangle ABD$ form a stellar triangulation of $\triangle ABC$ whose disjoint interiors sum to $\operatorname{Area}(\triangle ABC)$. Consequently, the 2-skeleton (surface) measure of the four faces of the degenerate tetrahedron $ABCD$ is **identically twice the uniform 2D area measure of $\triangle ABC$**, independent of the position of $D \in \triangle ABC$:

   $$
   \mu_{\partial(ABCD)} = \mu_{\triangle ABC} + \bigl(\mu_{\triangle DBC} + \mu_{\triangle ADC} + \mu_{\triangle ABD}\bigr) = 2\,\mu_{\triangle ABC}.
   $$

   In particular, for every $p > 1$, the 2-skeleton hull-power minimizer of $ABCD$ on the stellar locus $D \in \triangle ABC$ coincides identically with the 2D solid-triangle hull-power minimizer of $\triangle ABC$.
3. **Coplanar Cayley–Hamilton Reduction:** On $\Pi$, the third eigenvalue of $\widehat{S}_4$ is $\sigma_3 = 0$ and $\sigma_1 + \sigma_2 = 1$, so $(\widehat{S}_4\big|_\Pi)^2 = \widehat{S}_4\big|_\Pi - \sigma_1\sigma_2 I_2$. Consequently, $\mathcal{K}_2$ reduces on every coplanar 4-tuple to an exact combination of $\mathcal{K}_0$ and $\mathcal{K}_1$:

   $$
   \boxed{\mathcal{K}_2(P) = \frac{1}{3}\mathcal{K}_1(P) + \left(\frac{\operatorname{tr}(H^2)}{6} - \frac{1}{9}\right)\mathcal{K}_0(P).}
   $$

   Meanwhile, $(\mathcal{K}_0, \mathcal{K}_1)$, $(\mathcal{V}_1, \mathcal{V}_2)$, and $(\mathcal{K}_0, \mathcal{V}_2)$ remain **full rank 2** across $\Pi$.

### 7.2 Theorem 7.1 (Universal Subset Inclusion $\mathcal{H}_4(A, B, C, G_{ABC}) \subseteq \mathcal{H}_3(A, B, C)$)

Let $A, B, C \in \mathbb{R}^d$ be any triangle with centroid $G_{ABC} = \frac{A + B + C}{3}$. For every regularity class $\mathcal{A} \in \{\mathcal{A}^{\text{fr}}, \mathcal{A}^0, \mathcal{A}^1, \mathcal{A}^\infty, \mathcal{A}^\omega\}$, if $Z \in \mathcal{A}_{4, d}$ is a globally attractive 4-point center, then the pullback map

$$
\widetilde{Z}(A, B, C) := Z\left(A, \, B, \, C, \, \frac{A + B + C}{3}\right)
$$

is a globally attractive, $S_3$-invariant, similarity-equivariant 3-point center ($\widetilde{Z} \in \mathcal{A}_{3, d}$). Consequently,

$$
\boxed{\mathcal{H}_4\bigl(A, \, B, \, C, \, G_{ABC}\bigr) \subseteq \mathcal{H}_3(A, \, B, \, C).}
$$

**Proof (Both Finite-Displacement and Infinitesimal Jacobian):**
1. *Invariance and similarity equivariance:* Since $G_{ABC}$ is $S_3$-symmetric and affine with unit weight sum, $T(G_{ABC}) = G_{TA, TB, TC}$ for every similarity $T$, and every $\sigma \in S_3 \subset S_4$ fixing slot $4$ preserves $(A, B, C, G_{ABC})$.
2. *Finite-displacement attractivity (requiring no differentiability):* Fix $B, C$ and displace $A$ to $A' = A + u$. Then $G_{ABC}$ moves to $G' = G_{ABC} + \frac{1}{3}u$ in the **exact same direction** $u$. Factor $(A, B, C, G_{ABC}) \to (A', B, C, G')$ into two single-vertex moves in $(\mathbb{R}^d)^4$:
   * *Step 1 (move slot 1 from $A$ to $A' = A + u$):* Attractivity of $Z$ in slot 1 gives $\langle Z(A', B, C, G_{ABC}) - Z(A, B, C, G_{ABC}), \, u \rangle \ge 0$.
   * *Step 2 (move slot 4 from $G_{ABC}$ to $G' = G_{ABC} + \frac{1}{3}u$):* Attractivity of $Z$ in slot 4 gives $\langle Z(A', B, C, G') - Z(A', B, C, G_{ABC}), \, \frac{1}{3}u \rangle \ge 0$, hence $\langle Z(A', B, C, G') - Z(A', B, C, G_{ABC}), \, u \rangle \ge 0$.

   Summing Steps 1 and 2 telescopes the intermediate state $Z(A', B, C, G_{ABC})$ and yields $\langle \widetilde{Z}(A', B, C) - \widetilde{Z}(A, B, C), \, A' - A \rangle \ge 0$.
3. *Infinitesimal ($C^1$) Jacobian attractivity:* Since $\frac{\partial G_{ABC}}{\partial A} = \frac{1}{3}I_d$, the chain rule gives

   $$
   D_A \widetilde{Z}(A, B, C) = D_1 Z(A, B, C, G_{ABC}) + \frac{1}{3} D_4 Z(A, B, C, G_{ABC}) \implies \operatorname{Sym} D_A \widetilde{Z} = \operatorname{Sym} D_1 Z + \frac{1}{3}\operatorname{Sym} D_4 Z \succeq 0. \quad \square
   $$

*(Remark: $G_{ABC}$ is the **unique** $S_3$-invariant 3-point center for which $\frac{\partial D}{\partial A}$ is a positive scalar multiple of $I_d$ and $\delta D \parallel \delta A$ for every displacement $\delta A$; for any other center $M(A,B,C)$, $D_4 Z \cdot D_A M$ is a product of non-commuting matrices whose symmetric part need not be PSD.)*

### 7.3 Theorem 7.2 (Strictness $\mathcal{H}_4(A, B, C, G_{ABC}) \subsetneq \mathcal{H}_3(A, B, C)$ via the Parallelogram Bimedian Chest & Slope Contraction)

The inclusion $\mathcal{H}_4(A, B, C, G_{ABC}) \subsetneq \mathcal{H}_3(A, B, C)$ is **strict** for two independent reasons:

1. **Global Parallelogram Bimedian Chest Separation (Valid Even for Unrestricted $\mathcal{A}_4^{\text{fr}}$):**
   Because $Z(A, B, C, D)$ must be invariant under all $24$ permutations of $S_4$ (including transpositions swapping $D$ with $A, B, C$) and attractive when a single vertex moves with $D$ held fixed, any 3 vertices $(p_i, p_j, p_k)$ can be completed to a centrally symmetric **parallelogram** by moving $p_l$ to $p_l' := p_i + p_j - p_k$, where central inversion $(i \, j)(k \, l) \in S_4$ forces $Z(p_i, p_j, p_k, p_l') = \frac{p_i + p_j}{2}$. On the isosceles triangle $T_h = \{A=(0,h), \, B=(-1,0), \, C=(1,0)\}$ with $D = G_{ABC} = (0, h/3)$:
   * Moving $B=(-1,0)$ to $B' = C + D - A = (1, -2h/3)$ forms a parallelogram centered at $\frac{C+D}{2} = (\frac{1}{2}, \frac{h}{6})$ with displacement $B - B' = (-2, \frac{2}{3}h)$, forcing:

     $$
     \left\langle \left(-2, \, \frac{2}{3}h\right), \; \left(-\frac{1}{2}, \, y - \frac{h}{6}\right) \right\rangle \ge 0 \quad \Longleftrightarrow \quad \boxed{y_Z\bigl(A, B, C, G_{ABC}\bigr) \ge \frac{h}{6} - \frac{3}{2h}.}
     $$

   * Moving $C=(1,0)$ to $C' = A + D - B = (1, 4h/3)$ and $D=(0,h/3)$ to $D' = A + B - C = (-2, h)$ similarly forces $y_Z(A, B, C, G_{ABC}) \le \min\bigl(\frac{2}{3}h, \, \frac{h}{2} + \frac{3}{2h}\bigr)$.

   Meanwhile, the 3-point incenter $X(1) \in \mathcal{H}_3^\omega(T_h)$ has $y_{X(1)}(h) = \frac{h}{1 + \sqrt{1+h^2}} < 1$. For all $h > \sqrt{21 + 6\sqrt{13}} \approx 6.529419$ (e.g., $h = 7$, where $y_{X(1)}(7) \approx 0.8673 < \frac{20}{21} \approx 0.9524 \le y_Z$), $X(1) \in \mathcal{H}_3^\omega(T_h) \setminus \mathcal{C}_4^{\text{fr}}(A, B, C, G_{ABC})$.

2. **Near-Equilateral Slope Contraction:**
   At $P_{\text{eq}} = (A_{\text{eq}}, B_{\text{eq}}, C_{\text{eq}}, G_{\text{eq}})$, $S_3$ symmetry forces $D_4 Z(P_{\text{eq}}) = \alpha_4 I_2$ with $\alpha_4 \ge 0$. Since $D_A \widetilde{Z} = D_1 Z + \frac{\alpha_4}{3}I_2$ has eigenvalues $\frac{1}{3} \pm \frac{\kappa}{2}$, positive semidefiniteness of $\operatorname{Sym} D_1 Z(P_{\text{eq}})$ forces the near-equilateral slope $\kappa$ of $\widetilde{Z}$ to satisfy:

   $$
   \boxed{|\kappa(\widetilde{Z})| \le \frac{2}{3}(1 - \alpha_4),}
   $$

   strictly contracting Paper IV's 3-point slope bound $|\kappa| \le \frac{2}{3}$ whenever $\alpha_4 > 0$.

### 7.4 Theorem 7.3 (Exact Reduction Dictionary and Syzygies at $D = G_{ABC}$)

On $P_G = (A, B, C, G_{ABC})$, since $r_4 = 0$ and $\rho_i = \frac{2}{3} - s_i$ ($i=1,2,3$), all 4-point covariants reduce in closed form to the 2D triangle covariants $K_\triangle, H_\triangle K_\triangle,$ and $q_\triangle = \frac{3}{2}\sum_{i=1}^3(s_i - 1/3)^2$:

$$
\begin{aligned}
\mathcal{K}_0(A, B, C, G_{ABC}) &= -K_\triangle, &
\mathcal{V}_2(A, B, C, G_{ABC}) &= \frac{1}{6}K_\triangle - \frac{1}{6}H_\triangle K_\triangle, \\
\mathcal{K}_1(A, B, C, G_{ABC}) &= 3\mathcal{V}_2 = \frac{1}{2}K_\triangle - \frac{1}{2}H_\triangle K_\triangle, &
\tilde{q}_3(A, B, C, G_{ABC}) &= \frac{1}{2} - 2q_\triangle = 2\tilde{q}_\triangle, \\
\mathcal{K}_2(A, B, C, G_{ABC}) &= \frac{3 - 4q_\triangle}{12}K_\triangle - \frac{1}{6}H_\triangle K_\triangle, &
\mathcal{V}_3(A, B, C, G_{ABC}) &= \frac{25 - 48q_\triangle}{144}K_\triangle - \frac{1}{24}H_\triangle K_\triangle.
\end{aligned}
$$

Consequently, the three linearly independent 3D covariants

$$
\mathcal{S}_1 := \mathcal{K}_1 - 3\mathcal{V}_2, \qquad \mathcal{S}_2 := \mathcal{K}_2 - \mathcal{V}_2 + \frac{1}{6}\mathcal{M}_0, \qquad \mathcal{S}_3 := \mathcal{V}_3 - \frac{1}{4}\mathcal{V}_2 + \frac{7}{144}\mathcal{K}_0 + \frac{1}{6}\mathcal{M}_0
$$

**vanish identically on every centroid-augmented triangle $(A, B, C, G_{ABC})$** while remaining linearly independent in 3D on scalene tetrahedra.

## 8. Summary Comparison of the Five 3-Parametric Families

| Family | Explicit Formula $Z(\theta; P)$ | Certified Parameter Domain $\Omega$ | 3D Volume on $P_{\text{III}}$ | 3D Volume on $P_{\text{scalene},2}$ |
| :--- | :--- | :--- | :--- | :--- |
| **Baseline (1D Curve)** | Vertex Power $M_p(P)$ | $p \in [4 - 2\sqrt{2}, \, 4 + 2\sqrt{2}]$ | $2.3257 \times 10^{-4}$ ($1.00\times$) | $7.0493 \times 10^{-5}$ ($1.00\times$) |
| **Family I (`Skeletal-Constellation`)** | $\arg\min_x \Phi_{p;\, w_E, w_F}(x; P)$ | $[4-2\sqrt{2}, 4+2\sqrt{2}] \times \Delta_2$ (**exact, $\delta=0$**) | $6.4725 \times 10^{-4}$ (**$2.78\times$**) | $1.6388 \times 10^{-4}$ (**$2.32\times$**) |
| **Families II–IV (`Krylov / Vandermonde`)** | $G + \sum c_k \mathcal{K}_k + \sum a_m \mathcal{V}_m$ | Octahedron on $\mathcal{K}_0, \mathcal{K}_1, \mathcal{K}_2, \mathcal{V}_2, \mathcal{V}_3$ | $1.8315 \times 10^{-4}$ ($0.79\times$) | $2.5811 \times 10^{-4}$ (**$3.66\times$**) |
| **Families II–V (`+` $\tilde{q}_3$ `& Syzygy Rays`)** | $+\, \tilde{q}_3 \sum d_k W_k + \text{Rays } T_1\text{--}T_8$ | $+\, \mathcal{M}_0\text{--}\mathcal{M}_3, \mathcal{M}_{\mathcal{V}_2}, \mathcal{M}_{\mathcal{K}_1}, T_1\text{--}T_8$ | $2.1474 \times 10^{-4}$ (**$0.92\times$**) | $1.3151 \times 10^{-3}$ (**$18.66\times$**) |
| **Combined Hull (Families I–V + $T_1$–$T_8$)** | $\operatorname{conv}(\text{I} \cup \text{II} \cup \text{III} \cup \text{IV} \cup \text{V} \cup \{T_i\})$ | Joint 3D convex hull in $\mathcal{H}(P)$ | **$2.2724 \times 10^{-3}$ ($9.77\times$)** | **$1.7540 \times 10^{-3}$ ($24.88\times$)** |

### 7.5 Theorem 7.4 (Uniqueness of the Centroid for Pullback Attractivity & Explicit Counterexamples for $D \in \mathcal{H}_3(A, B, C) \setminus \{G_{ABC}\}$)

A natural question is whether Theorem 7.1 still holds if the fourth point $D = G_{ABC}$ is replaced by **any** attractive triangle center $D = M(A, B, C) \in \mathcal{H}_3(A, B, C)$ other than the centroid. The answer is **no**: the centroid $G_{ABC}$ is the **unique** $S_3$-invariant 3-point center for which the composite pullback $\widetilde{Z}(A, B, C) := Z(A, B, C, M(A, B, C))$ is guaranteed to remain an attractive center of $\triangle ABC$ for all $Z \in \mathcal{A}_4$.

#### 1. Why the Proof Fails for Every $M(A, B, C) \neq G_{ABC}$ (Uniqueness of Isotropic Pullback)

For a general differentiable 3-point center $M: (\mathbb{R}^d)^3 \to \mathbb{R}^d$ ($d \ge 2$) and any 4-point center $Z \in \mathcal{A}_{4, d}^1$, the chain rule gives the vertex Jacobian of $\widetilde{Z}(A, B, C) := Z(A, B, C, M(A, B, C))$ with respect to vertex $A$:

$$
D_A \widetilde{Z}(A, B, C) = D_1 Z\bigl(A, B, C, M(A, B, C)\bigr) + D_4 Z\bigl(A, B, C, M(A, B, C)\bigr)\,D_A M(A, B, C).
$$

* **Why $M = G_{ABC}$ is unique:** In dimension $d \ge 2$, if a $C^2$ vector field $F: \mathbb{R}^d \to \mathbb{R}^d$ has isotropic Jacobian $DF(x) = \lambda(x) I_d$, Schwarz's mixed-partials theorem forces $\frac{\partial \lambda}{\partial x_j} = \frac{\partial^2 F_i}{\partial x_j \partial x_i} = \frac{\partial^2 F_i}{\partial x_i^2}\delta_{ij} = 0$ for all $j \neq i$, so $\lambda$ is constant. Applying this to $A \mapsto M(A, B, C)$, $B \mapsto M(A, B, C)$, and $C \mapsto M(A, B, C)$ together with translation equivariance ($D_A M + D_B M + D_C M = I_d$) and $S_3$ symmetry proves that **$G_{ABC} = \frac{A+B+C}{3}$ is the unique $S_3$-invariant center whose vertex Jacobians are scalar multiples of $I_d$** ($D_A G_{ABC} = \frac{1}{3}I_d$).
* **Non-commuting PSD matrix product for $M \neq G_{ABC}$:** Whenever $M \neq G_{ABC}$, $D_A M(A, B, C)$ is anisotropic on generic triangles, and a finite displacement $\delta A = A' - A$ causes $D = M(A, B, C)$ to move in a **skewed direction** $\delta D = M(A', B, C) - M(A, B, C) \nparallel \delta A$. Even when $P := D_4 Z \succeq 0$ and $Q := D_A M \succeq 0$ are both symmetric positive definite $2 \times 2$ matrices, the symmetric part of their product $\operatorname{Sym}(PQ) = \frac{1}{2}(PQ + QP)$ has a **strictly negative determinant and strictly negative minimum eigenvalue** whenever their principal axes are misaligned by angle $\theta$ and their condition numbers satisfy $(1 - \varepsilon_P)(1 - \varepsilon_Q)|\sin 2\theta| > 4\sqrt{\varepsilon_P \varepsilon_Q}$. When $\operatorname{Sym}(D_1 Z)$ is small along that negative eigendirection, $\operatorname{Sym} D_A \widetilde{Z}$ acquires a strictly negative eigenvalue and $\widetilde{Z}$ moves **backwards** against $\delta A$ ($\langle \Delta \widetilde{Z}, \Delta A \rangle < 0$).

#### 2. Explicit Counterexample 1 (Canonical 3-Point Power Center $D = M_{p_-}^{(3)}$ + 4-Point Power Center $Z = M_{p_+}^{(4)}$)

Let $p_- = 4 - 2\sqrt{2} \approx 1.171572875$ and $p_+ = 4 + 2\sqrt{2} \approx 6.828427125$ be the exact endpoints of the universal power-center interval (Paper III, Theorem 4.1). Choose:
* $D(A, B, C) := M_{p_-}^{(3)}(A, B, C) = \arg\min_{x \in \mathbb{R}^2} \sum_{i=1}^3 \frac{1}{p_-}\|x - p_i\|^{p_-} \in \mathcal{H}_3^\omega(A, B, C)$,
* $Z(A, B, C, D) := M_{p_+}^{(4)}(A, B, C, D) = \arg\min_{x \in \mathbb{R}^2} \sum_{i=1}^4 \frac{1}{p_+}\|x - p_i\|^{p_+} \in \mathcal{A}_4^\omega$.

Evaluate the composite map $\widetilde{Z}(A, B, C) := Z\bigl(A, B, C, D(A, B, C)\bigr)$ on the rational triangle

$$
A = \left(\frac{5}{16}, \, \frac{7}{20}\right) = (0.3125, \, 0.35), \qquad B = (-1, \, 0), \qquad C = (1, \, 0).
$$

In 50-digit arithmetic (`verify_tetrahedron_3param_families.py`):
1. **Interior positions:**
   $$D = (0.298670767043600, \; 0.292626985430254) \in \mathcal{H}_3^\omega(A, B, C), \qquad \widetilde{Z}(A, B, C) = (0.001012356606327, \; 0.006217287001708).$$
2. **Infinitesimal attractivity failure ($\operatorname{Sym} D_A \widetilde{Z} \nsucceq 0$):**
   The symmetric part of the pullback Jacobian $D_A \widetilde{Z} = D_1 Z + D_4 Z \cdot D_A M_{p_-}^{(3)}$ is

   $$
   \operatorname{Sym} D_A \widetilde{Z}(A, B, C) = \begin{pmatrix} 0.011056609493 & -0.009128547597 \\ -0.009128547597 & 0.006181629258 \end{pmatrix},
   $$

   which has **strictly negative determinant and strictly negative minimum eigenvalue**:

   $$
   \det\bigl(\operatorname{Sym} D_A \widetilde{Z}(A, B, C)\bigr) = -1.498565954305 \times 10^{-5} < 0, \qquad \boxed{\lambda_{\min}\bigl(\operatorname{Sym} D_A \widetilde{Z}(A, B, C)\bigr) = -2.448746542031 \times 10^{-4} < 0.}
   $$

3. **Finite-displacement attractivity failure ($\widetilde{Z} \notin \mathcal{A}_3^{\text{fr}}$):**
   Displacing vertex $A$ along the unit negative eigenvector $u_{\min} = (0.5877787026, \, 0.8090217530)$ by $\delta = 10^{-3}$ to $A' = A + \delta u_{\min}$ (with $B, C$ fixed) yields:

   $$
   \boxed{\bigl\langle \widetilde{Z}(A', B, C) - \widetilde{Z}(A, B, C), \; A' - A \bigr\rangle = -2.466310034789 \times 10^{-10} < 0.}
   $$

#### 3. Explicit Counterexample 2 (Closed-Form Rational Triangle Center $D = R_5^*$ + 4-Point Power Center $Z = M_{p_-}^{(4)}$)

To avoid solving an optimization problem for $D$, take the exact zero-backoff certified rational polynomial triangle center $D(A, B, C) := R_5^*(A, B, C) = G_{ABC} + \frac{3040}{3113}\bigl[(\frac{9}{20} + \frac{6}{5}q_\triangle)K_\triangle + (-\frac{8}{5} + \frac{13}{5}q_\triangle)H_\triangle K_\triangle\bigr] \in \mathcal{H}_3^\omega(A, B, C)$ and $Z := M_{p_-}^{(4)} \in \mathcal{A}_4^\omega$ ($p_- = 4 - 2\sqrt{2}$) on the simple acute rational triangle

$$
A = \left(\frac{1}{2}, \, 1\right), \qquad B = (-1, \, 0), \qquad C = (1, \, 0),
$$

which has rational normalized squared sides $s = (\frac{8}{17}, \, \frac{5}{34}, \, \frac{13}{34})$ and $q_\triangle = \frac{189}{2312}$. Then:
* $D = R_5^*(A, B, C) = (0.069406090673652, \; 0.408702475138741) \in \mathcal{H}_3^\omega(A, B, C)$,
* $\widetilde{Z}(A, B, C) = (0.086064594641030, \; 0.408859755088740)$,
* $\det\bigl(\operatorname{Sym} D_A \widetilde{Z}(A, B, C)\bigr) = -1.567163989921 \times 10^{-4} < 0$ and $\boxed{\lambda_{\min}\bigl(\operatorname{Sym} D_A \widetilde{Z}(A, B, C)\bigr) = -4.025105532815 \times 10^{-4} < 0}$ (reaching $-3.435766546377 \times 10^{-3}$ at $A = (\frac{19}{40}, \frac{47}{50})$),
* And a finite step $A' = A + 10^{-3}u_{\min}$ gives $\bigl\langle \widetilde{Z}(A', B, C) - \widetilde{Z}(A, B, C), \; A' - A \bigr\rangle = -4.495874118502 \times 10^{-10} < 0$.

#### 4. Why 1-Step Reflection Chest Half-Planes Still Hold Pointwise While Pullback Attractivity Fails

Interestingly, if one fixes a triangle $\triangle ABC$ and a point $D \in \mathcal{C}_3^{(1),\text{refl}}(A, B, C)$ in the **1-step reflection Chest** (defined by single-vertex orthogonal projections $p_i \to p_i' = \operatorname{proj}_L(p_i)$ onto a symmetry line $L$ of $(p_i', p_j, p_k)$, such as the perpendicular bisector $L_{jk}$ or altitude $L_j$), then **every** $Z(A, B, C, D) \in \mathcal{H}_4^{\text{fr}}(A, B, C, D)$ still satisfies that 1-step reflection half-plane $\langle Z(A, B, C, D) - p_i', \, p_i - p_i' \rangle \ge 0$: projecting $p_i \to \operatorname{proj}_L(p_i)$ and $D \to \operatorname{proj}_L(D)$ moves both vertices along the **same normal direction** $n \perp L$, and $(p_i', p_j, p_k, \operatorname{proj}_L(D))$ is reflection-symmetric across $L$. The breakdown occurs specifically for **non-collinear coupled displacements** (where $\delta D = D_A M \cdot \delta A \nparallel \delta A$), which destroys the attractivity of $\widetilde{Z}(A, B, C) = Z(A, B, C, M(A, B, C))$ as a 3-point center.

### 7.6 Theorem 7.5 (Certified 4-Point Chest Subset of the Standard Triangle Chest: $\mathcal{C}_4(A, B, C, G_{ABC}) \subseteq \mathcal{C}_{\rm std}(ABC)$)

In *Attractive Centers I* (Section 7, Definition 7.3), the **standard chest** of a nondegenerate triangle $\triangle ABC$ is defined in the finite symmetry–displacement certificate calculus $\mathfrak{G}_{\rm fin}$ as the intersection of 12 half-planes:

$$
\mathcal{C}_{\rm std}(ABC) := \operatorname{conv}\{A, B, C\} \cap \operatorname{CP}(ABC) \cap \operatorname{CNT}(ABC),
$$

where $\operatorname{CP}(ABC) = \mathcal{S}_a \cap \mathcal{S}_b \cap \mathcal{S}_c$ is the **characteristic parallelogram** (bounded by the 3 perpendicular bisectors and the 3 altitude lines) and $\operatorname{CNT}(ABC)$ is the **internal characteristic Napoleon triangle** (bounded by the 3 equilateral-completion half-planes $(C - C_0)\cdot(x - N_c) \ge 0$ and cyclically, with $C_0 = A + R_{60}(B - A)$ and $N_c = \frac{A+B+C_0}{3}$).

In Section 9.3 of *Attractive Centers I*, the 4-point configuration $P_G = (A, B, C, D)$ with $D = G_{ABC} = (\frac{26}{3}, 4)$ on the $13$–$20$–$21$ triangle $A=(0,0), \, B=(21,0), \, C=(5,12)$ was analyzed using parallelogram strips ($58.4105\%$), useful pair-bisectors ($21.2397\%$), and a 48-scenario two-order network ($30.8008\%$), whose combined intersection had area $16.90001251$ ($13.4127\%$ of $\triangle ABC$)—larger than $\mathcal{C}_{\rm std}(ABC)$ ($7.472040$, or $5.9302\%$).

We now prove that in the **exact primitive symmetry–displacement calculus of Paper I** (Definition 6.2 and Corollary 5.2, *Parallel restoration*), there exists an explicit finite 4-point certificate $\Gamma_{\rm std}^{(4)} \in \mathfrak{G}_{\rm fin}$ for $(A, B, C, G_{ABC})$ whose certified chest satisfies

$$
\boxed{\mathcal{C}_{\Gamma_{\rm std}^{(4)}}\bigl(A, B, C, G_{ABC}\bigr) = \mathcal{C}_{\rm std}(ABC),}
$$

and that intersecting $\Gamma_{\rm std}^{(4)}$ with the $S_4$ parallelogram-strip/bimedian certificates yields a certified 4-point chest $\mathcal{C}_4^{\text{aug}}(A, B, C, G_{ABC}) \subseteq \mathcal{C}_{\rm std}(ABC)$ that is even a **strict subset** of $\mathcal{C}_{\rm std}(ABC)$ on elongated triangles.

#### Proof 1: Explicit 2-Step Parallel-Restoration Certificates for All 12 Half-Planes of $\mathcal{C}_{\rm std}(ABC)$

Let $P_G = (A, B, C, D)$ with $D = G_{ABC} = \frac{A + B + C}{3}$, and let $Z \in \mathcal{A}_{4,2}^{\text{fr}}$ be any finite-response attractive 4-point center rule. Every defining half-plane of $\mathcal{C}_{\rm std}(ABC)$ is certified for $Z(A, B, C, D)$ by a 2-step parallel restoration (Corollary 5.2 of Paper I):

1. **Convex Hull $\operatorname{conv}\{A, B, C\}$ (3 half-planes):**
   Since $D = \frac{A+B+C}{3} \in \operatorname{conv}\{A, B, C\}$, Theorem 3.1 of Paper I (*Convex-hull theorem*, Rule `C2`) gives $Z(A, B, C, D) \in \operatorname{conv}\{A, B, C, D\} = \operatorname{conv}\{A, B, C\}$.

2. **Perpendicular-Bisector Half-Planes of $\operatorname{CP}(ABC)$ (3 half-planes):**
   For side $AB$, let $M_c = \frac{A+B}{2}$, $u = B - A$, and let $L_{\text{bis}, c} = \{x \in \mathbb{R}^2 : u \cdot (x - M_c) = 0\}$ be the perpendicular bisector of $AB$. Since $D - M_c = \frac{A+B+C}{3} - \frac{A+B}{2} = \frac{1}{3}(C - M_c)$, we have

   $$
   u \cdot (D - M_c) = \frac{1}{3}\,u \cdot (C - M_c),
   $$

   so $C$ and $D$ always lie in the **same closed half-plane** of $L_{\text{bis}, c}$ (every triangle pair $\{A, B\}, \{B, C\}, \{C, A\}$ is automatically a *useful pair* in the sense of Paper I Section 9.2!). Projecting $C$ and $D$ orthogonally onto $L_{\text{bis}, c}$ forms the predecessor $Q_{\text{bis}, c} = (A, B, C_{\text{bis}}, D_{\text{bis}})$, which is fixed as a multiset by reflection across $L_{\text{bis}, c}$ (swapping $A \leftrightarrow B$ and fixing $C_{\text{bis}}, D_{\text{bis}}$), so Rule `(C1)` forces $u \cdot Z(Q_{\text{bis}, c}) = u \cdot M_c$. Restoring $C_{\text{bis}} \to C$ by $\Delta C = \frac{u \cdot (C - M_c)}{|u|^2}u$ and $D_{\text{bis}} \to D$ by $\Delta D = \frac{1}{3}\Delta C$ uses parallel displacements in the same direction, so Corollary 5.2 of Paper I yields:

   $$
   \operatorname{sgn}\bigl(u \cdot (C - M_c)\bigr)\,u \cdot \bigl(Z(A, B, C, G_{ABC}) - M_c\bigr) \ge 0.
   $$

3. **Altitude-Reflection Half-Planes of $\operatorname{CP}(ABC)$ (3 half-planes — the missing link in Paper I Section 9.3):**
   For side $AB$ with $u = B - A$, let $L_{\text{alt}, C} = \{x \in \mathbb{R}^2 : u \cdot (x - C) = 0\}$ be the altitude line through $C$ perpendicular to $AB$. Define the 4-point predecessor

   $$
   Q_{\text{alt}, C} := \bigl(A', \, B, \, C, \, D'\bigr),
   $$

   where $A' := R_{L_{\text{alt}, C}}(B) = B + 2\frac{u \cdot (C - B)}{|u|^2}u$ is the reflection of $B$ across $L_{\text{alt}, C}$ and $D' := \operatorname{proj}_{L_{\text{alt}, C}}(D) = D + \frac{u \cdot (C - D)}{|u|^2}u \in L_{\text{alt}, C}$ is the orthogonal projection of $D$ onto $L_{\text{alt}, C}$.
   * *Symmetry at $Q_{\text{alt}, C}$ (Rule `C1`):* Reflection across $L_{\text{alt}, C}$ exchanges $A' \leftrightarrow B$ and fixes both $C \in L_{\text{alt}, C}$ and $D' \in L_{\text{alt}, C}$, forcing $Z(Q_{\text{alt}, C}) \in L_{\text{alt}, C}$, i.e., $u \cdot Z(Q_{\text{alt}, C}) = u \cdot C$.
   * *Parallel restoration $Q_{\text{alt}, C} \to (A, B, C, D') \to (A, B, C, D)$ (Rule `C3` & Corollary 5.2):* Since $A + B = 2M_c$ and $C - D = \frac{2}{3}(C - M_c)$, the two restoration vectors $A' \to A$ and $D' \to D$ are

     $$
     \Delta A := A - A' = -\frac{2\,u \cdot (C - M_c)}{|u|^2}u, \qquad \Delta D := D - D' = -\frac{u \cdot (C - D)}{|u|^2}u = -\frac{2}{3}\frac{u \cdot (C - M_c)}{|u|^2}u = \frac{1}{3}\Delta A.
     $$

     Because $\Delta D = \frac{1}{3}\Delta A$ is a **positive scalar multiple of $\Delta A$**, Corollary 5.2 of Paper I telescopes the intermediate center $Z(A, B, C, D')$ and yields the exact altitude half-plane of $\mathcal{S}_c$:

     $$
     -\operatorname{sgn}\bigl(u \cdot (C - M_c)\bigr)\,u \cdot \bigl(Z(A, B, C, G_{ABC}) - C\bigr) \ge 0.
     $$

   Combining (2) and (3) cyclically across all three sides certifies $Z(A, B, C, G_{ABC}) \in \operatorname{CP}(ABC)$.

4. **Internal Characteristic Napoleon Half-Planes of $\operatorname{CNT}(ABC)$ (3 half-planes):**
   For side $AB$ (positively oriented $ABC$), let $C_0 = A + R_{60}(B - A)$ be the internal equilateral apex and $N_c = \frac{A + B + C_0}{3}$ be the centroid of equilateral triangle $ABC_0$. Define the 4-point predecessor

   $$
   Q_{\text{Nap}, c} := \bigl(A, \, B, \, C_0, \, N_c\bigr).
   $$

   * *Symmetry at $Q_{\text{Nap}, c}$ (Rule `C1`):* A $120^\circ$ rotation about $N_c$ cyclically permutes $(A \to B \to C_0 \to A)$ and fixes $N_c$ (permutation $(1 \, 2 \, 3)(4) \in S_4$), uniquely fixing $Z(Q_{\text{Nap}, c}) = N_c$.
   * *Parallel restoration $Q_{\text{Nap}, c} \to (A, B, C, N_c) \to (A, B, C, D)$ (Rule `C3` & Corollary 5.2):* Restoring slot 3 from $C_0$ to $C$ and slot 4 from $N_c = \frac{A+B+C_0}{3}$ to $D = \frac{A+B+C}{3}$ uses the displacements

     $$
     \Delta C := C - C_0, \qquad \Delta D := D - N_c = \frac{A + B + C}{3} - \frac{A + B + C_0}{3} = \frac{1}{3}(C - C_0) = \frac{1}{3}\Delta C.
     $$

     Since $\Delta D = \frac{1}{3}\Delta C$ is a **positive scalar multiple of $\Delta C$**, 2-step parallel restoration (Corollary 5.2) telescopes $Z(A, B, C, N_c)$ and gives

     $$
     (C - C_0) \cdot \bigl(Z(A, B, C, G_{ABC}) - N_c\bigr) \ge 0,
     $$

     and cyclically for $A_0, B_0$, certifying $Z(A, B, C, G_{ABC}) \in \operatorname{CNT}(ABC)$. $\square$

#### Proof 2: General Certificate-Lifting Theorem ($\mathcal{C}_{\rm fin}^{(4)}(A, B, C, G_{ABC}) \subseteq \mathcal{C}_{\rm fin}^{(3)}(ABC) \subseteq \mathcal{C}_{\rm std}(ABC)$)

More generally, **every** finite well-founded 3-point certificate $\Gamma_3 \in \mathfrak{G}_{\rm fin}^{(3)}$ (Definition 6.3 of Paper I) lifts via the centroid embedding $\iota(A, B, C) := (A, B, C, \frac{A+B+C}{3})$ to a finite well-founded 4-point certificate $\iota(\Gamma_3) \in \mathfrak{G}_{\rm fin}^{(4)}$ with $C_{\iota(\Gamma_3)}(A, B, C, G_{ABC}) = C_{\Gamma_3}(ABC)$:
* Every symmetry isometry $g \in E(2)$ fixing a 3-point node $P_v = (A_v, B_v, C_v)$ up to $\sigma \in S_3$ also fixes $G_{P_v} = \frac{A_v+B_v+C_v}{3}$ and thus fixes $\iota(P_v)$ up to $(\sigma, 4) \in S_4$ with the identical fixed subspace $\operatorname{Fix}(g)$.
* Every single-vertex motion edge $P_v \xrightarrow{\Delta p_i = d_{vw}} P_w$ in $\Gamma_3$ lifts to the two-edge parallel chain $\iota(P_v) \xrightarrow{\Delta p_i = d_{vw}} P_{vw}^{\text{mid}} \xrightarrow{\Delta p_4 = \frac{1}{3}d_{vw}} \iota(P_w)$, whose intermediate variable $z_{vw}$ eliminates by Rule `(C4)` to yield $d_{vw} \cdot (x_w - x_v) \ge 0$.

#### Strict Subset $\mathcal{C}_4^{\text{aug}}(A, B, C, G_{ABC}) \subsetneq \mathcal{C}_{\rm std}(ABC)$ and Resolution of the $13$–$20$–$21$ Example

1. **Resolution of the $13$–$20$–$21$ gap in Paper I Section 9.3:**
   In `verify_four_point.py` (Paper I Section 9.3), the useful pair-bisectors `bis` already contained all 3 perpendicular-bisector half-planes of $\operatorname{CP}(ABC)$, and the 48-scenario network `dh` already contained all 3 Napoleon half-planes of $\operatorname{CNT}(ABC)$. Adding the 3 altitude-reflection parallel-restoration half-planes from Step 3 above cuts the $13$–$20$–$21$ four-point chest in exact $\mathbb{Q}(\sqrt{3})$ arithmetic from area **$16.90001251$ ($13.4127\%$)** down to **$7.472040$ ($5.9302\%$)**, matching $\mathcal{C}_{\rm std}(ABC)$ with vertices $(5.96410, 4.55662), \, (10.5, 2.66667), \, (10.5, 4.375), \, (6.28814, 6.12994)$.
2. **Strict subset inclusion on elongated triangles:**
   Defining the augmented 4-point chest $\mathcal{C}_4^{\text{aug}}(A, B, C, G_{ABC}) := \mathcal{C}_{\rm std}(ABC) \cap \mathcal{C}_{\text{bimed}}(A, B, C, G_{ABC})$ (by intersecting $\Gamma_{\rm std}^{(4)}$ with the 1-step $S_4$ parallelogram-bimedian half-planes of Theorem 7.2) gives a certified 4-point chest that is a **strict subset** of $\mathcal{C}_{\rm std}(ABC)$ for every isosceles triangle $T_h = \{A=(0,h), \, B=(-1,0), \, C=(1,0)\}$ with $h > 3\sqrt{3} \approx 5.196152$: on $T_h$ ($h > \sqrt{3}$), $\mathcal{C}_{\rm std}(T_h) = \{0\} \times [\frac{1}{\sqrt{3}}, \frac{h^2-1}{2h}]$, whereas the 4-point bimedian inequality $y \ge \frac{h}{6} - \frac{3}{2h} > \frac{1}{\sqrt{3}}$ strictly slices off the bottom of $\mathcal{C}_{\rm std}(T_h)$ (e.g., at $h = 6$, $\mathcal{C}_4^{\text{aug}}(T_6, G_{T_6}) = \{0\} \times [0.75, 2.916667] \subsetneq [0.577350, 2.916667] = \mathcal{C}_{\rm std}(T_6)$).
