"""Directed interval certificates for two negative composition responses.

Root existence/uniqueness comes from strict convexity. A conservative uniform
Hessian lower bound on the convex rectangle bounds each root's distance from
a rational approximate root by residual/mu. All following calculations use
mpmath.iv interval arithmetic. No finite differences or numerical optimizer.
"""
import json
from pathlib import Path
import mpmath as mp
import sympy as s
from audit_exact import triangle
HERE=Path(__file__).resolve().parent
iv=mp.iv;iv.dps=70
def I(x):return iv.mpf(str(x))
def dot(a,b):return sum((x*y for x,y in zip(a,b)),I(0))
def add(a,b):return [x+y for x,y in zip(a,b)]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def scale(a,c):return [x*c for x in a]
def mm(A,B):return [[sum((A[i][k]*B[k][j] for k in range(2)),I(0)) for j in range(2)] for i in range(2)]
def matadd(A,B):return [[A[i][j]+B[i][j] for j in range(2)] for i in range(2)]
def inverse(A):
    det=A[0][0]*A[1][1]-A[0][1]*A[1][0]
    assert bool(det>I(0)),str(det)
    return [[A[1][1]/det,-A[0][1]/det],[-A[1][0]/det,A[0][0]/det]]
def grad(P,p,z):
    return [sum(((z[j]-a[j])*dot(sub(z,a),sub(z,a))**((p-2)/2) for a in P),I(0)) for j in range(2)]
def rootbox(P,p,center,radius,mu):
    # center is rational decimal, NOT an unchecked solver output.
    for z in P+[center]:
        assert bool(z[0]>=-I(1)) and bool(z[0]<=I(1))
        assert bool(z[1]>=I(0)) and bool(z[1]<=I(1))
    g=grad(P,p,center)
    bound=sum((abs(x) for x in g),I(0))/mu
    assert bool(bound<radius),str(bound)
    box=[x+iv.mpf([-1,1])*radius for x in center]
    return box,{'radius':str(radius),'root_error_bound':str(bound),'gradient':list(map(str,g)),'mu':str(mu)}
def jac(P,p,z):
    mats=[]
    for a in P:
        d=sub(z,a);r2=dot(d,d);assert bool(r2>I(0))
        mats.append([[r2**((p-2)/2)*(I(int(i==j))+(p-2)*d[i]*d[j]/r2) for j in range(2)] for i in range(2)])
    K=[[sum((a[i][j] for a in mats),I(0)) for j in range(2)] for i in range(2)]
    inv=inverse(K)
    return [mm(inv,a) for a in mats]
def ratio(x):
    x=s.Rational(x)
    return I(x.p)/I(x.q)
def main():
    highdata=json.loads((HERE/'counterexamples_80digit.json').read_text())
    lo=4-2*iv.sqrt(2);hi=4+2*iv.sqrt(2)
    assert bool(lo>I('1.1')) and bool(lo<I(2))
    records=[]
    for idx in (1,2):
        P=[[I(5)/16,I(7)/20],[-I(1),I(0)],[I(1),I(0)]] if idx==1 else [[I(1)/2,I(1)],[-I(1),I(0)],[I(1),I(0)]]
        data=highdata[f'example{idx}'];roots={}
        if idx==1:
            dc=[I(v[0]) for v in data['D']]
            D,roots['D']=rootbox(P,lo,dc,I('1e-50'),I('0.01'))
            JM=jac(P,lo,D)[0];pout=hi
        else:
            x,y=s.symbols('x y');pp=[s.Matrix([x,y,0]),s.Matrix([-1,0,0]),s.Matrix([1,0,0])]
            G,K,HK,q=triangle(pp)
            F=G+s.Rational(3040,3113)*((s.Rational(9,20)+s.Rational(6,5)*q)*K+(-s.Rational(8,5)+s.Rational(13,5)*q)*HK)
            values={x:s.Rational(1,2),y:1}
            D=[ratio(z.subs(values)) for z in F[:2]]
            deriv=F.jacobian([x,y]).subs(values)
            JM=[[ratio(deriv[i,j]) for j in range(2)] for i in range(2)];pout=lo
        zc=[I(v[0]) for v in data['Z']]
        Z,roots['Z']=rootbox(P+[D],pout,zc,I('1e-35'),I('0.01') if idx==2 else I(1))
        JJ=jac(P+[D],pout,Z);pull=matadd(JJ[0],mm(JJ[3],JM))
        direction=list(map(I,[-9,4] if idx==1 else [7,12]))
        response=sum((direction[i]*pull[i][j]*direction[j] for i in range(2) for j in range(2)),I(0))
        assert bool(response<I(0)),str(response)
        records.append({'example':idx,'direction':[-9,4] if idx==1 else [7,12],'quadratic_response_interval':str(response),'root_bounds':roots,'jacobian_intervals':[[str(z) for z in row] for row in pull], 'status':'CERTIFIED: strictly negative directional derivative by outward interval bounds'})
    result={'interval_decimal_precision':70,'proof_assumptions':'Strict convexity, convex-hull confinement, and Hessian lower bounds proved in COMPOSITION_INTERVAL_PROOF.md','records':records}
    (HERE/'composition_interval_certificates.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
