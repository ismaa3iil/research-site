"""Package the local review and its replayable calculations, preserving inputs."""
import hashlib,json,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
def main():
    files=sorted(p for p in HERE.iterdir() if p.is_file() and p.suffix in {'.md','.py','.mjs','.json'} and p.name!='MANIFEST.json')
    manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (HERE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    target=HERE.parent/'Attractive_Centers_Four_Point_Theorems_Review_2026-10-18.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files+[HERE/'MANIFEST.json']:z.write(p,p.name)
    with zipfile.ZipFile(target) as z:
        assert all(hashlib.sha256(z.read(name)).hexdigest()==sha for name,sha in manifest.items())
    print(json.dumps({'path':str(target),'entries':len(files)+1,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2))
if __name__=='__main__':main()
