# Supplied script execution record

18 October 2026. Input SHA256:
35D59B0FB59C1026A6610C4BE7B6141C7F1F425CB73CCD3B4CB8902E4F1FCB9D.
Run unchanged, with BLAS/OpenMP threads set to one. Exit code 0.

The following is the substantive stdout, with the input's own descriptions
preserved. Labels such as 'exact' and 'global' below are its labels, not the
review's interpretation of what numerical assertions establish.

```text
1. Exact analytical 3x3 vertex Jacobians (Families II-V) verified against FD: PASS
2. Closed-form 3D determinant identities verified: det_VM = -5.526314e-05, det_KS = 3.716670e-05: PASS
3. Exact Q(sqrt(6)) spectral extrema [-0.782668990158, 0.75] & 1D vanishing of D_i(q_tilde W): PASS
4. Coplanar dictionary, H_4(A,B,C,G) subsetneq H_3, D != G counterexamples, & C_4(A,B,C,G) subseteq C_std(ABC): PASS
5. Global attractivity audit across 552 3D/planar/collinear tetrahedra (min eig = 4.536e-04): PASS
6. 3D Heart Volume on Paper III Benchmark P_III:
   - 1D Vertex Power Curve conv(M_p):               2.325678e-04
   - Family I (3-Param Skeletal-Constellation):     5.956887e-04 (2.56x)
   - Families II-V (+ Syzygy Rays T1..T8):          2.147447e-04 (0.92x)
   - Combined Hull (Families I-V + T1..T8):         2.331399e-03 (10.02x)
6. 3D Heart Volume on Scalene Tetrahedron 2:
   - 1D Vertex Power Curve conv(M_p):               7.049343e-05
   - Family I (3-Param Skeletal-Constellation):     1.638789e-04 (2.32x)
   - Families II-V (+ Syzygy Rays T1..T8):          1.315142e-03 (18.66x)
   - Combined Hull (Families I-V + T1..T8):         1.754027e-03 (24.88x)
All verifications PASSED in 11.734s.
```

Python also emitted harmless invalid-escape SyntaxWarnings for backslashes
inside two docstrings. The supplied file has been preserved byte-for-byte.
