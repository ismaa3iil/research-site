"""Independent 80-digit Newton roots and analytic derivatives, not intervals."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import json
from pathlib import Path
import mpmath as m
HERE=Path(__file__).resolve().parent
m.mp.dps=80
def power(P,p,initial):
    def grad(x,y):
        z=m.matrix([x,y])
        return tuple(sum(((z-a)*(m.fdot(z-a,z-a)**((p-2)/2)) for a in P),m.matrix([0,0])))
    z=m.matrix(m.findroot(grad,initial,tol=m.mpf('1e-70'),maxsteps=60))
    K=[]
    for a in P:
        d=z-a;r2=m.fdot(d,d)
        K.append(r2**((p-2)/2)*(m.eye(2)+(p-2)*(d*d.T)/r2))
    total=sum(K,m.zeros(2));inv=total**-1
    return z,[inv*k for k in K],max(abs(x) for x in grad(*z))
def r5(P):
    ss=[m.fdot(P[(i+1)%3]-P[(i+2)%3],P[(i+1)%3]-P[(i+2)%3]) for i in range(3)]
    ss=[x/sum(ss) for x in ss];d=[x-m.mpf(1)/3 for x in ss]
    q=m.mpf(3)/2*sum(x*x for x in d)
    K=sum((d[i]*P[i] for i in range(3)),m.zeros(2,1))
    HK=sum(((4*d[i]-6*(ss[i]**2-sum(x*x for x in ss)/3))*P[i] for i in range(3)),m.zeros(2,1))
    return sum(P,m.zeros(2,1))/3+m.mpf(3040)/3113*((m.mpf(9)/20+m.mpf(6)/5*q)*K+(-m.mpf(8)/5+m.mpf(13)/5*q)*HK)
def strings(v):
    if isinstance(v,m.matrix):return [[m.nstr(v[i,j],65) for j in range(v.cols)] for i in range(v.rows)]
    return m.nstr(v,65)
def main():
    low=4-2*m.sqrt(2);high=4+2*m.sqrt(2);results={}
    for idx,(A,pexp) in enumerate([([m.mpf(5)/16,m.mpf(7)/20],high),([m.mpf(1)/2,m.mpf(1)],low)],1):
        P=[m.matrix(A),m.matrix([-1,0]),m.matrix([1,0])]
        if idx==1:
            D,JD,resD=power(P,low,(m.mpf('.30'),m.mpf('.29')));JM=JD[0]
        else:
            D=r5(P);resD=m.mpf(0)
            JM=m.matrix(2,2)
            for ax in range(2):
                def move(t):
                    pp=[a.copy() for a in P];pp[0][ax]+=t
                    return r5(pp)
                for row in range(2):JM[row,ax]=m.diff(lambda t:move(t)[row],0)
        init=(m.mpf('.001'),m.mpf('.006')) if idx==1 else (m.mpf('.086'),m.mpf('.409'))
        Z,J,resZ=power(P+[D],pexp,init)
        M=J[0]+J[3]*JM;S=(M+M.T)/2
        ev,vec=m.eigsy(S);direction=vec[:,0]
        if direction[1]<0:direction=-direction
        pp=[a.copy() for a in P];step=direction/1000;pp[0]+=step
        Dnew=power(pp,low,tuple(D))[0] if idx==1 else r5(pp)
        Znew=power(pp+[Dnew],pexp,tuple(Z))[0]
        dot=m.fdot(step,Znew-Z)
        assert ev[0]<0 and dot<0
        results[f'example{idx}']={'D':strings(D),'Z':strings(Z),'symmetric_J':strings(S),'minimum_eigenvalue':strings(ev[0]),'determinant':strings(m.det(S)),'direction':strings(direction),'finite_dot':strings(dot),'maximum_root_residual':strings(max(resD,resZ)), 'status':'80-digit numerical corroboration, not directed interval proof'}
        if idx==1:
            stated=m.matrix([m.mpf('0.5877787026'),m.mpf('0.8090217530')])/1000
            pp=[a.copy() for a in P];pp[0]+=stated
            Dbad=power(pp,low,tuple(D))[0];Zbad=power(pp+[Dbad],pexp,tuple(Z))[0]
            results['example1']['finite_dot_using_attachment_direction']=strings(m.fdot(stated,Zbad-Z))
    (HERE/'counterexamples_80digit.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
