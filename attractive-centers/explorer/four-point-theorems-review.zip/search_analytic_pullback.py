"""Bounded numerical search for a rational-map composition counterexample.
Any hit still needs a separate exact evaluation before being called a proof.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import json,time
from pathlib import Path
import numpy as np
import sympy as s
from audit_exact import triangle
import incoming_verify as inc
HERE=Path(__file__).resolve().parent
def main():
    x,y=s.symbols('x y');P=[s.Matrix([x,y,0]),s.Matrix([-1,0,0]),s.Matrix([1,0,0])]
    G,K,HK,q=triangle(P)
    M=G+s.Rational(3040,3113)*((s.Rational(9,20)+s.Rational(6,5)*q)*K+(-s.Rational(8,5)+s.Rational(13,5)*q)*HK)
    fn=s.lambdify((x,y),M,'numpy',cse=True);jf=s.lambdify((x,y),M.jacobian([x,y]),'numpy',cse=True)
    rays={'K0':[-.3333,.3194],'K1':[-.8676,.9029],'K2':[-1.9754,1.9803],'V2':[-1.4522,2.1167],'V3':[-2.8732,2.8669]}
    rng=np.random.default_rng(123);least=1.;best=None;t0=time.monotonic()
    for t in range(1800):
        xx=round(rng.uniform(-2,2),3);yy=round(10**rng.uniform(-2,1),3)
        Pn=np.array([[xx,yy,0],[-1,0,0],[1,0,0],fn(xx,yy).ravel()]);JM=jf(xx,yy)[:2,:]
        data=inc.exact_rational_family_data(Pn);sw=Pn.copy();sw[[0,3]]=sw[[3,0]];dd=inc.exact_rational_family_data(sw)
        for key,cs in rays.items():
            for c in cs:
                J=(np.eye(2)/4+c*data[key][1][:2,:2])+(np.eye(2)/4+c*dd[key][1][:2,:2])@JM
                ev=float(np.linalg.eigvalsh((J+J.T)/2)[0])
                if ev<least:
                    least=ev;best={'A':[xx,yy],'M':'R5_star','Z_basis':key,'coefficient':str(c),'numerical_eigenvalue':ev,'tested':t+1}
        if least< -1e-6:break
        if time.monotonic()-t0>35:break
    best['elapsed_seconds']=time.monotonic()-t0
    (HERE/'analytic_pullback_search.json').write_text(json.dumps(best,indent=2)+'\n')
    print(json.dumps(best,indent=2))
if __name__=='__main__':main()
