"""Independent symbolic and exact algebraic checks of the incoming claims.
No numerical optimizer or incoming function is used in this file.
"""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import json, itertools, time
from pathlib import Path
import sympy as s
HERE = Path(__file__).resolve().parent
R = s.Rational
def simp(x):
    return x.applyfunc(s.cancel) if isinstance(x, s.MatrixBase) else s.cancel(x)
def zero(x):
    vals = list(x) if isinstance(x, s.MatrixBase) else [x]
    assert all(s.cancel(v) == 0 for v in vals), vals
def fam(P):
    G = sum(P, s.zeros(3, 1))/4
    r = [p-G for p in P]
    L = s.expand(sum(v.dot(v) for v in r))
    delta = [s.cancel(v.dot(v)/L-R(1,4)) for v in r]
    U = [sum((delta[i]**k*r[i] for i in range(4)), s.zeros(3,1)) for k in (1,2,3)]
    S = sum((v*v.T for v in r), s.zeros(3))/L
    H = S-s.eye(3)/3
    return dict(G=G, L=L, S=S, U1=U[0],
                K1=(S-s.eye(3))*U[0],
                K2=(H*H-s.trace(H*H)*s.eye(3)/3-R(2,9)*s.eye(3))*U[0],
                V2=U[1]-U[0]/3, V3=U[2]-R(7,36)*U[0], q=1-s.trace(S*S))
def triangle(P):
    G=sum(P,s.zeros(3,1))/3
    ss=[(P[(i+1)%3]-P[(i+2)%3]).dot(P[(i+1)%3]-P[(i+2)%3]) for i in range(3)]
    ss=[s.cancel(a/sum(ss)) for a in ss]
    d=[a-R(1,3) for a in ss]
    K=sum((d[i]*P[i] for i in range(3)),s.zeros(3,1))
    HK=sum(((4*d[i]-6*(ss[i]**2-sum(a*a for a in ss)/3))*P[i] for i in range(3)),s.zeros(3,1))
    return G,K,HK,s.cancel(R(3,2)*sum(a*a for a in d))
def halfplanes(P):
    rows=[]
    rot=s.Matrix([[R(1,2),-s.sqrt(3)/2],[s.sqrt(3)/2,R(1,2)]])
    for i in range(3):
        a,b,c=P[i],P[(i+1)%3],P[(i+2)%3]
        u=b-a; n=s.Matrix([-u[1],u[0]])
        if s.sign(n.dot(c-a))<0:n=-n
        rows.append((n,n.dot(a)))
        lo,hi=sorted([u.dot((a+b)/2),u.dot(c)],key=lambda x:float(x))
        rows.extend([(u,lo),(-u,-hi)])
        ori=s.sign(s.det(s.Matrix.hstack(b-a,c-a)))
        rr=rot if ori>0 else rot.T
        c0=a+rr*u; nc=(a+b+c0)/3; w=c-c0
        rows.append((w,s.simplify(w.dot(nc))))
    return rows
def pairplanes(P):
    rows=[]
    for j in (1,2,3):
        other=[k for k in (1,2,3) if k!=j]
        a=(P[0]+P[j])/2;b=(P[other[0]]+P[other[1]])/2
        n=b-a
        rows.extend([(n,n.dot(a)),(-n,-n.dot(b))])
    return rows
def vertices(rows):
    out=[]
    for (a,b),(c,d) in itertools.combinations(rows,2):
        M=s.Matrix.vstack(a.T,c.T)
        if M.det()==0:continue
        p=simp(M.inv()*s.Matrix([b,d]))
        if all(s.sign(s.simplify(n.dot(p)-z))>=0 for n,z in rows):
            if not any(p==q for q in out):out.append(p)
    import math
    center=sum(out,s.zeros(2,1))/len(out)
    out.sort(key=lambda p:math.atan2(float(p[1]-center[1]),float(p[0]-center[0])))
    return out
def area(P):
    return s.simplify(abs(sum(s.det(s.Matrix.hstack(P[i],P[(i+1)%len(P)])) for i in range(len(P))))/2)
def strings(x):
    if isinstance(x,s.MatrixBase):return [str(s.simplify(v)) for v in x]
    return str(s.simplify(x))
def main():
    start=time.time(); report={}
    u,v,a,b=s.symbols('u v a b',real=True)
    P=[s.Matrix(z) for z in [(0,0,0),(1,0,0),(u,v,0)]]
    d=fam(P+[sum(P,s.zeros(3,1))/3]);G,K,HK,q=triangle(P)
    identities={
        'K0': d['U1']+K,
        'K1': d['K1']-(K-HK)/2,
        'V2': d['V2']-(K-HK)/6,
        'K2': d['K2']-((3-4*q)*K/12-HK/6),
        'V3': d['V3']-((25-48*q)*K/144-HK/24),
        'q': d['q']-(R(1,2)-2*q)}
    for name,x in identities.items():zero(x)
    report['generic_centroid_dictionary']='all six identities exactly zero in Q(u,v)'
    M0=d['q']*d['U1']
    for x in [d['K1']-3*d['V2'],d['K2']-d['V2']+M0/6,d['V3']-d['V2']/4+R(7,144)*d['U1']+M0/6]:zero(x)
    report['generic_centroid_syzygies']='all three identically zero'
    general=fam(P+[s.Matrix([a,b,0])])
    zero(general['K2']-general['K1']/3+general['q']*general['U1']/6)
    report['generic_coplanar_CH']='K2=K1/3-q_tilde*U1/6 in Q(u,v,a,b)'
    bench=[s.Matrix(z) for z in [(0,0,0),(1,0,0),(0,1,0),(3,-2,R(1,2))]]
    f=fam(bench);m=f['q']*f['U1']
    ss=[f['K1']-3*f['V2'],f['K2']-f['V2']+m/6,f['V3']-f['V2']/4+R(7,144)*f['U1']+m/6]
    det=s.factor(s.Matrix.hstack(*ss).det());assert det!=0
    report['syzygy_3D_det']=str(det)
    tri=[s.Matrix(z) for z in [(0,0),(21,0),(5,12)]]
    hp=halfplanes(tri);vs=vertices(hp);A=area(vs)
    aug=vertices(hp+pairplanes(tri+[sum(tri,s.zeros(2,1))/3]));Aa=area(aug)
    report['13_20_21']={'vertices':[strings(p) for p in vs], 'area':strings(A),'area_numeric':float(A),'area_percent':float(100*A/126),'augmented_area':strings(Aa),'area_unchanged_by_bimedian':s.simplify(A-Aa)==0}
    for h in (6,7):
        tri=[s.Matrix(z) for z in [(0,h),(-1,0),(1,0)]]
        hp=halfplanes(tri)
        vv=vertices(hp); aa=vertices(hp+pairplanes(tri+[sum(tri,s.zeros(2,1))/3]))
        report[f'isosceles_h{h}']={'standard':[strings(p) for p in vv],'augmented':[strings(p) for p in aa], 'incenter_y':str(s.simplify(h/(1+s.sqrt(1+h*h))))}
    _,_,_,q2=triangle([s.Matrix(z) for z in [(R(1,2),1,0),(-1,0,0),(1,0,0)]])
    report['counterexample2_correct_q']=str(q2)
    report['elapsed_seconds']=time.time()-start
    (HERE/'exact_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
