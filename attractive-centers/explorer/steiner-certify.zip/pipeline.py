"""Design, prune and certify explicit Steiner maps (family: f, g polynomial in q of degree D, plus p*(degree E))."""
import sys, json, time, numpy as np, smaps, design, certify
from multiprocessing import Pool
from scipy.optimize import linprog
from scipy.spatial import ConvexHull
D, E, EPS, BOUND, Q = 4, 1, 0.003, 30.0, 1024
N = smaps.ncoef(D, E)

def shape_triangle(k, delta):
    rho = (1 - k) / (1 + k); psi = np.arctan(rho); w = np.exp(2j * np.pi / 3)
    al, be = np.cos(psi) * np.exp(1j * delta), np.sin(psi) * np.exp(-1j * delta)
    return np.array([[z.real, z.imag] for z in (al * w**j + be * w**-j for j in range(3))])

def offsets(V):
    return np.array([smaps.weights_center(V, np.eye(N)[i], D, E) - V.mean(0) for i in range(N)])

def cert_one(c):
    c = np.array(c)
    for scale in (1.0, 0.99, 0.97, 0.94, 0.9):
        cc = np.round(c * scale * Q) / Q
        r = certify.certify(cc, D, E, max_boxes=3_000_000)
        if r['ok']:
            return dict(coef=cc.tolist(), scale=scale, **r)
    return dict(coef=c.tolist(), ok=False, reason=r.get('reason'))

if __name__ == '__main__':
    t0 = time.time()
    R = design.constraints(D, E); b = np.full(len(R), 1 / 3 - EPS); maps = []
    for k in [0.08, 0.17, 0.28, 0.4, 0.52, 0.64, 0.76, 0.88]:
        for delta in [0.02, np.pi / 18, np.pi / 9, np.pi / 6 - 0.02]:
            B = offsets(shape_triangle(k, delta))
            for u in np.linspace(0, 2 * np.pi, 10, endpoint=False):
                r = linprog(-(B @ np.array([np.cos(u), np.sin(u)])), A_ub=-R, b_ub=b, bounds=[(-BOUND, BOUND)] * N, method='highs')
                if r.status == 0: maps.append(r.x)
    maps = np.array(maps); print('designed', len(maps), 'in', round(time.time() - t0), 's', flush=True)
    # prune: keep maps that are hull vertices on some test shape
    rng = np.random.default_rng(5); keep = set()
    tests = [shape_triangle(k, d) for k in np.linspace(0.05, 0.95, 13) for d in np.linspace(0, np.pi / 6, 5)]
    tests += [np.array([[0, 0], [21, 0], [5, 12]], float), np.array([[0, 0], [3, 0], [-1/3, 4*np.sqrt(14)/3]])]
    for V in tests:
        pts = maps @ offsets(V)
        try: keep |= set(ConvexHull(pts).vertices.tolist())
        except Exception: pass
    maps = maps[sorted(keep)]; print('kept after pruning', len(maps), flush=True)
    with Pool(int(sys.argv[1]) if len(sys.argv) > 1 else 6) as pool:
        res = pool.map(cert_one, maps.tolist(), chunksize=1)
    good = [r for r in res if r['ok']]
    print('certified', len(good), 'of', len(res), 'time', round(time.time() - t0), 's; scales used', sorted({r['scale'] for r in good}))
    json.dump(dict(D=D, E=E, denominator=Q, psi_max=certify.PSI_MAX, delta_max=certify.DEL_MAX, maps=good, failed=[r for r in res if not r['ok']]), open('steiner_certified.json', 'w'))
    C = np.array([r['coef'] for r in good])
    for name, V in [('13-20-21', tests[-2]), ('6-5-3', tests[-1])]:
        pts = V.mean(0) + C @ offsets(V); H = pts[ConvexHull(pts).vertices]
        print(f'  {name}: certified hull {100*design.area(H)/design.area(V):.3f}% with {len(H)} vertices')
