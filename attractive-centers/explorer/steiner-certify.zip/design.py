"""Design explicit polynomial Steiner maps by LP on sampled constraints (floats; candidates only)."""
import sys, json, numpy as np, smaps
from scipy.optimize import linprog
from scipy.spatial import ConvexHull

def constraints(D, E, npsi=64, ndel=128, nh=24):
    psi = np.linspace(0, np.pi / 4, npsi); dl = np.linspace(0, np.pi, ndel, endpoint=False)
    P, L = [x.ravel() for x in np.meshgrid(psi, dl, indexing='ij')]
    B = smaps.basis(P, L, D, E); rows = []
    for u in np.linspace(0, np.pi, nh, endpoint=False):
        c, s = np.cos(u), np.sin(u)
        rows.append(np.stack([c * c * b[2] + 2 * c * s * b[3] + s * s * b[4] for b in B], 1))
    return np.vstack(rows)

def xy_objective(k, n, D, E):
    """n.(X,Y) at ratio k as a linear form in the coefficients (free family only, E = -1)."""
    kap = (1 - k * k) / (1 + k * k); q = kap * kap / 4; v = np.zeros(smaps.ncoef(D, E))
    for m in range(D + 1):
        v[m] = -kap * q ** m * (n[0] + n[1]); v[D + 1 + m] = -kap * kap * q ** m * (n[0] - n[1])
    return v

def tri(a, b, c):
    x = (b * b + c * c - a * a) / (2 * c); return np.array([[0, 0], [c, 0], [x, np.sqrt(b * b - x * x)]], float)

def area(P):
    x, y = P[:, 0], P[:, 1]; return abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))) / 2

if __name__ == '__main__':
    D = int(sys.argv[1]); eps = float(sys.argv[2]); E = -1
    R = constraints(D, E); b = np.full(len(R), 1 / 3 - eps)
    maps = []
    for k in [0.12, 0.25, 0.4, 0.55, 0.7, 0.85]:
        for u in np.linspace(0, 2 * np.pi, 12, endpoint=False):
            r = linprog(-xy_objective(k, (np.cos(u), np.sin(u)), D, E), A_ub=-R, b_ub=b, bounds=[(-60, 60)] * R.shape[1], method='highs')
            if r.status == 0: maps.append(r.x)
            else: print('LP failed', k, u, r.message)
    maps = np.array(maps); np.save(f'design_D{D}.npy', maps)
    print('D', D, 'eps', eps, 'maps', len(maps), 'max |coef|', np.abs(maps).max())
    for name, V, ref in [('13-20-21', np.array([[0, 0], [21, 0], [5, 12]], float), 3.379), ('6-5-3', np.array([[0, 0], [3, 0], [-1/3, 4*np.sqrt(14)/3]]), 17.527)]:
        pts = np.array([smaps.weights_center(V, c, D, E) for c in maps]); H = pts[ConvexHull(pts).vertices]
        print(f'  {name}: hull of explicit maps {100*area(H)/area(V):.3f}%  (LP free-family region {ref}%)  hull vertices {len(H)}')
