"""Independent replay: re-run the interval certificate for every map in the certificate files.

Usage: python verify_all.py [processes] [file ...]     (default files: steiner_certified.json steiner_certified2.json)
"""
import sys, json, time, os
from multiprocessing import Pool
import certify


def one(args):
    coef, D, E = args
    return certify.certify(coef, D, E, max_boxes=6_000_000)


if __name__ == '__main__':
    procs = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    files = sys.argv[2:] or [f for f in ('steiner_certified.json', 'steiner_certified2.json') if os.path.exists(f)]
    bad = 0
    for name in files:
        d = json.load(open(name)); t = time.time()
        with Pool(procs) as pool:
            res = pool.map(one, [(m['coef'], d['D'], d['E']) for m in d['maps']], chunksize=1)
        ok = sum(r['ok'] for r in res); bad += len(res) - ok
        print(f"{name}: {ok} of {len(res)} maps certified; boxes {sum(r['boxes'] for r in res)}; "
              f"smallest determinant lower bound {min(r.get('min_det_lower_bound', 0) for r in res):.3e}; {time.time() - t:.0f} s", flush=True)
    sys.exit(0 if bad == 0 else 1)
