"""Independent replay: re-run the interval certificate for every map in steiner_certified.json.

Usage: python verify_all.py [processes]
"""
import sys, json, time
from multiprocessing import Pool
import certify


def one(args):
    coef, D, E = args
    return certify.certify(coef, D, E, max_boxes=3_000_000)


if __name__ == '__main__':
    d = json.load(open('steiner_certified.json'))
    t = time.time()
    with Pool(int(sys.argv[1]) if len(sys.argv) > 1 else 4) as pool:
        res = pool.map(one, [(m['coef'], d['D'], d['E']) for m in d['maps']], chunksize=1)
    ok = sum(r['ok'] for r in res)
    print(f"{ok} of {len(res)} maps certified; boxes {sum(r['boxes'] for r in res)}; "
          f"smallest determinant lower bound {min(r.get('min_det_lower_bound', 0) for r in res):.3e}; {time.time() - t:.0f} s")
    sys.exit(0 if ok == len(res) else 1)
