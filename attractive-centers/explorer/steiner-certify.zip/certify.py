"""Interval-arithmetic certificate that a polynomial Steiner map is attractive.

Claim certified for a coefficient vector c (binary floating-point numbers, i.e. exact dyadic rationals):
for every (psi, delta) in [0, PSI_MAX] x [0, DEL_MAX] the matrix S = Sym dZ/dv_0 at
alpha = cos(psi) e^{i delta}, beta = sin(psi) e^{-i delta} satisfies S11 > 0 and S11*S22 - S12^2 > 0.

Why this covers every triangle and every vertex:
 * any three points that are not all equal are G + alpha w^j + beta w^-j with (alpha, beta) != 0; Z is
   translation-, rotation- and scale-covariant, so S only changes by a rotation conjugation: take
   |alpha|^2+|beta|^2 = 1 and arg(alpha) = -arg(beta) = delta;
 * relabelling j -> -j swaps alpha and beta and fixes vertex 0, so psi in [0, pi/4] suffices;
 * delta -> delta + pi is the half-turn of the triangle, so delta in [0, pi) suffices;
 * vertex j of the triangle is vertex 0 after relabelling, which shifts delta by 2 pi j/3.
PSI_MAX and DEL_MAX are slightly larger than pi/4 and pi.

Arithmetic: closed intervals with endpoints in IEEE doubles; after every +, -, * the lower endpoint is moved
down and the upper endpoint up by one ulp (np.nextafter), which encloses the exact result because IEEE
operations are correctly rounded.  cos and sin of a box [m-r, m+r] are enclosed by [f(m)-r-TRIG_SLACK,
f(m)+r+TRIG_SLACK] (Lipschitz constant 1; TRIG_SLACK = 1e-12 covers the libm error, assumed below that).
Boxes are bisected adaptively until the two inequalities hold on each.
"""
import sys, json, time, numpy as np
import smaps

PSI_MAX, DEL_MAX, TRIG_SLACK = 0.7854, 3.1416, 1e-12
NINF, PINF = -np.inf, np.inf


class I:
    __slots__ = ('lo', 'hi')

    def __init__(self, lo, hi):
        self.lo, self.hi = lo, hi

    @staticmethod
    def out(lo, hi):
        return I(np.nextafter(lo, NINF), np.nextafter(hi, PINF))

    def __add__(self, o):
        if isinstance(o, I):
            return I.out(self.lo + o.lo, self.hi + o.hi)
        return I.out(self.lo + o, self.hi + o)
    __radd__ = __add__

    def __neg__(self):
        return I(-self.hi, -self.lo)

    def __sub__(self, o):
        return self + (-o)

    def __rsub__(self, o):
        return (-self) + o

    def __mul__(self, o):
        if isinstance(o, I):
            a, b, c, d = self.lo * o.lo, self.lo * o.hi, self.hi * o.lo, self.hi * o.hi
            return I.out(np.minimum(np.minimum(a, b), np.minimum(c, d)), np.maximum(np.maximum(a, b), np.maximum(c, d)))
        a, b = self.lo * o, self.hi * o
        return I.out(np.minimum(a, b), np.maximum(a, b))
    __rmul__ = __mul__


def recip(x):
    assert np.all(x.lo > 0)
    return I.out(1.0 / x.hi, 1.0 / x.lo)


def trig(m, r):
    c, s = np.cos(m), np.sin(m)
    e = r + TRIG_SLACK
    return I(np.nextafter(c - e, NINF), np.nextafter(c + e, PINF)), I(np.nextafter(s - e, NINF), np.nextafter(s + e, PINF))


class T2:
    """interval value with interval partial derivatives in psi and delta."""
    __slots__ = ('v', 'a', 'b')

    def __init__(self, v, a, b):
        self.v, self.a, self.b = v, a, b

    def __add__(self, o):
        return T2(self.v + o.v, self.a + o.a, self.b + o.b) if isinstance(o, T2) else T2(self.v + o, self.a, self.b)
    __radd__ = __add__

    def __neg__(self):
        return T2(-self.v, -self.a, -self.b)

    def __sub__(self, o):
        return self + (-o)

    def __mul__(self, o):
        if isinstance(o, T2):
            return T2(self.v * o.v, self.a * o.v + self.v * o.a, self.b * o.v + self.v * o.b)
        return T2(self.v * o, self.a * o, self.b * o)
    __rmul__ = __mul__


def recip2(x):
    r = recip(x.v)
    r2 = r * r
    return T2(r, -(x.a * r2), -(x.b * r2))


def evaluate(boxes, coef, D, E):
    """Mean-value form: S(box) is enclosed by S(mid) + dS/dpsi(box)*[-r,r] + dS/ddelta(box)*[-r,r].

    boxes: array (n,4) = psi_lo, psi_hi, del_lo, del_hi.  Returns lower bounds of S11 and det."""
    n = len(boxes)
    pm, dm = (boxes[:, 0] + boxes[:, 1]) / 2, (boxes[:, 2] + boxes[:, 3]) / 2
    # radii rounded up so that [m-r, m+r] contains the box
    pr = np.nextafter(np.maximum(boxes[:, 1] - pm, pm - boxes[:, 0]), PINF)
    dr = np.nextafter(np.maximum(boxes[:, 3] - dm, dm - boxes[:, 2]), PINF)
    coef = [float(c) for c in coef]
    z = I(np.zeros(n), np.zeros(n))
    third1 = I(np.full(n, np.nextafter(1 / 3, NINF)), np.full(n, np.nextafter(1 / 3, PINF)))
    # derivatives over the whole box
    cp, sp = trig(pm, pr)
    cd, sd = trig(dm, dr)
    out = smaps.response(T2(cp, -sp, z), T2(sp, cp, z), T2(cd, z, -sd), T2(sd, z, cd), coef, D, E, recip2, T2(third1, z, z))
    # values at the midpoint (thin enclosures)
    zr = np.zeros(n)
    cp0, sp0 = trig(pm, zr)
    cd0, sd0 = trig(dm, zr)
    mid = smaps.response(cp0, sp0, cd0, sd0, coef, D, E, recip, third1)
    rp, rd = I(-pr, pr), I(-dr, dr)
    S = [m + g.a * rp + g.b * rd for m, g in zip(mid[1:], out[1:])]
    det = S[0] * S[2] - S[1] * S[1]
    return S[0].lo, det.lo


def certify(coef, D, E, n0=(32, 128), max_depth=14, max_boxes=4_000_000, chunk=200_000):
    ps = np.linspace(0, PSI_MAX, n0[0] + 1)
    ds = np.linspace(0, DEL_MAX, n0[1] + 1)
    boxes = np.array([[ps[i], ps[i + 1], ds[j], ds[j + 1]] for i in range(n0[0]) for j in range(n0[1])])
    total, worst = 0, np.inf
    for depth in range(max_depth + 1):
        if len(boxes) > max_boxes:
            return dict(ok=False, reason='box limit', boxes=total, depth=depth)
        good = np.zeros(len(boxes), bool)
        for a in range(0, len(boxes), chunk):
            s11, det = evaluate(boxes[a:a + chunk], coef, D, E)
            g = (s11 > 0) & (det > 0)
            good[a:a + chunk] = g
            if g.any():
                worst = min(worst, det[g].min())
        total += int(good.sum())
        bad = boxes[~good]
        if not len(bad):
            return dict(ok=True, boxes=total, depth=depth, min_det_lower_bound=float(worst))
        # definite failure: a floating-point evaluation at a box midpoint is clearly negative
        cm = [float(c) for c in coef]
        pmid, dmid = (bad[:, 0] + bad[:, 1]) / 2, (bad[:, 2] + bad[:, 3]) / 2
        _, f11, f12, f22 = smaps.response(np.cos(pmid), np.sin(pmid), np.cos(dmid), np.sin(dmid), cm, D, E, lambda x: 1.0 / x, 1.0 / 3.0)
        if np.any(f11 * f22 - f12 * f12 < -1e-9) or np.any(f11 < -1e-9):
            return dict(ok=False, reason='negative response found', boxes=total, depth=depth)
        pm, dm = (bad[:, 0] + bad[:, 1]) / 2, (bad[:, 2] + bad[:, 3]) / 2
        boxes = np.concatenate([np.stack([bad[:, 0], pm, bad[:, 2], dm], 1), np.stack([pm, bad[:, 1], bad[:, 2], dm], 1),
                                np.stack([bad[:, 0], pm, dm, bad[:, 3]], 1), np.stack([pm, bad[:, 1], dm, bad[:, 3]], 1)])
    return dict(ok=False, reason='depth limit', boxes=total, remaining=len(boxes))


if __name__ == '__main__':
    # self-test: the centroid passes, a known bad map (symmedian point X(6): f=1) must fail
    t = time.time(); print('G:', certify([0, 0, 0, 0], 1, -1), round(time.time() - t, 2), 's')
    t = time.time(); print('X(6) (must fail):', certify([1, 0, 0, 0], 1, -1), round(time.time() - t, 2), 's')
