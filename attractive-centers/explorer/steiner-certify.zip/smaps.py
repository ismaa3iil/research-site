"""Explicit polynomial Steiner maps and their vertex response.

Triangle v_j = G + alpha w^j + beta w^-j (w = exp(2 pi i/3)).  With N = |alpha|^2+|beta|^2,
  W  = (alpha^2 conj(beta) + beta^2 conj(alpha)) / N
  V2 = (|beta|^2 alpha^2 conj(beta) + |alpha|^2 beta^2 conj(alpha)) / N^2
  q  = |alpha|^2 |beta|^2 / N^2,   p = -8 Re((alpha conj(beta))^3) / N^3
  Z  = G - f W - 2 g V2,   f = sum_m (f_m + p fp_m) q^m,  g = sum_m (g_m + p gp_m) q^m.
In the Steiner frame Z = G + X cos3t GP + Y sin3t GQ with X = -kappa (f + g kappa), Y = -kappa (f - g kappa),
kappa = 2 sqrt(q); in side lengths the weights are 1/3 + (f+4g)(s_i-1/3) - 6g(s_i^2 - mean s^2).
Moving vertex 0 by h changes alpha, beta and G by h/3 each.

The arithmetic is generic: it runs on floats/NumPy arrays and on the interval class in certify.py.
Coefficient vector layout: [f_0..f_D, g_0..g_D, fp_0..fp_E, gp_0..gp_E].
"""
import numpy as np


class Dual:
    """value and two tangents (directions h = e1, e2)."""
    __slots__ = ('v', 'a', 'b')

    def __init__(self, v, a, b):
        self.v, self.a, self.b = v, a, b

    def __add__(self, o):
        return Dual(self.v + o.v, self.a + o.a, self.b + o.b) if isinstance(o, Dual) else Dual(self.v + o, self.a, self.b)
    __radd__ = __add__

    def __neg__(self):
        return Dual(-self.v, -self.a, -self.b)

    def __sub__(self, o):
        return self + (-o)

    def __mul__(self, o):
        if isinstance(o, Dual):
            return Dual(self.v * o.v, self.a * o.v + self.v * o.a, self.b * o.v + self.v * o.b)
        return Dual(self.v * o, self.a * o, self.b * o)
    __rmul__ = __mul__


def cmul(x, y):
    return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])


def response(cpsi, spsi, cdel, sdel, coef, D, E, recip, third):
    """Return (F, S11, S12, S22): F = Z-G (pair), S = Sym dZ/dv_0, at alpha = cpsi e^{i delta}, beta = spsi e^{-i delta}.

    recip(x) must return an enclosure of 1/x; third is 1/3 in the working arithmetic."""
    zero = cpsi * 0.0
    a = (Dual(cpsi * cdel, third + zero, zero), Dual(cpsi * sdel, zero, third + zero))
    b = (Dual(spsi * cdel, third + zero, zero), Dual(-(spsi * sdel), zero, third + zero))
    conj = lambda z: (z[0], -z[1])
    c2 = a[0] * a[0] + a[1] * a[1]
    d2 = b[0] * b[0] + b[1] * b[1]
    N = c2 + d2
    r = recip(N.v)
    iN = Dual(r, -(N.a * r * r), -(N.b * r * r))
    iN2 = iN * iN
    A2B = cmul(cmul(a, a), conj(b))
    B2A = cmul(cmul(b, b), conj(a))
    W = ((A2B[0] + B2A[0]) * iN, (A2B[1] + B2A[1]) * iN)
    V2 = ((d2 * A2B[0] + c2 * B2A[0]) * iN2, (d2 * A2B[1] + c2 * B2A[1]) * iN2)
    q = c2 * d2 * iN2
    ab = cmul(a, conj(b))
    p = cmul(cmul(ab, ab), ab)[0] * iN2 * iN * (-8.0)
    f0, g0 = coef[:D + 1], coef[D + 1:2 * D + 2]
    fp, gp = coef[2 * D + 2:2 * D + 3 + E], coef[2 * D + 3 + E:]

    def poly(cs):
        acc = None
        for cm in reversed(list(cs)):
            acc = (q * acc + cm) if acc is not None else (q * 0.0 + cm)
        return acc
    f = poly(f0)
    g = poly(g0)
    if len(fp):
        f = f + p * poly(fp)
        g = g + p * poly(gp)
    F = (-(f * W[0]) - (g * V2[0]) * 2.0, -(f * W[1]) - (g * V2[1]) * 2.0)
    S11 = F[0].a + third
    S22 = F[1].b + third
    S12 = (F[0].b + F[1].a) * 0.5
    return (F[0].v, F[1].v), S11, S12, S22


def ncoef(D, E):
    return 2 * (D + 1) + (2 * (E + 1) if E >= 0 else 0)


def basis(psi, delta, D, E):
    """Float basis: lists over coefficients of (F0, F1, S11-1/3, S12, S22-1/3) arrays."""
    n = ncoef(D, E)
    out = []
    cp, sp, cd, sd = np.cos(psi), np.sin(psi), np.cos(delta), np.sin(delta)
    for i in range(n):
        c = np.zeros(n); c[i] = 1.0
        F, S11, S12, S22 = response(cp, sp, cd, sd, c, D, E, lambda x: 1.0 / x, 1.0 / 3.0)
        out.append((F[0], F[1], S11 - 1.0 / 3.0, S12, S22 - 1.0 / 3.0))
    return out


def weights_center(V, coef, D, E):
    """Evaluate the map on a concrete triangle through the side-length weights (independent of the complex form)."""
    V = np.asarray(V, float)
    sq = np.array([np.sum((V[(i + 1) % 3] - V[(i + 2) % 3]) ** 2) for i in range(3)])
    s = sq / sq.sum()
    u = 1.0 / 3.0 - s
    q = (9 * np.mean(s * s) - 1) / 2
    p = 36 * np.sum((s - 1.0 / 3.0) ** 3)
    f0, g0 = coef[:D + 1], coef[D + 1:2 * D + 2]
    fp, gp = coef[2 * D + 2:2 * D + 3 + E], coef[2 * D + 3 + E:]
    pv = lambda cs: sum(c * q ** m for m, c in enumerate(cs))
    f = pv(f0) + p * pv(fp)
    g = pv(g0) + p * pv(gp)
    w = 1.0 / 3.0 - f * u - 6 * g * (u * u - np.mean(u * u))
    return w @ V
