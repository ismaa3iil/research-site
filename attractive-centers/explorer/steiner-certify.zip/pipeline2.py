"""Second batch of Steiner maps: degree 6 in q, p-terms of degree 2 in q, aimed in particular at the upper edge
of the 13-20-21 heart.  Design (parallel LPs), prune against the first batch, certify (interval arithmetic).

Usage: python pipeline2.py [processes]
"""
import sys, json, time, numpy as np, smaps, design, certify
from multiprocessing import Pool
from scipy.optimize import linprog
from scipy.spatial import ConvexHull

D, E, EPS, BOUND, Q = 6, 2, 0.003, 100.0, 1024
N = smaps.ncoef(D, E)
T13 = np.array([[0, 0], [21, 0], [5, 12]], float)
T653 = np.array([[0, 0], [3, 0], [-1 / 3, 4 * np.sqrt(14) / 3]])


def shape_triangle(k, delta):
    rho = (1 - k) / (1 + k); psi = np.arctan(rho); w = np.exp(2j * np.pi / 3)
    al, be = np.cos(psi) * np.exp(1j * delta), np.sin(psi) * np.exp(-1j * delta)
    return np.array([[z.real, z.imag] for z in (al * w**j + be * w**-j for j in range(3))])


def offsets(V):
    return np.array([smaps.weights_center(V, np.eye(N)[i], D, E) - V.mean(0) for i in range(N)])


def pad(c, d0, e0):
    """Coefficient vector of the family (d0, e0) written in the layout of the family (D, E)."""
    c = np.asarray(c, float); out = np.zeros(N)
    out[0:d0 + 1] = c[0:d0 + 1]; out[D + 1:D + 2 + d0] = c[d0 + 1:2 * d0 + 2]
    out[2 * D + 2:2 * D + 3 + e0] = c[2 * d0 + 2:2 * d0 + 3 + e0]; out[2 * D + 3 + E:2 * D + 4 + E + e0] = c[2 * d0 + 3 + e0:]
    return out


_R = None


def init():
    global _R
    _R = design.constraints(D, E)


def solve(obj):
    r = linprog(-np.asarray(obj), A_ub=-_R, b_ub=np.full(len(_R), 1 / 3 - EPS), bounds=[(-BOUND, BOUND)] * N, method='highs')
    return r.x.tolist() if r.status == 0 else None


def cert_one(item):
    idx, c = item; c = np.array(c)
    for scale in (1.0, 0.99, 0.97, 0.94, 0.9):
        cc = np.round(c * scale * Q) / Q
        r = certify.certify(cc, D, E, max_boxes=6_000_000, chunk=30_000)
        if r['ok']:
            return dict(coef=cc.tolist(), scale=scale, objective=idx, **r)
    return dict(coef=c.tolist(), ok=False, objective=idx, reason=r.get('reason'))


if __name__ == '__main__':
    procs = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    t0 = time.time()
    first = json.load(open('steiner_certified.json'))
    old = np.array([pad(m['coef'], first['D'], first['E']) for m in first['maps']])
    # sanity: padding does not change a map
    for V in (T13, T653):
        a = smaps.weights_center(V, np.array(first['maps'][7]['coef']), first['D'], first['E']); b = smaps.weights_center(V, old[7], D, E)
        assert np.abs(a - b).max() < 1e-12
    objectives = []
    for k in [0.08, 0.17, 0.28, 0.4, 0.52, 0.64, 0.76, 0.88]:
        for delta in [0.02, np.pi / 18, np.pi / 9, np.pi / 6 - 0.02]:
            B = offsets(shape_triangle(k, delta))
            objectives += [B @ np.array([np.cos(u), np.sin(u)]) for u in np.linspace(0, 2 * np.pi, 12, endpoint=False)]
    for V, nd in ((T13, 48), (T653, 24)):
        B = offsets(V)
        objectives += [B @ np.array([np.cos(u), np.sin(u)]) for u in np.linspace(0, 2 * np.pi, nd, endpoint=False)]
    # each design LP needs a few hundred megabytes, so the design stage uses few processes
    import os
    if os.path.exists('pipeline2_designed.npy'):
        sols = np.load('pipeline2_designed.npy')
    else:
        # each design LP needs a few hundred megabytes, so the design stage uses few processes
        with Pool(min(procs, 4), initializer=init) as pool:
            sols = pool.map(solve, [o.tolist() for o in objectives], chunksize=4)
        sols = np.array([s if s is not None else [np.nan] * N for s in sols]); np.save('pipeline2_designed.npy', sols)
    valid = np.flatnonzero(~np.isnan(sols[:, 0])); new = sols[valid]
    print('designed', len(new), 'of', len(objectives), 'in', round(time.time() - t0), 's', flush=True)
    # prune: keep new maps that are hull vertices of (first batch + new) on some test shape
    tests = [shape_triangle(k, d) for k in np.linspace(0.05, 0.95, 13) for d in np.linspace(0, np.pi / 6, 5)] + [T13, T653]
    allc = np.vstack([old, new]); keep = set()
    for V in tests:
        pts = allc @ offsets(V)
        try:
            keep |= {i - len(old) for i in ConvexHull(pts).vertices.tolist() if i >= len(old)}
        except Exception:
            pass
    # maps aimed at the two reference triangles (the last 72 objectives) are certified first
    order = sorted(keep, key=lambda i: (valid[i] < 384, valid[i]))
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else len(order)
    print('kept after pruning', len(order), '; certifying', min(limit, len(order)), flush=True)
    res, good = [], []
    with Pool(procs) as pool:
        for r in pool.imap_unordered(cert_one, [(int(valid[i]), new[i].tolist()) for i in order[:limit]], chunksize=1):
            res.append(r)
            if len(res) % 10 == 0 or len(res) == min(limit, len(order)):
                good = [x for x in res if x['ok']]
                json.dump(dict(D=D, E=E, denominator=Q, psi_max=certify.PSI_MAX, delta_max=certify.DEL_MAX, maps=sorted(good, key=lambda x: x['objective']), failed=[x for x in res if not x['ok']]), open('steiner_certified2.json', 'w'))
                print(f'  {len(res)} done, {len(good)} certified, {round(time.time() - t0)} s', flush=True)
    good = sorted([x for x in res if x['ok']], key=lambda x: x['objective'])
    print('certified', len(good), 'of', len(res), 'time', round(time.time() - t0), 's; scales', {s: sum(r['scale'] == s for r in good) for s in sorted({r['scale'] for r in good})},
          '; boxes', sum(r['boxes'] for r in good), '; max depth', max((r['depth'] for r in good), default=0), flush=True)
    C = np.vstack([old] + ([np.array([r['coef'] for r in good])] if good else []))
    for name, V in (('13-20-21', T13), ('6-5-3', T653)):
        for label, M in (('first batch', old), ('with second batch', C)):
            pts = V.mean(0) + M @ offsets(V); H = pts[ConvexHull(pts).vertices]
            print(f'  {name}: {label}: hull {100 * design.area(H) / design.area(V):.3f}% with {len(H)} vertices', flush=True)
