"""Discover SOS Gram matrices, then certify by exact integer arithmetic.

Rotation sets the tested displacement to e_x. A Hadamard frame parametrizes
ALL centered configurations by three unrestricted vectors a,b,c. Positivity
of the resulting homogeneous scalar polynomial proves all vertex responses
by Euclidean/permutation equivariance. Reflections in y,z split the SOS Gram
matrix into four parity blocks. Numerical solver status is never a proof.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import argparse,json,time,math
import sympy as sp
import numpy as np
import scipy.sparse as sparse

ROOT=Path(__file__).resolve().parent

def polynomial(family,coefficient):
    vs=sp.symbols('x0:3 y0:3 z0:3')
    a,b,c=[sp.Matrix([vs[i],vs[i+3],vs[i+6]]) for i in range(3)]
    r=[a+b+c,a-b-c,-a+b-c,-a-b+c]
    L=sp.Poly(4*sum(v*v for v in vs),*vs).as_expr()
    d=[sp.expand(v.dot(v)-L/4) for v in r]
    N=[sp.Matrix([sp.expand(sum(d[i]**m*r[i][j] for i in range(4))) for j in range(3)]) for m in (1,2,3)]
    S=sp.Matrix(3,3,lambda i,j:sp.expand(sum(v[i]*v[j] for v in r)))
    if family=='U1':num=N[0][0];k=1
    elif family=='K1':num=sp.expand(((S-L*sp.eye(3))*N[0])[0]);k=2
    elif family=='K2':num=sp.expand(((S*S-2*L*S/3-sp.trace(S*S)*sp.eye(3)/3)*N[0])[0]);k=3
    elif family=='V2':num=sp.expand(N[1][0]-L*N[0][0]/3);k=2
    elif family=='V3':num=sp.expand(N[2][0]-7*L**2*N[0][0]/36);k=3
    else:raise ValueError(family)
    DN=sum(sp.diff(num,v) for v in vs[:3])/4
    DL=sum(sp.diff(L,v) for v in vs[:3])/4
    p=sp.Poly(sp.expand(L**(k+1)/4+sp.Rational(coefficient)*(L*DN-k*num*DL)),*vs)
    den=sp.ilcm(*[q.q for q in p.coeffs()])
    ints={m:int(v*den) for m,v in p.terms()};normal=max(abs(v) for v in ints.values())
    assert all(sum(m)==2*(k+1) and sum(m[3:6])%2==0 and sum(m[6:9])%2==0 for m in ints)
    return vs,k+1,ints,normal

def exponents(n,degree):
    if n==1:return [(degree,)]
    return [(a,)+tail for a in range(degree+1) for tail in exponents(n-1,degree-a)]

def gram_setup(halfdegree,coefficients,normal):
    groups={}
    for m in exponents(9,halfdegree):groups.setdefault((sum(m[3:6])%2,sum(m[6:9])%2),[]).append(m)
    blocks=list(groups.values());terms=sorted({tuple(a+b for a,b in zip(u,v)) for block in blocks for u in block for v in block})
    index={m:i for i,m in enumerate(terms)};rows=[];cols=[];owners={};off=0
    for bi,block in enumerate(blocks):
        n=len(block)
        for j,v in enumerate(block):
            for i,u in enumerate(block):
                m=tuple(a+b for a,b in zip(u,v));rows.append(index[m]);cols.append(off+i+j*n)
                if m not in owners or i==j:owners[m]=(bi,i,j)
        off+=n*n
    A=sparse.coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(terms),off)).tocsr()
    rhs=np.array([coefficients.get(m,0)/normal for m in terms])
    return blocks,terms,A,rhs,owners

def certify_gram(blocks,terms,coefficients,normal,owners,values):
    D=normal*10**12
    Q=[]
    for v in values:
        v=(v+v.T)/2
        q=np.array([[int(round(float(z)*D)) for z in row] for row in v],dtype=object)
        Q.append(q)
    current={m:0 for m in terms};locations={m:[] for m in terms}
    for bi,(block,q) in enumerate(zip(blocks,Q)):
        for i,u in enumerate(block):
            for j,v in enumerate(block):
                m=tuple(a+b for a,b in zip(u,v));current[m]+=q[i,j];locations[m].append((bi,i,j))
    for m in terms:
        correction=coefficients.get(m,0)*(D//normal)-current[m]
        # Minimum-norm projection: distribute the coefficient residual over
        # its disjoint Gram entries before the final exact integer correction.
        common=correction//len(locations[m])
        for bi,i,j in locations[m]:Q[bi][i,j]+=common
        correction-=common*len(locations[m])
        bi,i,j=owners[m]
        if i==j:Q[bi][i,j]+=correction
        else:
            assert correction%2==0
            Q[bi][i,j]+=correction//2;Q[bi][j,i]+=correction//2
    # Reconstruct every coefficient exactly after the rational correction.
    replay={m:0 for m in terms}
    for block,q in zip(blocks,Q):
        for i,u in enumerate(block):
            for j,v in enumerate(block):replay[tuple(a+b for a,b in zip(u,v))]+=q[i,j]
    assert all(replay[m]*normal==coefficients.get(m,0)*D for m in terms)
    result=[]
    for block,q in zip(blocks,Q):
        qq=np.asarray(q,dtype=float)/float(D)
        mineig=float(np.linalg.eigvalsh(qq)[0])
        if mineig<=0:raise ValueError(f'Rational Gram block not positive definite: {mineig}')
        inv=np.linalg.inv(np.linalg.cholesky(qq).T)
        Dt=10**12
        T=np.array([[int(round(float(z)*Dt)) for z in row] for row in inv],dtype=object)
        B=T.T@q@T
        margins=[int(B[i,i]-sum(abs(B[i,j]) for j in range(len(B)) if j!=i)) for i in range(len(B))]
        if min(margins)<=0:raise ValueError('Exact congruence not diagonally dominant')
        result.append({'monomials':block,'gram_numerators':q.tolist(),'gram_denominator':D,
            'congruence_numerators':T.tolist(),'congruence_denominator':Dt,
            'exact_gershgorin_min_numerator':min(margins),'discovery_min_eigenvalue':mineig})
    return result

def run(family,coefficient,seconds):
    import cvxpy as cp
    started=time.time();vs,degree,coefficients,normal=polynomial(family,coefficient)
    blocks,terms,A,rhs,owners=gram_setup(degree,coefficients,normal)
    print('Polynomial',family,coefficient,'degree',2*degree,'terms',len(coefficients),'blocks',[len(b) for b in blocks],flush=True)
    Q=[cp.Variable((len(b),len(b)),symmetric=True) for b in blocks];t=cp.Variable()
    constraints=[A@cp.hstack([cp.vec(q,order='F') for q in Q])==rhs]+[q-t*np.eye(len(b))>>0 for q,b in zip(Q,blocks)]
    problem=cp.Problem(cp.Maximize(t),constraints)
    problem.solve(solver='SCS',eps=1e-8,max_iters=100000,time_limit_secs=seconds,verbose=False)
    status={'family':family,'coefficient':coefficient,'solver_status':problem.status,'discovery_gram_margin':None if t.value is None else float(t.value),
            'degree':2*degree,'blocks':[len(b) for b in blocks],'proved':False}
    print('Discovery',status,flush=True)
    if t.value is not None and t.value>1e-9 and all(q.value is not None for q in Q):
        try:
            certificate=certify_gram(blocks,terms,coefficients,normal,owners,[q.value for q in Q])
            status['proved']=True;status['certificate_blocks']=certificate
            status['normalization']=normal
            status['polynomial_integer_coefficients']=[{'exponent':m,'coefficient':v} for m,v in coefficients.items()]
            status['proof']='Exact polynomial SOS identity; exact integer positive-definiteness by rational congruence and strict Gershgorin dominance.'
        except Exception as e:status['certificate_error']=str(e)
    status['elapsed_seconds']=time.time()-started
    stem='sos_'+family+'_'+coefficient.replace('-','minus').replace('.','p')
    if all(q.value is not None for q in Q):np.savez_compressed(ROOT/(stem+'_discovery.npz'),**{str(i):q.value for i,q in enumerate(Q)})
    path=ROOT/(stem+'.json')
    if path.exists():
        archive=ROOT/'attempts';archive.mkdir(exist_ok=True)
        (archive/(stem+'_'+str(time.time_ns())+'.json')).write_bytes(path.read_bytes())
    path.write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
    print('PROVED' if status['proved'] else 'UNRESOLVED',path,'elapsed',status['elapsed_seconds'],flush=True)
    return status

if __name__=='__main__':
    arg=argparse.ArgumentParser();arg.add_argument('family',choices=['U1','K1','K2','V2','V3']);arg.add_argument('coefficient');arg.add_argument('--seconds',type=float,default=45)
    args=arg.parse_args();run(args.family,args.coefficient,args.seconds)
