"""Exact independent replay: no SDP solver, no floating-point PSD decisions.

Derivative polynomials are rederived by material vertex motion, independently
of the coordinate derivative operator used by the certificate generator.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,time,hashlib
from fractions import Fraction
import numpy as np
import sympy as sp

ROOT=Path(__file__).resolve().parent
CASES={'U1':['-0.3333','0.3194'],'K1':['-0.8676','0.9029'],
       'K2':['-1.9754','1.9803'],'V2':['-1.4522','2.1167'],'V3':['-2.8732','2.8669']}

def derive_independently():
    vs=sp.symbols('x0:3 y0:3 z0:3')
    a,b,c=[sp.Matrix([vs[i],vs[i+3],vs[i+6]]) for i in range(3)]
    r=[a+b+c,a-b-c,-a+b-c,-a-b+c]
    h=sp.Matrix([1,0,0]);dr=[3*h/4,-h/4,-h/4,-h/4]
    L=sp.expand(sum(v.dot(v) for v in r));DL=sp.expand(sum(2*v.dot(w) for v,w in zip(r,dr)))
    delta=[sp.expand(v.dot(v)-L/4) for v in r]
    Ddelta=[sp.expand(2*v.dot(w)-DL/4) for v,w in zip(r,dr)]
    N=[];DN=[]
    for m in (1,2,3):
        N.append(sum((delta[i]**m*r[i] for i in range(4)),sp.zeros(3,1)).applyfunc(sp.expand))
        DN.append(sum((m*delta[i]**(m-1)*Ddelta[i]*r[i]+delta[i]**m*dr[i] for i in range(4)),sp.zeros(3,1)).applyfunc(sp.expand))
    S=sum((v*v.T for v in r),sp.zeros(3)).applyfunc(sp.expand)
    DS=sum((v*w.T+w*v.T for v,w in zip(r,dr)),sp.zeros(3)).applyfunc(sp.expand)
    B=(L*DN[0]-DL*N[0]).applyfunc(sp.expand)
    H=S-L*sp.eye(3)/3;DH=DS-DL*sp.eye(3)/3
    A=(H*H-sp.trace(H*H)*sp.eye(3)/3-2*L**2*sp.eye(3)/9).applyfunc(sp.expand)
    DA=(DH*H+H*DH-2*sp.trace(H*DH)*sp.eye(3)/3-4*L*DL*sp.eye(3)/9).applyfunc(sp.expand)
    directions={'U1':(2,B[0]),
        'K1':(3,((S-L*sp.eye(3))*B+(L*DS-DL*S)*N[0])[0]),
        'K2':(4,((L*DA-2*DL*A)*N[0]+A*B)[0]),
        'V2':(3,(L*DN[1]-2*DL*N[1]-L*B/3)[0]),
        'V3':(4,(L*DN[2]-3*DL*N[2]-7*L**2*B/36)[0])}
    return vs,L,directions

def verify(path,vs,L,directions):
    d=json.loads(path.read_text(encoding='utf-8'));assert d['proved'] is True
    k,response=directions[d['family']]
    p=sp.Poly(sp.expand(L**k/4+sp.Rational(d['coefficient'])*response),*vs)
    raw={m:Fraction(v) for m,v in p.terms()};normal=max(abs(v) for v in raw.values())
    expected={m:v/normal for m,v in raw.items()}
    saved={tuple(row['exponent']):Fraction(row['coefficient'],d['normalization']) for row in d['polynomial_integer_coefficients']}
    assert expected==saved,'Independent derivative polynomial does not match.'
    actual={};sizes=[]
    for block in d['certificate_blocks']:
        monomials=[tuple(x) for x in block['monomials']]
        Q=np.array(block['gram_numerators'],dtype=object);T=np.array(block['congruence_numerators'],dtype=object)
        assert Q.shape==T.shape==(len(monomials),len(monomials))
        assert np.array_equal(Q,Q.T)
        D=block['gram_denominator'];assert D>0
        for i,u in enumerate(monomials):
            for j,v in enumerate(monomials):
                m=tuple(a+b for a,b in zip(u,v));actual[m]=actual.get(m,Fraction())+Fraction(int(Q[i,j]),D)
        S=T.T@Q@T;assert np.array_equal(S,S.T)
        margins=[int(S[i,i]-sum(abs(S[i,j]) for j in range(len(S)) if i!=j)) for i in range(len(S))]
        assert min(margins)>0
        assert min(margins)==block['exact_gershgorin_min_numerator']
        sizes.append(len(Q))
    actual={m:v for m,v in actual.items() if v}
    assert actual==expected,'Exact SOS coefficient identity fails.'
    return {'family':d['family'],'coefficient':d['coefficient'],'proved':True,
            'blocks':sizes,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'checks':['independent material derivative polynomial','exact SOS coefficient identity','exact positive-definite congruences by integer Gershgorin bounds']}

if __name__=='__main__':
    start=time.time();vs,L,directions=derive_independently();rows=[];unresolved=[]
    for family,coefficients in CASES.items():
        for coefficient in coefficients:
            path=ROOT/('sos_'+family+'_'+coefficient.replace('-','minus').replace('.','p')+'.json')
            if not path.exists() or not json.loads(path.read_text()).get('proved'):
                unresolved.append({'family':family,'coefficient':coefficient});continue
            row=verify(path,vs,L,directions);rows.append(row);print('Exact replay PASS',family,coefficient,flush=True)
    result={'verified':rows,'unresolved':unresolved,'all_ten_verified':len(rows)==10,
            'elapsed_seconds':time.time()-start,'scope':'Global sufficient endpoint certificates; no exact boundary maximality assertion.'}
    (ROOT/'SHARPENED_RAYS_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print('Verified',len(rows),'unresolved',len(unresolved),'elapsed',result['elapsed_seconds'],flush=True)
