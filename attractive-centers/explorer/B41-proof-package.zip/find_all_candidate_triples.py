"""Find stable B39 triples numerically containing every certified rational map."""
import itertools,json,os,sys
from pathlib import Path
here=Path(__file__).resolve().parent;root=here.parents[1]
sys.path.insert(0,str(root/'.deps/sympy'))
import numpy as np
import sympy as s
from sympy.polys.domains import QQ
from sympy.polys.rings import ring

work=here/'X5001-X10000'
family=here/'all-ranges-base-study/combined_through_X10000'
base=json.loads((family/'CURRENT_BASE_39_X10000.json').read_text())
catalogue={r['position']:r for r in json.loads((work/'catalogue_formulas.json').read_text())}
screen=json.loads((work/'current_base_screen.json').read_text())
if os.environ.get('AC_TARGET_POSITIONS_FROM_INVARIANTS','0')=='1':
    certified_positions=[r['position'] for r in json.loads((work/'all_candidate_invariants.json').read_text())['targets']]
else:
    certified_positions=[r['position'] for r in screen]
targets=[catalogue[p] for p in certified_positions]
selected=os.environ.get('AC_POSITIONS','').strip()
if selected:
    wanted={int(q) for q in selected.split(',') if q.strip()}
    targets=[row for row in targets if row['position'] in wanted]
R,a,b,c=ring('a,b,c',QQ);per=a+b+c

def invariant(row):
 f=s.cancel(s.sympify(row['formula']));num,den=s.fraction(f);fn,fd=R.from_expr(num),R.from_expr(den)
 ns=[fn,fn.compose([(a,b),(b,c),(c,a)]),fn.compose([(a,c),(b,a),(c,b)])]
 ds=[fd,fd.compose([(a,b),(b,c),(c,a)]),fd.compose([(a,c),(b,a),(c,b)])]
 common=ds[0].lcm(ds[1]).lcm(ds[2]);raw=[n*common.exquo(d) for n,d in zip(ns,ds)]
 g=raw[0].gcd(raw[1]).gcd(raw[2]);raw=[q.exquo(g) for q in raw];D=sum(raw,R.zero)
 l12=(raw[0]-raw[1]).exquo(a-b);l23=(raw[1]-raw[2]).exquo(b-c);W=(l12-l23).exquo(a-c);V=l12-(a+b)*W
 lam=QQ(str(row['lambda']));return lam*V,lam*W,D

base_models=[invariant(r) for r in base];target_models=[invariant(r) for r in targets]
invariants={'base':[{'base_position':i+1,'label':r['label'],'V':str(m[0]),'W':str(m[1]),'D':str(m[2])} for i,(r,m) in enumerate(zip(base,base_models))],
            'targets':[{'position':r['position'],'index':r['index'],'lambda':r['lambda'],'V':str(m[0]),'W':str(m[1]),'D':str(m[2])} for r,m in zip(targets,target_models)]}
(work/os.environ.get('AC_INVARIANTS_OUTPUT','all_candidate_invariants.json')).write_text(json.dumps(invariants,indent=2))

rng=np.random.default_rng(3910000)
shapes=[(d,q) for d in (.0001,.001,.01,.15,.5,.9,.9999) for q in (.0001,.01,.1,1,10,100,10000)]
shapes += [tuple(x) for x in np.column_stack((rng.uniform(.00001,.99999,40),10**rng.uniform(-5,5,40)))]
arr=np.array(shapes);A=1+arr[:,0]+arr[:,1];B=1+arr[:,1];C=np.ones(len(arr));scale=A;A,B,C=A/scale,B/scale,C/scale
sa,sb,sc=s.symbols('a b c')
def evaluate(models):
 out=[]
 for V,W,D in models:
  f=s.lambdify((sa,sb,sc),((sa+sb+sc)*V.as_expr()/D.as_expr(),(sa+sb+sc)**2*W.as_expr()/D.as_expr()),'numpy',cse=True)
  vals=f(A,B,C);out.append(np.array([np.broadcast_to(q,A.shape) for q in vals]).T)
 return np.array(out).transpose(1,0,2)
bp=evaluate(base_models);tp=evaluate(target_models)
combos=np.array(list(itertools.combinations(range(len(base)),3)),dtype=int)
x=bp[:,combos[:,0],:];y=bp[:,combos[:,1],:];z=bp[:,combos[:,2],:]
def cr(o,p,q):return (p[...,0]-o[...,0])*(q[...,1]-o[...,1])-(p[...,1]-o[...,1])*(q[...,0]-o[...,0])
ori=cr(x,y,z);valid=np.all(np.isfinite(ori)&(np.abs(ori)>1e-13),axis=0)
results=[]
margin_tolerance=float(os.environ.get('AC_MARGIN_TOL','1e-9'))
for k,(row,pnt) in enumerate(zip(targets,tp.transpose(1,0,2)),1):
 p0=pnt[:,None,:]
 with np.errstate(divide='ignore',invalid='ignore'):
  aa=cr(p0,y,z)/ori;bb=cr(x,p0,z)/ori;cc=cr(x,y,p0)/ori
  margins=np.nanmin(np.minimum(np.minimum(aa,bb),cc),axis=0)
 margins[~valid]=-np.inf
 order=np.argsort(margins)[::-1]
 choices=[]
 for j in order[:40]:
  if not np.isfinite(margins[j]) or margins[j] < -margin_tolerance:continue
  tri=combos[j]
  choices.append({'margin':float(margins[j]),'base_positions':[int(q)+1 for q in tri],
                  'base_labels':[base[int(q)]['label'] for q in tri]})
 rec={'position':row['position'],'index':row['index'],'lambda':row['lambda'],'candidate_triples':choices}
 results.append(rec);print(json.dumps({'done':k,'total':len(targets),'position':row['position'],'triples':len(choices),'best':choices[:1]}),flush=True)
 (work/os.environ.get('AC_CANDIDATE_OUTPUT','all_candidate_fixed_triples.json')).write_text(json.dumps(results,indent=2))
