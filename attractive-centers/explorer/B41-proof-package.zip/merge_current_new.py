"""Sample the joint hull of the current base and all newly separated maps."""

import json
import os
import sys
from pathlib import Path

p = Path(__file__).resolve().parent
root = p.parents[1]
sys.path.insert(0, str(root / ".deps/sympy"))
import numpy as np
import sympy as s
from sympy.polys.domains import QQ
from sympy.polys.rings import ring

work = p / os.environ.get("AC_WORK", "X3001-X5000")
base_path = Path(os.environ.get(
    "AC_BASE_CATALOGUE",
    work.parent / "X2001-X3000/combined_H23_plus3/catalogue.json",
))
if not base_path.is_absolute():
    base_path = (Path.cwd() / base_path).resolve()
outdir = Path(os.environ.get("AC_OUTDIR", work / "combined_current_plus_new"))
if not outdir.is_absolute():
    outdir = (Path.cwd() / outdir).resolve()
outdir.mkdir(exist_ok=True)

rows = [dict(r, group="previous-current-base") for r in json.loads(base_path.read_text())]
candidates = json.loads((work / "catalogue_formulas.json").read_text())
screen = json.loads((work / "current_base_screen.json").read_text())
explicit = os.environ.get("AC_NEW_POSITIONS", "").strip()
new_positions = (
    [int(q) for q in explicit.split(",") if q.strip()]
    if explicit
    else [r["position"] for r in screen if r["outside_witnesses"]]
)
for pos in new_positions:
    rows.append(dict(next(r for r in candidates if r["position"] == pos), group=os.environ.get("AC_NEW_GROUP", work.name)))
for j, row in enumerate(rows, 1):
    row["merge_position"] = j
    row["label"] = f"F({row['lambda']},X{row['index']})"
(outdir / "catalogue.json").write_text(json.dumps(rows, indent=2))

R, a, b, c = ring("a,b,c", QQ)
models = []
for row in rows:
    f = s.cancel(s.sympify(row["formula"]))
    num, den = s.fraction(f)
    fn, fd = R.from_expr(num), R.from_expr(den)
    ns = [fn, fn.compose([(a, b), (b, c), (c, a)]), fn.compose([(a, c), (b, a), (c, b)])]
    ds = [fd, fd.compose([(a, b), (b, c), (c, a)]), fd.compose([(a, c), (b, a), (c, b)])]
    common = ds[0].lcm(ds[1]).lcm(ds[2])
    raw = [n * common.exquo(d) for n, d in zip(ns, ds)]
    g = raw[0].gcd(raw[1]).gcd(raw[2])
    raw = [q.exquo(g) for q in raw]
    D = sum(raw, R.zero)
    l12 = (raw[0] - raw[1]).exquo(a - b)
    l23 = (raw[1] - raw[2]).exquo(b - c)
    W = (l12 - l23).exquo(a - c)
    V = l12 - (a + b) * W
    lam = QQ(str(row["lambda"]))
    models.append((lam * V, lam * W, D))

rng = np.random.default_rng(30015000)
shapes = [
    (d, q)
    for d in [1e-9, 1e-7, 1e-5, .001, .01, .1, .3, .5, .8, .99, .99999, 1 - 1e-9]
    for q in [1e-8, 1e-6, .0001, .01, .1, .5, 1, 3, 10, 100, 10000, 1e6, 1e8]
]
shapes += [
    (float(d), float(10 ** q))
    for d, q in rng.uniform([1e-9, -9], [1 - 1e-9, 9], (30000, 2))
]
arr = np.array(shapes)
A = 1 + arr[:, 0] + arr[:, 1]
B = 1 + arr[:, 1]
C = np.ones(len(arr))
scale = A
A, B, C = A / scale, B / scale, C / scale

sa, sb, sc = s.symbols("a b c")
points = []
for V, W, D in models:
    per = sa + sb + sc
    func = s.lambdify(
        (sa, sb, sc),
        (per * V.as_expr() / D.as_expr(), per ** 2 * W.as_expr() / D.as_expr()),
        "numpy",
        cse=True,
    )
    vals = func(A, B, C)
    points.append(np.array([np.broadcast_to(q, A.shape) for q in vals]).T)
points = np.array(points).transpose(1, 0, 2)


def cross(u, v):
    return u[..., 0] * v[..., 1] - u[..., 1] * v[..., 0]


def hull_ids(q):
    order = sorted(range(len(q)), key=lambda i: tuple(q[i]))
    parts = []
    for ids in (order, order[::-1]):
        chain = []
        for i in ids:
            while len(chain) > 1 and cross(q[chain[-1]] - q[chain[-2]], q[i] - q[chain[-2]]) <= 1e-11:
                chain.pop()
            chain.append(i)
        parts.append(chain)
    return parts[0][:-1] + parts[1][:-1]


seen = {}
for k, q in enumerate(points):
    if np.isfinite(q).all():
        for j in hull_ids(q):
            seen.setdefault(j + 1, k)

result = {
    "sample_count": len(shapes),
    "old_base_count": len(rows) - len(new_positions),
    "new_separated_count": len(new_positions),
    "sampled_base_positions": sorted(seen),
    "sampled_base_labels": [rows[i - 1]["label"] for i in sorted(seen)],
    "unseen_positions": [i for i in range(1, len(rows) + 1) if i not in seen],
    "unseen_labels": [rows[i - 1]["label"] for i in range(1, len(rows) + 1) if i not in seen],
    "new_seen_labels": [rows[i - 1]["label"] for i in sorted(seen) if rows[i - 1]["group"] != "previous-current-base"],
    "new_unseen_labels": [rows[i - 1]["label"] for i in range(1, len(rows) + 1) if i not in seen and rows[i - 1]["group"] != "previous-current-base"],
    "first_exposure_shape": {str(i): shapes[k] for i, k in seen.items()},
}
(outdir / "sampled_reduction.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
