"""Search exact rational triangle witnesses for representative maps not certified PSD."""

import itertools
import json
import os
import sys
from pathlib import Path

p = Path(__file__).resolve().parent
root = p.parents[1]
sys.path.insert(0, str(root / ".deps/sympy"))
import sympy as s

work = p / os.environ.get("AC_WORK", "X3001-X5000")
a, b, c = s.symbols("a b c")
rows = {r["position"]: r for r in json.loads((work / "catalogue_formulas.json").read_text())}
first = json.loads((work / "first_pass.json").read_text())
positions = [r["position"] for r in first if r.get("certified_interior_PSD") is False]
selected = os.environ.get("AC_POSITIONS", "").strip()
if selected:
    positions = [int(q) for q in selected.split(",")]


def jacobian_minors(row):
    f = s.sympify(row["formula"])
    lam = s.Rational(row["lambda"])
    raws = [f, f.xreplace({a: b, b: c, c: a}), f.xreplace({a: c, b: a, c: b})]
    weights = [s.cancel(lam * r / sum(raws) + (1 - lam) / 3) for r in raws]
    v, t = weights[1:]
    u = (b * b + c * c - a * a) / (2 * c)
    h2 = b * b - u * u
    va, vb = s.cancel(s.diff(v, a)), s.cancel(s.diff(v, b))
    ta, tb = s.cancel(s.diff(t, a)), s.cancel(s.diff(t, b))
    j11 = s.cancel(c * (va * (u - c) / a + vb * u / b) + t + u * (ta * (u - c) / a + tb * u / b))
    j22 = s.cancel(t + h2 * (ta / a + tb / b))
    off = s.cancel((c * (va / a + vb / b) + u * (ta / a + tb / b) + ta * (u - c) / a + tb * u / b) / 2)
    return weights, (j11, j22, s.cancel(j11 * j22 - off * off))


results = []
for pos in positions:
    row = rows[pos]
    weights, minors = jacobian_minors(row)
    witness = None
    # a=y+z, b=z+x, c=x+y parametrizes every strict triangle up to scale.
    values = [s.Rational(1, 8), s.Rational(1, 4), s.Rational(1, 2), 1, 2, 4, 8, 16]
    for x, y, z in itertools.product(values, repeat=3):
        subs = {a: y + z, b: z + x, c: x + y}
        vals = [s.cancel(q.subs(subs)) for q in minors]
        bad = next((i for i, q in enumerate(vals) if q.is_negative), None)
        if bad is not None:
            witness = {
                "triangle_parameters_xyz": list(map(str, (x, y, z))),
                "sides_abc": list(map(str, (y + z, z + x, x + y))),
                "failed_minor": ("S11", "S22", "det")[bad],
                "minor_values": list(map(str, vals)),
                "weights": [str(s.cancel(q.subs(subs))) for q in weights],
            }
            break
    rec = {
        "position": pos,
        "index": row["index"],
        "lambda": row["lambda"],
        "exact_negative_witness": witness,
    }
    results.append(rec)
    print(json.dumps(rec), flush=True)

(work / os.environ.get("AC_NEGATIVE_FILE", "exact_negative_witnesses.json")).write_text(json.dumps(results, indent=2))
