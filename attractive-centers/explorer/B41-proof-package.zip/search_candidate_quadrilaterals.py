"""Numerically propose fixed B39 quadrilaterals for selected target maps.

This is only a proposal stage.  Every accepted proposal must subsequently be
verified with exact polynomial sign certificates.
"""
import itertools, json, os, sys
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[1]
sys.path.insert(0, str(root / ".deps/sympy"))
import numpy as np
import sympy as s

work = here / "X5001-X10000"
data = json.loads((work / "all_candidate_invariants.json").read_text())
base = data["base"]
targets_by_pos = {r["position"]: r for r in data["targets"]}
positions = [int(q) for q in os.environ.get("AC_POSITIONS", "594,595").split(",")]

rng = np.random.default_rng(94459446)
shapes = [(d, q) for d in (1e-8, 1e-6, 1e-4, .01, .1, .3, .5, .8, .99, 1-1e-8)
          for q in (1e-8, 1e-5, .001, .1, 1, 10, 1000, 1e6, 1e8)]
shapes += [tuple(v) for v in np.column_stack((rng.uniform(1e-8, 1-1e-8, 2000),
                                               10**rng.uniform(-8, 8, 2000)))]
arr = np.array(shapes)
A, B, C = 1 + arr[:, 0] + arr[:, 1], 1 + arr[:, 1], np.ones(len(arr))
scale = A
A, B, C = A/scale, B/scale, C/scale
sa, sb, sc = s.symbols("a b c")

def evaluate(rows):
    out = []
    for row in rows:
        V, W, D = (s.sympify(row[k]) for k in ("V", "W", "D"))
        f = s.lambdify((sa, sb, sc), ((sa+sb+sc)*V/D, (sa+sb+sc)**2*W/D),
                       "numpy", cse=True)
        vals = f(A, B, C)
        out.append(np.array([np.broadcast_to(q, A.shape) for q in vals]).T)
    return np.array(out).transpose(1, 0, 2)

bp = evaluate(base)
tp = evaluate([targets_by_pos[p] for p in positions])
triples = list(itertools.combinations(range(len(base)), 3))
triple_index = {t: i for i, t in enumerate(triples)}

def cross(o, p, q):
    return ((p[..., 0]-o[..., 0])*(q[..., 1]-o[..., 1])
            - (p[..., 1]-o[..., 1])*(q[..., 0]-o[..., 0]))

results = []
for pos, target in zip(positions, tp.transpose(1, 0, 2)):
    margins = np.empty((len(shapes), len(triples)))
    for j, (i, k, l) in enumerate(triples):
        P, Q, R = bp[:, i], bp[:, k], bp[:, l]
        den = cross(P, Q, R)
        with np.errstate(divide="ignore", invalid="ignore"):
            aa = cross(target, Q, R)/den
            bb = cross(P, target, R)/den
            cc = cross(P, Q, target)/den
        margins[:, j] = np.minimum(np.minimum(aa, bb), cc)

    proposals = []
    for quad in itertools.combinations(range(len(base)), 4):
        ids = [triple_index[t] for t in itertools.combinations(quad, 3)]
        cover = np.max(margins[:, ids], axis=1)
        score = float(np.nanmin(cover))
        if np.isfinite(score) and score >= -1e-7:
            proposals.append((score, quad))
    proposals.sort(reverse=True)
    rec = {
        "target_position": pos,
        "index": targets_by_pos[pos]["index"],
        "lambda": targets_by_pos[pos]["lambda"],
        "sample_count": len(shapes),
        "candidate_quadrilaterals": [
            {"margin": score,
             "base_positions": [i+1 for i in quad],
             "base_labels": [base[i]["label"] for i in quad]}
            for score, quad in proposals[:100]
        ],
    }
    results.append(rec)
    print(json.dumps({**rec, "candidate_quadrilaterals": rec["candidate_quadrilaterals"][:3]}), flush=True)

(work / "candidate_quadrilaterals_9445_9446.json").write_text(json.dumps(results, indent=2))
