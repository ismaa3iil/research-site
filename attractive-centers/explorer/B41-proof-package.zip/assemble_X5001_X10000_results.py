"""Create audit tables for the X5001--X10000 exact/radical investigation."""
import csv, json
from pathlib import Path

here = Path(__file__).resolve().parent
work = here / "X5001-X10000"
all_candidates = json.loads((work / "candidates.json").read_text())
catalogue = {r["position"]: r for r in all_candidates if r.get("rational")}
classes = json.loads((work / "exact_map_classes.json").read_text())
first = {r["position"]: r for r in json.loads((work / "first_pass.json").read_text())}
second = {r["position"]: r for r in json.loads((work / "second_pass_timeouts.json").read_text())}
negative_rows = json.loads((work / "exact_negative_witnesses.json").read_text())
negative_rows += json.loads((work / "second_pass_negative_witnesses.json").read_text())
negative = {r["position"]: r for r in negative_rows if r.get("exact_negative_witness")}
replay = json.loads((work / "all_containment_replay.json").read_text())
contained = {r["position"]: r["kind"] for r in replay["verified"]}

refined = {}
for path in (work / "refined").glob("entry_*.json"):
    row = json.loads(path.read_text())
    if row.get("certified_PSD_refined") is True:
        refined[row["position"]] = row

table = []
for cls in classes:
    pos = cls["representative_position"]
    row = catalogue[pos]
    proof = second.get(pos, first.get(pos, {}))
    attractive = bool(proof.get("certified_interior_PSD")) or pos in refined
    if pos in negative:
        status = "proved non-attractive"
    elif attractive:
        status = "proved attractive"
    else:
        status = "unresolved attractivity"
    if pos in contained:
        containment = f"universally contained in B39 ({contained[pos]}); replayed"
    elif pos in (594, 595):
        containment = "adjoined to B41; no B39 containment certificate found"
    else:
        containment = "not applicable"
    table.append({
        "representative_position": pos,
        "ETC_index": row["index"],
        "lambda": row["lambda"],
        "formula": row["formula"],
        "class_size": len(cls["members"]),
        "class_members": "; ".join(f"X{m['index']}@{m['lambda']}" for m in cls["members"]),
        "attractivity_status": status,
        "attractivity_certificate": (
            str((work / "proofs" / f"entry_{pos}.json").relative_to(here))
            if attractive else ""
        ),
        "negative_witness": json.dumps(negative[pos]["exact_negative_witness"], separators=(",", ":"))
            if pos in negative else "",
        "containment_status": containment,
        "containment_certificate": (
            str((work / "all_containment_certificates" / f"position_{pos}.json").relative_to(here))
            if pos in contained else ""
        ),
    })

fields = list(table[0])
with (work / "RESULTS_TABLE.csv").open("w", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    writer.writerows(table)

radical = [r for r in all_candidates if not r.get("rational")]
radical_screen = {r["position"]: r for r in json.loads((work / "radical_bounded_results.json").read_text())}
with (work / "AREA_RADICAL_RECORDS.csv").open("w", newline="", encoding="utf-8") as stream:
    fields = ["position", "ETC_index", "lambda", "formula", "bounded_screen_status"]
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for row in radical:
        screen = radical_screen.get(row["position"], {})
        screen_status = screen.get("status")
        if not screen_status:
            screen_status = (
                "exact negative witness found" if screen.get("negative_witness")
                else "bounded low-integer screen completed; no negative witness (not a proof)"
            )
        writer.writerow({
            "position": row["position"], "ETC_index": row["index"],
            "lambda": row["lambda"], "formula": row["formula"],
            "bounded_screen_status": screen_status,
        })

summary = {
    "rational_records": 573,
    "distinct_rational_map_classes": len(table),
    "proved_attractive": sum(r["attractivity_status"] == "proved attractive" for r in table),
    "proved_non_attractive": sum(r["attractivity_status"] == "proved non-attractive" for r in table),
    "unresolved_attractivity": sum(r["attractivity_status"] == "unresolved attractivity" for r in table),
    "replayed_B39_containment": len(contained),
    "adjoined_to_B41": 2,
    "genuine_area_radical_records": len(radical),
}
(work / "RESULTS_SUMMARY.json").write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
