"""Bounded exact first pass for historical X151-X300 rational endpoints."""
import csv,json,sys,subprocess,time,importlib.util,re,os
from pathlib import Path
from fractions import Fraction
low,high=map(int,os.environ.get('AC_RANGE','151,300').split(','))
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'.deps/sympy'))
work=Path(__file__).resolve().parent/f'X{low}-X{high}'
work.mkdir(exist_ok=True);(work/'proofs').mkdir(exist_ok=True)
old=root/'output/handoff-audit/proofs192/Attractive_Centers_192_Proofs_Handoff'
if len(sys.argv)>1 and sys.argv[1]=='worker':
    sys.path.insert(0,str(old));import fast192
    fast192.p=work;fast192.run(int(sys.argv[2]));sys.exit()
import sympy as s
from sympy.parsing.mathematica import parse_mathematica
a,b,c=s.symbols('a b c')
if low>300:
    raw_path=work.parent/f'raw{low}_{high}.json'
    raw={int(r['Index']):r for r in json.loads(raw_path.read_text())}
    assert sorted(raw)==list(range(low,high+1)), f'incomplete formula export: {raw_path}'
    provenance=os.environ.get('AC_FORMULA_PROVENANCE','Local ETC.mx exported by installed Mathematica; S=twice area')
else:
    with (root/'etc_attractivity_first300.csv').open(encoding='utf-8-sig',newline='') as f:raw={int(r['Index']):r for r in csv.DictReader(f) if low<=int(r['Index'])<=high}
    provenance='Historical etc_attractivity_first300.csv ETCFunction; S=twice area'
with (root/'ETC_BoundaryCandidates_Rational_X1_X11799.csv').open(encoding='utf-8-sig',newline='') as f:chosen=[r for r in csv.DictReader(f) if low<=int(r['SourceIndex'])<=high]
rows=[];rational=[]
for j,r in enumerate(chosen,1):
    i=int(r['SourceIndex']);expr=parse_mathematica(re.sub(r'\bS\b','areaToken',raw[i]['ETCFunction']))
    expr=expr.subs(s.Symbol('areaToken'),s.sqrt((a+b+c)*(-a+b+c)*(a-b+c)*(a+b-c))/2)
    rec=dict(position=j,index=i,endpoint=r['Endpoint'],**{'lambda':str(Fraction(r['Rational']))},formula=str(expr),source=provenance,
             numerical_lambda=r['Lambda'],historical_record=raw[i],rational=bool(expr.is_rational_function(a,b,c)))
    rows.append(rec)
    if rec['rational']:rational.append(rec)
(work/'candidates.json').write_text(json.dumps(rows,indent=2))
(work/'catalogue_formulas.json').write_text(json.dumps(rational,indent=2))
if os.environ.get('AC_PREP_ONLY','0')=='1':
    print('PREPARED',len(rows),'candidates;',len(rational),'rational',flush=True)
    sys.exit()
results=[]
result_path=work/os.environ.get('AC_RESULT_FILE','first_pass.json')
selected=os.environ.get('AC_POSITIONS','').strip()
selected_positions=set(map(int,selected.split(','))) if selected else None
timeout_seconds=int(os.environ.get('AC_WORKER_TIMEOUT','35'))
for r in rows:
    n=r['position'];start=time.monotonic()
    if selected_positions is not None and n not in selected_positions:
        continue
    if not r['rational']:
        results.append(dict(position=n,index=r['index'],parameter=r['lambda'],status='Radical formula: deferred to separate method'));continue
    try:
        p=subprocess.run([sys.executable,'-X','utf8',__file__,'worker',str(n)],capture_output=True,text=True,timeout=timeout_seconds)
        rec=dict(position=n,index=r['index'],parameter=r['lambda'],returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
        if p.returncode==0:
            cert=json.loads((work/'proofs'/f'entry_{n}.json').read_text())
            rec.update(certified_interior_PSD=cert['certified_PSD'],flat_denominators_nonzero=cert['flat_denominators_nonzero'])
        else:rec['status']='Worker error: inconclusive'
    except subprocess.TimeoutExpired:rec=dict(position=n,index=r['index'],parameter=r['lambda'],status=f'{timeout_seconds}-second timeout: inconclusive')
    rec['seconds']=round(time.monotonic()-start,3);results.append(rec)
    result_path.write_text(json.dumps(results,indent=2));print(json.dumps(rec),flush=True)
result_path.write_text(json.dumps(results,indent=2))
print('DONE',len(rows),'candidates;',len(rational),'rational',flush=True)
