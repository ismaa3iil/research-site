"""Exact rational exposure screen for the combined verified 40-map family."""
import json, os, sys, math
from fractions import Fraction as Q
from pathlib import Path

here=Path(__file__).resolve().parent
root=here.parents[1]
sys.path.insert(0,str(root/'.deps/sympy'))
import sympy as s
from sympy.polys.domains import QQ
from sympy.polys.rings import ring

work=Path(os.environ.get('AC_FAMILY_DIR',here/'all-ranges-base-study/combined_40'))
if not work.is_absolute():work=(Path.cwd()/work).resolve()
rows=json.loads((work/'catalogue.json').read_text())
R,a,b,c=ring('a,b,c',QQ)

def normalize(row):
    expr=s.cancel(s.sympify(row['formula']));num,den=s.fraction(expr)
    fn,fd=R.from_expr(num),R.from_expr(den)
    subs=[[],[(a,b),(b,c),(c,a)],[(a,c),(b,a),(c,b)]]
    ns=[fn if not q else fn.compose(q) for q in subs]
    ds=[fd if not q else fd.compose(q) for q in subs]
    common=ds[0].lcm(ds[1]).lcm(ds[2]);raw=[n*common.exquo(d) for n,d in zip(ns,ds)]
    g=raw[0].gcd(raw[1]).gcd(raw[2]);raw=[v.exquo(g) for v in raw]
    D=sum(raw,R.zero);lam=R.domain.convert(s.Rational(row['lambda']))
    N=[lam*v+(1-lam)*D/3 for v in raw]
    g2=N[0].gcd(N[1]).gcd(N[2]).gcd(D)
    if g2 and g2!=R.one:N,D=[v.exquo(g2) for v in N],D.exquo(g2)
    return N,D

def value(model,t):
    N,D=model;sub=list(zip((a,b,c),t));d=Q(str(D.evaluate(sub)))
    if not d:raise ZeroDivisionError
    return tuple(Q(str(n.evaluate(sub)))/d for n in N)[1:]

def cross(o,p,q):return (p[0]-o[0])*(q[1]-o[1])-(p[1]-o[1])*(q[0]-o[0])
def hull(points):
    pts=sorted(set(points));lo=[];up=[]
    for q in pts:
        while len(lo)>1 and cross(lo[-2],lo[-1],q)<=0:lo.pop()
        lo.append(q)
    for q in reversed(pts):
        while len(up)>1 and cross(up[-2],up[-1],q)<=0:up.pop()
        up.append(q)
    return lo[:-1]+up[:-1]

models=[normalize(r) for r in rows]
triangles=set()
sample_only=os.environ.get('AC_SAMPLE_ONLY','0')=='1'
extreme_only=os.environ.get('AC_EXTREME_ONLY','0')=='1'
sample=json.loads((work/'sampled_reduction.json').read_text())
for d0,q0 in sample['first_exposure_shape'].values():
    d,q=Q(str(d0)),Q(str(q0))
    sides=(1+d+q,1+q,Q(1))
    scale=math.lcm(*(v.denominator for v in sides))
    triangles.add(tuple(int(v*scale) for v in sides))
if extreme_only:
    ds={Q(1,2),Q(1,3),Q(2,3),Q(1,4),Q(3,4)}
    ds.update(Q(1,10**k) for k in range(1,13))
    ds.update(1-Q(1,10**k) for k in range(1,13))
    qs={Q(1)}
    qs.update(Q(10**k) for k in range(1,11))
    qs.update(Q(1,10**k) for k in range(1,11))
    for d in ds:
        for q in qs:
            sides=(1+d+q,1+q,Q(1))
            scale=math.lcm(*(v.denominator for v in sides))
            triangles.add(tuple(int(v*scale) for v in sides))
if not sample_only and not extreme_only:
    # The systematic low-height grid supplements the sampled exposure shapes.
    pass
if not sample_only and not extreme_only:
    for aa in range(2,51):
        for bb in range(2,aa+1):
            for cc in range(1,bb+1):
                if bb+cc>aa:triangles.add((aa,bb,cc))
    for ratio in (50,100,500,1000,10000):
        triangles.update({(ratio,ratio,1),(ratio,ratio-1,2),(ratio,ratio//2+1,ratio//2)})

witnesses={}; valid=0
for tri in sorted(triangles):
    try:pts=[value(m,tri) for m in models]
    except ZeroDivisionError:continue
    valid+=1
    for i,pt in enumerate(pts):
        if i in witnesses:continue
        poly=hull(pts[:i]+pts[i+1:])
        if len(poly)<3:continue
        for A,B in zip(poly,poly[1:]+poly[:1]):
            gap=cross(A,B,pt)
            if gap<0:
                witnesses[i]={'sides':tri,'point':list(map(str,pt)),
                    'edge':[list(map(str,A)),list(map(str,B))],
                    'negative_orientation':str(gap)}
                print(i+1,rows[i]['label'],tri,flush=True);break
    if len(witnesses)==len(rows):break

result={'family_size':len(rows),'triangles_tested':valid,
        'proved_necessary_positions':[i+1 for i in sorted(witnesses)],
        'proved_necessary_labels':[rows[i]['label'] for i in sorted(witnesses)],
        'unresolved_positions':[i+1 for i in range(len(rows)) if i not in witnesses],
        'unresolved_labels':[rows[i]['label'] for i in range(len(rows)) if i not in witnesses],
        'witnesses':{str(i+1):w for i,w in sorted(witnesses.items())}}
output_name=('exact_extreme_exposure.json' if extreme_only else ('exact_sample_exposure.json' if sample_only else 'exact_exposure_screen.json'))
(work/output_name).write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='witnesses'},indent=2))
