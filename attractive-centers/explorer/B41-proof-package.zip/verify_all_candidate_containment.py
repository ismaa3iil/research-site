"""Independent exact replay of all X5001--X10000 containment certificates."""
import itertools, json, sys
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[1]
sys.path.insert(0, str(root / ".deps/sympy"))
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import QQ

work = here / "X5001-X10000"
certdir = work / "all_containment_certificates"
R, a, b, c = ring("a,b,c", QQ)
T, x, y, z = ring("x,y,z", QQ)
per = a+b+c
raw = json.loads((work / "all_candidate_invariants.json").read_text())

def datum(row):
    V, W, D = [R.from_expr(s.sympify(row[k])) for k in ("V", "W", "D")]
    sign = 1 if D.evaluate([(a, QQ(5)), (b, QQ(4)), (c, QQ(3))]) > 0 else -1
    return [sign*per*V, sign*per*per*W, sign*D]

BASE = {r["base_position"]: datum(r) for r in raw["base"]}
TARGET = {r["position"]: datum(r) for r in raw["targets"]}

def det(A, B, C):
    return (A[0]*(B[1]*C[2]-B[2]*C[1])
            - A[1]*(B[0]*C[2]-B[2]*C[0])
            + A[2]*(B[0]*C[1]-B[1]*C[0]))

def transform(f):
    out = T.zero
    targets = [2*z+2*x+y, 2*z+x+y, 2*z+x]
    degree = max(map(sum, f), default=0)
    powers = [[q**i for i in range(degree+1)] for q in targets]
    for (i, j, k), coefficient in f.items():
        out += coefficient*powers[0][i]*powers[1][j]*powers[2][k]
    return out

def check(poly, certificate):
    method = certificate["method"]
    if method == "zero":
        assert not poly
    elif method == "coefficients":
        assert poly and min(poly.values()) >= 0
    elif method == "positive multiplier":
        assert min((poly*(x+y+z)**certificate["power"]).values()) >= 0
    elif method == "six ordering cones":
        for perm in itertools.permutations((x, y, z)):
            q = poly.compose(list(zip(perm, [x, x+y, x+y+z])))
            assert q and min(q.values()) >= 0
    else:
        raise ValueError(method)

verified, unresolved = [], []
for path in sorted(certdir.glob("position_*.json"), key=lambda p: int(p.stem.split("_")[-1])):
    record = json.loads(path.read_text())
    target_position = record["target_position"]
    if not record.get("proved_universal_containment"):
        unresolved.append(target_position)
        continue
    target = TARGET[target_position]
    if record["kind"] == "exact-identity":
        base = BASE[record["base_position"]]
        assert all(target[i]*base[2] == base[i]*target[2] for i in range(2))
    else:
        i, j, k = record["base_positions"]
        P, Q, U = BASE[i], BASE[j], BASE[k]
        polys = [det(P,Q,U), det(target,Q,U), det(P,target,U), det(P,Q,target)]
        common = polys[0]
        for q in polys[1:]:
            common = common.gcd(q)
        assert str(common) == record["common_factor_removed"]
        polys = [q.exquo(common)*record["sign"] for q in polys]
        for q, stored in zip(polys, record["polynomials"]):
            transformed = transform(q)
            assert transformed == T.from_expr(s.sympify(stored["polynomial"]))
            check(transformed, stored["certificate"])
    verified.append({"position": target_position, "kind": record["kind"], "verified": True})

result = {"verified_certificates": len(verified), "unresolved_positions": unresolved,
          "verified": verified}
(work / "all_containment_replay.json").write_text(json.dumps(result, indent=2))
print(json.dumps({"verified_certificates": len(verified),
                  "unresolved_positions": unresolved}, indent=2))
