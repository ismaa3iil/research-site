"""Bounded exact fixed-triple containment proofs for all rational maps."""
import itertools,json,os,subprocess,sys,time
from pathlib import Path

here=Path(__file__).resolve().parent;root=here.parents[1]
sys.path.insert(0,str(root/'.deps/sympy'))
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import QQ

work=here/'X5001-X10000';family=here/'all-ranges-base-study/combined_through_X10000'
certdir=work/'all_containment_certificates';certdir.mkdir(exist_ok=True)
R,a,b,c=ring('a,b,c',QQ);T,x,y,z=ring('x,y,z',QQ);per=a+b+c
inv=json.loads((work/'all_candidate_invariants.json').read_text())
base_rows=json.loads((family/'CURRENT_BASE_39_X10000.json').read_text())
triple_rows={r['position']:r for r in json.loads((work/'all_candidate_fixed_triples.json').read_text())}

def datum(r):
 V,W,D=[R.from_expr(s.sympify(r[k])) for k in ('V','W','D')]
 test=D.evaluate([(a,QQ(5)),(b,QQ(4)),(c,QQ(3))]);sgn=1 if test>0 else -1
 return [sgn*per*V,sgn*per*per*W,sgn*D]
BASE={r['base_position']:datum(r) for r in inv['base']}
TARGET={r['position']:datum(r) for r in inv['targets']}
TARGET_ROWS={r['position']:r for r in inv['targets']}

def same(A,B):
 return all(A[i]*B[2]==B[i]*A[2] for i in range(2))
def det(A,B,C):
 return A[0]*(B[1]*C[2]-B[2]*C[1])-A[1]*(B[0]*C[2]-B[2]*C[0])+A[2]*(B[0]*C[1]-B[1]*C[0])
def trans(f):
 out=T.zero;targets=[2*z+2*x+y,2*z+x+y,2*z+x];degree=max(map(sum,f),default=0)
 powers=[[q**i for i in range(degree+1)] for q in targets]
 for (i,j,k),coef in f.items():out+=coef*powers[0][i]*powers[1][j]*powers[2][k]
 return out
def pos(f):
 if not f:return {'method':'zero'}
 if min(f.values())>=0:return {'method':'coefficients','terms':len(f)}
 q=f
 for power in range(1,5):
  q*=x+y+z
  if min(q.values())>=0:return {'method':'positive multiplier','power':power,'terms':len(q)}
 orders=[]
 for perm in itertools.permutations((x,y,z)):
  q=f.compose(list(zip(perm,[x,x+y,x+y+z])))
  if min(q.values())<0:return None
  orders.append(list(map(str,perm)))
 return {'method':'six ordering cones','orders':orders}
def prove(target,tri):
 A=TARGET[target];i,j,k=tri;P,Q,U=BASE[i],BASE[j],BASE[k]
 polys=[det(P,Q,U),det(A,Q,U),det(P,A,U),det(P,Q,A)]
 if not polys[0]:return None
 g=polys[0]
 for q in polys[1:]:g=g.gcd(q)
 polys=[q.exquo(g) for q in polys]
 test=polys[0].evaluate([(a,QQ(5)),(b,QQ(4)),(c,QQ(3))])
 if test==0:test=polys[0].evaluate([(a,QQ(6)),(b,QQ(5)),(c,QQ(3))])
 if test==0:return None
 sign=1 if test>0 else -1;records=[]
 for name,q in zip(('orientation','alpha','beta','gamma'),polys):
  transformed=trans(q*sign);cert=pos(transformed)
  if cert is None:return None
  records.append({'name':name,'polynomial':str(transformed),'certificate':cert})
 return {'kind':'fixed-triple','target_position':target,'base_positions':list(tri),
         'base_labels':[base_rows[q-1]['label'] for q in tri],
         'common_factor_removed':str(g),'sign':sign,
         'ordered_substitution':['a=2z+2x+y','b=2z+x+y','c=2z+x'],
         'polynomials':records,'proved_universal_containment':True}

def run(position):
 row=TARGET_ROWS[position];A=TARGET[position]
 for i,B in BASE.items():
  if same(A,B):
   result={'kind':'exact-identity','target_position':position,'base_position':i,
           'base_label':base_rows[i-1]['label'],'proved_universal_containment':True}
   break
 else:
  result=None
  for item in triple_rows[position]['candidate_triples'][:int(os.environ.get('AC_MAX_TRIPLES','40'))]:
   result=prove(position,tuple(item['base_positions']))
   if result:break
  if result is None:result={'kind':'unresolved','target_position':position,'proved_universal_containment':False}
 result.update({'index':row['index'],'lambda':row['lambda']})
 (certdir/f'position_{position}.json').write_text(json.dumps(result,indent=2))
 print(json.dumps({k:v for k,v in result.items() if k!='polynomials'}),flush=True)
 return result

if len(sys.argv)>1 and sys.argv[1]=='worker':
 run(int(sys.argv[2]));raise SystemExit

if os.environ.get('AC_DIRECT','0')=='1':
 selected=os.environ.get('AC_POSITIONS','').strip()
 positions={int(q) for q in selected.split(',') if q.strip()} if selected else None
 targets=[row for row in inv['targets'] if positions is None or row['position'] in positions]
 output=work/os.environ.get('AC_OUTPUT','all_containment_pass_direct.json')
 results=[]
 for count,row in enumerate(targets,1):
  start=time.monotonic();rec=run(row['position']);rec['seconds']=round(time.monotonic()-start,3);results.append(rec)
  output.write_text(json.dumps(results,indent=2))
  print(json.dumps({'done':count,'total':len(targets),'position':row['position'],'kind':rec['kind'],'seconds':rec['seconds']}),flush=True)
 raise SystemExit

timeout=int(os.environ.get('AC_WORKER_TIMEOUT','25'));results=[]
for count,row in enumerate(inv['targets'],1):
 position=row['position'];start=time.monotonic()
 try:
  p=subprocess.run([sys.executable,'-X','utf8',__file__,'worker',str(position)],capture_output=True,text=True,timeout=timeout)
  path=certdir/f'position_{position}.json'
  if p.returncode==0 and path.exists():rec=json.loads(path.read_text())
  else:rec={'kind':'worker-error','target_position':position,'index':row['index'],'lambda':row['lambda'],'proved_universal_containment':False,'stderr':p.stderr[-1000:]}
 except subprocess.TimeoutExpired:
  rec={'kind':f'{timeout}-second-timeout','target_position':position,'index':row['index'],'lambda':row['lambda'],'proved_universal_containment':False}
 rec['seconds']=round(time.monotonic()-start,3);results.append(rec)
 (work/'all_containment_pass.json').write_text(json.dumps(results,indent=2))
 print(json.dumps({'done':count,'total':len(inv['targets']),**{k:v for k,v in rec.items() if k!='polynomials'}}),flush=True)
