"""Finalize the smallest currently proved-sufficient rational family through X10000."""
import csv, json
from pathlib import Path

here = Path(__file__).resolve().parent
family = here / "all-ranges-base-study/combined_through_X10000_B41"
rows = json.loads((family / "catalogue.json").read_text())
exposure = json.loads((family / "exact_sample_exposure.json").read_text())
necessary = set(exposure["proved_necessary_positions"])

for i, row in enumerate(rows, 1):
    row["current_base_position"] = i
    row["necessity_status"] = (
        "proved necessary in B41" if i in necessary
        else "not proved necessary; retained for proved sufficiency"
    )

out_json = family / "CURRENT_BASE_41_X10000.json"
out_json.write_text(json.dumps(rows, indent=2))

undecided = [row for row in rows if row["current_base_position"] not in necessary]
summary = {
    "scope": "selected rational boundary maps through X10000; excludes 99 genuine area/radical records",
    "proved_attractive_distinct_rational_maps_X5001_X10000": 449,
    "maps_with_replayed_universal_containment_in_B39": 447,
    "maps_adjoined_for_proved_sufficiency": ["F(-1/2,X9445)", "F(-1/2,X9446)"],
    "proved_sufficient_base_size": 41,
    "proved_necessary_base_members": len(necessary),
    "minimum_cardinality_lower_bound": len(necessary),
    "minimum_cardinality_upper_bound": len(rows),
    "minimum_proved_exactly": False,
    "claim": "B41 is the smallest proved-sufficient family currently found, not a proof that 41 is minimal.",
    "undecided_positions": [row["current_base_position"] for row in undecided],
    "undecided_labels": [row["label"] for row in undecided],
    "base_labels": [row["label"] for row in rows],
}
(family / "BASE_41_SUMMARY.json").write_text(json.dumps(summary, indent=2))

with (family / "BASE_41.csv").open("w", newline="", encoding="utf-8") as stream:
    fields = ["current_base_position", "label", "index", "lambda", "group",
              "necessity_status", "formula"]
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for row in rows:
        writer.writerow({key: row.get(key, "") for key in fields})

print(json.dumps(summary, indent=2))
