"""Bounded independent audit; no source files, website, or paper are modified.

Numerical diagnostics are NOT global certificates. Run serially with BLAS=1.
"""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import json
from pathlib import Path
import time
import itertools
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
from scipy.optimize import differential_evolution

ROOT = Path(__file__).resolve().parent
BENCH = np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.],[3.,-2.,.5]])
LO, HI = 4-2*np.sqrt(2), 4+2*np.sqrt(2)
NAMES = ['U1','K1','K2','V2','V3','HU1','H2trU1','U2']

def bases(p):
    p=np.asarray(p)
    r=p-p.mean(axis=-2,keepdims=True)
    L=(r*r).sum(axis=(-2,-1))
    rho=(r*r).sum(axis=-1)/L[...,None]
    delta=rho-.25
    S=np.einsum('...ia,...ib->...ab',r,r)/L[...,None,None]
    H=S-np.eye(3)/3
    H2=H@H
    H2=H2-np.trace(H2,axis1=-2,axis2=-1)[...,None,None]*np.eye(3)/3
    U1=(delta[...,None]*r).sum(axis=-2)
    U2=((delta**2)[...,None]*r).sum(axis=-2)
    U3=((delta**3)[...,None]*r).sum(axis=-2)
    HU=np.einsum('...ab,...b->...a',H,U1)
    H2U=np.einsum('...ab,...b->...a',H2,U1)
    return np.stack([U1,HU-2*U1/3,H2U-2*U1/9,
                     U2-U1/3,U3-7*U1/36,HU,H2U,U2],axis=-2)

def responses(p):
    p=np.asarray(p,dtype=float)
    cols=[]
    for j in range(3):
        q=p.astype(complex)
        q[...,0,j]+=1e-25j
        cols.append(bases(q).imag/1e-25)
    J=np.stack(cols,axis=-1)
    return (J+np.swapaxes(J,-1,-2))/2

def exact_checks():
    P=sp.Matrix([[0,0,0],[1,0,0],[0,1,0],[3,-2,sp.Rational(1,2)]])
    g=sum((P.row(i).T for i in range(4)),sp.zeros(3,1))/4
    r=[P.row(i).T-g for i in range(4)]
    L=sum(v.dot(v) for v in r)
    rho=[v.dot(v)/L for v in r]
    d=[v-sp.Rational(1,4) for v in rho]
    U=[sum((d[i]**m*r[i] for i in range(4)),sp.zeros(3,1)) for m in (1,2,3)]
    S=sum((v*v.T for v in r),sp.zeros(3))/L
    H=S-sp.eye(3)/3
    H2=H*H-sp.trace(H*H)*sp.eye(3)/3
    K=[U[0],(S-sp.eye(3))*U[0],(H2-2*sp.eye(3)/9)*U[0]]
    V=[U[0],U[1]-U[0]/3,U[2]-7*U[0]/36]
    dets={'KS':sp.Matrix.hstack(*K).det(),
          'VM':sp.Matrix.hstack(*V).det(),
          'SV':sp.Matrix.hstack(K[0],K[1],V[1]).det()}
    aug=sp.Matrix.vstack(sp.ones(1,4),P.T)
    signedvol=aug.det()/6
    vand=sp.prod(rho[j]-rho[i] for i in range(4) for j in range(i+1,4))
    assert sp.simplify(dets['VM']-sp.Rational(3,2)*signedvol*vand)==0
    F=[sum((r[j]-r[k]).dot(r[j]-r[k]) for j,k in itertools.combinations([j for j in range(4) if j!=i],2)) for i in range(4)]
    assert all(sp.simplify(F[i]-(3*L-4*r[i].dot(r[i])))==0 for i in range(4))
    assert all(sp.simplify(d[i]-(sp.Rational(1,2)-F[i]/(4*L)))==0 for i in range(4))
    # Direct symbolic differentiation verifies the supplied U1 Jacobian.
    z=sp.symbols('z0:3')
    PP=[sp.Matrix(z),P.row(1).T,P.row(2).T,P.row(3).T]
    gg=sum(PP,sp.zeros(3,1))/4
    rr=[v-gg for v in PP]
    LL=sum(v.dot(v) for v in rr)
    UU=sum(((v.dot(v)/LL-sp.Rational(1,4))*v for v in rr),sp.zeros(3,1))
    JJ=UU.jacobian(z).subs(dict(zip(z,[0,0,0])))
    formula=d[0]*sp.eye(3)+2*r[0]*r[0].T/L-S/2-2*U[0]*r[0].T/L
    assert JJ==formula
    # The cubic factorization in the report is correct.
    t=sp.symbols('t')
    assert sp.expand((t-sp.sqrt(2))*(5*t*t+8*sp.sqrt(2)*t+1) - (5*t**3+3*sp.sqrt(2)*t*t-15*t-sp.sqrt(2)))==0
    h=np.array([.2,-.3,.7]);errors=[]
    SS=responses(BENCH)
    for i in range(len(NAMES)):
        exact=exact_directional_response(BENCH,h,i,'1')
        numeric=float(h@(np.eye(3)/4+SS[i])@h)
        errors.append(abs(numeric-exact['response_float']))
    assert max(errors)<2e-13
    return {'determinants':{k:{'exact':str(v),'float':float(v)} for k,v in dets.items()},
            'benchmark_volume':float(abs(signedvol)),
            'correct_delta_identity':'delta_i = 1/2 - F_i/(4L)',
            'U1_Jacobian_exact_check':True,'VM_determinant_exact_check':True,
            'all_eight_generators_rational_vs_complex_step_max_error':max(errors)}

def spectral_audit():
    rng=np.random.default_rng(20261017)
    p=rng.normal(size=(12000,4,3))
    ev=np.linalg.eigvalsh(responses(p))
    ans={name:{'random_min':float(ev[:,i,0].min()),'random_max':float(ev[:,i,-1].max())} for i,name in enumerate(NAMES)}
    bounds=[4,7,8,6,4]
    ans['conservative_domain_regression']={NAMES[i]:{
         'proved_operator_bound':b,
         'symmetric_ray_interval':[-1/(4*b),1/(4*b)],
         'random_minimum_endpoint_response':float(min(.25+ev[:,i,0].min()/(4*b),.25-ev[:,i,-1].max()/(4*b)))
         } for i,b in enumerate(bounds)}
    def obj(x,sign):
        q=np.vstack((x.reshape(3,3),-x.reshape(3,3).sum(axis=0)))
        if np.linalg.norm(q)<1e-10:return 1e6
        e=np.linalg.eigvalsh(responses(q)[0])
        return e[0] if sign==1 else -e[-1]
    for sign in (1,-1):
        fit=differential_evolution(lambda x:obj(x,sign),[(-1,1)]*9,
              seed=45+sign,popsize=7,maxiter=120,tol=1e-9,polish=True,workers=1)
        q=np.vstack((fit.x.reshape(3,3),-fit.x.reshape(3,3).sum(axis=0)))
        ans['U1']['optimized_'+('min' if sign==1 else 'max')]=float(sign*fit.fun)
        ans['U1']['shape_'+('min' if sign==1 else 'max')]=q.tolist()
    return ans

def anchors(P):
    C=np.concatenate([np.eye(4),np.array([(np.eye(4)[i]+np.eye(4)[j])/2 for i,j in itertools.combinations(range(4),2)]),(np.ones((4,4))-np.eye(4))/3])
    return C,C@P

def power(A,p,w,start=None):
    x=np.average(A,axis=0,weights=w) if start is None else np.array(start,copy=True)
    def energy(z): return np.dot(w,np.linalg.norm(z-A,axis=1)**p)/p
    for it in range(150):
        v=x-A
        r=np.linalg.norm(v,axis=1)
        good=r>1e-15
        f=np.zeros(len(r));f[good]=w[good]*r[good]**(p-2)
        grad=(f[:,None]*v).sum(axis=0)
        if np.linalg.norm(grad)<3e-12:break
        safe=np.maximum(r,1e-14)
        hh=w*safe**(p-2)
        H=hh.sum()*np.eye(3)+(p-2)*np.einsum('i,ia,ib->ab',hh/safe**2,v,v)
        step=np.linalg.solve(H,grad)
        alpha=1.;old=energy(x)
        for back in range(45):
            trial=x-alpha*step
            if energy(trial)<=old-1e-4*alpha*np.dot(grad,step):break
            alpha*=.5
        x=trial
    v=x-A;r=np.linalg.norm(v,axis=1)
    good=r>1e-15;f=np.zeros(len(r));f[good]=w[good]*r[good]**(p-2)
    residual=np.linalg.norm((f[:,None]*v).sum(axis=0))
    return x,residual

def constellation_audit(pcount=41, weightsteps=8, basecount=301):
    G=BENCH.mean(axis=0);scale=np.max(np.linalg.norm(BENCH-G,axis=1))
    P=(BENCH-G)/scale;C,A=anchors(P)
    vertex=np.array([power(P,p,np.ones(4)/4) for p in np.unique(np.r_[np.linspace(LO,HI,basecount),2.])],dtype=object)
    base=np.stack(vertex[:,0]);res=[float(z) for z in vertex[:,1]]
    samples=[];labels=[]
    ps=np.unique(np.r_[np.linspace(LO,HI,pcount),2.])
    for p in ps:
        for i in range(weightsteps+1):
            for j in range(weightsteps+1-i):
                wE=i/weightsteps;wF=j/weightsteps;wV=1-wE-wF
                w=np.r_[np.full(4,wV/4),np.full(6,wE/6),np.full(4,wF/4)]
                pt,r=power(A,p,w)
                res.append(r)
                if r<2e-9:
                    samples.append(pt);labels.append([p,wE,wF])
    points=np.asarray(samples);hb=ConvexHull(base);he=ConvexHull(np.r_[base,points])
    face=-base/3
    hf=ConvexHull(np.r_[base,face])
    extra=points@hf.equations[:,:3].T+hf.equations[:,3]
    outside=points@hb.equations[:,:3].T+hb.equations[:,3]
    k,l=np.unravel_index(np.argmax(outside),outside.shape)
    pp,we,wf=labels[k]
    def cpoint(par):
        p,e,f=par
        w=np.r_[np.full(4,(1-e-f)/4),np.full(6,e/6),np.full(4,f/4)]
        return power(A,p,w)[0]
    par=np.array([3.3,.2,.25]);dd=1e-4
    derivative=np.column_stack([(cpoint(par+dd*np.eye(3)[i])-cpoint(par-dd*np.eye(3)[i]))/(2*dd) for i in range(3)])
    U=bases(P)
    # Reproduce claimed polynomial octahedra only as unverified numerical sets.
    ranges=[[-1/3,.31941984],[-.8677,.9030],[-1.9755,1.9804],[-1.4523,2.1168],[-2.8733,2.8670]]
    raw=[];vols={}
    for name,ids in [('KS',[0,1,2]),('VM',[0,3,4]),('SV',[0,1,3])]:
        v=np.asarray([c*U[i] for i in ids for c in ranges[i]])
        raw.extend(v);vols[name]=float(ConvexHull(v).volume*scale**3)
    combined=ConvexHull(np.r_[base,points,np.asarray(raw)])
    safe=[]
    for name,ids,bounds in [('KS',[0,1,2],[1/16,1/28,1/32]),('VM',[0,3,4],[1/16,1/24,1/16]),('SV',[0,1,3],[1/16,1/28,1/24])]:
        safe.extend([sign*b*U[i] for i,b in zip(ids,bounds) for sign in (-1,1)])
    hs=ConvexHull(np.r_[base,points,np.asarray(safe)])
    return {'baseline_samples':len(base),'constellation_samples':len(points),
            'p_samples':len(ps),'weight_subdivisions':weightsteps,
            'max_normalized_stationarity_residual':max(res),
            'max_baseline_residual':max(float(z) for z in vertex[:,1]),
            'rejected_constellation_samples':len(ps)*(weightsteps+1)*(weightsteps+2)//2-len(points),
            'vertex_power_hull_volume':float(hb.volume*scale**3),
            'constellation_hull_volume':float(he.volume*scale**3),
            'constellation_to_vertex_ratio':float(he.volume/hb.volume),
            'vertex_and_face_only_volume':float(hf.volume*scale**3),
            'mixture_support_gap_beyond_vertex_and_face':float(extra.max()*scale),
            'safe_polynomial_plus_constellation_hull_volume':float(hs.volume*scale**3),
            'strict_numerical_support_gap':float(outside[k,l]*scale),
            'support_witness_parameters':[pp,we,wf],
            'support_witness_point':(points[k]*scale+G).tolist(),
            'parameter_jacobian_at_3_3_0_2_0_25':derivative.tolist(),
            'parameter_jacobian_determinant':float(np.linalg.det(derivative)*scale**3),
            'unverified_polynomial_octahedron_volumes':vols,
            'unverified_combined_hull_volume':float(combined.volume*scale**3),
            'numerical_scope':'Finite samples and double precision only. Polynomial ray endpoints are not certified by this computation.'}

def exact_directional_response(Pnums,hnums,index,cstr):
    P=[sp.Matrix([sp.Rational(str(round(float(v),7))) for v in row]) for row in Pnums]
    h=sp.Matrix([sp.Rational(str(round(float(v),7))) for v in hnums])
    G=sum(P,sp.zeros(3,1))/4;r=[p-G for p in P]
    L=sum(v.dot(v) for v in r);Ld=2*r[0].dot(h)
    rho=[v.dot(v)/L for v in r];delta=[v-sp.Rational(1,4) for v in rho]
    rd=[(sp.Rational(3,4) if i==0 else -sp.Rational(1,4))*h for i in range(4)]
    dd=[2*r[i].dot(rd[i])/L-rho[i]*Ld/L for i in range(4)]
    U=[sum((delta[i]**m*r[i] for i in range(4)),sp.zeros(3,1)) for m in (1,2,3)]
    Ud=[sum((m*delta[i]**(m-1)*dd[i]*r[i]+delta[i]**m*rd[i] for i in range(4)),sp.zeros(3,1)) for m in (1,2,3)]
    S=sum((v*v.T for v in r),sp.zeros(3))/L
    Sd=(r[0]*h.T+h*r[0].T)/L-S*Ld/L
    H=S-sp.eye(3)/3;H2=H*H-sp.trace(H*H)*sp.eye(3)/3
    H2d=H*Sd+Sd*H-2*sp.trace(H*Sd)*sp.eye(3)/3
    Wd=[Ud[0],Sd*U[0]+(S-sp.eye(3))*Ud[0],
        H2d*U[0]+(H2-2*sp.eye(3)/9)*Ud[0],
        Ud[1]-Ud[0]/3,Ud[2]-7*Ud[0]/36,
        Sd*U[0]+H*Ud[0],H2d*U[0]+H2*Ud[0],Ud[1]]
    val=sp.factor(h.dot(h)/4+sp.Rational(cstr)*h.dot(Wd[index]))
    return {'P':[[str(x) for x in v] for v in P], 'h':[str(x) for x in h],
            'coefficient':cstr,'exact_response':str(val),'response_float':float(val),
            'tetrahedron_determinant':str(sp.Matrix.hstack(P[1]-P[0],P[2]-P[0],P[3]-P[0]).det())}

def endpoint_audit():
    ends={1:['-0.8677','0.9030'],2:['-1.9755','1.9804'],3:['-1.4523','2.1168'],4:['-2.8733','2.8670']}
    result={}
    for index,interval in ends.items():
        result[NAMES[index]]=[]
        for cs in interval:
            coeff=float(cs)
            def obj(x):
                q=np.vstack((x.reshape(3,3),-x.reshape(3,3).sum(axis=0)))
                if np.linalg.norm(q)<1e-10:return 1e6
                return np.linalg.eigvalsh(np.eye(3)/4+coeff*responses(q)[index])[0]
            fit=differential_evolution(obj,[(-1,1)]*9,seed=17+index,
                  popsize=8,maxiter=180,tol=1e-10,polish=True,workers=1)
            q=np.vstack((fit.x.reshape(3,3),-fit.x.reshape(3,3).sum(axis=0)))
            e,h=np.linalg.eigh(np.eye(3)/4+coeff*responses(q)[index])
            row={'coefficient':cs,'numerical_smallest_eigenvalue':float(e[0])}
            if e[0]<-1e-9:
                row['rational_check']=exact_directional_response(q,h[:,0],index,cs)
            result[NAMES[index]].append(row)
            print(NAMES[index],cs,float(e[0]),flush=True)
    return result

if __name__=='__main__':
    import sys
    started=time.time()
    if '--rays' in sys.argv:
        result=endpoint_audit()
        (ROOT/'rounded_endpoint_audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        print('Endpoint diagnostics complete',time.time()-started,flush=True)
        sys.exit(0)
    if '--refine' in sys.argv:
        result=constellation_audit(pcount=121,weightsteps=16,basecount=601)
        result['elapsed_seconds']=time.time()-started
        (ROOT/'refined_constellation_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(result,indent=2),flush=True)
        sys.exit(0)
    result={'exact':exact_checks()}
    print('Exact identities checked',flush=True)
    result['spectra']=spectral_audit()
    print('Spectral diagnostics complete',flush=True)
    result['constellation']=constellation_audit()
    result['elapsed_seconds']=time.time()-started
    (ROOT/'audit_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2),flush=True)
