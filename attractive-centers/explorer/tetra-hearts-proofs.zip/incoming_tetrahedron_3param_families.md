# Three-Parametric Non-Collinear Attractive Center Families for the Tetrahedron ($n = 4, d = 3$)

**Date:** 17 October 2026  
**Scope:** Exact mathematical constructions, analytical global attractivity proofs, closed-form 3D non-coplanarity determinants, and volumetric Heart inner-approximation benchmarks extending *Attractive Centers I–IV* (`https://ismaa3iil.fyi`) from triangles ($n=3, d=2$) to tetrahedra ($n=4, d=3$).

---

## 1. Why Estimating the Tetrahedron Heart Requires 3-Parametric Families

For a tetrahedron $P = (p_1, p_2, p_3, p_4) \in (\mathbb{R}^3)^4$ with centroid $G = \frac{1}{4}\sum_{i=1}^4 p_i$, the ambient space is $\mathbb{R}^3$ and the normalized barycentric weight simplex $\sum_{i=1}^4 w_i = 1$ is 3-dimensional:
- Both the **vertex power center curve** $M_p(P) = \arg\min_{x \in \mathbb{R}^3} \sum_{i=1}^4 \frac{1}{p}\|x - p_i\|^p$ for $p \in [4 - 2\sqrt{2}, \, 4 + 2\sqrt{2}]$ (Paper III, Theorem 4.1) and the **hull-power center curve** $H_p(P)$ are **1-parametric space curves** in $\mathbb{R}^3$ (requiring convex hulling across distinct exponents to span 3D volume).
- Moreover, as shown in Paper III (Section 7.2, *Failure for tetrahedra*), the intermediate skeletal centroids $C_{3,1}$ (wireframe centroid) and $C_{3,2}$ (surface area centroid) **fail** global attractivity on $A=(0,0,0), \, B=(1,0,0), \, C=(0,1,0), \, D=(3,-2,1/2)$ because metric weighting by edge lengths $\ell_{ij}$ or face areas $A_k$ introduces non-radial metric-stretching drift when a vertex moves.

To map a 3D parameter domain $\Omega \subset \mathbb{R}^3$ directly onto a **3-dimensional volumetric region** inside the tetrahedron Heart $\mathcal{H}(P) \subset \mathbb{R}^3$ (the 3D analogue of the 2-parameter Symmedian–Steiner domain $\Omega_{K, HK}$ for triangles), we need a **3-parametric family** $(\theta_1, \theta_2, \theta_3) \mapsto Z(\theta_1, \theta_2, \theta_3; P) \in \mathbb{R}^3$ whose parameter Jacobian $\frac{\partial Z}{\partial(\theta_1, \theta_2, \theta_3)} \in \mathbb{R}^{3 \times 3}$ has **full rank 3** ($\det \frac{\partial Z}{\partial \theta} \neq 0$) on a generic scalene tetrahedron while satisfying $\operatorname{Sym} D_i Z(P) \succeq 0$ for all $i \in \{1,2,3,4\}$ across all configurations.

Below are **four complementary 3-parametric families** (one variational/mechanical family with an unconditional zero-backoff proof from Paper III, and three root-free rational polynomial covariant families generalizing Paper IV's polynomial module and Symmedian–Steiner calculus to $n=4, d=3$).

---

## 2. Family I: The 3-Parametric Skeletal-Constellation Power Family $Z_{\text{const}}(p, w_E, w_F)$

### 2.1 Definition
Instead of weighting the 1-skeleton and 2-skeleton by Euclidean edge lengths or face areas (which destroys attractivity at $p=2$ in Paper III Section 7.2), equip the **three canonical $S_4$-orbits of affine barycentric anchors**—the $4$ vertices $v_i = p_i$, the $6$ edge midpoints $m_{ij} = \frac{1}{2}(p_i + p_j)$, and the $4$ face centroids $f_k = \frac{1}{3}\sum_{j \neq k} p_j$—with homogeneous radial power springs of exponent $p$:
$$Z_{\text{const}}(p, w_E, w_F; P) := \arg\min_{x \in \mathbb{R}^3} \left[ \frac{1 - w_E - w_F}{4}\sum_{i=1}^4 \frac{\|x - p_i\|^p}{p} + \frac{w_E}{6}\sum_{1 \le i < j \le 4} \frac{\|x - m_{ij}\|^p}{p} + \frac{w_F}{4}\sum_{k=1}^4 \frac{\|x - f_k\|^p}{p} \right]$$
over the **3-dimensional parameter prism**:
$$\Omega_{\text{const}} = \bigl\{(p, w_E, w_F) \in \mathbb{R}^3 : 4 - 2\sqrt{2} \le p \le 4 + 2\sqrt{2}, \quad w_E \ge 0, \quad w_F \ge 0, \quad w_E + w_F \le 1\bigr\}.$$

### 2.2 Theorem 2.1 (Unconditional Global Attractivity of Barycentric-Constellation Power Centers)
For every $(p, w_E, w_F) \in \Omega_{\text{const}}$ (and more generally for any probability measure over $S_4$-orbits of barycentric anchors $a_\alpha(P) = \sum_{i=1}^4 C_{\alpha i} p_i$ with $C_{\alpha i} \ge 0, \, \sum_i C_{\alpha i} = 1$), $Z_{\text{const}}(p, w_E, w_F; P)$ is Euclidean similarity-equivariant, $S_4$-invariant, and **globally attractive on all configurations $P \in (\mathbb{R}^d)^4$ ($d \ge 1$) with zero parameter backoff**.

**Proof:**
1. *Similarity equivariance:* Because all 14 anchors $a_\alpha(P)$ are affine barycentric combinations ($\sum_{i=1}^4 C_{\alpha i} = 1$) and every term shares the same homogeneous exponent $p$, translation, orthogonal rotation, and positive scaling $P \mapsto \lambda P$ transform the objective by $x \mapsto \lambda x$ and scale the potential by $\lambda^p$, preserving the unique minimizer.
2. *Positive semidefinite vertex response:* Let $K_\alpha = \omega_\alpha D^2\bigl(\frac{1}{p}\|x - a_\alpha\|^p\bigr)\big|_{x=Z}$ be the stiffness tensor of anchor $\alpha \in \{1, \dots, 14\}$ and $K_{\text{tot}} = \sum_{\alpha=1}^{14} K_\alpha$. By Theorem 4.1 of Paper III (*Exact Power Classification*), $4 - 2\sqrt{2} \le p \le 4 + 2\sqrt{2}$ implies $\operatorname{Sym}(K_{\text{tot}}^{-1} K_\alpha) \succeq 0$ for every individual anchor $\alpha$. Since $\frac{\partial a_\alpha}{\partial p_i} = C_{\alpha i} I_3$ with $C_{\alpha i} \ge 0$, the chain rule gives:
   $$D_i Z_{\text{const}}(P) = \sum_{\alpha=1}^{14} C_{\alpha i} K_{\text{tot}}^{-1} K_\alpha \implies \operatorname{Sym}\bigl(D_i Z_{\text{const}}(P)\bigr) = \sum_{\alpha=1}^{14} C_{\alpha i} \operatorname{Sym}\bigl(K_{\text{tot}}^{-1} K_\alpha\bigr) \succeq 0.$$
   The finite-displacement inequality across anchor collisions follows identically by summing the anchor finite-displacement inequalities with nonnegative weights $C_{\alpha i} \ge 0$. $\square$

### 2.3 Volumetric Gain
On the Paper III benchmark tetrahedron $A=(0,0,0), \, B=(1,0,0), \, C=(0,1,0), \, D=(3,-2,1/2)$, the 1D vertex power curve $M_p$ ($w_E = w_F = 0$) has convex-hull volume $2.3257 \times 10^{-4}$, whereas the 3-parametric family $Z_{\text{const}}(p, w_E, w_F)$ spans a convex-hull volume of **$6.4725 \times 10^{-4}$ ($2.78\times$ larger)** and protrudes by $+1.7398 \times 10^{-2}$ in Euclidean distance outside $\operatorname{conv}(M_p)$.

---

## 3. Family II: The 3-Parametric Krylov–Steiner Operator Family $Z_{\text{KS}}(c_0, c_1, c_2)$

### 3.1 Construction and Collinear Cancellation
Let $r_i = p_i - G$ ($\sum_{i=1}^4 r_i = 0$), let $L := \sum_{i=1}^4 \|r_i\|^2 = \frac{1}{4}\sum_{1 \le i < j \le 4} \ell_{ij}^2$ be the total second moment, and let
$$\rho_i := \frac{\|r_i\|^2}{L} \in \left[0, \, \frac{3}{4}\right], \qquad \delta_i := \rho_i - \frac{1}{4} = \frac{1}{4} - \frac{F_i}{12L},$$
where $F_i = \sum_{\{j,k\}\subset\{1..4\}\setminus\{i\}} \ell_{jk}^2 = 3L - 4\|r_i\|^2$ is the sum of squared edge lengths of the face opposite vertex $i$. Define the **3D Lemoine / Radial-Moment Vector**:
$$U_1(P) := \sum_{i=1}^4 \delta_i p_i = \sum_{i=1}^4 \delta_i r_i \in \mathbb{R}^3.$$
Let $\widehat{S} := \frac{1}{L}\sum_{i=1}^4 r_i r_i^T \in \mathbb{R}^{3 \times 3}$ be the normalized Steiner inertia tensor ($\operatorname{tr}\widehat{S} = 1, \, \widehat{S} \succeq 0$), let $H := \widehat{S} - \frac{1}{3}I_3$ be its traceless part, and let $\widetilde{H}_2 := H^2 - \frac{1}{3}\operatorname{tr}(H^2)I_3$ be its traceless square.

On any 1D collinear configuration along a unit axis $e_1$, $\widehat{S} = e_1 e_1^T$, so $H U_1 = \frac{2}{3} U_1$ and $\widetilde{H}_2 U_1 = \frac{2}{9} U_1$. Subtracting these collinear limits yields the **Collinear-Cancelled Krylov–Steiner Basis**:
$$\mathcal{K}_0(P) := U_1(P), \qquad \mathcal{K}_1(P) := \left(H - \frac{2}{3}I_3\right) U_1(P) = (\widehat{S} - I_3) U_1(P), \qquad \mathcal{K}_2(P) := \left(\widetilde{H}_2 - \frac{2}{9}I_3\right) U_1(P),$$
and the **3-parametric Krylov–Steiner family**:
$$Z_{\text{KS}}(c_0, c_1, c_2; P) := G + c_0 \mathcal{K}_0(P) + c_1 \mathcal{K}_1(P) + c_2 \mathcal{K}_2(P).$$

### 3.2 Exact Closed-Form 3D Non-Coplanarity Determinant
In the principal frame of $\widehat{S}$ with eigenvalues $\sigma_1, \sigma_2, \sigma_3$ ($\sigma_1 + \sigma_2 + \sigma_3 = 1$), the transition between $(U_1, H U_1, \widetilde{H}_2 U_1)$ and $(\mathcal{K}_0, \mathcal{K}_1, \mathcal{K}_2)$ is unit upper-triangular, so the $3 \times 3$ Vandermonde determinant in $(\sigma_1, \sigma_2, \sigma_3)$ gives:
$$\boxed{\left|\det\bigl[\mathcal{K}_0(P), \, \mathcal{K}_1(P), \, \mathcal{K}_2(P)\bigr]\right| = \bigl|(U_1)_1 (U_1)_2 (U_1)_3 (\sigma_1 - \sigma_2)(\sigma_2 - \sigma_3)(\sigma_3 - \sigma_1)\bigr|.}$$
Hence $Z_{\text{KS}}(c_0, c_1, c_2; P)$ has **full rank 3** (mapping 3D parameter bodies onto 3D volumetric regions in $\mathbb{R}^3$) on every scalene tetrahedron with distinct principal moments $\sigma_1 > \sigma_2 > \sigma_3$ and nonzero principal components of $U_1$.

### 3.3 Exact Vertex Jacobians and Exact $\mathbb{Q}(\sqrt{6})$ Spectral Thresholds
Differentiating $U_1, HK, \widetilde{H}_2 K$ with respect to vertex $p_1$ (labeled $i=0$) yields the exact closed-form $3 \times 3$ vertex Jacobian:
$$D_0 U_1 = \delta_0 I_3 + \frac{2}{L} r_0 r_0^T - \frac{1}{2}\widehat{S} - \frac{2}{L} U_1 r_0^T, \qquad \operatorname{Sym}(D_0 U_1) = \delta_0 I_3 + \frac{2}{L} r_0 r_0^T - \frac{1}{2}\widehat{S} - \frac{1}{L}\bigl(U_1 r_0^T + r_0 U_1^T\bigr).$$

**Theorem 3.1 (Exact Global Spectral Range of $U_1, U_2, HK, \widetilde{H}_2 K$ in $\mathbb{Q}(\sqrt{6})$):**
For any unit vector $e \in S^2$, letting $x_i = (r_i \cdot e)/\sqrt{L}$ and $w_i = \rho_i - x_i^2 \ge 0$, the Rayleigh quotient $e^T (\operatorname{Sym} D_0 U_1) e$ is affine linear in $w = (w_0, w_1, w_2, w_3)$:
$$e^T (\operatorname{Sym} D_0 U_1) e = 3 x_0^2 - \frac{1}{4} - \frac{1}{2}\sum_{i=0}^3 x_i^2 - 2 x_0 \sum_{i=0}^3 x_i^3 + (1 - 2 x_0^2) w_0 - 2 x_0 \sum_{i=1}^3 x_i w_i,$$
and attains its global extrema over all configurations $P \in (\mathbb{R}^3)^4$ on the 1D collinear boundary ($w_i = 0$) with two equal passive coordinates ($x_1 = x_2 = -\frac{1}{3}x_0 + \frac{\sin\theta}{\sqrt{6}}, \; x_3 = -\frac{1}{3}x_0 - \frac{2\sin\theta}{\sqrt{6}}, \; x_0 = \frac{\sqrt{3}}{2}\cos\theta$). Setting $t = \cot\theta$, the stationary equation factors over $\mathbb{Q}(\sqrt{2})$ as
$$5t^3 + 3\sqrt{2}t^2 - 15t - \sqrt{2} = (t - \sqrt{2})\bigl(5t^2 + 8\sqrt{2}t + 1\bigr) = 0,$$
yielding the **exact global eigenvalue bounds**:
$$\boxed{-\frac{3 + 9\sqrt{6}}{32} \le \lambda\bigl(\operatorname{Sym} D_i U_1(P)\bigr) \le \frac{3}{4} \qquad \left(-\frac{3 + 9\sqrt{6}}{32} \approx -0.782668990158\right),}$$
and hence the **exact maximal globally attractive ray interval** for $G + c_0 \mathcal{K}_0$:
$$\boxed{c_0 \in \left[-\frac{1}{3}, \; \frac{8(3\sqrt{6} - 1)}{159}\right] \approx [-0.33333333, \; +0.31941984].}$$
For the raw generators $U_2, HK, \widetilde{H}_2 K$, the global spectral extrema occur at the same collinear configurations with exact ratios $1 : \frac{1}{3} : \frac{2}{3} : \frac{2}{9}$, whereas the collinear-cancelled generators $\mathcal{K}_1, \mathcal{K}_2$ vanish identically on all 1D collinear shapes and expand the attractive ray intervals to $c_1 \in [-0.8677, \, +0.9030]$ and $c_2 \in [-1.9755, \, +1.9804]$.

---

## 4. Family III: The 3-Parametric Radial–Vandermonde Covariant Family $Z_{\text{VM}}(a_1, a_2, a_3)$

### 4.1 Construction (Generalizing Paper IV Theorem 5.1 to $S_4$)
By the $S_4$ generalization of Theorem 5.1 (`thm:covmodule`) of Paper IV, every zero-sum $S_4$-equivariant polynomial in the normalized vertex squared radii $(\rho_1, \rho_2, \rho_3, \rho_4)$ is generated over the symmetric ring $\mathbb{R}[e_2(\delta), e_3(\delta), e_4(\delta)]$ by the three power-moment covariants:
$$v_i^{(1)} = \delta_i, \qquad v_i^{(2)} = \delta_i^2 - \frac{1}{4}\sum_{j=1}^4 \delta_j^2, \qquad v_i^{(3)} = \delta_i^3 - \frac{1}{4}\sum_{j=1}^4 \delta_j^3, \qquad U_m(P) := \sum_{i=1}^4 v_i^{(m)} p_i = \sum_{i=1}^4 \delta_i^m r_i.$$
Subtracting the 3-to-1 vertex-collision ratios ($\delta = (1/2, -1/6, -1/6, -1/6)$, where $v^{(2)} = \frac{1}{3}v^{(1)}$ and $v^{(3)} = \frac{7}{36}v^{(1)}$) yields the **Collision-Cancelled Radial–Vandermonde Basis**:
$$\mathcal{V}_1(P) := U_1(P), \qquad \mathcal{V}_2(P) := U_2(P) - \frac{1}{3}U_1(P), \qquad \mathcal{V}_3(P) := U_3(P) - \frac{7}{36}U_1(P),$$
and the **3-parametric Radial–Vandermonde family**:
$$Z_{\text{VM}}(a_1, a_2, a_3; P) := G + a_1 \mathcal{V}_1(P) + a_2 \mathcal{V}_2(P) + a_3 \mathcal{V}_3(P).$$

### 4.2 Theorem 4.1 (Exact Cauchy–Binet Vandermonde Volume Identity)
On every tetrahedron $P = (p_1, p_2, p_3, p_4) \in (\mathbb{R}^3)^4$ with signed volume $\operatorname{Vol}(P) = \frac{1}{6}\det\begin{pmatrix} 1 & 1 & 1 & 1 \\ p_1 & p_2 & p_3 & p_4 \end{pmatrix}$,
$$\boxed{\det\bigl[\mathcal{V}_1(P), \, \mathcal{V}_2(P), \, \mathcal{V}_3(P)\bigr] = \det\bigl[U_1(P), \, U_2(P), \, U_3(P)\bigr] = \frac{3}{2}\,\operatorname{Vol}(P) \prod_{1 \le i < j \le 4} (\rho_j - \rho_i).}$$

**Proof:**
Factor the $4 \times 4$ matrix product
$$\begin{pmatrix} 1 & 1 & 1 & 1 \\ p_1 & p_2 & p_3 & p_4 \end{pmatrix} \begin{pmatrix} 1/4 & v_1^{(1)} & v_1^{(2)} & v_1^{(3)} \\ 1/4 & v_2^{(1)} & v_2^{(2)} & v_2^{(3)} \\ 1/4 & v_3^{(1)} & v_3^{(2)} & v_3^{(3)} \\ 1/4 & v_4^{(1)} & v_4^{(2)} & v_4^{(3)} \end{pmatrix} = \begin{pmatrix} 1 & 0 & 0 & 0 \\ G & U_1 & U_2 & U_3 \end{pmatrix}.$$
Adding multiples of column 1 to columns 3 and 4 converts the second matrix into $\operatorname{diag}(1/4, 1, 1, 1)$ times the standard $4 \times 4$ Vandermonde matrix in $(\delta_1, \delta_2, \delta_3, \delta_4)$, whose determinant is $\frac{1}{4}\prod_{1 \le i < j \le 4}(\delta_j - \delta_i) = \frac{1}{4}\prod_{1 \le i < j \le 4}(\rho_j - \rho_i)$. Since $\det\begin{pmatrix} 1 & \dots & 1 \\ p_1 & \dots & p_4 \end{pmatrix} = 6\,\operatorname{Vol}(P)$, taking determinants gives $\frac{6}{4}\operatorname{Vol}(P)\prod_{i<j}(\rho_j - \rho_i) = \frac{3}{2}\operatorname{Vol}(P)\prod_{i<j}(\rho_j - \rho_i)$. $\square$

---

## 5. Family IV: The 3-Parametric Hybrid Steiner–Vandermonde Family $Z_{\text{SV}}(b_1, b_2, b_3)$

### 5.1 Resolving Rank Drops Across Symmetry Strata
Notice the complementary degeneracy loci of Families II and III:
- If a scalene tetrahedron has an axisymmetric inertia ellipsoid ($\sigma_1 = \sigma_2$) while all four vertex radii $\rho_1, \rho_2, \rho_3, \rho_4$ are distinct, Family II (`Krylov–Steiner`) drops rank to 2 while Family III (`Radial–Vandermonde`) remains **full rank 3**.
- Conversely, if two vertices happen to lie at equal distance from $G$ ($\rho_1 = \rho_2$) while $\sigma_1 > \sigma_2 > \sigma_3$, Family III drops rank to 2 while Family II remains **full rank 3**.

Combining $\mathcal{K}_0 = U_1$, the first collinear-cancelled Steiner vector $\mathcal{K}_1 = (\widehat{S} - I_3) U_1$, and the collision-cancelled quadratic radial covariant $\mathcal{V}_2 = U_2 - \frac{1}{3}U_1$ defines the **3-parametric Hybrid Steiner–Vandermonde family**:
$$Z_{\text{SV}}(b_1, b_2, b_3; P) := G + b_1 \mathcal{K}_0(P) + b_2 \mathcal{K}_1(P) + b_3 \mathcal{V}_2(P).$$
By Proposition 4.3 of Paper I (*Convex Mixing*), for any 3-vector basis $(W_1, W_2, W_3)$ whose individual coordinate rays $G + c_m W_m$ are globally attractive on $[c_m^-, c_m^+]$, the entire **3D cross-polytope (octahedron)**:
$$\Omega_{\text{oct}}(W_1, W_2, W_3) = \left\{(c_1, c_2, c_3) \in \mathbb{R}^3 : \sum_{m=1}^3 \max\left(\frac{c_m}{c_m^+}, \, \frac{c_m}{c_m^-}\right) \le 1\right\}$$
is globally attractive and maps onto a 3D octahedron inside $\mathcal{H}(P)$ of volume $\frac{1}{6}\prod_{m=1}^3(c_m^+ - c_m^-)\,\bigl|\det[W_1, W_2, W_3]\bigr|$.

---

## 6. Summary Comparison of the Four 3-Parametric Families

| Family | Explicit Formula $Z(\theta_1, \theta_2, \theta_3; P)$ | Certified Parameter Domain $\Omega \subset \mathbb{R}^3$ | 3D Non-Coplanarity Determinant on Benchmark $P_{\text{III}}$ | 3D Heart Volume on $P_{\text{III}}$ |
| :--- | :--- | :--- | :--- | :--- |
| **Baseline (1D Curve)** | Vertex Power $M_p(P)$ | $p \in [4 - 2\sqrt{2}, \, 4 + 2\sqrt{2}]$ | 1D space curve (coplanar rank 1 locally) | $2.3257 \times 10^{-4}$ ($\text{conv}(M_p)$) |
| **Family I (`Skeletal-Constellation`)** | $\arg\min_x \Phi_{p;\, w_E, w_F}(x; P)$ | $[4-2\sqrt{2}, 4+2\sqrt{2}] \times \Delta_2$ (**exact, $\delta=0$**) | Full 3D nonlinear solid | $6.4725 \times 10^{-4}$ (**$2.78\times$** $\text{conv}(M_p)$) |
| **Family II (`Krylov–Steiner`)** | $G + c_0 \mathcal{K}_0 + c_1 \mathcal{K}_1 + c_2 \mathcal{K}_2$ | Octahedron on $[-0.3333, 0.3194] \times [-0.8677, 0.9030] \times [-1.9755, 1.9804]$ | $\det[\mathcal{K}_0, \mathcal{K}_1, \mathcal{K}_2] = -3.7167 \times 10^{-5}$ | $2.8323 \times 10^{-5}$ (single octahedron) |
| **Family III (`Radial–Vandermonde`)** | $G + a_1 \mathcal{V}_1 + a_2 \mathcal{V}_2 + a_3 \mathcal{V}_3$ | Octahedron on $[-0.3333, 0.3194] \times [-1.4523, 2.1168] \times [-2.8733, 2.8670]$ | $\det[\mathcal{V}_1, \mathcal{V}_2, \mathcal{V}_3] = -5.5263 \times 10^{-5}$ | $1.2318 \times 10^{-4}$ (single octahedron) |
| **Family IV (`Hybrid Steiner–Vandermonde`)** | $G + b_1 \mathcal{K}_0 + b_2 \mathcal{K}_1 + b_3 \mathcal{V}_2$ | Octahedron on $[-0.3333, 0.3194] \times [-0.8677, 0.9030] \times [-1.4523, 2.1168]$ | $\det[\mathcal{K}_0, \mathcal{K}_1, \mathcal{V}_2] = +1.0653 \times 10^{-4}$ | $7.3248 \times 10^{-5}$ (single octahedron) |
| **Combined Hull (Families I–IV)** | Convex mixing $\operatorname{conv}(\text{I} \cup \text{II} \cup \text{III} \cup \text{IV})$ | Joint 3D convex hull in $\mathcal{H}(P_{\text{III}})$ | Full 3D volumetric region | **$2.2576 \times 10^{-3}$ ($9.71\times$ $\text{conv}(M_p)$)** |

---

## 7. Reproducibility Command

Run the standalone verification script:
```bash
python3 verify_tetrahedron_3param_families.py
```
