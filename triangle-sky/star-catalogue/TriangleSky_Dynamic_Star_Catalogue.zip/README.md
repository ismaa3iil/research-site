# Triangle Sky — Dynamic Star Catalogue

Open `TriangleSkyStarCatalogue.nb` in Wolfram Mathematica 15 (13+ should also work) and evaluate its input cell.

The visualization defaults to the 53 ranked constructive stars with effective index at most 4, together with the six adopted optimization stars EVS, CVS, IVS, ERS, DGS and NFIS. The cutoff can be moved through the complete 167-star ranked catalogue up to index 5.

Controls:

- Drag A, B and C in the x-y reference-triangle editor.
- Use the three z sliders to move the reference vertices in full 3D.
- Rotate or zoom the main 3D plot with the mouse.
- Hover over a star to draw the dashed perpendicular to its foot.
- Click a star to pin its information.
- Switch between concentrated and detailed information.
- Use the search field to filter by star expression, adopted name, or ETC index.

The numerical ERS, DGS and NFIS optimizers pause while a locator or slider is actively moving and recompute when it is released. EVS, CVS and IVS update from their closed forms immediately.

The notebook expects the `.wl`, `.json`, and foundations file to remain beside it. The supplied ZIP preserves this layout.
