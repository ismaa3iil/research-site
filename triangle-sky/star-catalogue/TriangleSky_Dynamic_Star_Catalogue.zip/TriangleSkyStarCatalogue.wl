(* ::Package:: *)

BeginPackage["TriangleSkyStarCatalogue`"];

TriangleSkyStarCatalogue::usage =
  "TriangleSkyStarCatalogue[] opens the interactive 3D catalogue of ranked Triangle Sky stars.";

Begin["`Private`"];

$TSResourceDirectory = DirectoryName[$InputFileName];

Get[FileNameJoin[{$TSResourceDirectory, "TriangleSkyFoundations.wl"}]];

(* In the catalogue the base triangle may be arbitrarily oriented in R^3.
   Therefore the one-argument foot operator must project to the actual base
   plane, rather than to the global x-y plane used by the batch enumerator. *)
TSEvaluate[TSFoot[e_], tri_List] := Module[{p = TSEvaluate[e, tri], base = tsPlane @@ tri},
  If[MissingQ[p] || AssociationQ[p] || MissingQ[base],
   Missing["InvalidFootArgument"], tsProjectToPlane[p, base]]
  ];

$TSRawRankedData =
  Import[FileNameJoin[{$TSResourceDirectory, "TriangleSkyRankedStars.json"}], "RawJSON"];

tsFriendlyName[s_String] := Switch[s,
   "TSZ[1]", "Equifacial Star (ES)",
   "TSZ[2]", "Orthostar (OS)",
   "TSZ[3]", "First Circumstar (CS1)",
   _, s
   ];

tsFormalRecord[r_Association] := Module[{s = r["StarExpression"], etc},
  etc = Replace[Lookup[r, "ETCIndex", ""], Null -> ""];
  <|
   "ID" -> "R" <> ToString[r["Rank"]],
   "Category" -> "Constructive",
   "Rank" -> r["Rank"],
   "Name" -> tsFriendlyName[s],
   "ExpressionText" -> s,
   "Expression" -> ToExpression[s, InputForm],
   "IndexExact" -> r["EffectiveIndexExact"],
   "Index" -> N[r["EffectiveIndexNumeric"]],
   "DefinitionCount" -> r["CoincidingDefinitionCount"],
   "Definitions" -> Lookup[r, "Definitions", {s}],
   "SimplestDefinition" -> First[Lookup[r, "Definitions", {s}]],
   "ETCStatus" -> Lookup[r, "ETCStatus", ""],
   "ETCIndex" -> etc,
   "FootBarycentrics" -> Lookup[r, "FootBarycentricsNormalized", "Not available"],
   "HeightFormula" -> Lookup[r, "HeightFormula", "Not available"]
   |>
  ];

$TSFormalRecords = tsFormalRecord /@ $TSRawRankedData;

$TSOptimizationRecords = {
   <|"ID" -> "O-IVS", "Category" -> "Optimization", "Rank" -> "O1",
    "Name" -> "Insphere-Volume Star (IVS)", "ExpressionText" -> "IVS",
    "IndexExact" -> "3/2", "Index" -> 3/2, "DefinitionCount" -> 1,
    "Definitions" -> {
      "Maximize Vol(insphere of ABCD)/Vol(ABCD), equivalently minimize surface-area(ABCD)^3/Vol(ABCD)^2."
      },
    "SimplestDefinition" -> "Maximize Vol(insphere)/Vol(tetrahedron).",
    "ETCStatus" -> "ETCMatch", "ETCIndex" -> "X(1)",
    "FootBarycentrics" -> "{a,b,c}/(a+b+c)",
    "HeightFormula" -> "2 Sqrt[2] r"|>,

   <|"ID" -> "O-DGS", "Category" -> "Optimization", "Rank" -> "O2",
    "Name" -> "Dihedral Gram Star (DGS)", "ExpressionText" -> "DGS",
    "IndexExact" -> "5/3", "Index" -> 5/3, "DefinitionCount" -> 1,
    "Definitions" -> {
      "Minimize Sum_e (Cos[theta_e]-1/3)^2 over the six internal dihedral angles."
      },
    "EquivalentForms" -> {"Gram form: minimize (1/2)||N^T N-G_regular||_F^2."},
    "SimplestDefinition" -> "Minimize Sum_e (Cos[theta_e]-1/3)^2.",
    "ETCStatus" -> "NoExactMatch", "ETCIndex" -> "",
    "FootBarycentrics" -> "Implicit symmetric optimizer {alpha_DGS(a,b,c), beta_DGS(a,b,c), gamma_DGS(a,b,c)}",
    "HeightFormula" -> "Implicit invariant optimizer h_DGS(a,b,c)"|>,

   <|"ID" -> "O-ERS", "Category" -> "Optimization", "Rank" -> "O3",
    "Name" -> "Euler-Ratio Star (ERS)", "ExpressionText" -> "ERS",
    "IndexExact" -> "7/4", "Index" -> 7/4, "DefinitionCount" -> 1,
    "Definitions" -> {"Minimize R_ABCD/r_ABCD."},
    "SimplestDefinition" -> "Minimize tetrahedral circumradius/inradius R/r.",
    "ETCStatus" -> "NoExactMatch", "ETCIndex" -> "",
    "FootBarycentrics" -> "Implicit symmetric optimizer {alpha_ERS(a,b,c), beta_ERS(a,b,c), gamma_ERS(a,b,c)}",
    "HeightFormula" -> "Implicit invariant optimizer h_ERS(a,b,c)"|>,

   <|"ID" -> "O-EVS", "Category" -> "Optimization", "Rank" -> "O4",
    "Name" -> "Edges-Variance Star (EVS)", "ExpressionText" -> "EVS",
    "IndexExact" -> "2", "Index" -> 2, "DefinitionCount" -> 1,
    "Definitions" -> {"Minimize the variance of the six edge lengths of ABCD."},
    "SimplestDefinition" -> "Minimize Var[{AB,BC,CA,AD,BD,CD}].",
    "ETCStatus" -> "ETCMatch", "ETCIndex" -> "X(3)",
    "FootBarycentrics" ->
      "Normalize[{a^2 (b^2+c^2-a^2), b^2 (c^2+a^2-b^2), c^2 (a^2+b^2-c^2)}]",
    "HeightFormula" -> "Sqrt[(p/3)^2-R^2] (real when p>3R)"|>,

   <|"ID" -> "O-NFIS", "Category" -> "Optimization", "Rank" -> "O5",
    "Name" -> "Normal-Frame Isotropy Star (NFIS)", "ExpressionText" -> "NFIS",
    "IndexExact" -> "2", "Index" -> 2, "DefinitionCount" -> 1,
    "Definitions" -> {
      "Minimize ||Sum_i n_i n_i^T-(4/3)I||_F^2 for the four outward unit face normals."
      },
    "EquivalentForms" -> {"Dihedral form: minimize Sum_e Cos[theta_e]^2."},
    "SimplestDefinition" -> "Minimize the tight-frame defect of the four face normals.",
    "ETCStatus" -> "NoExactMatch", "ETCIndex" -> "",
    "FootBarycentrics" -> "Implicit symmetric optimizer {alpha_NFIS(a,b,c), beta_NFIS(a,b,c), gamma_NFIS(a,b,c)}",
    "HeightFormula" -> "Implicit invariant optimizer h_NFIS(a,b,c)"|>,

   <|"ID" -> "O-CVS", "Category" -> "Optimization", "Rank" -> "O6",
    "Name" -> "Circum-Volume Star (CVS)", "ExpressionText" -> "CVS",
    "IndexExact" -> "9/4", "Index" -> 9/4, "DefinitionCount" -> 1,
    "Definitions" -> {"Minimize Vol(circumsphere of ABCD)/Vol(ABCD)."},
    "SimplestDefinition" -> "Minimize circumsphere-volume/tetrahedron-volume.",
    "ETCStatus" -> "ETCMatch", "ETCIndex" -> "X(3)",
    "FootBarycentrics" ->
      "Normalize[{a^2 (b^2+c^2-a^2), b^2 (c^2+a^2-b^2), c^2 (a^2+b^2-c^2)}]",
    "HeightFormula" -> "Sqrt[2] R"|>
   };

$TSAllMetadata = Join[$TSFormalRecords, $TSOptimizationRecords];

(* ---------- Numerical geometry ---------- *)

tsValidTriangleQ[tri_] := Module[{v},
  v = Quiet@Check[N[Cross[tri[[2]] - tri[[1]], tri[[3]] - tri[[1]]]], $Failed];
  v =!= $Failed && VectorQ[v, NumericQ] && Norm[v] > 10^-7
  ];

tsRealPointQ[p_] := Quiet@Check[
   VectorQ[p, NumericQ] && Length[p] == 3 &&
    FreeQ[p, Indeterminate | ComplexInfinity | _DirectedInfinity] &&
    Max[Abs[Im[N[p]]]] < 10^-7,
   False
   ];

tsBaseNormal[tri_] := Normalize[Cross[tri[[2]] - tri[[1]], tri[[3]] - tri[[1]]]];

tsProjectToBase[p_, tri_] := Module[{n = tsBaseNormal[tri]},
  p - Dot[p - tri[[1]], n] n
  ];

tsBarycentrics[p_, tri_] := Module[{m, q, beta, gamma},
  m = Transpose[{tri[[2]] - tri[[1]], tri[[3]] - tri[[1]]}];
  q = Quiet@Check[LeastSquares[m, p - tri[[1]]], {Indeterminate, Indeterminate}];
  {beta, gamma} = q; Chop[{1 - beta - gamma, beta, gamma}]
  ];

tsBaseInvariants[tri_] := Module[{a, b, c, area, per, rin, rcirc},
  {a, b, c} = N[tsSides[tri]];
  area = Norm[Cross[tri[[2]] - tri[[1]], tri[[3]] - tri[[1]]]]/2;
  per = a + b + c;
  rin = 2 area/per;
  rcirc = a b c/(4 area);
  <|"Sides" -> {a, b, c}, "Area" -> area, "Perimeter" -> per,
   "Inradius" -> rin, "Circumradius" -> rcirc|>
  ];

tsFaceNormals[pts_] := Table[
   Module[{ids = Delete[Range[4], i], p, q, r, raw, u},
    {p, q, r} = pts[[ids]];
    raw = Cross[q - p, r - p];
    If[Norm[raw] < 10^-12, $Failed,
     u = raw/Norm[raw];
     If[Dot[u, pts[[i]] - p] > 0, -u, u]]
    ],
   {i, 4}
   ];

tsDihedralCosines[pts_] := Module[{nn = tsFaceNormals[pts]},
  If[nn === $Failed || MemberQ[nn, $Failed], Return[$Failed]];
  (-Dot @@ #) & /@ Subsets[nn, {2}]
  ];

tsTetraVolume[pts_] := Abs[Det[Rest[pts] - First[pts]]]/6;

tsTetraSurfaceArea[pts_] := Total[tsTriangleArea /@ (pts[[#]] & /@ Subsets[Range[4], {3}])];

tsTetraInradius[pts_] := Module[{s = tsTetraSurfaceArea[pts], v = tsTetraVolume[pts]},
  If[s <= 10^-12, Indeterminate, 3 v/s]
  ];

tsTetraCircumradius[pts_] := Module[{p = First[pts], o},
  o = Quiet@Check[
     LinearSolve[2 (Rest[pts] - p), ((# . #) & /@ Rest[pts]) - p . p],
     $Failed];
  If[o === $Failed, Indeterminate, Norm[o - p]]
  ];

tsObjectiveValue[name_, pts_] := Module[{cc, rr, cosines},
  Switch[name,
   "ERS",
   cc = tsTetraCircumradius[pts]; rr = tsTetraInradius[pts];
   If[! NumericQ[cc] || ! NumericQ[rr] || rr <= 10^-10, 10.^12, cc/rr],
   "DGS",
   cosines = tsDihedralCosines[pts];
   If[cosines === $Failed, 10.^12, Total[(cosines - 1/3)^2]],
   "NFIS",
   cosines = tsDihedralCosines[pts];
   If[cosines === $Failed, 10.^12, Total[cosines^2]],
   _, 10.^12
   ]
  ];

tsOptimizeApex[name_, tri_] := Module[
  {n, scale, a, b, c, per, starts, f, candidates, good, best, x, y, z,
   value, rules, apex, foot, h},
  If[! tsValidTriangleQ[tri], Return[Missing["DegenerateBase"]]];
  n = tsBaseNormal[tri];
  scale = Max[N[tsSides[tri]]];
  {a, b, c} = N[tsSides[tri]]; per = a + b + c;
  starts = Switch[name,
    "ERS", {{.38, .33, Log[.70]}, {a/per, b/per, Log[.55]}, {1/3, 1/3, Log[.65]}},
    "DGS", {{.13, .41, Log[.57]}, {a/per, b/per, Log[.52]}, {1/3, 1/3, Log[.60]}},
    "NFIS", {{.12, .40, Log[.54]}, {a/per, b/per, Log[.50]}, {1/3, 1/3, Log[.58]}},
    _, {{1/3, 1/3, Log[.6]}}
    ];
  f[xx_?NumericQ, yy_?NumericQ, zz_?NumericQ] := Module[{d, penalty},
    penalty = 10.^5 Total[
       Max[0., #]^2 & /@ {
         -2. - xx, xx - 3., -2. - yy, yy - 3.,
         -2. - (1. - xx - yy), (1. - xx - yy) - 3.,
         -4. - zz, zz - 1.6}];
    d = xx tri[[1]] + yy tri[[2]] + (1. - xx - yy) tri[[3]] +
       scale Exp[zz] n;
    N[tsObjectiveValue[name, Append[tri, d]]] + penalty
    ];
  candidates = (Quiet@Check[
        FindMinimum[f[x, y, z], {{x, #[[1]]}, {y, #[[2]]}, {z, #[[3]]}},
         Method -> "PrincipalAxis", MaxIterations -> 500,
         AccuracyGoal -> 7, PrecisionGoal -> 7], $Failed] &) /@ starts;
  good = Select[candidates,
    # =!= $Failed && MatchQ[#, {_?NumericQ, {__Rule}}] && First[#] < 10.^10 &];
  If[good === {}, Return[Missing["OptimizerFailed"]]];
  best = First@SortBy[good, First];
  value = First[best]; rules = Last[best];
  foot = (x tri[[1]] + y tri[[2]] + (1 - x - y) tri[[3]]) /. rules;
  h = scale Exp[z /. rules]; apex = foot + h n;
  <|"Point" -> N[apex], "Foot" -> N[foot], "Height" -> N[h],
   "Objective" -> N[value], "BarycentricsNumeric" -> N[tsBarycentrics[foot, tri]]|>
  ];

SetAttributes[tsCachedOptimize, HoldFirst];
tsCachedOptimize[cache_, name_, tri_, calculate_: True] := Module[{key, sol},
  key = name <> ":" <> ToString[Round[Flatten[N[tri]], 10^-5], InputForm];
  If[KeyExistsQ[cache, key], Return[cache[key]]];
  If[! TrueQ[calculate], Return[Missing["OptimizationPaused"]]];
  sol = tsOptimizeApex[name, N[tri]];
  If[Length[cache] > 60, cache = <||>];
  AssociateTo[cache, key -> sol];
  sol
  ];

tsEvaluateFormal[r_, tri_] := Module[{p, foot, h},
  p = Quiet@Check[N[TSEvaluate[r["Expression"], N[tri]]], $Failed];
  If[p === $Failed || ! tsRealPointQ[p],
   Return[Join[r, <|"Available" -> False, "Reason" -> "Not real for this triangle"|>]]];
  p = Chop[Re[p]]; foot = tsProjectToBase[p, tri];
  h = Abs[Dot[p - tri[[1]], tsBaseNormal[tri]]];
  Join[r, <|"Available" -> True, "Point" -> p, "Foot" -> foot,
    "Height" -> h, "BarycentricsNumeric" -> tsBarycentrics[foot, tri]|>]
  ];

SetAttributes[tsCachedFormalEvaluation, HoldFirst];
tsCachedFormalEvaluation[cache_, records_, tri_] := Module[{key, value},
  key = "FORMAL:" <> StringRiffle[Lookup[records, "ID", {}], ","] <> ":" <>
     ToString[Round[Flatten[N[tri]], 10^-5], InputForm];
  If[KeyExistsQ[cache, key], Return[cache[key]]];
  value = tsEvaluateFormal[#, N[tri]] & /@ records;
  AssociateTo[cache, key -> value];
  value
  ];

SetAttributes[tsEvaluateOptimization, HoldRest];
tsEvaluateOptimization[r_, tri_, calculate_, cache_] := Module[
  {name = r["ExpressionText"], inv, n, foot, h2, h, p, sol},
  inv = tsBaseInvariants[tri]; n = tsBaseNormal[tri];
  Switch[name,
   "EVS",
   foot = tsTriangleCircumcenter[tri];
   h2 = (inv["Perimeter"]/3)^2 - inv["Circumradius"]^2;
   If[h2 <= 10^-10,
    Join[r, <|"Available" -> False, "Reason" -> "No positive real EVS for this base"|>],
    h = Sqrt[h2]; p = foot + h n;
    Join[r, <|"Available" -> True, "Point" -> p, "Foot" -> foot,
      "Height" -> h, "BarycentricsNumeric" -> tsBarycentrics[foot, tri]|>]],
   "CVS",
   foot = tsTriangleCircumcenter[tri]; h = Sqrt[2] inv["Circumradius"];
   p = foot + h n;
   Join[r, <|"Available" -> True, "Point" -> p, "Foot" -> foot,
     "Height" -> h, "BarycentricsNumeric" -> tsBarycentrics[foot, tri]|>],
   "IVS",
   foot = tsTriangleCenter[1, tri]; h = 2 Sqrt[2] inv["Inradius"];
   p = foot + h n;
   Join[r, <|"Available" -> True, "Point" -> p, "Foot" -> foot,
     "Height" -> h, "BarycentricsNumeric" -> tsBarycentrics[foot, tri]|>],
   "ERS" | "DGS" | "NFIS",
   sol = tsCachedOptimize[cache, name, tri, calculate];
   If[AssociationQ[sol], Join[r, <|"Available" -> True|>, sol],
    Join[r, <|"Available" -> False, "Reason" -> ToString[sol, InputForm]|>]],
   _, Join[r, <|"Available" -> False, "Reason" -> "Unknown optimization star"|>]
   ]
  ];

(* ---------- Appearance and information ---------- *)

tsIndexColor[index_] := Module[{t},
  t = Clip[Rescale[N[index], {10/13, 5}], {0, 1}];
  Blend[{RGBColor[1., .96, .42], RGBColor[1., .39, .08],
    RGBColor[.25, .10, .48]}, Sqrt[t]]
  ];

tsStarRadius[index_, scale_] := scale (.009 + .040/(.65 + N[index]));

tsShort[s_, n_: 68] := If[StringLength[ToString[s]] <= n, ToString[s],
  StringTake[ToString[s], n - 1] <> "\[Ellipsis]"];

tsETCText[r_] := If[r["ETCStatus"] === "ETCMatch" && StringQ[r["ETCIndex"]] && r["ETCIndex"] =!= "",
  r["ETCIndex"], "No exact ETC match"];

tsInfoPanel[rec_, detail_] := Module[{basic, extra, defs, equivalents},
  If[! AssociationQ[rec],
   Return[Framed[
     Pane[Column[{Style["Hover over a star", 17, Bold, White],
        Style["A dashed light line will connect the apex to its foot. Click a star to pin its information here.",
         11, RGBColor[.78, .82, .90]]}, Spacings -> 1.2], {370, 560}],
     Background -> RGBColor[.055, .075, .12], FrameStyle -> RGBColor[.20, .27, .40],
     RoundingRadius -> 10]]];
  basic = Grid[{
      {Style["Rank", Bold], rec["Rank"]},
      {Style["Index", Bold], Row[{rec["IndexExact"], "   (", NumberForm[N[rec["Index"]], {5, 3}], ")"}]},
      {Style["Independent definitions", Bold], rec["DefinitionCount"]},
      {Style["Foot in ETC", Bold], tsETCText[rec]},
      {Style["Numerical height", Bold],
       If[KeyExistsQ[rec, "Height"], NumberForm[N[rec["Height"]], {12, 7}], "Unavailable"]},
      {Style["Type", Bold], rec["Category"]}
      }, Alignment -> {{Left, Left}}, Spacings -> {1.2, .75},
     BaseStyle -> {11, RGBColor[.90, .92, .96]}];
  defs = Lookup[rec, "Definitions", {}];
  equivalents = Lookup[rec, "EquivalentForms", {}];
  extra = If[detail === "Detailed",
    Column[{
      Style["All independent definitions", 12, Bold, RGBColor[1., .77, .30]],
      Column[MapIndexed[Row[{First[#2], ".  ", Style[#1, 10]}] &, defs], Spacings -> .55],
      If[equivalents === {}, Nothing,
       Column[{Style["Equivalent algebraic forms", 12, Bold, RGBColor[1., .77, .30]],
         Column[Style[#, 10] & /@ equivalents, Spacings -> .45]}, Spacings -> .55]],
      Style["Foot barycentric center function", 12, Bold, RGBColor[1., .77, .30]],
      Style[Lookup[rec, "FootBarycentrics", "Not available"], 9.5, FontFamily -> "Consolas"],
      Style["Numerical foot barycentrics", 12, Bold, RGBColor[1., .77, .30]],
      Style[ToString[NumberForm[Lookup[rec, "BarycentricsNumeric", {}], {10, 6}], InputForm],
       9.5, FontFamily -> "Consolas"],
      Style["Invariant height", 12, Bold, RGBColor[1., .77, .30]],
      Style[Lookup[rec, "HeightFormula", "Not available"], 9.5, FontFamily -> "Consolas"]
      }, Spacings -> .8],
    Column[{
      Style["Simplest definition", 12, Bold, RGBColor[1., .77, .30]],
      Style[Lookup[rec, "SimplestDefinition", ""], 10.5]
      }, Spacings -> .6]
    ];
  Framed[
   Pane[Style[Column[{Style[rec["Name"], 16, Bold, White], basic, extra}, Spacings -> 1.0],
     RGBColor[.90, .92, .96], FontFamily -> "Source Sans Pro"],
    {370, 560}, Scrollbars -> Automatic],
   Background -> RGBColor[.055, .075, .12], FrameStyle -> tsIndexColor[rec["Index"]],
   RoundingRadius -> 10]
  ];

SetAttributes[tsCatalogueView, HoldAll];
tsCatalogueView[tri_, cutoff_, detail_, hovered_, selected_, search_,
   showConstructive_, showOptimization_, calculateOptimizers_, cache_] := Module[
  {formalMeta, optMeta, query, formal, opt, records, available, unavailable,
   scale, activeID, active, hoverRec, footPrimitive, pointPrimitives, plot,
   ids, selector, countText, vertexLabels = {"A", "B", "C"}, bounds, pts},
  If[! tsValidTriangleQ[N[tri]],
   Return[Framed[Style["The three reference vertices are nearly collinear. Move a vertex to restore a valid triangle.",
      16, Darker[Red]], Background -> Lighter[Red, .85], RoundingRadius -> 8]]];
  query = ToLowerCase[StringTrim[search]];
  formalMeta = If[TrueQ[showConstructive],
    Select[$TSFormalRecords, #Index <= N[cutoff] + 10^-10 &], {}];
  optMeta = If[TrueQ[showOptimization],
    Select[$TSOptimizationRecords, #Index <= N[cutoff] + 10^-10 &], {}];
  If[query =!= "",
   formalMeta = Select[formalMeta,
     StringContainsQ[ToLowerCase[#Name <> " " <> #ExpressionText <> " " <> ToString[#ETCIndex]], query] &];
   optMeta = Select[optMeta,
     StringContainsQ[ToLowerCase[#Name <> " " <> #ExpressionText <> " " <> ToString[#ETCIndex]], query] &]
   ];
  formal = tsCachedFormalEvaluation[cache, formalMeta, N[tri]];
  opt = tsEvaluateOptimization[#, N[tri], calculateOptimizers, cache] & /@ optMeta;
  records = Join[formal, opt];
  available = Select[records, TrueQ[Lookup[#, "Available", False]] &];
  unavailable = Length[records] - Length[available];
  scale = Max[N[tsSides[tri]]];
  activeID = If[hovered =!= None, hovered, selected];
  active = SelectFirst[available, #ID === activeID &, Missing["NoSelection"]];
  hoverRec = SelectFirst[available, #ID === hovered &, Missing["NoHover"]];
  footPrimitive = If[AssociationQ[hoverRec],
    {Directive[RGBColor[.88, .94, 1.], Dashed, AbsoluteThickness[1.8], Opacity[.90]],
     Line[{hoverRec["Point"], hoverRec["Foot"]}],
     Directive[White, PointSize[.012]], Point[hoverRec["Foot"]]}, {}];
  pointPrimitives = Map[
    Function[rec, Module[{col = tsIndexColor[rec["Index"]],
       rad = tsStarRadius[rec["Index"], scale], id = rec["ID"], body, over},
      body = {EdgeForm[Directive[White, Opacity[.55], Thin]], FaceForm[col],
        If[rec["Category"] === "Optimization", Glow[col], Nothing],
        Sphere[rec["Point"], rad]};
      over = {Glow[White], EdgeForm[Directive[White, Thick]],
        FaceForm[Lighter[col, .22]], Sphere[rec["Point"], 1.42 rad]};
      EventHandler[Tooltip[Mouseover[body, over], rec["Name"]],
       {"MouseEntered" :> (hovered = id),
        "MouseExited" :> If[hovered === id, hovered = None],
        "MouseClicked" :> (selected = id)}]
      ]],
    Reverse@SortBy[available, #Index &]
    ];
  pts = Join[N[tri], Lookup[available, "Point", {}]];
  bounds = If[pts === {}, All,
    With[{lo = Min /@ Transpose[pts], hi = Max /@ Transpose[pts]},
     MapThread[{#1 - .08 scale, #2 + .08 scale} &, {lo, hi}]]];
  plot = Graphics3D[
    {
     {FaceForm[Directive[RGBColor[.10, .18, .31], Opacity[.42]]],
      EdgeForm[Directive[RGBColor[.55, .71, .92], AbsoluteThickness[2.2]]], Polygon[N[tri]]},
     {RGBColor[.80, .88, 1.], AbsoluteThickness[2.4],
      Line[Append[N[tri], First[N[tri]]]]},
     MapThread[{Glow[#2], #2, Sphere[#1, .026 scale],
         Text[Style[#3, 15, Bold, White], #1 + .055 scale tsBaseNormal[tri]]} &,
      {N[tri], {RGBColor[1., .35, .28], RGBColor[.28, .72, 1.], RGBColor[.34, 1., .59]}, vertexLabels}],
     footPrimitive,
     pointPrimitives
     },
    PlotRange -> bounds, Boxed -> False, Axes -> True,
    AxesStyle -> Directive[RGBColor[.46, .53, .66], 9],
    Background -> RGBColor[.025, .035, .065],
    Lighting -> {{"Ambient", White}}, SphericalRegion -> True,
    ViewPoint -> {1.8, -2.25, 1.55}, ViewVertical -> {0, 0, 1},
    ImageSize -> {780, 610}
    ];
  ids = Thread[Lookup[available, "ID"] ->
      (Row[{#Rank, "  |  ", tsShort[#Name, 48]}] & /@ available)];
  selector = PopupMenu[Dynamic[selected], Prepend[ids, None -> "Hover or choose a star"]];
  countText = Row[{Style[Length[available], Bold, White], " visible / ", Length[records],
     " selected by filters", If[unavailable > 0, Row[{"   (", unavailable, " unavailable/complex)"}], ""]}];
  Grid[{
    {Column[{Row[{Style["Visible stars   ", 11, Bold, White], selector}],
       Style[countText, 10.5, RGBColor[.74, .80, .91]], plot}, Spacings -> .55],
     tsInfoPanel[active, detail]}
    }, Alignment -> Top, Spacings -> {1.1, 0}]
  ];

(* ---------- Public dynamic visualization ---------- *)

TriangleSkyStarCatalogue[] := DynamicModule[
  {tri = N[{{0, 0, 0}, {21, 0, 0}, {16, 12, 0}}],
   cutoff = 4., detail = "Concentrated", hovered = None, selected = None,
   search = "", showConstructive = True, showOptimization = True,
   calculateOptimizers = True, optimizationCache = <||>, labels = {"A", "B", "C"}},
  Column[{
    Row[{Style["TRIANGLE SKY", 25, Bold, RGBColor[1., .78, .26]],
      Spacer[14], Style["Dynamic Star Catalogue", 22, FontWeight -> "Light", White]}],
    Style["Ranked constructive stars plus EVS, CVS, IVS, ERS, DGS and NFIS",
     11.5, RGBColor[.67, .74, .86]],
    Framed[
     Grid[{
       {Style["Index cutoff", 11, Bold, White],
        Row[{Slider[Dynamic[cutoff], {10/13, 5, .01}, ImageSize -> 250],
          Spacer[8], Dynamic@Style[NumberForm[cutoff, {4, 2}], 12, Bold, White],
          Spacer[12], Button["2", cutoff = 2], Button["3", cutoff = 3],
          Button["4", cutoff = 4], Button["5", cutoff = 5]}],
        Style["Information", 11, Bold, White],
        SetterBar[Dynamic[detail], {"Concentrated", "Detailed"}]},
       {Style["Catalogue", 11, Bold, White],
        Row[{Checkbox[Dynamic[showConstructive]], " constructive   ",
          Checkbox[Dynamic[showOptimization]], " optimization   ",
          Checkbox[Dynamic[calculateOptimizers]], " solve ERS/DGS/NFIS"}],
        Style["Search", 11, Bold, White],
        InputField[Dynamic[search], String, FieldSize -> 26]}
       }, Alignment -> {{Left, Left, Left, Left}}, Spacings -> {1.2, .8}],
     Background -> RGBColor[.055, .075, .12], FrameStyle -> RGBColor[.19, .27, .41],
     RoundingRadius -> 9],
    Grid[{{
       Framed[
        Column[{
          Style["Reference triangle", 14, Bold, White],
          Style["Drag A, B and C in this x-y editor. The three z sliders make the motion fully 3D.",
           9.5, RGBColor[.72, .79, .90]],
          LocatorPane[
           Dynamic[tri[[All, {1, 2}]]],
           Dynamic@Graphics[
             {FaceForm[Directive[RGBColor[.18, .31, .50], Opacity[.58]]],
              EdgeForm[Directive[RGBColor[.72, .84, 1.], Thick]], Polygon[tri[[All, {1, 2}]]],
              MapThread[{#2, Disk[#1, .45], Text[Style[#3, 12, Bold, White], #1 + {.7, .7}]} &,
               {tri[[All, {1, 2}]], {RGBColor[1., .35, .28], RGBColor[.28, .72, 1.],
                 RGBColor[.34, 1., .59]}, labels}]},
             PlotRange -> {{-8, 30}, {-8, 25}}, Axes -> True,
             Background -> RGBColor[.025, .035, .065], ImageSize -> {275, 225}],
           LocatorAutoCreate -> False],
          Grid@Table[
            {Style[labels[[i]] <> " z", 10, Bold, White],
             Slider[Dynamic[tri[[i, 3]]], {-20, 20, .05}, ImageSize -> 180],
             Dynamic@NumberForm[tri[[i, 3]], {6, 2}]}, {i, 3}],
          Row[{Button["13-20-21", tri = N[{{0, 0, 0}, {21, 0, 0}, {16, 12, 0}}]],
            Spacer[6], Button["6-9-13", tri = N[{{0, 0, 0}, {13, 0, 0},
                {107/13, Sqrt[9^2 - (107/13)^2], 0}}]],
            Spacer[6], Button["Clear optimizer cache", optimizationCache = <||>]}],
          Style["Rotate and zoom the large 3D plot with the mouse. Hover for a foot line; click to pin.",
           9.5, RGBColor[.72, .79, .90]]
          }, Spacings -> .75],
        Background -> RGBColor[.055, .075, .12], FrameStyle -> RGBColor[.19, .27, .41],
        RoundingRadius -> 9],
       Dynamic[
        ControlActive[
         tsCatalogueView[tri, cutoff, detail, hovered, selected, search,
          showConstructive, showOptimization, False, optimizationCache],
         tsCatalogueView[tri, cutoff, detail, hovered, selected, search,
          showConstructive, showOptimization, calculateOptimizers, optimizationCache]],
        TrackedSymbols :> {tri, cutoff, detail, hovered, selected, search,
          showConstructive, showOptimization, calculateOptimizers},
        SynchronousUpdating -> False]
       }}, Alignment -> Top, Spacings -> {1.0, 0}],
    Style["Color and sphere radius decrease monotonically with the rational index. Optimization ranks O1-O6 form a separate adopted annex; constructive ranks retain the workbook ranking.",
     9.5, RGBColor[.56, .64, .76]]
    }, Spacings -> .8,
   Background -> RGBColor[.018, .025, .047]]
  ];

End[];
EndPackage[];
