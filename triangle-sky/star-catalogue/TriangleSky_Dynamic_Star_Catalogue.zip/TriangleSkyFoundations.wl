(* ::Package:: *)

(* Triangle Sky -- foundational geometry and expression evaluator.
   Wolfram Language 15.0.  All calculations are coordinate-free in R^3.

   Inert expression heads:
     TSA, TSB, TSC                         base vertices, cost 0
     TSX[i]                                X(1)..X(4), cost 1
     TSZ[i]                                ES, OS, CS1, cost 1
     TSY[i,p,q,r,s]                        tetrahedral center, cost 1 + arguments
     TSLine[p,q], TSPlane[p,q,r]           geometric carriers
     TSIntersect[u,v]
     TSConjugate[p], TSTrace[p,q], TSAxis[p], TSFoot[p]
*)

ClearAll[
  TSA, TSB, TSC, TSX, TSY, TSZ, TSLine, TSPlane, TSIntersect,
  TSConjugate, TSTrace, TSAxis, TSFoot, TSCost, TSEvaluate,
  TSStarQ, TSFormalStarQ, TSSkyQ, TSCenterQ, TSStarHeight,
  TSHeightSquared, TSSignedHeight, TSStarFoot, TSPrimitiveName,
  TSCanonicalExpression, TSEquivalentQ, TSFingerprint
  ];

$TSTolerance = 10^-9;
$TSPrimitiveName = <|
   TSX[1] -> "X(1) — incenter",
   TSX[2] -> "X(2) — centroid",
   TSX[3] -> "X(3) — circumcenter",
   TSX[4] -> "X(4) — orthocenter",
   TSY[1] -> "Y(1) — tetrahedral incenter",
   TSY[2] -> "Y(2) — tetrahedral centroid",
   TSY[3] -> "Y(3) — tetrahedral circumcenter",
   TSZ[1] -> "Z(1) — equifacial star ES",
   TSZ[2] -> "Z(2) — orthostar OS",
   TSZ[3] -> "Z(3) — first circumstar CS1"
   |>;

(* ---------- Euclidean helpers ---------- *)

(* Bilinear, rather than Hermitian, length gives the analytic continuation
   required when a formal construction has complex coordinates. *)
tsLength[v_] := Sqrt[v . v];
tsPlaneNormal[{a_, b_, c_}] := Module[{w = Cross[b - a, c - a]}, w/tsLength[w]];
tsTriangleArea[{a_, b_, c_}] := tsLength[Cross[b - a, c - a]]/2;
tsSides[{a_, b_, c_}] := {tsLength[b - c], tsLength[c - a], tsLength[a - b]};

tsReflectInBase[x_, tri : {a_, b_, c_}] := Module[{n = tsPlaneNormal[tri]},
  x - 2 Dot[x - a, n] n
  ];

tsTriangleCircumcenter[{a_, b_, c_}] := Module[{u = b - a, v = c - a, x},
  x = LinearSolve[{2 u, 2 v, Cross[u, v]},
    {b . b - a . a, c . c - a . a, Dot[Cross[u, v], a]}];
  x
  ];

tsTriangleCenter[i_Integer, tri : {a_, b_, c_}] := Module[{sa, sb, sc, o},
  {sa, sb, sc} = tsSides[tri];
  Switch[i,
   1, (sa a + sb b + sc c)/(sa + sb + sc),
   2, Mean[tri],
   3, tsTriangleCircumcenter[tri],
   4, o = tsTriangleCircumcenter[tri]; a + b + c - 2 o,
   _, Missing["UnknownTriangleCenter", i]
   ]
  ];

tsTetrahedronCenter[i_Integer, pts : {p1_, p2_, p3_, p4_}] := Module[{weights},
  Switch[i,
   1,
   weights = tsTriangleArea /@ {
      {p2, p3, p4}, {p1, p3, p4}, {p1, p2, p4}, {p1, p2, p3}};
   If[Abs[N[Total[weights]]] <= $TSTolerance, Missing["DegenerateTetrahedron"],
    Total[MapThread[#1 #2 &, {weights, pts}]]/Total[weights]],
   2, Mean[pts],
   3, Quiet@Check[
     LinearSolve[2 (Rest[pts] - p1), Rest[(# . #) & /@ pts] - p1 . p1],
     Missing["DegenerateTetrahedron"]],
   _, Missing["UnknownTetrahedralCenter", i]
   ]
  ];

(* ES is the positively oriented intersection of spheres
   DA=a, DB=b, DC=c, where a=BC, b=CA, c=AB. *)
tsEquifacialStar[tri : {a0_, b0_, c0_}] := Module[
  {a, b, c, u, v, gram, rhs, coeff, foot, h2, n},
  {a, b, c} = tsSides[tri]; u = b0 - a0; v = c0 - a0;
  gram = {{u . u, u . v}, {u . v, v . v}};
  rhs = {(c^2 - b^2 + a^2)/2, (b^2 - c^2 + a^2)/2};
  coeff = Quiet@Check[LinearSolve[gram, rhs], Return[Missing["DegenerateBase"]]];
  foot = a0 + coeff[[1]] u + coeff[[2]] v;
  h2 = a^2 - Norm[foot - a0]^2;
  n = tsPlaneNormal[tri]; foot + Sqrt[h2] n
  ];

(* OS has foot H=X(4); DA, DB, DC are pairwise orthogonal at D. *)
tsOrthostar[tri : {a_, b_, c_}] := Module[{h, h2},
  h = tsTriangleCenter[4, tri];
  h2 = -Dot[a - h, b - h];
  h + Sqrt[h2] tsPlaneNormal[tri]
  ];

tsSimpleStar[i_Integer, tri_List] := Switch[i,
  1, tsEquifacialStar[tri],
  2, tsOrthostar[tri],
  3, With[{es = tsEquifacialStar[tri]},
    If[MissingQ[es], es, Mean[Append[tri, es]]]],
  _, Missing["UnknownSimpleStar", i]
  ];

(* ---------- Typed geometric carriers ---------- *)

tsLine[p_, q_] := If[Abs[N[tsLength[q - p]]] <= $TSTolerance,
  Missing["CoincidentLinePoints"],
  <|"Type" -> "Line", "Point" -> p, "Direction" -> q - p|>];

tsPlane[p_, q_, r_] := Module[{n = Cross[q - p, r - p]},
  If[Abs[N[tsLength[n]]] <= $TSTolerance, Missing["CollinearPlanePoints"],
   <|"Type" -> "Plane", "Point" -> p, "Normal" -> n|>]
  ];

tsIntersect[line_Association, plane_Association] /;
   line["Type"] === "Line" && plane["Type"] === "Plane" := Module[{den, t},
  den = Dot[plane["Normal"], line["Direction"]];
  If[Abs[den] <= $TSTolerance, Return[Missing["NoUniqueIntersection"]]];
  t = Dot[plane["Normal"], plane["Point"] - line["Point"]]/den;
  line["Point"] + t line["Direction"]
  ];

tsIntersect[plane_Association, line_Association] /;
   plane["Type"] === "Plane" && line["Type"] === "Line" := tsIntersect[line, plane];

tsIntersect[l1_Association, l2_Association] /;
   l1["Type"] === "Line" && l2["Type"] === "Line" := Module[{m, t, p, q},
  m = Transpose[{l1["Direction"], -l2["Direction"]}];
  t = Quiet@Check[LeastSquares[m, l2["Point"] - l1["Point"]],
    Return[Missing["NoUniqueIntersection"]]];
  p = l1["Point"] + t[[1]] l1["Direction"];
  q = l2["Point"] + t[[2]] l2["Direction"];
  If[Norm[p - q] <= 100 $TSTolerance, Mean[{p, q}], Missing["SkewLines"]]
  ];

tsIntersect[p1_Association, p2_Association] /;
   p1["Type"] === "Plane" && p2["Type"] === "Plane" := Module[{d, x},
  d = Cross[p1["Normal"], p2["Normal"]];
  If[Norm[d] <= $TSTolerance, Return[Missing["NoUniqueIntersection"]]];
  x = LeastSquares[{p1["Normal"], p2["Normal"]},
    {Dot[p1["Normal"], p1["Point"]], Dot[p2["Normal"], p2["Point"]]}];
  <|"Type" -> "Line", "Point" -> x, "Direction" -> d|>
  ];

tsIntersect[___] := Missing["UnsupportedIntersection"];

(* ---------- Expression cost ---------- *)

TSCost[TSA | TSB | TSC] := 0;
TSCost[TSX[i_Integer]] /; 1 <= i <= 4 := 1;
TSCost[TSZ[i_Integer]] /; 1 <= i <= 3 := 1;
TSCost[TSConjugate[e_]] := TSCost[e];
TSCost[TSY[i_Integer, args__]] := 1 + Total[TSCost /@ {args}];
TSCost[(TSLine | TSIntersect | TSTrace)[args__]] := 1 + Total[TSCost /@ {args}];
TSCost[TSPlane[args__]] := 1 + Total[TSCost /@ {args}];
TSCost[TSAxis[e_]] := 1 + TSCost[e];
TSCost[TSFoot[args__]] := 1 + Total[TSCost /@ {args}];
TSCost[_] := Infinity;

(* ---------- Expression evaluation ---------- *)

TSEvaluate[TSA, tri_List] := tri[[1]];
TSEvaluate[TSB, tri_List] := tri[[2]];
TSEvaluate[TSC, tri_List] := tri[[3]];
TSEvaluate[TSX[i_Integer], tri_List] := tsTriangleCenter[i, tri];
TSEvaluate[TSZ[i_Integer], tri_List] := tsSimpleStar[i, tri];
TSEvaluate[TSY[i_Integer, args__], tri_List] := Module[{p = TSEvaluate[#, tri] & /@ {args}},
  If[AnyTrue[p, MissingQ], First@Select[p, MissingQ], tsTetrahedronCenter[i, p]]];
TSEvaluate[TSLine[p_, q_], tri_List] := Module[{u = TSEvaluate[p, tri], v = TSEvaluate[q, tri]},
  If[MissingQ[u] || MissingQ[v], Missing["InvalidLineArguments"], tsLine[u, v]]];
TSEvaluate[TSPlane[p_, q_, r_], tri_List] := Module[
  {u = TSEvaluate[p, tri], v = TSEvaluate[q, tri], w = TSEvaluate[r, tri]},
  If[MissingQ[u] || MissingQ[v] || MissingQ[w], Missing["InvalidPlaneArguments"], tsPlane[u, v, w]]];
TSEvaluate[TSIntersect[p_, q_], tri_List] := Module[{u = TSEvaluate[p, tri], v = TSEvaluate[q, tri]},
  If[MissingQ[u] || MissingQ[v], Missing["InvalidIntersectionArguments"], tsIntersect[u, v]]];
TSEvaluate[TSConjugate[e_], tri_List] := TSEvaluate[e, tri[[{1, 3, 2}]]];
TSEvaluate[TSTrace[p_, q_], tri_List] := Module[{u, v, base},
  {u, v} = TSEvaluate[#, tri] & /@ {p, q}; base = tsPlane @@ tri;
  If[MissingQ[u] || MissingQ[v] || MissingQ[base], Missing["InvalidTraceArguments"],
   tsIntersect[tsLine[u, v], base]]];
TSEvaluate[TSAxis[e_], tri_List] := Module[{u, v},
  u = TSEvaluate[e, tri]; v = TSEvaluate[TSConjugate[e], tri];
  If[MissingQ[u] || MissingQ[v], Missing["InvalidAxisArgument"], tsLine[u, v]]];
tsProjectToPlane[p_, plane_Association] := Module[{n = plane["Normal"]},
  p - Dot[p - plane["Point"], n]/Dot[n, n] n];

(* foot(point) projects to the global x-y plane.  foot(point,plane) uses an
   explicitly constructed plane.  In canonical catalog coordinates ABC is
   placed in the x-y plane. *)
TSEvaluate[TSFoot[e_], tri_List] := Module[{p = TSEvaluate[e, tri]},
  If[MissingQ[p] || AssociationQ[p], Missing["InvalidFootArgument"],
   tsProjectToPlane[p, <|"Type" -> "Plane", "Point" -> {0, 0, 0}, "Normal" -> {0, 0, 1}|>]]];
TSEvaluate[TSFoot[e_, plane_], tri_List] := Module[
  {p = TSEvaluate[e, tri], q = TSEvaluate[plane, tri]},
  If[MissingQ[p] || MissingQ[q] || AssociationQ[p] || ! AssociationQ[q] || q["Type"] =!= "Plane",
   Missing["InvalidFootArguments"], tsProjectToPlane[p, q]]];
TSEvaluate[e_, _List] := Missing["UnknownExpression", HoldForm[e]];

(* ---------- Star/center recognition ---------- *)

TSSignedHeight[e_, tri_List] := Module[{d = TSEvaluate[e, tri]},
  If[MissingQ[d] || AssociationQ[d], Missing["NotPoint"],
   Dot[d - tri[[1]], tsPlaneNormal[tri]]]
  ];

TSHeightSquared[e_, tri_List] := Module[{d = TSEvaluate[e, tri], f},
  If[MissingQ[d] || AssociationQ[d], Return[Missing["NotPoint"]]];
  f = TSStarFoot[e, tri]; (d - f) . (d - f)
  ];

TSStarHeight[e_, tri_List] := Module[{q = TSHeightSquared[e, tri]},
  If[MissingQ[q], q, Sqrt[q]]
  ];

TSStarFoot[e_, tri_List] := Module[{d = TSEvaluate[e, tri], n = tsPlaneNormal[tri]},
  If[MissingQ[d] || AssociationQ[d], Missing["NotPoint"],
   d - Dot[d - tri[[1]], n]/Dot[n, n] n]
  ];

(* A formal star is recognized from the two defining invariants only:
   permutation-invariant foot and a symmetric homogeneous height.  Squared
   height is used so the test remains analytic for complex branches. *)
TSFormalStarQ[e_, tri_List, tol_: 10^-7] := Module[
  {d, f, q, perms, feet, qvals, scale = 1.731, scaledTri, fs, qs,
   shift = {.371, -.813, 1.147}, ft, qt},
  d = TSEvaluate[e, tri];
  If[MissingQ[d] || AssociationQ[d] || ! VectorQ[N[d], NumericQ], Return[False]];
  f = TSStarFoot[e, tri]; q = TSHeightSquared[e, tri];
  If[MissingQ[f] || MissingQ[q] || Abs[N[q]] <= tol, Return[False]];
  perms = Permutations[Range[3]];
  feet = TSStarFoot[e, tri[[#]]] & /@ perms;
  qvals = TSHeightSquared[e, tri[[#]]] & /@ perms;
  If[AnyTrue[Join[feet, qvals], MissingQ] ||
    ! And @@ (Norm[N[# - f]] <= tol & /@ feet) ||
    ! And @@ (Abs[N[# - q]] <= tol & /@ qvals), Return[False]];
  scaledTri = scale tri; fs = TSStarFoot[e, scaledTri]; qs = TSHeightSquared[e, scaledTri];
  If[MissingQ[fs] || MissingQ[qs] || Norm[N[fs - scale f]] > 10 tol ||
    Abs[N[qs - scale^2 q]] > 10 tol, Return[False]];
  ft = TSStarFoot[e, (# + shift) & /@ tri]; qt = TSHeightSquared[e, (# + shift) & /@ tri];
  ! MissingQ[ft] && ! MissingQ[qt] && Norm[N[ft - (f + shift)]] <= 10 tol &&
   Abs[N[qt - q]] <= 10 tol
  ];

TSStarQ[e_, tri_List, tol_: 10^-7] := TSFormalStarQ[e, tri, tol];

(* A formal star appears in the real sky when its chosen branch is real and
   lies on the positive side of the ordered base. *)
TSSkyQ[e_, tri_List, tol_: 10^-7] := Module[{d, h},
  If[! TSFormalStarQ[e, tri, tol], Return[False]];
  d = N[TSEvaluate[e, tri]]; h = N[TSSignedHeight[e, tri]];
  Max[Abs[Im[d]]] <= tol && Abs[Im[h]] <= tol && Re[h] > tol
  ];

TSCenterQ[e_, tri_List, tol_: 10^-7] := Module[{d, values, perms, n},
  d = TSEvaluate[e, tri];
  If[MissingQ[d] || AssociationQ[d] || ! VectorQ[N[d], NumericQ], Return[False]];
  n = tsPlaneNormal[tri]; If[Abs[Dot[d - tri[[1]], n]] > tol, Return[False]];
  perms = Permutations[Range[3]]; values = TSEvaluate[e, tri[[#]]] & /@ perms;
  ! AnyTrue[values, MissingQ] && And @@ (Norm[N[# - d]] <= tol & /@ values)
  ];

(* Basic canonicalization prevents zero-cost conjugation loops and removes
   ordering duplicates for symmetric carriers. More rules belong in the enumerator. *)
TSCanonicalExpression[TSConjugate[TSConjugate[e_]]] := TSCanonicalExpression[e];
TSCanonicalExpression[TSConjugate[TSA]] := TSA;
TSCanonicalExpression[TSConjugate[TSB]] := TSC;
TSCanonicalExpression[TSConjugate[TSC]] := TSB;
TSCanonicalExpression[TSConjugate[e_]] := TSConjugate[TSCanonicalExpression[e]];
TSCanonicalExpression[TSLine[p_, q_]] := TSLine @@ SortBy[TSCanonicalExpression /@ {p, q}, ToString[InputForm[#]] &];
TSCanonicalExpression[TSPlane[p_, q_, r_]] := TSPlane @@ SortBy[TSCanonicalExpression /@ {p, q, r}, ToString[InputForm[#]] &];
TSCanonicalExpression[TSIntersect[p_, q_]] := TSIntersect @@ SortBy[TSCanonicalExpression /@ {p, q}, ToString[InputForm[#]] &];
TSCanonicalExpression[TSTrace[p_, q_]] := TSTrace @@ SortBy[TSCanonicalExpression /@ {p, q}, ToString[InputForm[#]] &];
TSCanonicalExpression[TSY[i_, p_, q_, r_, s_]] :=
  TSY[i, Sequence @@ SortBy[TSCanonicalExpression /@ {p, q, r, s}, ToString[InputForm[#]] &]];
TSCanonicalExpression[h_[args___]] := h @@ (TSCanonicalExpression /@ {args});
TSCanonicalExpression[e_] := e;

(* A multi-sample numerical fingerprint for semantic deduplication. *)
$TSSampleTriangles = N@{
   {{0, 0, 0}, {4, 0, 0}, {1.2, 3.1, 0}},
   {{0, 0, 0}, {5.1, 0, 0}, {2.2, 3.7, 0}},
   {{0, 0, 0}, {3.7, 0, 0}, {1.6, 2.9, 0}}
   };

TSFingerprint[e_, digits_: 9] := Module[{v = TSEvaluate[e, #] & /@ $TSSampleTriangles},
  If[AnyTrue[v, MissingQ], Missing["UndefinedFingerprint"],
   Round[Flatten[N[v]], 10.^(-digits)]]
  ];

TSEquivalentQ[e1_, e2_, tol_: 10^-8] := Module[{f1 = TSFingerprint[e1], f2 = TSFingerprint[e2]},
  ! MissingQ[f1] && ! MissingQ[f2] && Norm[N[f1 - f2]] <= tol
  ];

(* Examples from the project statement. *)
$TSExample1 = TSY[2, TSA, TSB, TSC, TSZ[2]];
$TSExample2 = TSTrace[
   TSY[3, TSA, TSB, TSC, TSConjugate[TSZ[3]]],
   TSZ[3]];
