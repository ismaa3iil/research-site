# Exact finite check for the cumulative near-primitive-root mass through d=33.
# No external packages.  All comparisons are Rational{BigInt}.

const DMAX = 33
const SMALL_PRIMES = [2,3,5,7,11,13,17,19,23,29,31]

function factor_distinct(n::Int)
    ps = Int[]; t=n; p=2
    while p*p <= t
        if t % p == 0
            push!(ps,p); while t%p==0; t ÷= p; end
        end
        p = p==2 ? 3 : p+2
    end
    t>1 && push!(ps,t)
    ps
end

function two_part(n::Int)
    a=1
    while iseven(n); a*=2; n÷=2; end
    a
end

function EoverA(t::Int)
    r = big(1)//big(t)^2
    for p in factor_distinct(t)
        r *= big(p*p-1)//big(p*p-p-1)
    end
    r
end

function B(g::Int,t::Int)
    r=big(1)//big(1)
    for p in factor_distinct(g)
        if t%p != 0
            r *= -big(1)//big(p*p-p-1)
        end
    end
    r
end

# Moree Table 1 for positive squarefree g.
function mass_over_A(g::Int)
    mod(g,4)==0 && error("g must be squarefree")
    R=big(0)//big(1)
    for t in 1:DMAX
        E=EoverA(t); b=B(g,t); t2=two_part(t)
        fac = if g%4==1
            t2==1 ? 1-b : 1+b
        elseif g%4==2
            t2<4 ? 1 : (t2==4 ? 1-b/3 : 1+b)
        else # g % 4 == 3
            t2==1 ? 1 : (t2==2 ? 1-b/3 : 1+b)
        end
        R += E*fac
    end
    R
end

G = sum(EoverA(t) for t in 1:DMAX)
R2 = mass_over_A(2)
@assert G-R2 > G//1331  # rules out any squarefree kernel having a prime >=37

bestR = G; bestg = 0
for mask in 1:(2^length(SMALL_PRIMES)-1)
    g=1
    for (i,p) in enumerate(SMALL_PRIMES)
        if ((mask >> (i-1)) & 1)==1; g*=p; end
    end
    R=mass_over_A(g)
    if R < bestR; global bestR=R; global bestg=g; end
end
@assert bestg==2 && bestR==R2

A = BigFloat("0.37395581361920228805472805434641641511162924860615")
println("generic mass through 33 = ", BigFloat(G)*A)
println("minimum non-perfect-power mass = ", BigFloat(bestR)*A)
println("minimizing squarefree kernel = ",bestg)
println("tail certificate: G-R2 > G/1331 = ", G-R2 > G//1331)
