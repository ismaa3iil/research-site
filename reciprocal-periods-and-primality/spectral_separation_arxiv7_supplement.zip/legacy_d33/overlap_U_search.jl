#!/usr/bin/env julia

# overlap_U_search.jl
#
# Certified overlap-aware exhaustive search for odd composite n such that
#
#       ord_n(b) = (n-1)/m
#
# for some integer base b >= 2 coprime to n.
#
# Mathematical state:
#
#   L = (n-1)/m
#   d = lambda(n)/L
#   H = phi(n)/lambda(n)
#   j = d*H = phi(n)/L
#
# For n = prod p_i^a_i, write
#
#   P = prod p_i^(a_i-1) = n/rad(n).
#
# The structural lemmas used by this program are:
#
#   P | d,
#   2^(s-1) | H,
#   j=dH <= m-1,
#
# and, after dividing m*phi(n)=j(n-1) by P,
#
#   m * prod_i (p_i-1)
#       = c * (P*prod_i p_i - 1),       c = j/P.
#
# For a prefix of s-1 distinct primes this equation is linear in the last
# prime, so the last prime is solved EXACTLY rather than searched.
#
# Overlap state:
#
#   local_i = p_i^(a_i-1)*(p_i-1)
#   Lambda_k = lcm(local_1,...,local_k)
#   H_k = prod(local_i)/Lambda_k
#
# and
#
#   H_k = H_(k-1) * gcd(Lambda_(k-1), local_k).
#
# Every prefix is discarded unless H_k | H and enough overlap budget remains
# for the remaining local factors.
#
# IMPORTANT RIGOR RULES:
# No floating-point calculation is used in a pruning decision.
# Prime-candidate decisions are deterministic for every candidate < 2^64;
# a larger candidate aborts the run rather than using a probable-prime test.
#
# External package dependencies: none.
# Run, for example:
#
#   julia -t auto overlap_U_search.jl --start=17 --stop=32 --out=run17_32
#   julia -t auto overlap_U_search.jl --start=33 --stop=33 --out=run33
#   julia -t auto overlap_U_search.jl --selftest
#
# A completed m is marked by m_XXX_DONE.txt.  --resume=true skips such m.
#
# ---------------------------------------------------------------------------

using Dates
using Printf
using SHA

# --------------------- deterministic 64-bit primality ----------------------
#
# The paper certifies only d <= 33.  Prime candidates are required to fit in
# UInt64 and are tested deterministically by the standard seven-base
# Miller--Rabin set valid for every n < 2^64.  UInt128 products prevent
# overflow in modular multiplication.  If a future search reaches a candidate
# outside this range, the program aborts rather than silently switching to a
# probable-prime test.

const MR_BASES_U64 = UInt64[2, 325, 9375, 28178, 450775, 9780504, 1795265022]
const SMALL_TRIAL_U64 = UInt64[2,3,5,7,11,13,17,19,23,29,31,37]

@inline function mulmod_u64(a::UInt64, b::UInt64, m::UInt64)::UInt64
    return UInt64((UInt128(a) * UInt128(b)) % UInt128(m))
end

function powmod_u64(a::UInt64, e::UInt64, m::UInt64)::UInt64
    r = UInt64(1)
    x = a % m
    k = e
    while k > 0
        if isodd(k)
            r = mulmod_u64(r, x, m)
        end
        k >>= 1
        k == 0 && break
        x = mulmod_u64(x, x, m)
    end
    return r
end

function isprime_u64(n::UInt64)::Bool
    n < 2 && return false
    for p in SMALL_TRIAL_U64
        n == p && return true
        n % p == 0 && return false
    end

    d = n - 1
    s = 0
    while iseven(d)
        d >>= 1
        s += 1
    end

    for a0 in MR_BASES_U64
        a = a0 % n
        a == 0 && continue
        x = powmod_u64(a, d, n)
        (x == 1 || x == n - 1) && continue

        hit_minus_one = false
        for _ in 1:(s - 1)
            x = mulmod_u64(x, x, n)
            if x == n - 1
                hit_minus_one = true
                break
            end
        end
        hit_minus_one || return false
    end
    return true
end

function isprime_exact(n::Integer)::Bool
    n < 0 && return false
    nb = BigInt(n)
    nb <= BigInt(typemax(UInt64)) ||
        error("Prime candidate exceeds deterministic UInt64 range: $n")
    return isprime_u64(UInt64(nb))
end

function nextprime_exact(n::Integer)::BigInt
    x = BigInt(n)
    x <= 2 && return BigInt(2)
    x <= BigInt(typemax(UInt64)) ||
        error("Prime-search lower bound exceeds deterministic UInt64 range: $x")
    iseven(x) && (x += 1)
    while true
        x <= BigInt(typemax(UInt64)) ||
            error("Prime search exceeded deterministic UInt64 range")
        isprime_exact(x) && return x
        x += 2
    end
end

# ---------------------------- argument parsing -----------------------------

function parse_args(args)
    opts = Dict{String,String}(
        "start" => "17",
        "stop" => "33",
        "out" => "overlap_U_results",
        "resume" => "true",
        "selftest" => "false",
        "write_branches" => "true",
        "write_solutions" => "true",
    )

    for arg in args
        if arg == "--selftest"
            opts["selftest"] = "true"
        elseif startswith(arg, "--") && occursin("=", arg)
            key, val = split(arg[3:end], "=", limit=2)
            opts[key] = val
        else
            error("Unrecognized argument: $arg")
        end
    end

    return opts
end

parse_bool(s::AbstractString) = lowercase(s) in ("1","true","yes","y","on")

# ---------------------------- small utilities ------------------------------

function small_divisors(n::Int)
    ds = Int[]
    for d in 1:n
        n % d == 0 && push!(ds, d)
    end
    return ds
end

function prime_factors_small(n::Int)
    n == 1 && return Int[]
    t = n
    out = Int[]
    p = 2
    while p*p <= t
        if t % p == 0
            push!(out,p)
            while t % p == 0
                t ÷= p
            end
        end
        p = p == 2 ? 3 : p + 2
    end
    t > 1 && push!(out,t)
    return out
end

function vp_small(n::Int, p::BigInt)
    n == 1 && return 0
    pp = Int(p)
    e = 0
    t = n
    while t % pp == 0
        e += 1
        t ÷= pp
    end
    return e
end

@inline function local_carmichael_factor(p::BigInt, P::Int)
    e_extra = vp_small(P, p)
    return p^e_extra * (p - 1)
end

function contains_all_required_primes(primes::Vector{BigInt}, P::Int)
    req = prime_factors_small(P)
    for q in req
        BigInt(q) in primes || return false
    end
    return true
end

function smallest_missing_required(primes::Vector{BigInt}, P::Int)
    for q in prime_factors_small(P)
        if !(BigInt(q) in primes)
            return BigInt(q)
        end
    end
    return nothing
end

# ------------------------ exact recursive prime bound ----------------------
#
# At a prefix with
#
#   R = (m*A)/(c*P*B) > 1
#
# and t primes still to be supplied (including the algebraically solved last
# prime), a necessary condition for the next prime x is
#
#   (x/(x-1))^t > R,
#
# equivalently
#
#   x^t * (c*P*B) > (x-1)^t * (m*A).
#
# The predicate is monotone decreasing in x.

@inline function bound_holds(x::BigInt,
                             ratio_num::BigInt,
                             ratio_den::BigInt,
                             t::Int)
    x < 2 && return false
    return x^t * ratio_den > (x - 1)^t * ratio_num
end

function exact_max_integer_bound(ratio_num::BigInt,
                                 ratio_den::BigInt,
                                 t::Int,
                                 lower::BigInt)
    @assert ratio_num > ratio_den > 0
    @assert t >= 1

    lower < 2 && (lower = BigInt(2))

    if !bound_holds(lower, ratio_num, ratio_den, t)
        return lower - 1
    end

    lo = lower
    hi = max(BigInt(4), 2lo)

    while bound_holds(hi, ratio_num, ratio_den, t)
        lo = hi
        hi *= 2
    end

    while hi - lo > 1
        mid = (lo + hi) ÷ 2
        if bound_holds(mid, ratio_num, ratio_den, t)
            lo = mid
        else
            hi = mid
        end
    end

    return lo
end

# ----------------------------- result types --------------------------------

struct Branch
    m::Int
    s::Int
    d::Int
    H::Int
    P::Int
    c::Int
end

struct Solution
    m::Int
    n::BigInt
    s::Int
    d::Int
    H::Int
    P::Int
    c::Int
    L::BigInt
    lambda_n::BigInt
    phi_n::BigInt
    primes::Vector{BigInt}
end

mutable struct SearchStats
    nodes::Int
    prime_candidates::Int
    overlap_prunes::Int
    ratio_prunes::Int
    required_prime_prunes::Int
    final_candidates::Int
end

SearchStats() = SearchStats(0,0,0,0,0,0)

struct BranchResult
    branch::Branch
    solutions::Vector{Solution}
    stats::SearchStats
end

# -------------------------- overlap state checks ---------------------------

function overlap_can_finish(Hprefix::BigInt,
                            Htarget::Int,
                            selected_count::Int,
                            totalS::Int)
    Ht = BigInt(Htarget)

    Ht % Hprefix == 0 || return false

    remaining_additions = totalS - selected_count
    # After at least one local factor has been selected, every later local
    # Carmichael factor is even, while Lambda_prefix is even, so each future
    # overlap multiplier is at least 2.
    if selected_count >= 1
        min_remaining = BigInt(2)^remaining_additions
        Ht ÷ Hprefix >= min_remaining || return false
    end

    return true
end

# -------------------------- branch search engine ---------------------------

function search_branch(branch::Branch)::BranchResult
    m, s, d, H, P, c =
        branch.m, branch.s, branch.d, branch.H, branch.P, branch.c

    stats = SearchStats()
    sols = Solution[]

    req_primes = prime_factors_small(P)

    # P is the entire extra prime-power part and must use only selected primes.
    # If P has more distinct prime factors than s, the branch is impossible.
    length(req_primes) > s && return BranchResult(branch, sols, stats)

    function dfs!(current::Vector{BigInt},
                  prod_minus1::BigInt,
                  prod_p::BigInt,
                  lambda_prefix::BigInt,
                  Hprefix::BigInt)

        stats.nodes += 1
        r = length(current)

        # If a required prime from P has already been passed, the branch is dead.
        if !isempty(current)
            lastp = last(current)
            for q in req_primes
                qb = BigInt(q)
                if qb < lastp && !(qb in current)
                    stats.required_prime_prunes += 1
                    return
                end
            end
        end

        missing_count = count(q -> !(BigInt(q) in current), req_primes)
        remaining_slots = s - r
        if missing_count > remaining_slots
            stats.required_prime_prunes += 1
            return
        end

        overlap_can_finish(Hprefix, H, r, s) || begin
            stats.overlap_prunes += 1
            return
        end

        # ---------------------- solve exact last prime ----------------------
        if r == s - 1
            A = prod_minus1
            B = prod_p

            num = BigInt(m) * A - c
            den = BigInt(m) * A - BigInt(c) * BigInt(P) * B

            if den <= 0 || num <= 0 || num % den != 0
                return
            end

            pLast = num ÷ den
            stats.final_candidates += 1

            pLast > last(current) || return
            isprime_exact(pLast) || return

            full_primes = copy(current)
            push!(full_primes, pLast)

            contains_all_required_primes(full_primes, P) || return

            local_last = local_carmichael_factor(pLast, P)
            lambda_full = lcm(lambda_prefix, local_last)
            g = gcd(lambda_prefix, local_last)
            Hfull = Hprefix * g

            Hfull == H || return

            n = BigInt(P) * prod_p * pLast
            (n - 1) % m == 0 || return
            L = (n - 1) ÷ m

            # Order 1 is allowed: it is represented by b ≡ 1 (mod n).
            L >= 1 || return

            phi_n = BigInt(P) * prod_minus1 * (pLast - 1)

            # Independent exact consistency checks.
            BigInt(m) * phi_n == BigInt(d) * BigInt(H) * (n - 1) || return
            phi_n == BigInt(H) * lambda_full || return
            lambda_full == BigInt(d) * L || return

            push!(sols, Solution(m, n, s, d, H, P, c, L,
                                 lambda_full, phi_n, full_primes))
            return
        end

        # ---------------------- recursive next-prime bound -----------------
        ratio_num = BigInt(m) * prod_minus1
        ratio_den = BigInt(c) * BigInt(P) * prod_p

        if ratio_num <= ratio_den
            stats.ratio_prunes += 1
            return
        end

        t = s - r
        lastp = r == 0 ? BigInt(2) : last(current)
        lower = lastp + 1

        maxp = exact_max_integer_bound(ratio_num, ratio_den, t, lower)
        maxp < lower && return

        # A still-missing prime divisor of P cannot be skipped, because the
        # selected primes are strictly increasing.  Hence no current prime may
        # exceed the smallest missing required prime.
        reqmin = smallest_missing_required(current, P)
        if reqmin !== nothing
            maxp = min(maxp, reqmin)
        end

        p = nextprime_exact(lastp + 1)

        while p <= maxp
            stats.prime_candidates += 1

            local_factor = local_carmichael_factor(p, P)

            if r == 0
                lambda_new = local_factor
                Hnew = BigInt(1)
            else
                g = gcd(lambda_prefix, local_factor)

                # The new overlap multiplier must divide the remaining budget.
                remaining_budget = BigInt(H) ÷ Hprefix
                if remaining_budget % g != 0
                    stats.overlap_prunes += 1
                    p = nextprime_exact(p + 1)
                    continue
                end

                lambda_new = lcm(lambda_prefix, local_factor)
                Hnew = Hprefix * g
            end

            push!(current, p)

            if overlap_can_finish(Hnew, H, r + 1, s)
                dfs!(current,
                     prod_minus1 * (p - 1),
                     prod_p * p,
                     lambda_new,
                     Hnew)
            else
                stats.overlap_prunes += 1
            end

            pop!(current)
            p = nextprime_exact(p + 1)
        end
    end

    # At r=0 the overlap quotient is 1 by convention.
    dfs!(BigInt[], BigInt(1), BigInt(1), BigInt(1), BigInt(1))

    return BranchResult(branch, sols, stats)
end

# --------------------------- prime-power branch ----------------------------

function prime_power_solutions(m::Int)
    sols = Solution[]

    # If n=p^a is composite then H=1 and p^(a-1) | d <= m-1.
    p = 3
    while p <= m - 1
        if isprime_exact(p)
            a = 2
            while BigInt(p)^(a - 1) <= m - 1
                n = BigInt(p)^a

                if (n - 1) % m == 0
                    L = (n - 1) ÷ m
                    lambda_n = BigInt(p)^(a - 1) * (p - 1)

                    if L >= 1 && lambda_n % L == 0
                        d = Int(lambda_n ÷ L)
                        if 1 <= d <= m - 1
                            H = 1
                            P = Int(BigInt(p)^(a - 1))
                            d % P == 0 || error("Internal theorem check failed: P does not divide d")
                            phi_n = lambda_n
                            c = d ÷ P
                            push!(sols,
                                  Solution(m,n,1,d,H,P,c,L,
                                           lambda_n,phi_n,[BigInt(p)]))
                        end
                    end
                end

                a += 1
            end
        end
        p += 2
    end

    return sols
end

# ------------------------------ branch list --------------------------------

function make_branches(m::Int)
    branches = Branch[]
    smax = ndigits(m - 1; base=2)

    for s in 2:smax
        minH = 2^(s - 1)

        # d*H <= m-1 and H >= minH.
        for d in 1:((m - 1) ÷ minH)
            maxH = (m - 1) ÷ d

            # 2^(s-1) divides H.
            for H in minH:minH:maxH
                j = d * H

                # P = n/rad(n) divides d.
                for P in small_divisors(d)
                    j % P == 0 || continue
                    c = j ÷ P
                    push!(branches, Branch(m,s,d,H,P,c))
                end
            end
        end
    end

    return branches
end

# --------------------------- deterministic sorting -------------------------

solution_key(sol::Solution) = (sol.n, sol.s, sol.d, sol.H, sol.P, sol.c)

function unique_solutions(sols::Vector{Solution})
    sort!(sols, by=solution_key)
    out = Solution[]
    seen = Set{BigInt}()

    for sol in sols
        if !(sol.n in seen)
            push!(out, sol)
            push!(seen, sol.n)
        else
            # The same n,m should determine d,H,P uniquely.  A duplicate from a
            # different branch is suspicious and should fail loudly.
            old = out[end]
            if old.n == sol.n &&
               (old.d != sol.d || old.H != sol.H || old.P != sol.P)
                error("Inconsistent duplicate solution n=$(sol.n) for m=$(sol.m)")
            end
        end
    end

    return out
end

# ------------------------------- I/O ---------------------------------------

function primes_string(v::Vector{BigInt})
    return join(string.(v), ",")
end

function write_solutions_file(path::String, sols::Vector{Solution})
    open(path, "w") do io
        println(io, "m\tn\ts\td\tH\tP\tc\tL\tlambda\tphi\tprimes")
        for z in sols
            println(io,
                "$(z.m)\t$(z.n)\t$(z.s)\t$(z.d)\t$(z.H)\t$(z.P)\t$(z.c)\t" *
                "$(z.L)\t$(z.lambda_n)\t$(z.phi_n)\t$(primes_string(z.primes))")
        end
    end
end

function write_branches_file(path::String, results::Vector{BranchResult})
    open(path, "w") do io
        println(io,
            "m\ts\td\tH\tP\tc\tsolutions\tnodes\tprime_candidates\t" *
            "overlap_prunes\tratio_prunes\trequired_prime_prunes\tfinal_candidates\tmax_n")
        for r in sort(results, by=x -> (x.branch.s,x.branch.d,x.branch.H,x.branch.P))
            maxn = isempty(r.solutions) ? BigInt(0) : maximum(z.n for z in r.solutions)
            st = r.stats
            b = r.branch
            println(io,
                "$(b.m)\t$(b.s)\t$(b.d)\t$(b.H)\t$(b.P)\t$(b.c)\t" *
                "$(length(r.solutions))\t$(st.nodes)\t$(st.prime_candidates)\t" *
                "$(st.overlap_prunes)\t$(st.ratio_prunes)\t" *
                "$(st.required_prime_prunes)\t$(st.final_candidates)\t$(maxn)")
        end
    end
end

function file_sha256(path::String)
    open(path, "r") do io
        return bytes2hex(sha256(io))
    end
end

function append_global_summary(path::String,
                               m::Int,
                               sols::Vector{Solution},
                               branch_count::Int,
                               elapsed::Float64,
                               branch_file::String,
                               solution_file::String)
    newfile = !isfile(path)
    open(path, "a") do io
        if newfile
            println(io,
                "m\tcount\tmax_n\tbranch_count\telapsed_seconds\t" *
                "solutions_sha256\tbranches_sha256")
        end

        maxn = isempty(sols) ? BigInt(0) : maximum(z.n for z in sols)
        sh_sol = isfile(solution_file) ? file_sha256(solution_file) : "-"
        sh_br  = isfile(branch_file) ? file_sha256(branch_file) : "-"

        @printf(io, "%d\t%d\t%s\t%d\t%.6f\t%s\t%s\n",
                m,length(sols),string(maxn),branch_count,elapsed,sh_sol,sh_br)
    end
end

# ------------------------------ one m --------------------------------------

function run_one_m(m::Int, outdir::String;
                   write_branches::Bool=true,
                   write_solutions::Bool=true)

    mkpath(outdir)

    branches = make_branches(m)
    println("\n[m=$m] branches = $(length(branches)), threads = $(Threads.nthreads())")

    t0 = time()

    tasks = [Threads.@spawn search_branch(b) for b in branches]
    results = BranchResult[]

    # fetch propagates TaskFailedException: no failed branch can be silently
    # counted as completed.
    for t in tasks
        push!(results, fetch(t))
    end

    sols = prime_power_solutions(m)
    for r in results
        append!(sols, r.solutions)
    end
    sols = unique_solutions(sols)

    elapsed = time() - t0

    base = @sprintf("m_%03d", m)
    solution_file = joinpath(outdir, base * "_solutions.tsv")
    branch_file   = joinpath(outdir, base * "_branches.tsv")
    done_file     = joinpath(outdir, base * "_DONE.txt")

    write_solutions && write_solutions_file(solution_file, sols)
    write_branches && write_branches_file(branch_file, results)

    open(done_file, "w") do io
        println(io, "m=$m")
        println(io, "completed=$(now())")
        println(io, "julia=$(VERSION)")
        println(io, "threads=$(Threads.nthreads())")
        println(io, "branches=$(length(branches))")
        println(io, "solutions=$(length(sols))")
        println(io, "max_n=$(isempty(sols) ? 0 : maximum(z.n for z in sols))")
        println(io, "elapsed_seconds=$elapsed")
        isfile(solution_file) && println(io, "solutions_sha256=$(file_sha256(solution_file))")
        isfile(branch_file) && println(io, "branches_sha256=$(file_sha256(branch_file))")
    end

    println("[m=$m] completed in $(round(elapsed,digits=3)) s")
    println("[m=$m] solutions = ", [z.n for z in sols])

    return sols, results, elapsed, solution_file, branch_file
end

# ------------------------------ regression --------------------------------

const EXPECTED_SMALL = Dict(
    1 => BigInt[],
    2 => BigInt[],
    3 => BigInt[],
    4 => BigInt[9],
    5 => BigInt[6601],
    6 => BigInt[25],
    7 => BigInt[15,561],
    8 => BigInt[9,49],
)

function selftest()
    println("Running exact regression test for m=1,...,8")
    tmp = mktempdir()

    for m in 1:8
        if m == 1
            got = BigInt[]
        else
            sols, _, _, _, _ =
                run_one_m(m, tmp; write_branches=false, write_solutions=false)
            got = sort([z.n for z in sols])
        end

        expected = EXPECTED_SMALL[m]
        got == expected ||
            error("SELFTEST FAILED at m=$m: expected=$expected got=$got")
        println("  m=$m OK: $got")
    end

    println("SELFTEST PASSED.")
    return true
end

# ------------------------------- main --------------------------------------

function main()
    opts = parse_args(ARGS)

    if parse_bool(opts["selftest"])
        selftest()
        return
    end

    start_m = parse(Int, opts["start"])
    stop_m  = parse(Int, opts["stop"])
    outdir  = opts["out"]
    resume  = parse_bool(opts["resume"])
    wb      = parse_bool(opts["write_branches"])
    ws      = parse_bool(opts["write_solutions"])

    start_m <= stop_m || error("--start must be <= --stop")
    start_m >= 2 || error("This search expects m >= 2")

    mkpath(outdir)

    summary = joinpath(outdir, "summary.tsv")

    println("============================================================")
    println("Certified overlap-aware exceptional-composite search")
    println("Julia version: ", VERSION)
    println("Threads: ", Threads.nthreads())
    println("Range: $start_m <= m <= $stop_m")
    println("Output: $outdir")
    println("Started: ", now())
    println("============================================================")

    for m in start_m:stop_m
        done_file = joinpath(outdir, @sprintf("m_%03d_DONE.txt",m))
        if resume && isfile(done_file)
            println("[m=$m] DONE marker exists; skipping (--resume=true).")
            continue
        end

        sols, results, elapsed, solution_file, branch_file =
            run_one_m(m, outdir; write_branches=wb, write_solutions=ws)

        append_global_summary(summary,m,sols,length(results),elapsed,
                              branch_file,solution_file)
    end

    println("\nFinished: ", now())
end

main()
