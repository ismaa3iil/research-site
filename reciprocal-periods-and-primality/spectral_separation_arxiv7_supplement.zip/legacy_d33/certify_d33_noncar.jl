# Exact kappa>1 search for spectral index d=33.
# Requires overlap_U_search.jl in the same directory.
# In overlap_U_search.jl, the paper's spectral index d is named m,
# and the field named d is kappa=lambda(n)/L.

src = read("overlap_U_search.jl", String)
src = replace(src, r"main\(\)\s*$" => "")
include_string(Main, src)

branches = [b for b in make_branches(33) if b.d > 1]
println("kappa>1 branches: ", length(branches), ", threads: ", Threads.nthreads())
results = Vector{BranchResult}(undef, length(branches))
Threads.@threads for i in eachindex(branches)
    results[i] = search_branch(branches[i])
end
sols = Solution[]
for r in results
    append!(sols, r.solutions)
end
sols = unique_solutions(sols)
got = sort([z.n for z in sols])
expected = BigInt[1047619,2210671,3494701,15197491,25158871,93755971]
println("solutions: ", got)
@assert got == expected


expected_data = Dict(
    BigInt(1047619)  => (BigInt[79,89,149],       4,8,32,BigInt(126984),BigInt(31746)),
    BigInt(2210671)  => (BigInt[59,89,421],       4,8,32,BigInt(267960),BigInt(66990)),
    BigInt(3494701)  => (BigInt[7,101,4943],      7,4,28,BigInt(741300),BigInt(105900)),
    BigInt(15197491) => (BigInt[37,431,953],      4,8,32,BigInt(1842120),BigInt(460530)),
    BigInt(25158871) => (BigInt[41,173,3547],     4,8,32,BigInt(3049560),BigInt(762390)),
    BigInt(93755971) => (BigInt[41,167,13693],    4,8,32,BigInt(11364360),BigInt(2841090)),
)
for z in sols
    fac,kappa,H,j,lam,L = expected_data[z.n]
    @assert z.primes == fac
    @assert z.d == kappa && z.H == H && z.d*z.H == j
    @assert z.lambda_n == lam && z.L == L
end
println("d=33 factorization/invariant table verified")
