# Specialized d=33 Carmichael-side completion.
# Requires overlap_U_search.jl in the same directory.
# In the search engine, the field named `d` is the paper's kappa=lambda(n)/L.

src = read("overlap_U_search.jl", String)
src = replace(src, r"main\(\)\s*$" => "")
include_string(Main, src)

# Analytically impossible branches (paper, 2-adic parity lemma):
# (s,kappa,H) = (6,1,32) and (5,1,32).
branches = [b for b in make_branches(33)
            if b.d == 1 && !((b.s==6 && b.H==32) || (b.s==5 && b.H==32))]

println("reduced kappa=1 parameter branches: ", length(branches))
@assert length(branches) == 29
sols = Solution[]
for b in branches
    r = search_branch(b)
    append!(sols,r.solutions)
    println((b.s,b.d,b.H,b.P,b.c), " nodes=", r.stats.nodes,
            " candidates=", r.stats.prime_candidates,
            " sols=", [z.n for z in r.solutions])
end
sols = unique_solutions(sols)
println("all reduced kappa=1 solutions: ", [z.n for z in sols])
@assert isempty(sols)
