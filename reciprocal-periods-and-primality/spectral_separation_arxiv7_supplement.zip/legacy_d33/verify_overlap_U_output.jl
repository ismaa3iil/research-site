#!/usr/bin/env julia

# verify_overlap_U_output.jl
#
# Independent arithmetic verifier for output produced by overlap_U_search.jl.
# It uses no external packages.  Every reported prime factor must fit in UInt64
# and is certified by deterministic seven-base Miller--Rabin for n < 2^64.
# The script recomputes n, phi(n), lambda(n), L, kappa, H, P and c, checks the
# defining divisibilities, and compares d <= 33 with the manuscript table.

using SHA
using Printf

const MR_BASES_U64 = UInt64[2, 325, 9375, 28178, 450775, 9780504, 1795265022]
const SMALL_TRIAL_U64 = UInt64[2,3,5,7,11,13,17,19,23,29,31,37]

@inline mulmod_u64(a::UInt64,b::UInt64,m::UInt64) =
    UInt64((UInt128(a)*UInt128(b)) % UInt128(m))

function powmod_u64(a::UInt64,e::UInt64,m::UInt64)::UInt64
    r=UInt64(1); x=a%m; k=e
    while k>0
        isodd(k) && (r=mulmod_u64(r,x,m))
        k >>= 1
        k==0 && break
        x=mulmod_u64(x,x,m)
    end
    r
end

function isprime_u64(n::UInt64)::Bool
    n<2 && return false
    for p in SMALL_TRIAL_U64
        n==p && return true
        n%p==0 && return false
    end
    d=n-1; s=0
    while iseven(d); d >>= 1; s += 1; end
    for a0 in MR_BASES_U64
        a=a0%n; a==0 && continue
        x=powmod_u64(a,d,n)
        (x==1 || x==n-1) && continue
        hit=false
        for _ in 1:(s-1)
            x=mulmod_u64(x,x,n)
            if x==n-1; hit=true; break; end
        end
        hit || return false
    end
    true
end

function isprime_exact(n::BigInt)::Bool
    0 <= n <= BigInt(typemax(UInt64)) || return false
    isprime_u64(UInt64(n))
end

const EXPECTED = Dict{Int,Vector{BigInt}}(
     1 => BigInt[], 2 => BigInt[], 3 => BigInt[],
     4 => BigInt[9],
     5 => BigInt[6601],
     6 => BigInt[25],
     7 => BigInt[15,561],
     8 => BigInt[9,49],
     9 => BigInt[30889,88561,534061],
    10 => BigInt[21,6601],
    11 => BigInt[45],
    12 => BigInt[25,121],
    13 => BigInt[27,126673,1333333],
    14 => BigInt[15,169,561],
    15 => BigInt[91,6601],
    16 => BigInt[33,49,65],
    17 => BigInt[35,139231],
    18 => BigInt[289,30889,88561,534061,55462177,8885251441,42018333841],
    19 => BigInt[39,153,4371,7107],
    20 => BigInt[21,361,3201,6601],
    21 => BigInt[85,8695,10585,26335,9717247,16666651,37769887],
    22 => BigInt[45,133,2465],
    23 => BigInt[231,645,1105,24013,34133],
    24 => BigInt[25,49,121,529],
    25 => BigInt[51,6601,15051,11921001],
    26 => BigInt[27,105,126673,1333333],
    27 => BigInt[55,325,3565,30889,88561,534061],
    28 => BigInt[57,169,561],
    29 => BigInt[117,175,1045,1447681,2121061,164424781],
    30 => BigInt[91,841,6601,158401],
    31 => BigInt[63,125,435,62745,1154131,2609581,3936691,5624641],
    32 => BigInt[33,65,385,961,12673,12801],
    33 => BigInt[1047619,2210671,3494701,15197491,25158871,93755971],
)

function file_sha256(path::String)
    open(path,"r") do io
        bytes2hex(sha256(io))
    end
end

function parse_primes(s::AbstractString)
    isempty(strip(s)) && return BigInt[]
    BigInt[parse(BigInt,x) for x in split(strip(s),",")]
end

function distinct_prime_factors(n::BigInt)
    n>=1 || error("factor input must be positive")
    t=n; out=BigInt[]; p=BigInt(2)
    while p*p<=t
        if t%p==0
            push!(out,p)
            while t%p==0; t÷=p; end
        end
        p = p==2 ? BigInt(3) : p+2
    end
    t>1 && push!(out,t)
    out
end

function vp_int(P::BigInt,p::BigInt)
    e=0; t=P
    while t%p==0; e+=1; t÷=p; end
    e
end

function verify_solution_fields(fields,lineno::Int)
    length(fields)==11 || error("Line $lineno: expected 11 TSV fields")
    m=parse(Int,fields[1]); n=parse(BigInt,fields[2]); s=parse(Int,fields[3])
    kappa_field=parse(BigInt,fields[4]); H_field=parse(BigInt,fields[5])
    P_field=parse(BigInt,fields[6]); c_field=parse(BigInt,fields[7])
    L_field=parse(BigInt,fields[8]); lam_field=parse(BigInt,fields[9])
    phi_field=parse(BigInt,fields[10]); primes=parse_primes(fields[11])

    length(primes)==s || error("Line $lineno: s mismatch")
    issorted(primes) || error("Line $lineno: primes not sorted")
    length(unique(primes))==length(primes) || error("Line $lineno: repeated prime")
    for p in primes
        isprime_exact(p) || error("Line $lineno: non-prime or >UInt64 factor $p")
    end

    for q in distinct_prime_factors(P_field)
        q in primes || error("Line $lineno: factor $q of P absent from prime list")
    end

    n_calc=P_field*prod(primes;init=BigInt(1))
    n_calc==n || error("Line $lineno: n mismatch")

    locals=BigInt[]
    for p in primes
        e=vp_int(P_field,p)
        push!(locals,p^e*(p-1))
    end
    phi_calc=prod(locals;init=BigInt(1))
    lambda_calc=foldl(lcm,locals;init=BigInt(1))
    phi_calc==phi_field || error("Line $lineno: phi mismatch")
    lambda_calc==lam_field || error("Line $lineno: lambda mismatch")

    (n-1)%m==0 || error("Line $lineno: spectral index does not divide n-1")
    L_calc=(n-1)÷m
    L_calc==L_field || error("Line $lineno: L mismatch")
    lambda_calc%L_calc==0 || error("Line $lineno: L does not divide lambda")
    kappa_calc=lambda_calc÷L_calc
    kappa_calc==kappa_field || error("Line $lineno: kappa mismatch")
    phi_calc%lambda_calc==0 || error("Line $lineno: lambda does not divide phi")
    H_calc=phi_calc÷lambda_calc
    H_calc==H_field || error("Line $lineno: H mismatch")
    j=kappa_calc*H_calc
    kappa_calc%P_field==0 || error("Line $lineno: P does not divide kappa")
    c_calc=j÷P_field
    c_calc==c_field || error("Line $lineno: c mismatch")
    BigInt(m)*phi_calc==j*(n-1) || error("Line $lineno: master equation fails")
    (length(primes)==1 && P_field==1) && error("Line $lineno: n is prime")
    return m,n
end

function read_solutions(path::String)
    lines=readlines(path); isempty(lines) && error("Empty solutions file: $path")
    strip(lines[1])=="m\tn\ts\td\tH\tP\tc\tL\tlambda\tphi\tprimes" ||
        error("Unexpected TSV header in $path")
    bym=Dict{Int,Vector{BigInt}}()
    for (offset,line) in enumerate(lines[2:end])
        idx = offset + 1
        isempty(strip(line)) && continue
        m,n=verify_solution_fields(split(line,'\t'),idx)
        push!(get!(bym,m,BigInt[]),n)
    end
    for v in values(bym); sort!(unique!(v)); end
    bym
end

function parse_done(path::String)
    d=Dict{String,String}()
    for line in eachline(path)
        occursin("=",line) || continue
        k,v=split(line,"=",limit=2); d[k]=v
    end
    d
end

function verify_directory(outdir::String)
    isdir(outdir) || error("Not a directory: $outdir")
    donefiles=sort(filter(f->occursin(r"^m_\d+_DONE\.txt$",basename(f)),
                          readdir(outdir,join=true)))
    isempty(donefiles) && error("No DONE files found in $outdir")
    total_rows=0; checked=Int[]
    for done in donefiles
        meta=parse_done(done); m=parse(Int,meta["m"]); base=@sprintf("m_%03d",m)
        solfile=joinpath(outdir,base*"_solutions.tsv")
        brfile=joinpath(outdir,base*"_branches.tsv")
        isfile(solfile) || error("m=$m: missing solutions file")
        isfile(brfile) || error("m=$m: missing branches file")
        haskey(meta,"solutions_sha256") &&
            file_sha256(solfile)!=meta["solutions_sha256"] && error("m=$m: solutions SHA mismatch")
        haskey(meta,"branches_sha256") &&
            file_sha256(brfile)!=meta["branches_sha256"] && error("m=$m: branches SHA mismatch")
        got=sort(get(read_solutions(solfile),m,BigInt[]))
        parse(Int,meta["solutions"])==length(got) || error("m=$m: DONE count mismatch")
        maxgot=isempty(got) ? BigInt(0) : maximum(got)
        parse(BigInt,meta["max_n"])==maxgot || error("m=$m: DONE max_n mismatch")
        if haskey(EXPECTED,m)
            exp=sort(EXPECTED[m]); got==exp || error("TABLE MISMATCH m=$m\nexpected=$exp\ngot=$got")
        end
        println("m=$m VERIFIED: count=$(length(got)), max=$maxgot")
        total_rows+=length(got); push!(checked,m)
    end
    println("\nVerification passed.")
    println("m values checked: ",checked)
    println("reported solutions checked: ",total_rows)
end

function main()
    isempty(ARGS) && error("Usage: julia verify_overlap_U_output.jl OUTPUT_DIRECTORY")
    verify_directory(ARGS[1])
end
main()
