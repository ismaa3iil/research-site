Reproducibility supplement for
"Pseudoprimes with Small Indices Are Rare" (Journal Draft 10)

PURPOSE
-------
This archive is part of the computer-assisted proof through spectral index
d=33. It separates the general exact branch search (d<=32), an independent
arithmetic verifier, and the split certification of the dyadic transition d=33.
All proof-critical scripts were actually executed under Julia 1.12.6 before
this archive was frozen; the corresponding logs are included in logs/.

PROOF ARCHITECTURE
------------------
1. d<=8: overlap_U_search.jl --selftest reproduces the hand classification.
2. 9<=d<=32: overlap_U_search.jl exhausts every finite parameter branch.
3. verify_overlap_U_output.jl independently recomputes the arithmetic data in
   every reported factorization and checks hashes/DONE metadata.  This is an
   independent arithmetic verifier of reported outputs, not an independent
   implementation of search completeness; completeness is proved in the
   manuscript's finite-search proposition.
4. d=33, kappa=1: the paper analytically eliminates exactly the two branches
   (s,kappa,H)=(6,1,32) and (5,1,32). certify_d33_reduced.jl exhausts the
   remaining 29 kappa=1 parameter branches and finds no solution.
5. d=33, kappa>1: certify_d33_noncar.jl exhausts all 135 parameter branches
   and returns exactly the six exceptions in the paper.
6. prime_mass_d33_check.jl performs the exact Rational{BigInt} finite
   minimization used in the GRH-conditional prime-mass theorem.

IMPLEMENTATION GUARANTEES
-------------------------
* No floating-point value is used in a pruning decision.
* The proof scripts use only Julia standard libraries.
* Prime candidates below 2^64 are tested by the deterministic seven-base
  Miller-Rabin set {2,325,9375,28178,450775,9780504,1795265022} with UInt128
  modular products.  The manuscript cites the Sinclair SPRP records for this
  finite-range certification and Sorenson--Webster for a peer-reviewed
  comparison using the first twelve prime bases.
* If a future search reaches a prime candidate >=2^64, the search aborts rather
  than silently using a probable-prime decision.
* Completed main-search lines carry DONE files and SHA-256 hashes for their
  solution and branch TSV files.

RECOMMENDED COMMANDS
--------------------
  julia +release overlap_U_search.jl --selftest
  julia +release -t auto overlap_U_search.jl --start=9 --stop=32 --out=run_d9_d32
  julia +release verify_overlap_U_output.jl run_d9_d32
  julia +release certify_d33_reduced.jl
  julia +release -t auto certify_d33_noncar.jl
  julia +release prime_mass_d33_check.jl

REFERENCE EXECUTION
-------------------
The frozen reference run used Julia 1.12.6 on 2026-08-23. The parallel runs
reported 16 Julia threads. See EXECUTION_REPORT_DRAFT10.txt and logs/ for the actual outputs.  The
proof-critical source and captured runs are the same successful reference
executions frozen on 2026-08-23; Journal Draft 10 changes the mathematical
completeness exposition and supplement metadata, not the search algorithm. In particular, the verifier checked 96 incidences for 9<=d<=32;
combined with the 7 incidences at d<=8 and the 6 certified d=33 incidences this
gives the manuscript total of 109 incidences through d=33.

FILES
-----
overlap_U_search.jl
  Exact overlap-aware exhaustive search and d<=8 regression test.

verify_overlap_U_output.jl
  Independent deterministic verifier for main-search output directories.

certify_d33_reduced.jl
  Exact search of all 29 non-analytically-excluded kappa=1 branches at d=33.

certify_d33_noncar.jl
  Thread-parallel exact search of all 135 kappa>1 branches at d=33, followed
  by assertions for the six factorizations and their invariants.

prime_mass_d33_check.jl
  Exact rational minimization of the cumulative near-primitive-root mass.

branch_parameter_counts_d9_d33.tsv
  Closed-form parameter-branch counts. At d=33 the total is
  166 = 29 computed kappa=1 + 2 analytically excluded kappa=1 + 135 kappa>1.

SHA256SUMS.txt
  SHA-256 manifest for the frozen supplement contents (excluding itself).

EXECUTION_REPORT_DRAFT10.txt
  Human-readable record of the successful reference executions and their
  relationship to Journal Draft 10.

logs/
  Captured stdout from the successful reference runs.

HISTORICAL NOTE
---------------
The original exploratory Exceptional_Search2.jl is not part of the proof. It
used floating-point pruning and at one stage used integer division before
checking divisibility by the spectral index. Journal Draft 10 uses only the exact search
and verification path described above.
