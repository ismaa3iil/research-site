import math, sys, time, os
from multiprocessing import Pool
from sympy import factorint
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from search_reference_python import nextprime_exact, exact_max_bound, overlap_can_finish

# Sorenson-Webster: smallest strong pseudoprime to the first 12 prime bases.
PSI12 = 318665857834031151167461
MR12 = (2,3,5,7,11,13,17,19,23,29,31,37)

def isprime_certified(n):
    if n < 2: return False
    small=(2,3,5,7,11,13,17,19,23,29,31,37)
    for p in small:
        if n == p: return True
        if n % p == 0: return False
    if n >= PSI12:
        raise RuntimeError(f'primality input {n} exceeds Sorenson-Webster threshold')
    d=n-1; s=0
    while d % 2 == 0:
        d//=2; s+=1
    for a in MR12:
        x=pow(a,d,n)
        if x in (1,n-1): continue
        for _ in range(s-1):
            x=pow(x,2,n)
            if x == n-1: break
        else:
            return False
    return True

m=49; s=5; kappa=3; H=16; P=1; c=48; j=48
prefixes=[]
def dfs(cur,A,B,lam,Hp):
    r=len(cur)
    if not overlap_can_finish(Hp,H,r,s): return
    if r==s-2:
        prefixes.append((tuple(cur),A,B,lam,Hp)); return
    num=m*A; den=c*B
    if num<=den:return
    t=s-r; lp=2 if r==0 else cur[-1]; lower=lp+1
    maxp=exact_max_bound(num,den,t,lower)
    if maxp<lower:return
    p=nextprime_exact(lp+1)
    while p<=maxp:
        lf=p-1
        if r==0: ln=lf;Hn=1
        else:
            g=math.gcd(lam,lf);budget=H//Hp
            if budget%g:
                p=nextprime_exact(p+1);continue
            ln=math.lcm(lam,lf);Hn=Hp*g
        cur.append(p)
        if overlap_can_finish(Hn,H,r+1,s):dfs(cur,A*(p-1),B*p,ln,Hn)
        cur.pop();p=nextprime_exact(p+1)

def work(item):
    pr,A,B,lam,Hp=item
    a=m*A; b=j*B; D=a-b
    if D<=0:return []
    T=a*(b-c)+b*c
    fac=factorint(T)
    z=1
    for q,e in fac.items():
        q=int(q); e=int(e)
        if not isprime_certified(q):
            raise RuntimeError(f'factorint returned composite factor {q}')
        z*=q**e
    if z!=T: raise RuntimeError('factor reconstruction failed')
    divs=[1]
    for q,e in fac.items():
        q=int(q);e=int(e)
        divs=[d*q**k for d in divs for k in range(e+1)]
    sols=[]
    for u in divs:
        v=T//u
        if u>=v:continue
        if (u+a)%D or (v+a)%D:continue
        x=(u+a)//D; y=(v+a)//D
        if not(pr[-1]<x<y):continue
        if not isprime_certified(x) or not isprime_certified(y):continue
        lam2=math.lcm(lam,x-1,y-1); phi=A*(x-1)*(y-1)
        if phi!=H*lam2:continue
        n=B*x*y
        if (n-1)%m:continue
        L=(n-1)//m
        if lam2!=kappa*L:continue
        sols.append((n,pr+(x,y)))
    return sols

if __name__=='__main__':
    t=time.time(); dfs([],1,1,1,1)
    print('Sorenson-Webster threshold',PSI12)
    print('prefixes',len(prefixes),'gen_sec',time.time()-t,flush=True)
    allsol=[]
    with Pool(processes=min(12,os.cpu_count() or 4)) as pool:
        for i,res in enumerate(pool.imap_unordered(work,prefixes,chunksize=25),1):
            allsol.extend(res)
            if i%5000==0: print('processed',i,'solutions',allsol,flush=True)
    print('DONE sec',time.time()-t,'solutions',sorted(set(allsol)),flush=True)
