#!/usr/bin/env python3
from __future__ import annotations
import math, sys, time, argparse, csv
from dataclasses import dataclass
from functools import lru_cache
from typing import List, Tuple

U64_MAX=(1<<64)-1
MR_BASES=(2,3,5,7,11,13,17,19,23,29,31,37)
SMALL=(2,3,5,7,11,13,17,19,23,29,31,37)

@lru_cache(maxsize=1000000)
def isprime_u64(n:int)->bool:
    if n<2:return False
    if n>U64_MAX: raise OverflowError(f'prime candidate >2^64: {n}')
    for p in SMALL:
        if n==p:return True
        if n%p==0:return False
    d=n-1;s=0
    while d%2==0: s+=1;d//=2
    for a0 in MR_BASES:
        a=a0%n
        if a==0: continue
        x=pow(a,d,n)
        if x==1 or x==n-1: continue
        ok=False
        for _ in range(s-1):
            x=(x*x)%n
            if x==n-1: ok=True;break
        if not ok:return False
    return True

def nextprime_exact(n:int)->int:
    if n<=2:return 2
    x=n if n%2 else n+1
    while True:
        if x>U64_MAX: raise OverflowError('prime search >2^64')
        if isprime_u64(x):return x
        x+=2

def divisors(n:int):
    out=[]
    for d in range(1, int(math.isqrt(n))+1):
        if n%d==0:
            out.append(d)
            if d*d!=n:out.append(n//d)
    return sorted(out)

def prime_factors_small(n:int):
    out=[];t=n;p=2
    while p*p<=t:
        if t%p==0:
            out.append(p)
            while t%p==0:t//=p
        p=3 if p==2 else p+2
    if t>1:out.append(t)
    return out

def vp_small(n:int,p:int):
    e=0
    while n%p==0:
        e+=1;n//=p
    return e

def local_factor(p:int,P:int):
    return (p**vp_small(P,p))*(p-1)

def bound_holds(x:int,num:int,den:int,t:int):
    return pow(x,t)*den > pow(x-1,t)*num

def exact_max_bound(num:int,den:int,t:int,lower:int):
    if num<=den or den<=0:return lower-1
    lower=max(lower,2)
    if not bound_holds(lower,num,den,t):return lower-1
    lo=lower;hi=max(4,2*lo)
    while bound_holds(hi,num,den,t):
        lo=hi;hi*=2
        if hi>U64_MAX:
            # We can still binary search but actual candidate enumeration beyond u64 is unsupported.
            hi=U64_MAX+1;break
    while hi-lo>1:
        mid=(lo+hi)//2
        if bound_holds(mid,num,den,t):lo=mid
        else:hi=mid
    return lo

@dataclass(frozen=True)
class Branch:
    m:int;s:int;kappa:int;H:int;P:int;c:int
@dataclass
class Sol:
    m:int;n:int;s:int;kappa:int;H:int;P:int;c:int;L:int;lam:int;phi:int;primes:Tuple[int,...]

class Stats:
    __slots__=('nodes','pc','op','rp','req','fc')
    def __init__(self):self.nodes=self.pc=self.op=self.rp=self.req=self.fc=0

def overlap_can_finish(Hprefix:int,Htarget:int,r:int,s:int)->bool:
    if Htarget%Hprefix:return False
    rem=s-r
    if r>=1 and Htarget//Hprefix < (1<<rem):return False
    return True

def search_branch(br:Branch):
    m,s,kappa,H,P,c=br.m,br.s,br.kappa,br.H,br.P,br.c
    req=prime_factors_small(P);st=Stats();sols=[]
    if len(req)>s:return sols,st
    def dfs(cur:List[int],A:int,B:int,lam_pref:int,Hpref:int):
        st.nodes+=1;r=len(cur)
        if cur:
            lp=cur[-1]
            for q in req:
                if q<lp and q not in cur:st.req+=1;return
        miss=sum(q not in cur for q in req)
        if miss>s-r:st.req+=1;return
        if not overlap_can_finish(Hpref,H,r,s):st.op+=1;return
        if r==s-1:
            num=m*A-c;den=m*A-c*P*B
            if den<=0 or num<=0 or num%den:return
            p=num//den;st.fc+=1
            if p<=cur[-1] or not isprime_u64(p):return
            full=cur+[p]
            if any(q not in full for q in req):return
            lf=local_factor(p,P)
            lam=math.lcm(lam_pref,lf);g=math.gcd(lam_pref,lf);Hfull=Hpref*g
            if Hfull!=H:return
            n=P*B*p
            if (n-1)%m:return
            L=(n-1)//m
            phi=P*A*(p-1)
            if m*phi != kappa*H*(n-1):return
            if phi != H*lam:return
            if lam != kappa*L:return
            sols.append(Sol(m,n,s,kappa,H,P,c,L,lam,phi,tuple(full)))
            return
        num=m*A;den=c*P*B
        if num<=den:st.rp+=1;return
        t=s-r;lp=2 if r==0 else cur[-1];lower=lp+1
        maxp=exact_max_bound(num,den,t,lower)
        if maxp<lower:return
        missing=[q for q in req if q not in cur]
        if missing:maxp=min(maxp,min(missing))
        p=nextprime_exact(lp+1)
        while p<=maxp:
            st.pc+=1
            lf=local_factor(p,P)
            if r==0:lam_new=lf;Hnew=1
            else:
                g=math.gcd(lam_pref,lf)
                budget=H//Hpref
                if budget%g:
                    st.op+=1;p=nextprime_exact(p+1);continue
                lam_new=math.lcm(lam_pref,lf);Hnew=Hpref*g
            cur.append(p)
            if overlap_can_finish(Hnew,H,r+1,s):
                dfs(cur,A*(p-1),B*p,lam_new,Hnew)
            else:st.op+=1
            cur.pop();p=nextprime_exact(p+1)
    dfs([],1,1,1,1)
    return sols,st

def make_branches(m:int, kappa_min=1):
    out=[];smax=(m-1).bit_length()
    for s in range(2,smax+1):
        minH=1<<(s-1)
        for kappa in range(max(1,kappa_min),(m-1)//minH+1):
            maxH=(m-1)//kappa
            for H in range(minH,maxH+1,minH):
                j=kappa*H
                for P in divisors(kappa):
                    if j%P:continue
                    out.append(Branch(m,s,kappa,H,P,j//P))
    return out

def prime_power_solutions(m:int):
    sols=[]
    for p in range(3,m,2):
        if not isprime_u64(p):continue
        a=2
        while p**(a-1)<=m-1:
            n=p**a
            if (n-1)%m==0:
                L=(n-1)//m;lam=p**(a-1)*(p-1)
                if L>=1 and lam%L==0:
                    kappa=lam//L
                    if 1<=kappa<=m-1:
                        P=p**(a-1)
                        if kappa%P==0:
                            sols.append(Sol(m,n,1,kappa,1,P,kappa//P,L,lam,lam,(p,)))
            a+=1
    return sols

def run_m(m:int,kappa_min=1):
    t=time.time();branches=make_branches(m,kappa_min)
    sols=prime_power_solutions(m) if kappa_min<=1 else []
    stats=[0]*6
    for i,b in enumerate(branches):
        ss,st=search_branch(b);sols.extend(ss)
        for j,x in enumerate((st.nodes,st.pc,st.op,st.rp,st.req,st.fc)):stats[j]+=x
    byn={}
    for z in sorted(sols,key=lambda z:(z.n,z.s,z.kappa,z.H,z.P)):
        byn.setdefault(z.n,z)
    elapsed=time.time()-t
    return list(byn.values()),len(branches),stats,elapsed

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=9);ap.add_argument('--stop',type=int,default=32);ap.add_argument('--kappa-min',type=int,default=1);ap.add_argument('--out',default='')
    a=ap.parse_args();rows=[]
    for m in range(a.start,a.stop+1):
        sols,bc,st,el=run_m(m,a.kappa_min)
        print(f'd={m} branches={bc} time={el:.3f}s count={len(sols)} solutions={[z.n for z in sols]}',flush=True)
        rows.append((m,bc,el,len(sols),max([z.n for z in sols],default=0),st,sols))
    if a.out:
        with open(a.out,'w',newline='') as f:
            w=csv.writer(f,delimiter='\t');w.writerow(['d','branches','seconds','count','max_n','nodes','prime_candidates','overlap_prunes','ratio_prunes','required_prunes','final_candidates','solutions'])
            for m,bc,el,c,mx,st,sols in rows:w.writerow([m,bc,f'{el:.6f}',c,mx,*st,','.join(str(z.n) for z in sols)])
if __name__=='__main__':main()
