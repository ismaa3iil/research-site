#!/usr/bin/env python3
from pathlib import Path
import re,sys
ROOT=Path(__file__).resolve().parent/'logs'

def readlog(p):
    t=p.read_text(errors='replace')
    m=re.search(r'total_prefixes (\d+)',t)
    if not m:
        raise SystemExit(f'INCOMPLETE LOG: {p}')
    if 'overflow = false' not in t or 'factor_certificate_abort = false' not in t:
        raise SystemExit(f'FAILED FLAG: {p}')
    row=re.search(r'd=(34|35) branches=.* solutions=\[(.*?)\]',t)
    if row and row.group(2).strip():
        raise SystemExit(f'UNEXPECTED SOLUTION in empty index: {p}: {row.group(2)}')
    b=re.search(r'max_ratio_prime_bound (\d+)',t)
    return int(m.group(1)), int(b.group(1)) if b else 0

def summarize(d):
    folder=ROOT/f'kappa1_d{d}'
    vals=[]
    for p in sorted(folder.glob('*.log')):
        n,b=readlog(p); vals.append((p.name,n,b))
    total=sum(x[1] for x in vals); maxb=max(x[2] for x in vals)
    return vals,total,maxb

for d,expected,expected_max in [(34,344284,2140591),(35,381524,7296343)]:
    vals,total,maxb=summarize(d)
    print(f'd={d} logs={len(vals)} total_prefixes={total} max_ratio_prime_bound={maxb}')
    if total!=expected: raise SystemExit(f'd={d}: prefix total {total} != {expected}')
    if maxb!=expected_max: raise SystemExit(f'd={d}: max bound {maxb} != {expected_max}')
    print(f'd={d} PASS')
print('ALL SPLIT LOGS PASS')
