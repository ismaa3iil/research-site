#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std; using boost::multiprecision::cpp_int;
using u64=uint64_t; using u128=__uint128_t;
const u64 UMAX=~u64(0);
static const u64 MRB[]={2,3,5,7,11,13,17,19,23,29,31,37};
static const u64 SMALL[]={2,3,5,7,11,13,17,19,23,29,31,37};
static u64 MAX_PRIMALITY_INPUT=0;
inline u64 mulmod(u64 a,u64 b,u64 m){return (u128)a*b%m;}
u64 powmod(u64 a,u64 e,u64 m){u64 r=1,x=a%m; while(e){if(e&1)r=mulmod(r,x,m);e>>=1;if(e)x=mulmod(x,x,m);}return r;}
bool isprime(u64 n){MAX_PRIMALITY_INPUT=max(MAX_PRIMALITY_INPUT,n);if(n<2)return false;for(u64 p:SMALL){if(n==p)return true;if(n%p==0)return false;}u64 d=n-1;int s=0;while(!(d&1)){d>>=1;s++;}for(u64 a0:MRB){u64 a=a0%n;if(!a)continue;u64 x=powmod(a,d,n);if(x==1||x==n-1)continue;bool ok=false;for(int i=1;i<s;i++){x=mulmod(x,x,n);if(x==n-1){ok=true;break;}}if(!ok)return false;}return true;}
u64 nextprime(u64 n){if(n<=2)return 2;u64 x=(n&1)?n:n+1;for(;;x+=2){if(x<3)throw runtime_error("prime overflow");if(isprime(x))return x;}}
cpp_int gcdcpp(cpp_int a, cpp_int b){while(b!=0){cpp_int r=a%b;a=b;b=r;}return a;}
cpp_int lcmcpp(const cpp_int&a,const cpp_int&b){return a/gcdcpp(a,b)*b;}
vector<int> divisors(int n){vector<int>a;for(int d=1;d*d<=n;d++)if(n%d==0){a.push_back(d);if(d*d!=n)a.push_back(n/d);}sort(a.begin(),a.end());return a;}
vector<int> pfactors(int n){vector<int>v;for(int p=2;p*p<=n;p+=(p==2?1:2))if(n%p==0){v.push_back(p);while(n%p==0)n/=p;}if(n>1)v.push_back(n);return v;}
int vp(int n,u64 p){int e=0;while(n%(int)p==0){e++;n/=(int)p;}return e;}
cpp_int ipow(u64 p,int e){cpp_int r=1;while(e--)r*=p;return r;}
cpp_int local_factor(u64 p,int P){return ipow(p,vp(P,p))*(p-1);}
bool to_u64(const cpp_int&x,u64&out){if(x<0||x>cpp_int(UMAX))return false;out=x.convert_to<u64>();return true;}
cpp_int powi(cpp_int x,int t){cpp_int r=1;while(t--)r*=x;return r;}
bool bound_holds(u64 x,const cpp_int&num,const cpp_int&den,int t){cpp_int X=x;return powi(X,t)*den>powi(X-1,t)*num;}
u64 exact_max_bound(const cpp_int&num,const cpp_int&den,int t,u64 lower,bool &overflow){overflow=false;if(num<=den||den<=0)return lower-1;if(lower<2)lower=2;if(!bound_holds(lower,num,den,t))return lower-1;u64 lo=lower,hi=max<u64>(4,2*lo);while(bound_holds(hi,num,den,t)){lo=hi;if(hi>UMAX/2){overflow=true;return UMAX;}hi*=2;}while(hi-lo>1){u64 mid=lo+(hi-lo)/2;if(bound_holds(mid,num,den,t))lo=mid;else hi=mid;}return lo;}
struct Branch{int m,s,k,H,P,c;};
struct Sol{int m,s,k,H,P,c; cpp_int n,L,lam,phi; vector<u64>pr;};
struct Stats{uint64_t nodes=0,pc=0,op=0,rp=0,req=0,fc=0; u64 maxb=0;};
bool overlap_finish(const cpp_int&Hp,int H,int r,int s){if(cpp_int(H)%Hp!=0)return false;int rem=s-r;if(r>=1){cpp_int q=cpp_int(H)/Hp;cpp_int mn=cpp_int(1)<<rem;if(q<mn)return false;}return true;}
struct Res{vector<Sol> sols; Stats st; bool overflow=false;};
Res search_branch(const Branch&br){Res R;auto req=pfactors(br.P);if((int)req.size()>br.s)return R;vector<u64>cur;
 function<void(cpp_int,cpp_int,cpp_int,cpp_int)> dfs=[&](cpp_int A,cpp_int B,cpp_int lam,cpp_int Hp){R.st.nodes++;int r=cur.size();if(r){u64 lp=cur.back();for(int q:req)if((u64)q<lp&&find(cur.begin(),cur.end(),(u64)q)==cur.end()){R.st.req++;return;}}int miss=0;for(int q:req)if(find(cur.begin(),cur.end(),(u64)q)==cur.end())miss++;if(miss>br.s-r){R.st.req++;return;}if(!overlap_finish(Hp,br.H,r,br.s)){R.st.op++;return;}
 if(r==br.s-1){cpp_int num=cpp_int(br.m)*A-br.c,den=cpp_int(br.m)*A-cpp_int(br.c)*br.P*B;if(den<=0||num<=0||num%den!=0)return;cpp_int pp=num/den;R.st.fc++;u64 p;if(!to_u64(pp,p)){R.overflow=true;return;}if(p<=cur.back()||!isprime(p))return;for(int q:req)if(find(cur.begin(),cur.end(),(u64)q)==cur.end()&&p!=(u64)q)return;cpp_int lf=local_factor(p,br.P),g=gcdcpp(lam,lf),lfull=lcmcpp(lam,lf),Hfull=Hp*g;if(Hfull!=br.H)return;cpp_int n=cpp_int(br.P)*B*p;if((n-1)%br.m!=0)return;cpp_int L=(n-1)/br.m,phi=cpp_int(br.P)*A*(p-1);if(cpp_int(br.m)*phi!=cpp_int(br.k)*br.H*(n-1))return;if(phi!=cpp_int(br.H)*lfull)return;if(lfull!=cpp_int(br.k)*L)return;auto prs=cur;prs.push_back(p);R.sols.push_back({br.m,br.s,br.k,br.H,br.P,br.c,n,L,lfull,phi,prs});return;}
 cpp_int num=cpp_int(br.m)*A,den=cpp_int(br.c)*br.P*B;if(num<=den){R.st.rp++;return;}int t=br.s-r;u64 lp=r?cur.back():2,lower=lp+1;bool ov=false;u64 maxp=exact_max_bound(num,den,t,lower,ov);R.st.maxb=max(R.st.maxb,maxp);if(ov){R.overflow=true;return;}if(maxp<lower)return;u64 reqmin=UMAX;for(int q:req)if(find(cur.begin(),cur.end(),(u64)q)==cur.end())reqmin=min(reqmin,(u64)q);if(reqmin!=UMAX)maxp=min(maxp,reqmin);u64 p=nextprime(lp+1);while(p<=maxp){R.st.pc++;cpp_int lf=local_factor(p,br.P),ln,Hn;if(r==0){ln=lf;Hn=1;}else{cpp_int g=gcdcpp(lam,lf),budget=cpp_int(br.H)/Hp;if(budget%g!=0){R.st.op++;if(p>UMAX-2)break;p=nextprime(p+1);continue;}ln=lcmcpp(lam,lf);Hn=Hp*g;}cur.push_back(p);if(overlap_finish(Hn,br.H,r+1,br.s))dfs(A*(p-1),B*p,ln,Hn);else R.st.op++;cur.pop_back();if(p>UMAX-2)break;p=nextprime(p+1);} };
 dfs(1,1,1,1);return R;}
vector<Branch> branches(int m,int kmin){vector<Branch>v;int smax=0,x=m-1;while(x){smax++;x>>=1;}for(int s=2;s<=smax;s++){int minH=1<<(s-1);for(int k=max(1,kmin);k<=(m-1)/minH;k++){int maxH=(m-1)/k;for(int H=minH;H<=maxH;H+=minH){int j=k*H;for(int P:divisors(k))if(j%P==0)v.push_back({m,s,k,H,P,j/P});}}}return v;}
vector<Sol> primepowers(int m){vector<Sol>v;for(int p=3;p<=m-1;p+=2)if(isprime(p)){for(int a=2;;a++){cpp_int P=ipow(p,a-1);if(P>m-1)break;cpp_int n=P*p;if((n-1)%m)continue;cpp_int L=(n-1)/m,lam=P*(p-1);if(lam%L)continue;cpp_int kk=lam/L;
 if(kk<1||kk>m-1)continue;int ki=kk.convert_to<int>(),Pi=P.convert_to<int>();if(ki%Pi)continue;v.push_back({m,1,ki,1,Pi,ki/Pi,n,L,lam,lam,{(u64)p}});}}return v;}
int main(int argc,char**argv){int a=9,b=32,kmin=1,smin=2,smaxfilter=99,kexact=0,Pexact=0;string out="";for(int i=1;i<argc;i++){string s=argv[i];auto eq=s.find('=');string key=s.substr(0,eq),val=eq==string::npos?"":s.substr(eq+1);if(key=="--start")a=stoi(val);else if(key=="--stop")b=stoi(val);else if(key=="--kappa-min")kmin=stoi(val);else if(key=="--out")out=val;else if(key=="--smin")smin=stoi(val);else if(key=="--smax")smaxfilter=stoi(val);else if(key=="--kappa-exact")kexact=stoi(val);else if(key=="--P-exact")Pexact=stoi(val);}
ofstream fo;if(!out.empty()){fo.open(out);fo<<"d\tbranches\tseconds\tcount\tmax_n\tnodes\tprime_candidates\toverlap_prunes\tratio_prunes\trequired_prunes\tfinal_candidates\tmax_prime_bound\tmax_primality_input\toverflow\tsolutions\n";}
for(int m=a;m<=b;m++){MAX_PRIMALITY_INPUT=0;auto t0=chrono::steady_clock::now();auto bs=branches(m,kmin); bs.erase(remove_if(bs.begin(),bs.end(),[&](const Branch&z){return z.s<smin||z.s>smaxfilter||(kexact&&z.k!=kexact)||(Pexact&&z.P!=Pexact);}),bs.end()); vector<Sol>sols;if(kmin<=1){auto pp=primepowers(m);sols.insert(sols.end(),pp.begin(),pp.end());}Stats T;bool ov=false;for(auto &br:bs){auto r=search_branch(br);sols.insert(sols.end(),r.sols.begin(),r.sols.end());T.nodes+=r.st.nodes;T.pc+=r.st.pc;T.op+=r.st.op;T.rp+=r.st.rp;T.req+=r.st.req;T.fc+=r.st.fc;T.maxb=max(T.maxb,r.st.maxb);ov|=r.overflow;if(ov){cerr<<"overflow in d="<<m<<"\n";return 3;}}
sort(sols.begin(),sols.end(),[](const Sol&a,const Sol&b){return a.n<b.n;});vector<Sol>u;for(auto &z:sols)if(u.empty()||z.n!=u.back().n)u.push_back(z);auto t1=chrono::steady_clock::now();double sec=chrono::duration<double>(t1-t0).count();cout<<"d="<<m<<" branches="<<bs.size()<<" sec="<<sec<<" count="<<u.size()<<" sols=[";for(size_t i=0;i<u.size();i++){if(i)cout<<",";cout<<u[i].n;}cout<<"] max_prime_bound="<<T.maxb<<" max_primality_input="<<MAX_PRIMALITY_INPUT<<" overflow=false\n"<<flush;if(fo){cpp_int mx=u.empty()?cpp_int(0):u.back().n;fo<<m<<"\t"<<bs.size()<<"\t"<<fixed<<setprecision(6)<<sec<<"\t"<<u.size()<<"\t"<<mx<<"\t"<<T.nodes<<"\t"<<T.pc<<"\t"<<T.op<<"\t"<<T.rp<<"\t"<<T.req<<"\t"<<T.fc<<"\t"<<T.maxb<<"\t"<<MAX_PRIMALITY_INPUT<<"\tfalse\t";for(size_t i=0;i<u.size();i++){if(i)fo<<",";fo<<u[i].n;}fo<<"\n";}}
}
