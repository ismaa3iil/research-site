#!/usr/bin/env python3
from __future__ import annotations
import argparse, math, os, shutil, subprocess, sys, time
import sympy as sp
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import List, Tuple

# Sorenson--Webster, Math. Comp. 86 (2017), Theorem 1.1.
PSI12 = 318665857834031151167461
PSI13 = 3317044064679887385961981
MR12 = (2,3,5,7,11,13,17,19,23,29,31,37)
MR13 = MR12 + (41,)
SMALL = MR13
U64_MAX=(1<<64)-1

# This certificate is specialized to kappa=1, hence squarefree Carmichael
# numbers n with index d=(n-1)/lambda(n). It implements the finite ratio
# recursion in Pinch's prescribed-index proof and stops with two primes left,
# which are exhausted by the exact divisor-pair identity used in the paper.

def mr_screen(n:int,bases=MR12)->bool:
    """Strong probable-prime test to the supplied prime bases."""
    if n < 2: return False
    for p in SMALL:
        if n == p: return True
        if n % p == 0: return False
    d=n-1; s=0
    while d % 2 == 0:
        d//=2; s+=1
    for a in bases:
        x=pow(a,d,n)
        if x in (1,n-1): continue
        for _ in range(s-1):
            x=(x*x)%n
            if x == n-1: break
        else:
            return False
    return True

def raw_coreutils_factors(n:int)->List[int]:
    exe=shutil.which('factor')
    if not exe: raise RuntimeError('GNU/coreutils factor not found')
    cp=subprocess.run([exe,str(n)],text=True,capture_output=True,check=True)
    line=cp.stdout.strip(); left,right=line.split(':',1)
    if int(left.strip())!=n: raise RuntimeError('factor single-value mismatch')
    fs=[int(x) for x in right.split()]
    z=1
    for f in fs:z*=f
    if z!=n: raise RuntimeError(f'factor reconstruction failed for {n}')
    return fs

@lru_cache(maxsize=None)
def prime_certified(n:int)->bool:
    """Deterministic certificate for every primality decision used here.

    Below psi_12, Sorenson--Webster makes MR12 deterministic. Above psi_12,
    an MR12-passing input is proved by a full Pocklington certificate after
    factoring n-1. Returned factors are recursively certified the same way.
    """
    if n < PSI12:
        return mr_screen(n,MR12)
    if n < PSI13:
        return mr_screen(n,MR13)
    if not mr_screen(n,MR13): return False
    fs=raw_coreutils_factors(n-1)
    uniq=sorted(set(fs))
    for q in uniq:
        if not prime_certified(q):
            raise RuntimeError(f'could not certify factor {q} of {n}-1')
    # Full factorization means F=n-1 > sqrt(n), so Pocklington applies.
    for q in uniq:
        found=False
        for a in range(2,200):
            if pow(a,n-1,n)!=1: continue
            if math.gcd(pow(a,(n-1)//q,n)-1,n)==1:
                found=True; break
        if not found:
            return False
    return True

def nextprime(n:int)->int:
    if n<=2:return 2
    x=n if n&1 else n+1
    while True:
        if x>U64_MAX:
            raise RuntimeError(f'prime search exceeds 2^64-1: {x}')
        if prime_certified(x): return x
        x+=2

def bound_holds(x:int,num:int,den:int,t:int)->bool:
    # (x/(x-1))^t > num/den, exact integer cross multiplication.
    return pow(x,t)*den > pow(x-1,t)*num

def exact_max_bound(num:int,den:int,t:int,lower:int)->int:
    if num<=den or den<=0:return lower-1
    lower=max(lower,2)
    if not bound_holds(lower,num,den,t):return lower-1
    lo=lower; hi=max(4,2*lo)
    while bound_holds(hi,num,den,t):
        lo=hi; hi*=2
        if hi>U64_MAX:
            raise RuntimeError(f'ratio prime bound exceeds 2^64-1; lower witness {lo}')
    while hi-lo>1:
        mid=(lo+hi)//2
        if bound_holds(mid,num,den,t):lo=mid
        else:hi=mid
    return lo

def overlap_can_finish(Hp:int,H:int,r:int,s:int)->bool:
    if H%Hp:return False
    rem=s-r
    # Every newly adjoined odd prime contributes at least one additional
    # factor 2 to phi/lambda once a first prime is present.
    if r>=1 and H//Hp < (1<<rem):return False
    return True

def divisors_from_prime_factors(fs:List[int])->List[int]:
    expo=[]
    for p in fs:
        if expo and expo[-1][0]==p: expo[-1][1]+=1
        else: expo.append([p,1])
    ds=[1]
    for p,e in expo:
        base=list(ds); pe=1
        for _ in range(e):
            pe*=p
            ds += [d*pe for d in base]
    return ds

def coreutils_factor_batch(vals:List[int])->List[List[int]]:
    """Untrusted factor backend, followed by independent reconstruction and primality certification.

    SymPy factorint is used because a few ~100-bit auxiliary integers are slow
    for GNU coreutils factor.  Correctness does not rely on SymPy primality:
    every returned factor is independently certified below.
    """
    ans=[]
    for n in vals:
        fd=sp.factorint(n)
        fs=[]
        for f,e in sorted(fd.items()):
            f=int(f); e=int(e)
            if not prime_certified(f):
                raise RuntimeError(f'factor backend returned nonprime factor {f} for {n}')
            fs.extend([f]*e)
        z=1
        for f in fs: z*=f
        if z!=n: raise RuntimeError(f'factor reconstruction failed for {n}')
        ans.append(fs)
    return ans

@dataclass
class Prefix:
    m:int; s:int; H:int; primes:Tuple[int,...]; A:int; B:int; lam:int; Hp:int
    a:int; b:int; D:int; T:int; lower_u:int

class Certifier:
    def __init__(self,batch_size=10000):
        self.batch_size=batch_size; self.batch:List[Prefix]=[]
        self.solutions={}; self.prefixes={}; self.factor_prefixes={}; self.divpairs=0
        self.max_ratio_bound=0; self.max_prime_test=0; self.max_factor=0; self.factor_calls=0
        self.start=time.time()
    def prime(self,n:int)->bool:
        self.max_prime_test=max(self.max_prime_test,n)
        return prime_certified(n)
    def add_prefix(self,P:Prefix):
        self.prefixes[P.m]=self.prefixes.get(P.m,0)+1
        if P.lower_u >= math.isqrt(P.T): return
        self.factor_prefixes[P.m]=self.factor_prefixes.get(P.m,0)+1
        self.batch.append(P)
        if len(self.batch)>=self.batch_size:self.flush()
    def flush(self):
        if not self.batch:return
        vals=[P.T for P in self.batch]
        fact=coreutils_factor_batch(vals); self.factor_calls+=1
        for P,fs in zip(self.batch,fact):
            if fs:self.max_factor=max(self.max_factor,max(fs))
            ds=divisors_from_prime_factors(fs)
            rt=math.isqrt(P.T)
            for u in ds:
                if u<=P.lower_u or u>=rt: continue
                v=P.T//u
                if u>=v:continue
                if (u+P.a)%P.D or (v+P.a)%P.D:continue
                x=(u+P.a)//P.D; y=(v+P.a)//P.D
                if not(P.primes[-1] < x < y):continue
                self.divpairs+=1
                if not self.prime(x) or not self.prime(y):continue
                lam2=math.lcm(P.lam,x-1,y-1)
                phi=P.A*(x-1)*(y-1)
                if phi != P.H*lam2:continue
                n=P.B*x*y
                if (n-1)%lam2:continue
                if (n-1)//lam2 != P.m:continue
                # Redundant Korselt check, useful for auditing.
                full=P.primes+(x,y)
                if any((n-1)%(p-1) for p in full):continue
                self.solutions.setdefault(P.m,set()).add(n)
        self.batch=[]
    def run_branch(self,m:int,s:int,H:int,prefix_exact:Tuple[int,...]=(),p1_min:int=0,p1_max:int=0,p2_min:int=0,p2_max:int=0,p3_min:int=0,p3_max:int=0,p4_min:int=0,p4_max:int=0):
        cur=[]
        def dfs(A:int,B:int,lam:int,Hp:int):
            r=len(cur)
            if not overlap_can_finish(Hp,H,r,s):return
            if r==s-2:
                a=m*A; b=H*B; D=a-b
                if D<=0:return
                # For kappa=P=1, the last-two-prime equation is
                # (D*x-a)(D*y-a)=T with T=a(b-H)+bH.
                T=a*(b-H)+b*H
                if T<=0:return
                lower=max(0,D*cur[-1]-a)
                self.add_prefix(Prefix(m,s,H,tuple(cur),A,B,lam,Hp,a,b,D,T,lower))
                return
            num=m*A; den=H*B
            if num<=den:return
            lp=2 if r==0 else cur[-1]
            mx=exact_max_bound(num,den,s-r,lp+1)
            self.max_ratio_bound=max(self.max_ratio_bound,mx)
            if mx<=lp:return
            p=nextprime(lp+1)
            while p<=mx:
                if r < len(prefix_exact) and p != prefix_exact[r]:
                    p=nextprime(p+1); continue
                if r==0 and ((p1_min and p<p1_min) or (p1_max and p>p1_max)):
                    p=nextprime(p+1); continue
                if r==1 and ((p2_min and p<p2_min) or (p2_max and p>p2_max)):
                    p=nextprime(p+1); continue
                if r==2 and ((p3_min and p<p3_min) or (p3_max and p>p3_max)):
                    p=nextprime(p+1); continue
                if r==3 and ((p4_min and p<p4_min) or (p4_max and p>p4_max)):
                    p=nextprime(p+1); continue
                self.max_prime_test=max(self.max_prime_test,p)
                lf=p-1
                if r==0:
                    ln=lf; Hn=1
                else:
                    g=math.gcd(lam,lf); budget=H//Hp
                    if budget%g:
                        p=nextprime(p+1); continue
                    ln=math.lcm(lam,lf); Hn=Hp*g
                cur.append(p)
                if overlap_can_finish(Hn,H,r+1,s):dfs(A*(p-1),B*p,ln,Hn)
                cur.pop(); p=nextprime(p+1)
        dfs(1,1,1,1)
    def run_m(self,m:int,s_exact:int=0,s_min:int=0,s_max_filter:int=0,H_exact:int=0,prefix_exact:Tuple[int,...]=(),p1_min:int=0,p1_max:int=0,p2_min:int=0,p2_max:int=0,p3_min:int=0,p3_max:int=0,p4_min:int=0,p4_max:int=0):
        t=time.time(); b=0
        smax=(m-1).bit_length()
        for s in range(3,smax+1):
            if s_exact and s!=s_exact: continue
            if s_min and s<s_min: continue
            if s_max_filter and s>s_max_filter: continue
            h0=1<<(s-1)
            for H in range(h0,m,h0):
                if H_exact and H!=H_exact: continue
                b+=1; self.run_branch(m,s,H,prefix_exact,p1_min,p1_max,p2_min,p2_max,p3_min,p3_max,p4_min,p4_max)
        self.flush()
        sols=sorted(self.solutions.get(m,set()))
        print(f'd={m} branches={b} prefixes={self.prefixes.get(m,0)} factor_prefixes={self.factor_prefixes.get(m,0)} solutions={sols} sec={time.time()-t:.3f}',flush=True)
        return sols,b

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--start',type=int,default=34);ap.add_argument('--stop',type=int,default=64)
    ap.add_argument('--batch-size',type=int,default=10000)
    ap.add_argument('--s-exact',type=int,default=0); ap.add_argument('--s-min',type=int,default=0); ap.add_argument('--s-max',type=int,default=0); ap.add_argument('--H-exact',type=int,default=0); ap.add_argument('--prefix',default='',help='comma-separated exact initial primes for a split certificate run')
    ap.add_argument('--p1-min',type=int,default=0); ap.add_argument('--p1-max',type=int,default=0); ap.add_argument('--p2-min',type=int,default=0); ap.add_argument('--p2-max',type=int,default=0); ap.add_argument('--p3-min',type=int,default=0); ap.add_argument('--p3-max',type=int,default=0); ap.add_argument('--p4-min',type=int,default=0); ap.add_argument('--p4-max',type=int,default=0)
    ap.add_argument('--expected',default='')
    args=ap.parse_args()
    print('kappa=1 independent prescribed-index certificate')
    print('factor_backend=SymPy factorint (untrusted); factors are reconstructed and independently certified (MR12/MR13 below the Sorenson-Webster thresholds, recursive Pocklington above)')
    print('Sorenson-Webster psi12=',PSI12,'psi13=',PSI13)
    C=Certifier(args.batch_size); allrows=[]
    expected={}
    if args.expected:
        with open(args.expected) as f:
            next(f)
            for line in f:
                d,s=line.rstrip('\n').split('\t',1)
                expected[int(d)]=[] if not s else [int(x) for x in s.split(',')]
    print('filters', 's_exact='+str(args.s_exact), 's_min='+str(args.s_min), 's_max='+str(args.s_max), 'H_exact='+str(args.H_exact), 'prefix='+str(args.prefix or '-'), 'p1='+str((args.p1_min,args.p1_max)), 'p2='+str((args.p2_min,args.p2_max)), 'p3='+str((args.p3_min,args.p3_max)), 'p4='+str((args.p4_min,args.p4_max)))
    for m in range(args.start,args.stop+1):
        pref=tuple(int(x) for x in args.prefix.split(',') if x)
        sols,b=C.run_m(m,args.s_exact,args.s_min,args.s_max,args.H_exact,pref,args.p1_min,args.p1_max,args.p2_min,args.p2_max,args.p3_min,args.p3_max,args.p4_min,args.p4_max); allrows.append((m,sols))
        if expected and not (args.s_exact or args.s_min or args.s_max or args.H_exact or args.prefix or args.p1_min or args.p1_max or args.p2_min or args.p2_max or args.p3_min or args.p3_max or args.p4_min or args.p4_max) and sols!=expected.get(m,[]):
            raise RuntimeError(f'expected mismatch at d={m}: got {sols}, expected {expected.get(m,[])}')
    C.flush()
    print('SUMMARY')
    print('range',args.start,args.stop)
    print('total_prefixes',sum(C.prefixes.values()))
    print('total_factor_prefixes',sum(C.factor_prefixes.values()))
    print('divisor_pair_candidates',C.divpairs)
    print('max_ratio_prime_bound',C.max_ratio_bound)
    print('max_primality_input',C.max_prime_test)
    print('max_returned_factor',C.max_factor)
    print('sorenson_webster_psi12',PSI12)
    print('sorenson_webster_psi13',PSI13)
    print('overflow = false')
    print('factor_certificate_abort = false')
    print('expected_table_match =',bool(expected) and not (args.s_exact or args.s_min or args.s_max or args.H_exact or args.prefix or args.p1_min or args.p1_max or args.p2_min or args.p2_max or args.p3_min or args.p3_max or args.p4_min or args.p4_max))
    print('elapsed_sec',f'{time.time()-C.start:.3f}')
    for m,sols in allrows: print(f'{m}\t'+','.join(map(str,sols)))

if __name__=='__main__':main()
