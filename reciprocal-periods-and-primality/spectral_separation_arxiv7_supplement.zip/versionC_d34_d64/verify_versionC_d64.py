#!/usr/bin/env python3
"""Independent arithmetic verification of the versionC d<=64 table."""
import json, math
from pathlib import Path
from sympy import factorint
ROOT=Path(__file__).resolve().parent
stats=json.loads((ROOT/'combined_d1_64.json').read_text())

def lcm(a,b): return a//math.gcd(a,b)*b

def carmichael_from_factorization(f):
    z=1
    for p,a in f.items():
        if p==2 and a>=3: local=2**(a-2)
        else: local=(p-1)*p**(a-1)
        z=lcm(z,int(local))
    return z

inc=0; distinct=set(); bad=[]
for ds,row in stats.items():
    d=int(ds)
    for n in row['vals']:
        inc += 1; distinct.add(n)
        f=factorint(n)
        if len(f)==1 and next(iter(f.values()))==1: bad.append((d,n,'prime'))
        lam=carmichael_from_factorization(f)
        if (n-1)%d or lam%((n-1)//d): bad.append((d,n,'spectral'))
print('incidences',inc)
print('distinct',len(distinct))
print('bad',bad)
assert inc==351 and len(distinct)==234 and not bad
print('PASS')
