Four OEIS-candidate sequences certified through spectral index d=64.

1. oeis_d64/oeis_inclusive_spectral_list_d64.txt
   351 terms: concatenate E(1),...,E(64), sorting each row; inherited repetitions retained.
2. oeis_d64/oeis_genuine_spectral_list_d64.txt
   234 terms: concatenate only first/genuine appearances; every odd composite appears once.
3. oeis_d64/oeis_inclusive_counts_e_d64.txt
   64 terms: e(d)=|E(d)|, d=1,...,64.
4. oeis_d64/oeis_genuine_counts_g_d64.txt
   64 terms: g(d)=|G(d)|, d=1,...,64.

The canonical row data are also in versionC_d34_d64/combined_d1_64.json.
All classifications are exact in n; no numerical cutoff on n is used.
