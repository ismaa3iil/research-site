RECIPROCAL PERIODS AND PRIMALITY — EXTENDED ARXIV REPRODUCIBILITY SUPPLEMENT
(incorporating the journal Version C certificates)
================================================================================

Scope
-----
This frozen supplement supports the certified inclusive composite classification
for every 1 <= d <= 64, with no imposed upper cutoff on n, together with the
exact prime-mass computation through D=64.

The computational proof has two historical layers:

  * legacy_d33/ contains the original Julia machinery used for the certified
    range through d=33 and the specialized d=33 transition calculation.
  * versionC_d34_d64/ contains the new extension through d=64, including the
    independent kappa=1 prescribed-index certificate requested by the referee,
    the kappa>1 C++ search, the special d=49 last-two-prime certificate, the
    combined d<=64 data, and independent verifiers.

The d=33 files are retained only as provenance for the earlier part of the
classification.  All current range-level statements, combined tables, rarity
statistics, and prime-mass computations in this extended arXiv version extend through d=64.

A. Independent kappa=1 prescribed-index certification
------------------------------------------------------
Source:
  versionC_d34_d64/certify_kappa1_d34_d64.py

This program independently exhausts the squarefree Carmichael stratum

    n - 1 = d * lambda(n)

for 34 <= d <= 64.  It implements the finite prescribed-index ratio recursion
and the manuscript's last-two-prime divisor-pair completion.  Pinch's published
table is NOT used as a search input; it is retained only as an external
cross-check in:

  versionC_d34_d64/outputs/kappa1_pinch_crosscheck_d34_d64.tsv

Factorization is treated as an untrusted backend.  Returned factors are
reconstructed and independently primality-certified.  Below the
Sorenson-Webster psi_12 threshold the first twelve prime Miller-Rabin bases are
used; below psi_13 the first thirteen are used; above psi_13 the code falls
back to a recursive Pocklington certificate after exact factorization of n-1.

The two expensive empty indices are certified by exact, non-overlapping split
runs:

  d=34: 15 (s,H) branches; 344,284 last-two-prime prefixes;
        max exact ratio-prime bound 2,140,591; no solution.

  d=35: 15 (s,H) branches; 381,524 last-two-prime prefixes;
        max exact ratio-prime bound 7,296,343; no solution.

The verifier

  versionC_d34_d64/verify_kappa1_split_logs.py

checks the exact coverage totals and all abort/overflow flags.  Captured whole-
range logs for d=36..48 and d=49..64 reproduce Pinch's entries exactly.
The independently nonempty kappa=1 indices in 34..64 are

  37, 39, 43, 44, 45, 47, 48, 49, 50, 52, 53, 54, 55, 60, 61.

In particular, index 49 includes 1208361237478669.

Historical split-log banner note:
Some d=34 and d=35 split logs were captured immediately before a cosmetic
banner correction and say "factor_backend=GNU coreutils factor".  The source
version that generated those logs already called sympy.factorint; every factor
was in any case reconstructed and independently certified.  The exact source
corresponding to those captured logs is retained as

  versionC_d34_d64/certify_kappa1_d34_d64_log_version.py

and the final corrected program is certify_kappa1_d34_d64.py.

B. kappa>1 and prime-power strata, d=34..64
--------------------------------------------
Sources:
  versionC_d34_d64/search_versionC_filtered.cpp
  versionC_d34_d64/search_versionC_filtered2.cpp

The C++ extension now uses the first twelve prime bases

  2,3,5,7,11,13,17,19,23,29,31,37

for deterministic Miller-Rabin primality decisions in its certified 64-bit
candidate domain, justified by Sorenson-Webster.  Exact branch algebra is not
silently truncated: each recorded index prints the maximum recursive prime
bound, maximum primality-test input, and overflow=false.  If an exact branch
would require a prime outside the certified candidate domain, the program is
designed to abort rather than convert it to a probable-prime decision.

Captured logs:
  versionC_d34_d64/logs/cpp/cpp_d34_48_kappagt1.log
  versionC_d34_d64/logs/cpp/cpp_d50_54_kappagt1.log
  versionC_d34_d64/logs/cpp/cpp_d55_59_kappagt1.log
  versionC_d34_d64/logs/cpp/cpp_d60_64_kappagt1.log

The prime-power stratum is recorded in:
  versionC_d34_d64/outputs/primepowers_d34_d64.tsv

The combined kappa>1 output is:
  versionC_d34_d64/outputs/kappagt1_d34_d64_results.tsv

C. Special d=49 branch
----------------------
The difficult branch

    (d,s,kappa,H,P) = (49,5,3,16,1)

is handled by the exact last-two-prime divisor-pair program

  versionC_d34_d64/d49_p1_twoprime_certified.py

It exhausts exactly 49,496 three-prime prefixes and finds no additional
solution.  The remaining d=49 strata are captured in logs/d49/ and outputs/.

D. Combined d<=64 arithmetic verification
------------------------------------------
Combined data:
  versionC_d34_d64/combined_d1_64.json
  versionC_d34_d64/outputs/combined_d1_64.json

Verifier:
  versionC_d34_d64/verify_versionC_d64.py

Expected final verifier output:

  incidences 351
  distinct 234
  bad []
  PASS

The verifier factors all 234 distinct composites, recomputes Carmichael's
lambda-function, and checks every incidence condition and first-occurrence
count encoded in the combined data.

E. Exact prime-mass computation through D=64
---------------------------------------------
Source:
  prime_mass_d64_check_exact.py

Captured log:
  prime_mass_d64_check_exact_final.log

Figure:
  prime_mass_cumulative_d64_versionC.png (proof-certificate copy)

The exact calculation evaluates all 2^18-1 = 262,143 relevant nonempty
squarefree kernels, certifies kernel 2 as the unique minimizer, verifies the
q>=67 tail certificate, and obtains

  G_64 = 0.9845291459538847133627846309104729...
  M_2(64) = 0.9827091606818653790657857435100441...

The plotted lower curve is M_2(D).  Only its endpoint D=64 is asserted in the
paper to be the proven global minimum over the admissible non-perfect-power
bases.

F. Minimal verification commands
---------------------------------
From the supplement directory:

  python versionC_d34_d64/verify_versionC_d64.py
  python versionC_d34_d64/verify_kappa1_split_logs.py
  python prime_mass_d64_check_exact.py

To inspect the independent kappa=1 command-line options:

  python versionC_d34_d64/certify_kappa1_d34_d64.py --help

The captured whole-range kappa=1 logs for d=36..64 and split logs for d=34,35
are included so that the expensive searches need not be rerun merely to audit
the submitted certificate.

G. Archival status
------------------
SHA256SUMS_ARXIV7.txt hashes every file in this frozen supplement except the manifest itself.  This exact archive is intended to be deposited unchanged in
Zenodo or an institutional repository.  The manuscript contains the placeholder
[SUPPLEMENT-DOI]; that placeholder must be replaced by the repository DOI after
deposition and before final publication.  The DOI is therefore the only
acceptance item that cannot be completed inside this local reproducibility
package.


H. Extended-arXiv-only low-omega experiment
--------------------------------------------
The long arXiv article retains an exploratory calculation that is deliberately
separate from the proof-critical classification:

  low_omega_spectrum_experiment_arxiv7.py
  low_omega_spectrum_experiment_arxiv7.log

Before extending to d=500, the script validates every omega<=3 incidence
against the complete certified d<=64 table.  The retained captured output
begins

  VALIDATION d<=64: PASS

and records that the omega<=3 strata account for 320 of the 351 certified
incidences through d=64.  This experiment is not used in any completeness
proof or theorem beyond the certified range.

I. OEIS candidate data through d=64
-----------------------------------
The long arXiv article also retains four machine-readable candidate sequences
under oeis_d64/:

  oeis_inclusive_spectral_list_d64.txt   (351 terms)
  oeis_genuine_spectral_list_d64.txt     (234 terms)
  oeis_inclusive_counts_e_d64.txt        (64 terms)
  oeis_genuine_counts_g_d64.txt          (64 terms)

OEIS_D64_README.txt documents their interpretation.  The canonical row data
for all four are versionC_d34_d64/combined_d1_64.json; no d<=33 truncation is
used in these arXiv tables or sequence prefixes.

J. Extended-arXiv figures
-------------------------
The arXiv-only composite-rarity and prime-mass graphics are included as

  composite_rarity_cumulative_d64_arxiv7.png
  prime_mass_cumulative_d64_arxiv7.png

Both extend through D=64.  As in the manuscript, the lower prime-mass curve is
M_2(D); only its D=64 endpoint is asserted to be the proven global minimum over
positive non-perfect-power bases.

K. Fresh-rerun packaging check
------------------------------
For this arXiv archive the specialized d=49 certificate was rerun from the
packaged source after changing its module import from the obsolete historical
name search_versionB to the shipped twelve-base reference module
search_reference_python.  The fresh run again exhausted 49,496 prefixes and
returned solutions [].  Its output is

  versionC_d34_d64/logs/d49/d49_certified_arxiv7.log

The combined verifier, split-log verifier, D=64 prime-mass computation, and
low-omega d<=64 validation were also rerun from this merged archive; fresh
logs with the arxiv7 suffix are included where appropriate.
