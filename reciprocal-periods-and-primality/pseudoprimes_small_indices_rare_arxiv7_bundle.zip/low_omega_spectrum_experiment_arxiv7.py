#!/usr/bin/env python3
"""Exploratory exact enumeration of the omega<=3 spectral strata.

This is independent of the proof-critical Julia classification.  It implements
only the exact formulas proved in the manuscript: prime-power inheritance and
the two-prime divisor-pair completion identity.  Every candidate is finally
rechecked from n, d and Carmichael lambda(n).
"""
from functools import lru_cache
from math import lcm
from statistics import mean
from sympy import primerange, divisors, isprime, factorint

@lru_cache(None)
def divs(n: int):
    return tuple(divisors(n))

def lambda_from_P_primes(P, primes):
    vals=[]
    for p in primes:
        t=P; e=0
        while t%p==0:
            e+=1; t//=p
        vals.append((p**e)*(p-1))
    z=1
    for v in vals:
        z=lcm(z,v)
    return z

def valid_candidate(d,P,primes):
    t=P
    for p in primes:
        while t%p==0:
            t//=p
    if t!=1:
        return False
    n=P
    for p in primes:
        n*=p
    if (n-1)%d:
        return False
    L=(n-1)//d
    return lambda_from_P_primes(P,primes)%L==0

def e1_set(d):
    out=set()
    # R_a(p)>=p+1 and R_a(p)|d, so p<d.
    for p in primerange(3,d):
        R=1+p
        a=2
        while R<=d:
            if d%R==0 and (p-1)%(d//R)==0:
                out.add(p**a)
            a+=1
            R=R*p+1
    return out

def e2_set(d):
    out=set()
    # s=2 => j is even and P | j/2.
    for j in range(2,d,2):
        for P in divs(j//2):
            c=j//P
            Delta=d-j
            T=c*(d*(P-1)+j)
            for u in divs(T):
                v=T//u
                if u>=v:
                    continue
                if (u+d)%Delta or (v+d)%Delta:
                    continue
                p=(u+d)//Delta; q=(v+d)//Delta
                if p<3 or p>=q or not isprime(p) or not isprime(q):
                    continue
                if valid_candidate(d,P,(p,q)):
                    out.add(P*p*q)
    return out

def e3_set(d):
    out=set()
    # s=3 => j is divisible by 4 and P | j/4.
    for j in range(4,d,4):
        for P in divs(j//4):
            c=j//P
            # p1 < (d+2j)/(d-j), strict.
            pmax=(d+2*j-1)//(d-j)
            for p in primerange(3,pmax+1):
                a=d*(p-1); b=j*p; Delta=a-b
                if Delta<=0:
                    continue
                T=a*(b-c)+b*c
                for u in divs(T):
                    v=T//u
                    if u>=v:
                        continue
                    if (u+a)%Delta or (v+a)%Delta:
                        continue
                    q=(u+a)//Delta; r=(v+a)//Delta
                    if not (p<q<r) or not isprime(q) or not isprime(r):
                        continue
                    if valid_candidate(d,P,(p,q,r)):
                        out.add(P*p*q*r)
    return out

EXPECTED={
1:[],
2:[],
3:[],
4:[9],
5:[6601],
6:[25],
7:[15, 561],
8:[9, 49],
9:[30889, 88561, 534061],
10:[21, 6601],
11:[45],
12:[25, 121],
13:[27, 126673, 1333333],
14:[15, 169, 561],
15:[91, 6601],
16:[33, 49, 65],
17:[35, 139231],
18:[289, 30889, 88561, 534061, 55462177, 8885251441, 42018333841],
19:[39, 153, 4371, 7107],
20:[21, 361, 3201, 6601],
21:[85, 8695, 10585, 26335, 9717247, 16666651, 37769887],
22:[45, 133, 2465],
23:[231, 645, 1105, 24013, 34133],
24:[25, 49, 121, 529],
25:[51, 6601, 15051, 11921001],
26:[27, 105, 126673, 1333333],
27:[55, 325, 3565, 30889, 88561, 534061],
28:[57, 169, 561],
29:[117, 175, 1045, 1447681, 2121061, 164424781],
30:[91, 841, 6601, 158401],
31:[63, 125, 435, 62745, 1154131, 2609581, 3936691, 5624641],
32:[33, 65, 385, 961, 12673, 12801],
33:[1047619, 2210671, 3494701, 15197491, 25158871, 93755971],
34:[35, 69, 341, 139231],
35:[561, 91001, 610051, 683761],
36:[145, 217, 289, 30889, 88561, 534061, 55462177, 8885251441, 42018333841],
37:[75, 17169, 33153, 45141, 62605, 2415953, 2929291, 11972017, 16894571, 67902031, 191834567],
38:[39, 77, 153, 1065, 1369, 4371, 7107, 13833, 1170401],
39:[703, 15211, 126673, 334153, 1333333],
40:[81, 361, 481, 3201, 6601, 460801, 1372801],
41:[165, 247, 2871, 8365, 73555, 184255, 9345541, 128950249],
42:[85, 169, 1681, 8695, 10585, 26335, 9717247, 16666651, 37769887],
43:[87, 259, 861, 22791, 52633, 69231, 82733],
44:[45, 133, 1849, 2465, 15841],
45:[91, 451, 8911, 88561, 534061, 3763801, 14245741],
46:[93, 185, 231, 369, 645, 1105, 24013, 34133],
47:[95, 1035, 2821, 4795, 204263, 223721, 308039, 559489, 38649041],
48:[49, 529, 1729, 2209, 52417],
49:[99, 87676681, 133861729, 161005573, 258844951, 1411040359, 3462426241, 7950140448251, 131097700645913, 798178197617711, 989473937059427, 1208361237478669],
50:[51, 301, 1001, 6601, 15051, 3679201, 11921001, 4199932801, 1353385637801],
51:[205, 32131, 139231],
52:[105, 833, 9361, 126673, 741937, 1333333, 206955841, 560630848961],
53:[425, 637, 3605, 8481, 55651, 3547291, 3984541, 43523707, 52519291, 260410837, 1271325841, 152674725071, 3916268927681],
54:[55, 325, 2809, 3565, 30889, 88561, 534061, 4169867689],
55:[111, 221, 1431, 6601, 15181, 100101, 689701, 1269621, 271794601, 568898551],
56:[57, 169, 225, 561, 25761, 376993],
57:[115, 343, 2737, 95761, 37883341, 713798461],
58:[117, 175, 1045, 2553, 80041, 1447681, 2121061, 8372881, 164424781],
59:[119, 1653, 1771, 42353741],
60:[121, 361, 841, 3481, 6601, 25201, 158401, 6840001],
61:[123, 245, 1221, 44409, 50997, 74665, 631351, 964411, 1102759, 940724555, 1962804565, 2417562005],
62:[63, 125, 435, 3721, 19345, 62745, 264121, 828073, 1154131, 2609581, 3936691, 5624641, 7697921],
63:[1891, 8695, 10585, 26335, 9717247, 16666651, 37769887],
64:[65, 129, 385, 961, 1281, 12673, 12801]
}
def validate_d64():
    for d in range(1,65):
        got={1:e1_set(d),2:e2_set(d),3:e3_set(d)}
        exp={1:set(),2:set(),3:set()}
        for n in EXPECTED[d]:
            w=len(factorint(n))
            if w<=3: exp[w].add(n)
        if got!=exp:
            raise AssertionError((d,got,exp))
    print('VALIDATION d<=64: PASS (all omega<=3 incidences match certified table)')

def block_stats(D=1000):
    rows=[]
    for d in range(2,D+1):
        a,b,c=len(e1_set(d)),len(e2_set(d)),len(e3_set(d))
        rows.append((d,a,b,c,a+b+c))
    blocks=[(2,100),(101,200),(201,500)]
    print('block\tmean e1\tmean e2\tmean e3\tmean e<=3')
    for lo,hi in blocks:
        z=[r for r in rows if lo<=r[0]<=min(hi,D)]
        if not z: continue
        print(f'{lo}-{min(hi,D)}\t{mean(r[1] for r in z):.6f}\t'
              f'{mean(r[2] for r in z):.6f}\t{mean(r[3] for r in z):.6f}\t'
              f'{mean(r[4] for r in z):.6f}')
    print('selected d: d e1 e2 e3 e<=3')
    for d in [33,50,100,200,300,500]:
        if d<=D:
            r=rows[d-2]
            print(*r)

if __name__=='__main__':
    validate_d64()
    block_stats(500)
