#!/usr/bin/env python3
"""Exact rational certification of cumulative near-primitive-root mass through d=64.

The calculation certifies the minimum over every positive non-perfect-power
integer base by reducing to its squarefree kernel g.  Kernels containing a
prime >=67 are excluded by a rigorous tail bound.  The remaining 2^18-1
kernels (primes <=61) are checked with exact integer arithmetic via a subset
zeta transform.  No floating-point arithmetic enters the minimization.
"""
from fractions import Fraction
from math import gcd
from decimal import Decimal, getcontext

DMAX=64
P=[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61]
N=1<<len(P)
TAIL_PRIME=67
TAIL_DEN=TAIL_PRIME*TAIL_PRIME-TAIL_PRIME-1 # 4421
ARTIN=Decimal('0.373955813619202288054728054346416415111629248606150042094742802')

def lcm(a,b): return a//gcd(a,b)*b

def factor_distinct(n):
    out=[]; t=n; p=2
    while p*p<=t:
        if t%p==0:
            out.append(p)
            while t%p==0:t//=p
        p=3 if p==2 else p+2
    if t>1:out.append(t)
    return out

def e_over_a(d):
    r=Fraction(1,d*d)
    for q in factor_distinct(d):
        r*=Fraction(q*q-1,q*q-q-1)
    return r

E=[e_over_a(d) for d in range(1,DMAX+1)]
G=sum(E,Fraction(0))
idx={p:i for i,p in enumerate(P)}
m=[p*p-p-1 for p in P]

def alpha(gmod4,d):
    d2=d & -d
    if gmod4==1:
        return Fraction(-1 if d2==1 else 1)
    if gmod4==2:
        if d2<4:return Fraction(0)
        if d2==4:return Fraction(-1,3)
        return Fraction(1)
    if gmod4==3:
        if d2==1:return Fraction(0)
        if d2==2:return Fraction(-1,3)
        return Fraction(1)
    raise ValueError

# For a fixed mod-4 class, correction mass is F(mask)*P_class(mask), where
# F(mask)=prod_{q in mask}(-1/(q^2-q-1)).  P_class(mask) is a multilinear
# polynomial.  Build it in coefficient form and evaluate at all masks by the
# subset zeta transform.
def build_zeta(gmod4):
    coeff=[Fraction(0) for _ in range(N)]
    for d,e in enumerate(E,1):
        a=alpha(gmod4,d)
        if not a: continue
        supp=[idx[q] for q in factor_distinct(d)]
        # prod_{q|d, q in kernel} (-m_q)
        # = prod_{q|d} [1 + x_q*(-m_q-1)]
        # Expand over subsets of supp.
        k=len(supp)
        for sm in range(1<<k):
            mask=0; mult=1
            for j,ii in enumerate(supp):
                if (sm>>j)&1:
                    mask |= 1<<ii
                    mult *= -(m[ii]+1)
            coeff[mask] += e*a*mult
    # one common denominator -> integer zeta transform
    L=1
    for c in coeff:L=lcm(L,c.denominator)
    z=[c.numerator*(L//c.denominator) for c in coeff]
    for i in range(len(P)):
        bit=1<<i
        for mask in range(N):
            if mask & bit:
                z[mask]+=z[mask^bit]
    return L,z

L1,Z1=build_zeta(1)
L2,Z2=build_zeta(2)
L3,Z3=build_zeta(3)

# denominator product, parity and g mod 4 for all masks
PROD=[1]*N; PAR=[0]*N; GMOD=[1]*N
for mask in range(1,N):
    bit=mask & -mask; i=bit.bit_length()-1; prev=mask^bit
    PROD[mask]=PROD[prev]*m[i]
    PAR[mask]=PAR[prev]^1
    GMOD[mask]=(GMOD[prev]*(P[i]%4))%4

def mass(mask):
    gm=GMOD[mask]
    L,Z=(L1,Z1) if gm==1 else ((L2,Z2) if gm==2 else (L3,Z3))
    sign=-1 if PAR[mask] else 1
    return G + Fraction(sign*Z[mask],L*PROD[mask])

R2=mass(1) # kernel {2}
assert G-R2 > G/Fraction(TAIL_DEN), 'tail certificate fails'
best=R2; bestmask=1
for mask in range(1,N):
    r=mass(mask)
    if r<best:
        best=r;bestmask=mask
assert bestmask==1 and best==R2

def kernel(mask): return '*'.join(str(P[i]) for i in range(len(P)) if mask>>i&1)
getcontext().prec=70
def dec(fr):return Decimal(fr.numerator)/Decimal(fr.denominator)
print('DMAX =',DMAX)
print('kernels checked exactly =',N-1)
print('minimizing squarefree kernel =',kernel(bestmask))
print('generic coefficient G/A =',dec(G))
print('minimum coefficient M/A =',dec(best))
print('tail certificate G-M2 > G/4421 =',G-R2 > G/Fraction(TAIL_DEN))
print('generic mass through 64 =',dec(G)*ARTIN)
print('minimum non-perfect-power mass through 64 =',dec(best)*ARTIN)
print('generic percent =',dec(G)*ARTIN*100)
print('minimum percent =',dec(best)*ARTIN*100)
